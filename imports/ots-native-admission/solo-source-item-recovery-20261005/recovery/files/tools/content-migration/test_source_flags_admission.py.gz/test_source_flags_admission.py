"""Small owning inverse fixtures, no full registry/current Native reads."""

import copy
import tempfile
import unittest
from pathlib import Path

import item_source_flags_admission as gate


def observation():
    return {
        "source_cut": "CANARY_47DF",
        "external_item_id": 200,
        "phase": "FRESH_CPP_PROTOBUF_THEN_FULL_ORDERED_XML_BEFORE_LUA",
        "prototype_message_sha256": "a" * 64,
        "xml_record_ordinal": 1,
        "xml_record_sha256": "b" * 64,
        "source_group": "ITEM_GROUP_NONE",
        "current_world_owner_pointers": [],
        "ordered_assignments": [],
        "parameter": {
            "kind": "FLAGS_READ_WRITE",
            "flags": dict.fromkeys(gate.FLAGS, False),
            "read_write": {
                "readable": False,
                "writeable": False,
                "max_text_length": 0,
                "write_once_external_item_id": 0,
            },
            "prototype_flag_presence": dict.fromkeys(gate.PRESENCE, False),
        },
    }


class OwningFlags(unittest.TestCase):
    def setUp(self):
        self.before = {
            "kind": "Item",
            "identity": {"family": "Item", "key": "i200", "revision": "r1"},
            "semantics": {
                "physical": {"state": "KNOWN", "value": {"weight": 20}},
                "source_presentation_observations": {
                    "state": "KNOWN",
                    "value": ["own-name"],
                },
            },
        }
        self.vector = [observation()]
        self.after, witness = gate.add_child(self.before, self.vector)
        self.other = {
            "kind": "Item",
            "identity": {"family": "Item", "key": "i901", "revision": "r1"},
            "semantics": {},
        }
        self.admission = {
            "qualified": {
                "i200": {
                    "identity": self.before["identity"],
                    "views": {"canonical": witness, "reference": witness},
                }
            },
            "_vectors": {"i200": self.vector},
            "documents": [
                {"role": "canonical", "record_count": 2},
                {"role": "reference", "record_count": 2},
            ],
            "outside_sha256": {
                r: gate.outside_digest([self.other], {"i200"})
                for r in ("canonical", "reference")
            },
        }

    def test_inverse_preserves_names_intermediate_and_known_native_both_views(self):
        gate.validate_observation(self.vector[0])
        for role in ("canonical", "reference"):
            self.assertEqual(
                gate.project_before([self.after, self.other], self.admission, role),
                [self.before, self.other],
            )
        self.assertIn(gate.FIELD, self.after["semantics"])

    def test_inside_outside_missing_duplicate_role_and_revision_negatives(self):
        changed = copy.deepcopy(self.after)
        changed["semantics"]["source_presentation_observations"] = {"state": "UNKNOWN"}
        with self.assertRaises(ValueError):
            gate.verify([changed, self.other], self.admission, "canonical")
        outside = copy.deepcopy(self.other)
        outside["kind"] = "Terrain"
        with self.assertRaises(ValueError):
            gate.verify([self.after, outside], self.admission, "reference")
        changed = copy.deepcopy(self.after)
        changed["identity"]["revision"] = "wrong"
        for records, role in [
            ([changed, self.other], "canonical"),
            ([self.other], "canonical"),
            ([self.after, self.after], "canonical"),
            ([self.after, self.other], "client"),
        ]:
            with self.assertRaises(ValueError):
                gate.verify(records, self.admission, role)

    def test_no_known_overwrite_protected_fullkey_and_raw_shape_negatives(self):
        with self.assertRaises(ValueError):
            gate.add_child(self.after, self.vector)
        protected = copy.deepcopy(self.before)
        protected["identity"]["key"] = "oteryn:item.tibia.i901"
        with self.assertRaises(ValueError):
            gate.add_child(protected, self.vector)
        for field, value in [
            ("prototype_message_sha256", "not-sha"),
            ("source_group", "BORROWED"),
            ("phase", "AFTER_LUA"),
        ]:
            row = observation()
            row[field] = value
            with self.assertRaises(ValueError):
                gate.validate_observation(row)
        row = observation()
        row["parameter"]["flags"]["movable"] = {"state": "KNOWN", "value": False}
        with self.assertRaises(ValueError):
            gate.validate_observation(row)
        row = observation()
        row["parameter"]["read_write"]["max_text_length"] = True
        with self.assertRaises(ValueError):
            gate.validate_observation(row)

    def test_absent_gate_known_rejects_and_placeholder_manifest_fails_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.assertEqual(
                gate.project_if_installed(root, [self.before], "canonical"),
                [self.before],
            )
            with self.assertRaises(ValueError):
                gate.project_if_installed(root, [self.after], "canonical")
            path = root / gate.PATH
            path.parent.mkdir(parents=True)
            path.write_bytes(b"{}")
            with self.assertRaisesRegex(ValueError, "FLAGS_GATE_DIGEST"):
                gate.load_gate(root)


if __name__ == "__main__":
    unittest.main()

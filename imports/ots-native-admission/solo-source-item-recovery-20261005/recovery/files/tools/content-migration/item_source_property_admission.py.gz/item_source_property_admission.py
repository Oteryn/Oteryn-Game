"""Closed Source11499 storage gate; legacy Artifact export remains held."""

import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path

PATH = (
    "imports/ots-native-admission/source-property-observations/property-admissions.json"
)
SHA256 = "d4ba1642b1719b96a45f4933a8ab11c816154197fa1bf11f81e0f0dd6dde13ce"
PREREQUISITES = "imports/ots-native-admission/source-property-observations/source-prerequisites.json"
PREREQUISITES_SHA = "7149b629990db20ee2d357c548a214f5c8dc6ec7bb3c892ab0981fe7a43ae67f"
CLASS = "imports/ots-native-admission/source-property-observations/original-source-class-registry.json"
CLASS_SHA = "bc33ac10473d2ee5530428f072766f534f9a6df0612cb3571aa86e971677961c"
SCALAR = "apps/game-server/src/content/source-scalar-registry.json"
SCALAR_SHA = "cd2a09643e275fad21c504d6df078708793fb0164faa7ac18e0fb28e837163e9"
FIELDS = ("source_class_observations", "source_scalar_observations")
UNKNOWN = {"state": "UNKNOWN"}
CUTS = {
    "CANARY_47DF": (
        "canary",
        "47dfd51f45280a59a1d3e50ba7edd573d7234446",
        "canary-47df",
    ),
    "CRYSTAL_FF7": (
        "crystalserver",
        "ff7ede593c69d4c658b382c97443e8155926924a",
        "crystal-ff7",
    ),
    "CRYSTAL_00CE": (
        "crystalserver",
        "00ce02a57ca5a12e48f32a3476e37471167e4c3f",
        "crystal-00ce",
    ),
}


def encoded(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(test, message):
    if not test:
        raise ValueError(message)


def pinned(root, relative, expected):
    require(
        ".." not in Path(relative).parts and not Path(relative).is_absolute(),
        "SOURCE_SAFE_PATH",
    )
    raw = (root / relative).read_bytes()
    require(sha(raw) == expected, "SOURCE_INPUT_DIGEST:" + relative)
    return json.loads(raw)


def appearance_payload(raw):
    values = []
    offset = 0
    for _ in range(2):
        value = 0
        for shift in range(0, 70, 7):
            require(offset < len(raw), "PROPERTY_PROTO_FRAME_TRUNCATED")
            byte = raw[offset]
            offset += 1
            value |= (byte & 127) << shift
            if byte < 128:
                break
        else:
            raise ValueError("PROPERTY_PROTO_FRAME_VARINT")
        values.append(value)
    require(
        values[0] == 10 and values[1] == len(raw) - offset,
        "PROPERTY_PROTO_FRAME_LENGTH",
    )
    return raw[offset:]


def load_gate(root, gate_path=None, prerequisites_path=None):
    root = Path(root)
    raw = (gate_path or root / PATH).read_bytes()
    require(sha(raw) == SHA256, "PROPERTY_CLOSED_GATE_DIGEST")
    gate = json.loads(raw)
    raw = (prerequisites_path or root / PREREQUISITES).read_bytes()
    require(sha(raw) == PREREQUISITES_SHA, "PROPERTY_PREREQUISITE_DIGEST")
    prerequisites = json.loads(raw)
    require(
        prerequisites["schema"]
        == "OTERYN_OWN_SOURCE_PROPERTIES_PORTABLE_PREREQUISITES/v1",
        "PROPERTY_PREREQUISITE_SCHEMA",
    )
    for relative, expected in prerequisites["source_input_sha256"].items():
        require(
            relative.startswith("imports/")
            and ".." not in Path(relative).parts
            and not Path(relative).is_absolute(),
            "SOURCE_SAFE_PATH",
        )
        require(
            sha((root / relative).read_bytes()) == expected, "PROPERTY_OWN_SOURCE_PIN"
        )
    classes = pinned(root, CLASS, CLASS_SHA)
    scalars = pinned(root, SCALAR, SCALAR_SHA)
    properties = {}
    for key, revisions in classes["targets"].items():
        require(len(revisions) == 1, "PROPERTY_OWN_REVISION")
        revision, values = next(iter(revisions.items()))
        properties[(key, revision)] = {FIELDS[0]: {"state": "KNOWN", "value": values}}
    for row in scalars["rows"]:
        tag = (row["target_key"], row["target_revision"])
        require(
            FIELDS[1] not in properties.setdefault(tag, {}), "PROPERTY_DUPLICATE_SCALAR"
        )
        properties[tag][FIELDS[1]] = {"state": "KNOWN", "value": row["observations"]}
    require(
        len(properties) == 11499
        and sum(FIELDS[0] in p for p in properties.values()) == 11465
        and sum(FIELDS[1] in p for p in properties.values()) == 1276,
        "PROPERTY_CLOSED_COHORT",
    )
    require(
        sum(len(p.get(FIELDS[0], {}).get("value", [])) for p in properties.values())
        == 22303
        and sum(len(p.get(FIELDS[1], {}).get("value", [])) for p in properties.values())
        == 2401,
        "PROPERTY_CLOSED_COUNTS",
    )
    bindings = {}
    for relative, expected in gate["own_bindings_sha256"].items():
        require(
            relative
            in (
                "imports/canary/bindings/items.json",
                "imports/crystalserver/bindings/items.json",
            ),
            "PROPERTY_BINDING_PATH",
        )
        for binding in pinned(root, relative, expected)["bindings"]:
            tag = (
                binding["source_key"],
                binding["source_revision"],
                binding["identity_namespace"],
                binding["external_id"],
                encoded(binding["target"]),
            )
            bindings.setdefault(tag, []).append(binding)
    wanted = {cut: {} for cut in CUTS}
    targets = {}
    for row in gate["qualified"]:
        identity = row["identity"]
        tag = (identity["key"], identity["revision"])
        require(
            identity["family"] == "Item"
            and identity["key"] != "oteryn:item.tibia.i901"
            and tag not in targets,
            "PROPERTY_FULL_IDENTITY",
        )
        require(row["children"] == properties.get(tag), "PROPERTY_EXACT_OWN_REGISTRY")
        require(set(row["views"]) == {"canonical", "reference"}, "PROPERTY_BOTH_VIEWS")
        witnesses = []
        for child in row["children"].values():
            for entry in child["value"]:
                provider, revision, _label = CUTS[entry["source_cut"]]
                identifier = entry["external_item_id"]
                require(
                    type(identifier) is int and 1 <= identifier <= 65535,
                    "PROPERTY_OWN_UINT16_ID",
                )
                witness = {
                    "source_cut": entry["source_cut"],
                    "source_key": f"oteryn:source.{provider}",
                    "source_revision": revision,
                    "identity_namespace": "ots/item_server_id",
                    "external_id": str(identifier),
                    "target": identity,
                }
                witnesses.append(witness)
                btag = (
                    witness["source_key"],
                    revision,
                    "ots/item_server_id",
                    str(identifier),
                    encoded(identity),
                )
                require(
                    len(bindings.get(btag, [])) == 1
                    and bindings[btag][0]["disposition"] == "EXACT",
                    "PROPERTY_EXACT_CURRENT_BINDING",
                )
                digest = entry.get("raw_record_sha256")
                own = wanted[entry["source_cut"]]
                if (
                    identifier in own
                    and digest is not None
                    and own[identifier] is not None
                ):
                    require(own[identifier] == digest, "PROPERTY_OWN_PROTO_CONSISTENT")
                if identifier not in own or digest is not None:
                    own[identifier] = digest
        require(witnesses == row["own_binding_witnesses"], "PROPERTY_OWN_WITNESSES")
        for view in row["views"].values():
            require(
                set(view["old_children"]) == set(FIELDS), "PROPERTY_COMPLEMENT_FENCES"
            )
        targets[tag] = row
    require(set(targets) == set(properties), "PROPERTY_COMPLETE_TARGETS")
    for cut, expected in wanted.items():
        _provider, revision, label = CUTS[cut]
        path = (
            root
            / f"imports/ots-source-evidence/upstream-items-source-first/protobuf/{label}-all-wire-records.jsonl.gz"
        )
        seen = {}
        with gzip.open(path, "rt") as stream:
            require(
                json.loads(next(stream))["source"]["revision"] == revision,
                "PROPERTY_OWN_PROTO_REVISION",
            )
            for line in stream:
                record = json.loads(line)
                if record["namespace"] != "object":
                    continue
                ids = [f[5] for f in record["wire"] if f[0] == 1 and f[1] == 0]
                if not set(ids).intersection(expected):
                    continue
                parents = [f for f in record["wire"] if f[0] == 3 and f[1] == 2]
                require(
                    record["field_number"] == 1
                    and record["wire_type"] == 2
                    and len(ids) == len(parents) == 1
                    and ids[0] not in seen,
                    "PROPERTY_OWN_LOADED_PROTO",
                )
                digest = sha(appearance_payload(bytes.fromhex(record["raw_hex"])))
                require(expected[ids[0]] in (None, digest), "PROPERTY_OWN_PROTO_RAW")
                seen[ids[0]] = digest
        require(set(seen) == set(expected), "PROPERTY_ALL_OWN_PROTO_LOADED")
    gate["_targets"] = targets
    return gate


def project_record(record, gate, role):
    require(role in ("canonical", "reference"), "PROPERTY_VIEW")
    if record["kind"] != "Item":
        return record
    identity = record["identity"]
    row = gate["_targets"].get((identity["key"], identity["revision"]))
    if row is None:
        require(
            all(record.get("semantics", {}).get(f, UNKNOWN) == UNKNOWN for f in FIELDS),
            "PROPERTY_UNREGISTERED_OBSERVATION",
        )
        return record
    require(identity == row["identity"], "PROPERTY_FULL_IDENTITY")
    view = row["views"][role]
    require(
        sha(encoded(record)) == view["after_record_sha256"], "PROPERTY_AFTER_PARENT"
    )
    result = copy.deepcopy(record)
    semantics = result.get("semantics", {})
    for field in FIELDS:
        old = view["old_children"][field]
        require(
            semantics.get(field, UNKNOWN) == row["children"].get(field, old["value"]),
            "PROPERTY_BOTH_DOMAIN_VALUES",
        )
        if old["present"]:
            semantics[field] = copy.deepcopy(old["value"])
        else:
            semantics.pop(field, None)
    require(
        sha(encoded(result)) == view["before_record_sha256"],
        "PROPERTY_ONLY_APPROVED_SIBLINGS",
    )
    return result


def project_before(records, gate, role):
    seen = set()
    result = []
    for record in records:
        if record["kind"] == "Item":
            tag = (record["identity"]["key"], record["identity"]["revision"])
            require(tag not in seen, "PROPERTY_DUPLICATE_IDENTITY")
            seen.add(tag)
        result.append(project_record(record, gate, role))
    require(set(gate["_targets"]) <= seen, "PROPERTY_COMPLETE_VIEW")
    return result


def verify(records, gate, role):
    project_before(records, gate, role)


def verify_repository(root):
    root = Path(root)
    gate = load_gate(root)
    canonical = []
    for path in sorted((root / "content/items/definitions").glob("items-*.json")):
        canonical.extend(
            r["definition"] for r in json.loads(path.read_bytes())["records"]
        )
    reference = json.loads(
        (root / "content/world/definitions/reference.json").read_bytes()
    )["records"]
    from item_source_class_expansion import load_gate as expansion_gate
    from item_source_class_expansion import project_before as expansion_before
    from item_source_combat_admission import PATH as combat_path
    from item_source_combat_admission import load_gate as combat_gate
    from item_source_combat_admission import project_before as combat_before
    from item_source_definition_admission import load_gate as definition_gate
    from item_source_definition_admission import project_before as definition_before
    from item_source_media_admission import load_gate as load_media_gate
    from item_source_media_admission import verify as verify_media

    combat = combat_gate(root) if (root / combat_path).exists() else None
    definition = definition_gate(root)
    expansion = expansion_gate(root)
    media = load_media_gate(root)
    from item_source_presentation_admission import project_if_installed as project_names

    for role, records in (("canonical", canonical), ("reference", reference)):
        records = project_names(root, records, role)
        if combat is not None:
            records = combat_before(records, combat, role)
        else:
            require(
                all(
                    row.get("semantics", {}).get(
                        "source_combat_observations", {"state": "UNKNOWN"}
                    )
                    == {"state": "UNKNOWN"}
                    for row in records
                    if row["kind"] == "Item"
                ),
                "SOURCE_COMBAT_WITHOUT_QUALIFIED_ADMISSION",
            )
        verify_media(
            project_before(
                expansion_before(
                    definition_before(records, definition, role), expansion, role
                ),
                gate,
                role,
            ),
            media,
            role,
        )
    return "PASS11499_SOURCE_PROPERTIES_BOTH_VIEWS_11465_CLASS_1276_SCALAR_V7_HELD"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    print(verify_repository(parser.parse_args().root))

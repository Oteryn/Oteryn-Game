"""Only closed Source flag_read_write children; preserve complete Native parents."""

import copy
import hashlib
import json

FIELD = "source_flag_read_write_observations"
UNKNOWN = {"state": "UNKNOWN"}
REGISTRY_SHA = "f9b0cae9b18722142c8afad2abb50ea7c453c604d6ec561b4265388d50fe5c2c"
REFERENCE_SHA = "7e730f2bf7fb3a4b85c2df702330605b32c9dc809bfbea763b3e23574a8f31bc"


def digest(value):
    return hashlib.sha256(
        (
            json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
            + "\n"
        ).encode()
    ).hexdigest()


def require(test, reason):
    if not test:
        raise ValueError(reason)


def add_child(record, vector):
    require(
        record["kind"] == "Item" and record["identity"]["family"] == "Item",
        "FLAGS_NONITEM",
    )
    require(record["identity"]["key"] != "oteryn:item.tibia.i901", "FLAGS_901")
    require(isinstance(record.get("semantics"), dict), "FLAGS_NO_PARENT")
    semantics = record["semantics"]
    require(semantics.get(FIELD, UNKNOWN) == UNKNOWN, "FLAGS_EXISTING_STATE_HOLD")
    require(1 <= len(vector) <= 2, "FLAGS_CUT_COUNT")
    require(
        len({v["source_cut"] for v in vector}) == len(vector),
        "FLAGS_DUPLICATE_CUT",
    )
    for observation in vector:
        validate_observation(observation)
    result = dict(record)
    result["semantics"] = {FIELD: {"state": "KNOWN", "value": vector}, **semantics}
    if FIELD in semantics:
        result["semantics"][FIELD] = {"state": "KNOWN", "value": vector}
    witness = {
        "field_present": FIELD in semantics,
        "before_sha256": digest(record),
        "after_sha256": digest(result),
    }
    require(
        inverse_record(result, vector, witness) == record,
        "FLAGS_FULL_PARENT_PRESERVATION",
    )
    return result, witness


def inverse_record(record, vector, witness):
    require(record["kind"] == "Item", "FLAGS_INVERSE_KIND")
    require(digest(record) == witness["after_sha256"], "FLAGS_FULL_AFTER_PARENT")
    require(
        record["semantics"].get(FIELD) == {"state": "KNOWN", "value": vector},
        "FLAGS_EXACT_VECTOR",
    )
    result = dict(record)
    result["semantics"] = dict(record["semantics"])
    if witness["field_present"]:
        result["semantics"][FIELD] = copy.deepcopy(UNKNOWN)
    else:
        del result["semantics"][FIELD]
    require(digest(result) == witness["before_sha256"], "FLAGS_FULL_BEFORE_PARENT")
    return result


FLAGS = (
    "show_count",
    "show_duration",
    "show_charges",
    "show_attributes",
    "movable",
    "pickupable",
    "block_projectile",
    "block_solid",
    "walk_stack",
    "replaceable",
    "distance_read",
    "usable_by_house_guests",
)
PRESENCE = ("unmove", "take", "unsight", "unpass", "write", "write_once")


def outside_digest(records, targets):
    return digest(
        {
            r["identity"]["key"]: digest(r)
            for r in records
            if r["identity"]["key"] not in targets
        }
    )


def validate_observation(row):
    require(
        set(row)
        == {
            "source_cut",
            "external_item_id",
            "phase",
            "prototype_message_sha256",
            "xml_record_ordinal",
            "xml_record_sha256",
            "source_group",
            "current_world_owner_pointers",
            "ordered_assignments",
            "parameter",
        },
        "FLAGS_HEADER_FIELDS",
    )
    require(
        row["phase"] == "FRESH_CPP_PROTOBUF_THEN_FULL_ORDERED_XML_BEFORE_LUA",
        "FLAGS_PHASE",
    )
    require(
        row["source_group"]
        in (
            "ITEM_GROUP_NONE",
            "ITEM_GROUP_GROUND",
            "ITEM_GROUP_CONTAINER",
            "ITEM_GROUP_SPLASH",
            "ITEM_GROUP_FLUID",
        ),
        "FLAGS_SOURCE_GROUP",
    )
    require(
        len(row["ordered_assignments"]) <= 3
        and len(row["current_world_owner_pointers"]) <= 1,
        "FLAGS_MEASURED_BOUNDS",
    )
    require(
        type(row["external_item_id"]) is int and 0 <= row["external_item_id"] <= 65535,
        "FLAGS_EXTERNAL_ID",
    )
    require(
        type(row["xml_record_ordinal"]) is int
        and 0 <= row["xml_record_ordinal"] <= 2**32 - 1,
        "FLAGS_XML_ORDINAL",
    )
    require(
        all(
            isinstance(row[k], str)
            and len(row[k]) == 64
            and all(c in "0123456789abcdef" for c in row[k])
            for k in ("prototype_message_sha256", "xml_record_sha256")
        ),
        "FLAGS_MESSAGE_XML_DIGEST",
    )
    for pointer in row["current_world_owner_pointers"]:
        require(
            set(pointer) == {"family", "key", "revision"}
            and pointer["family"] in ("Terrain", "WorldObject")
            and all(isinstance(v, str) and v for v in pointer.values()),
            "FLAGS_WORLD_FULL_IDENTITY",
        )
    ordinal = -1
    for assignment in row["ordered_assignments"]:
        require(
            set(assignment) == {"key", "value_lexeme", "attribute_ordinal"},
            "FLAGS_ASSIGNMENT_FIELDS",
        )
        require(
            assignment["key"]
            in (
                "showcount",
                "showduration",
                "showcharges",
                "showattributes",
                "movable",
                "allowpickupable",
                "pickupable",
                "blockprojectile",
                "blocking",
                "walkstack",
                "replaceable",
                "allowdistread",
                "usedbyhouseguests",
                "readable",
                "writeable",
                "maxtextlen",
                "writeonceitemid",
            ),
            "FLAGS_CPP_XML_KEY",
        )
        require(
            isinstance(assignment["value_lexeme"], str)
            and len(assignment["value_lexeme"].encode()) <= 4,
            "FLAGS_LEXEME_BOUND",
        )
        current = assignment["attribute_ordinal"]
        require(
            type(current) is int and ordinal < current <= 65535,
            "FLAGS_RAW_CAPTURE_ORDER",
        )
        ordinal = current
    p = row["parameter"]
    require(
        set(p) == {"kind", "flags", "read_write", "prototype_flag_presence"}
        and p["kind"] == "FLAGS_READ_WRITE",
        "FLAGS_PARAMETER_DOMAIN",
    )
    require(
        set(p["flags"]) == set(FLAGS)
        and set(p["prototype_flag_presence"]) == set(PRESENCE),
        "FLAGS_FIXED_PRIMITIVE_FIELDS",
    )
    rw = p["read_write"]
    require(
        set(rw)
        == {"readable", "writeable", "max_text_length", "write_once_external_item_id"},
        "FLAGS_READ_WRITE_FIELDS",
    )
    require(
        all(
            type(v) is bool
            for v in [
                *p["flags"].values(),
                *p["prototype_flag_presence"].values(),
                rw["readable"],
                rw["writeable"],
            ]
        ),
        "FLAGS_PRIMITIVE_BOOL",
    )
    require(
        all(
            type(rw[k]) is int and 0 <= rw[k] <= 65535
            for k in ("max_text_length", "write_once_external_item_id")
        ),
        "FLAGS_OWN_UINT16",
    )


PATH = "imports/ots-native-admission/source-flag-read-write-observations/flag-read-write-admissions.json.gz"
REGISTRY_PATH = "apps/game-server/src/content/source-flag-read-write-registry.json"
CONSUMER_PATH = "imports/ots-native-admission/source-flag-read-write-observations/consumer-manifest.json"
CONSUMER_SHA = "37310a45fd7fd567dc5e3baa6066e66e4554a642ae59ac473de4898387ac3a01"
PHASE_PATH = "imports/ots-native-admission/source-flag-read-write-observations/source-phase-qualification.json"
PHASE_SHA = "5e28444c0d48d3f5840ce8a49bc72955ab3c024a919fbccc5b29c39bd6149031"
GATE_SHA = "7a2345b98988ec78e158c7f3039f4d7b1e4fc1655046986a516c244a37c9354d"


def load_gate(root, gate_path=None, registry_path=None, consumer_path=None):
    import gzip
    from pathlib import Path

    root = Path(root)
    raw = (gate_path or root / PATH).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == GATE_SHA, "FLAGS_GATE_DIGEST")
    gate = json.loads(gzip.decompress(raw))
    registry_raw = (registry_path or root / REGISTRY_PATH).read_bytes()
    require(
        hashlib.sha256(registry_raw).hexdigest() == REGISTRY_SHA,
        "FLAGS_REGISTRY_DIGEST",
    )
    require(
        hashlib.sha256((consumer_path or root / CONSUMER_PATH).read_bytes()).hexdigest()
        == CONSUMER_SHA,
        "FLAGS_CONSUMER_DIGEST",
    )
    from flag_consumer_resources import verify_resources

    verify_resources(
        root, json.loads((consumer_path or root / CONSUMER_PATH).read_bytes())
    )
    phase_raw = (root / PHASE_PATH).read_bytes()
    require(
        hashlib.sha256(phase_raw).hexdigest() == PHASE_SHA, "FLAGS_SOURCE_PHASE_SEAL"
    )
    phase = json.loads(phase_raw)
    require(
        phase["status"] == "QUALIFIED_WHOLE_SOURCE_FLAGS_PHASE"
        and phase["targets"] == 33975
        and phase["observations"] == 45721
        and phase["Native_promotions"] == 0
        and phase["registry_sha256"] == REGISTRY_SHA
        and phase["actual_CPP_load_completed"] == "NOT_EXECUTED_UNKNOWN",
        "FLAGS_SOURCE_PHASE_SCOPE",
    )
    registry = json.loads(registry_raw)
    targets = registry["targets"]
    require(
        gate["schema"] == "OTERYN_SOURCE_FLAGS_ADMISSION_33975/v1"
        and registry["schema"] == "OTERYN_SOURCE_FLAGS_READ_WRITE_CLOSED/v1",
        "FLAGS_SCHEMA",
    )
    require(
        len(targets) == len(gate["qualified"]) == 33975
        and set(targets) == set(gate["qualified"]),
        "FLAGS_CLOSED_TARGETS",
    )
    bindings = {}
    for relative, expected in gate["source_binding_input_sha256"].items():
        require(
            relative.startswith("imports/") and ".." not in Path(relative).parts,
            "FLAGS_INPUT_PATH",
        )
        source_raw = (root / relative).read_bytes()
        require(
            hashlib.sha256(source_raw).hexdigest() == expected,
            "FLAGS_OWN_BINDING_PIN",
        )
        payload = json.loads(source_raw)
        for b in payload.get("bindings", []):
            own = (
                b["source_key"],
                b["source_revision"],
                b["identity_namespace"],
                b["external_id"],
            )
            require(own not in bindings, "FLAGS_AMBIGUOUS_BINDING")
            bindings[own] = b
    require(
        gate.get("phase_prerequisites", {}).get("conditional_receipt_sha256")
        == "ff9ef1952c39f2e8be42f76d2831c9aceaba74043db4023154ba38468c1a4db8"
        and gate["phase_prerequisites"].get("whole_run_freeze_sha256")
        == "f358afb2adbeda8631804c4c368b9d136dfc608e02c70cebd1286fa835d11b6a"
        and gate["phase_prerequisites"].get("phase_proof_sha256")
        == "63a2fb3f3f11418e4dde261bf99c28b82f1b5537ff781563de17bc853fb5f670"
        and gate["phase_prerequisites"].get("actual_CPP_execution")
        == "NOT_EXECUTED_UNKNOWN",
        "FLAGS_OWN_NORMAL_RETURN_PHASE",
    )
    observations = 0
    for key, row in gate["qualified"].items():
        revision = row["identity"]["revision"]
        require(
            row["identity"]["key"] == key
            and row["identity"]["family"] == "Item"
            and key != "oteryn:item.tibia.i901",
            "FLAGS_IDENTITY_OWNER",
        )
        require(
            set(targets[key]) == {revision}
            and set(row["views"]) == {"canonical", "reference"},
            "FLAGS_EXACT_REVISION_VIEWS",
        )
        vector = targets[key][revision]
        require(
            1 <= len(vector) <= 2
            and len({v["source_cut"] for v in vector}) == len(vector),
            "FLAGS_CUT_SCOPE",
        )
        for observation in vector:
            validate_observation(observation)
            cut = gate["source_cut_binding_tuples"][observation["source_cut"]]
            own = (
                cut["source_key"],
                cut["source_revision"],
                cut["identity_namespace"],
                str(observation["external_item_id"]),
            )
            b = bindings.get(own)
            require(
                b is not None
                and b["disposition"] == "EXACT"
                and b["target"] == {"family": "Item", "key": key, "revision": revision},
                "FLAGS_EXACT_OWN_SOURCE_TARGET",
            )
        observations += len(vector)
    require(observations == 45721, "FLAGS_OBSERVATION_COUNT")
    gate["_vectors"] = {
        key: targets[key][r["identity"]["revision"]]
        for key, r in gate["qualified"].items()
    }
    return gate


def verify(records, gate, role):
    require(role in ("canonical", "reference"), "FLAGS_VIEW")
    expected = sum(d["record_count"] for d in gate["documents"] if d["role"] == role)
    keys = [r["identity"]["key"] for r in records]
    require(len(keys) == len(set(keys)) == expected, "FLAGS_UNIVERSE")
    current = dict(zip(keys, records, strict=True))
    targets = gate["qualified"]
    require(
        outside_digest(records, targets) == gate["outside_sha256"][role],
        "FLAGS_WHOLE_OUTSIDE_COMPLEMENT",
    )
    require(set(targets) <= set(current), "FLAGS_MISSING_TARGET")
    for key, record in current.items():
        if key not in targets:
            require(
                record.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN,
                "FLAGS_UNDECLARED_CHILD",
            )
            continue
        row = targets[key]
        require(
            record["kind"] == "Item" and record["identity"] == row["identity"],
            "FLAGS_FULL_IDENTITY",
        )
        inverse_record(record, gate["_vectors"][key], row["views"][role])
    return {
        "targets": len(targets),
        "runtime_activation": False,
        "artifact_export": "HELD",
    }


def project_record(record, gate, role):
    require(role in ("canonical", "reference"), "FLAGS_VIEW")
    key = record["identity"]["key"]
    if key not in gate["qualified"]:
        require(
            record.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN,
            "FLAGS_UNDECLARED_CHILD",
        )
        return record
    row = gate["qualified"][key]
    require(record["identity"] == row["identity"], "FLAGS_FULL_IDENTITY")
    return inverse_record(record, gate["_vectors"][key], row["views"][role])


def project_before(records, gate, role):
    verify(records, gate, role)
    return [
        inverse_record(
            r,
            gate["_vectors"][r["identity"]["key"]],
            gate["qualified"][r["identity"]["key"]]["views"][role],
        )
        if r["identity"]["key"] in gate["qualified"]
        else r
        for r in records
    ]


def project_if_installed(root, records, role):
    from pathlib import Path

    root = Path(root)
    require(role in ("canonical", "reference"), "FLAGS_VIEW")
    if (root / PATH).exists():
        return project_before(records, load_gate(root), role)
    require(
        all(r.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN for r in records),
        "FLAGS_WITHOUT_QUALIFIED_ADMISSION",
    )
    return records


def verify_repository(root):
    from pathlib import Path

    root = Path(root)
    gate = load_gate(root)
    reference = json.loads(
        (root / "content/world/definitions/reference.json").read_bytes()
    )["records"]
    verify(reference, gate, "reference")
    del reference
    canonical = []
    for relative in json.loads((root / "content/items/index.json").read_bytes())[
        "shards"
    ]:
        canonical.extend(
            r["definition"]
            for r in json.loads((root / relative).read_bytes())["records"]
        )
    verify(canonical, gate, "canonical")
    return "PASS33975_SOURCE_FLAGS_BOTH_VIEWS_45721_OWN_OBSERVATIONS_EXPORT_HELD"


if __name__ == "__main__":
    import argparse
    from pathlib import Path

    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    print(verify_repository(parser.parse_args().root))

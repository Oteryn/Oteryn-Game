"""Portable closed Sourceclass expansion and historical inverse regression tests."""

import copy
import json
import sys
import unittest
from pathlib import Path

import item_source_class_expansion as expansion
import item_source_property_admission as historical
from item_source_media_admission import load_gate as media_load
from item_source_media_admission import verify as media_verify

ROOT = (
    Path(sys.argv.pop(1))
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-")
    else Path(__file__).resolve().parents[2]
)


class SourceClassExpansion(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gate = expansion.load_gate(ROOT)
        cls.historical = historical.load_gate(ROOT)
        cls.media = media_load(ROOT)
        cls.views = {
            "reference": json.loads(
                (ROOT / "content/world/definitions/reference.json").read_bytes()
            )["records"],
            "canonical": [
                row["definition"]
                for path in sorted(
                    (ROOT / "content/items/definitions").glob("items-*.json")
                )
                for row in json.loads(path.read_bytes())["records"]
            ],
        }
        from item_source_combat_admission import project_if_installed
        from item_source_definition_admission import load_gate as definition_gate
        from item_source_definition_admission import project_before as definition_before

        cls.views = {
            role: project_if_installed(ROOT, records, role)
            for role, records in cls.views.items()
        }
        definition = definition_gate(ROOT)
        cls.views = {
            role: definition_before(records, definition, role)
            for role, records in cls.views.items()
        }
        cls.items = {
            role: {
                (r["identity"]["key"], r["identity"]["revision"]): r
                for r in records
                if r["kind"] == "Item"
            }
            for role, records in cls.views.items()
        }

    def test_actual_complete_two_views_inverse_chain(self):
        self.assertEqual(sum(map(len, self.views.values())), 95217)
        self.assertEqual(len(self.gate["_targets"]), 22510)
        self.assertEqual(len(self.gate["_classes"]), 33975)
        for role, records in self.views.items():
            before = expansion.project_before(records, self.gate, role)
            media_verify(
                historical.project_before(before, self.historical, role),
                self.media,
                role,
            )

    def test_mutated_source_identity_and_native_siblings_rejected(self):
        tag = next(iter(self.gate["_targets"]))
        for role, items in self.items.items():
            for mutation in ("source", "raw", "revision", "weight", "scalar"):
                bad = copy.deepcopy(items[tag])
                child = bad["semantics"][expansion.FIELD]["value"][0]
                if mutation == "source":
                    child["source_cut"] = "FOREIGN"
                elif mutation == "raw":
                    child["raw_record_sha256"] = "0" * 64
                elif mutation == "revision":
                    bad["identity"]["revision"] = "wrong-r1"
                elif mutation == "weight":
                    bad["semantics"]["physical"] = {
                        "state": "KNOWN",
                        "value": {"weight": {"state": "KNOWN", "value": 999}},
                    }
                else:
                    bad["semantics"]["source_scalar_observations"] = {
                        "state": "CONFLICT"
                    }
                with (
                    self.subTest(role=role, mutation=mutation),
                    self.assertRaises(ValueError),
                ):
                    expansion.project_record(bad, self.gate, role)

    def test_sparse_unknowns_and_901_are_not_generic_projection(self):
        for role, items in self.items.items():
            tag = next(
                tag
                for tag, row in self.gate["_targets"].items()
                if row["views"][role]["added_unknown_outer_fields"]
            )
            bad = copy.deepcopy(items[tag])
            field = self.gate["_targets"][tag]["views"][role][
                "added_unknown_outer_fields"
            ][0]
            bad["semantics"][field] = {"state": "NOT_APPLICABLE"}
            with self.assertRaises(ValueError):
                expansion.project_record(bad, self.gate, role)
            protected = next(
                r for t, r in items.items() if t[0] == "oteryn:item.tibia.i901"
            )
            bad = copy.deepcopy(protected)
            bad.setdefault("semantics", {})[expansion.FIELD] = {
                "state": "KNOWN",
                "value": [],
            }
            with self.assertRaises(ValueError):
                expansion.project_record(bad, self.gate, role)

    def test_missing_and_duplicate_targets_fail_closed(self):
        for role, records in self.views.items():
            target = self.items[role][next(iter(self.gate["_targets"]))]
            with self.assertRaises(ValueError):
                expansion.project_before(records + [target], self.gate, role)
            with self.assertRaises(ValueError):
                expansion.project_before(
                    [r for r in records if r is not target], self.gate, role
                )


if __name__ == "__main__":
    unittest.main()

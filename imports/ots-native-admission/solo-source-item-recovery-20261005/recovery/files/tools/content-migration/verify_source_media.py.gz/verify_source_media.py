"""Portable repository readback; no writes, no runtime/asset completion claim."""

import argparse
import json
from pathlib import Path

from item_source_media_admission import load_gate, require, verify


def read_views(root, overlay=None):
    def load(relative):
        candidate = overlay / relative if overlay else None
        return json.loads(
            (
                candidate if candidate and candidate.exists() else root / relative
            ).read_bytes()
        )

    reference = load("content/world/definitions/reference.json")["records"]
    index = load("content/items/index.json")
    canonical = []
    for path in index["shards"]:
        shard = load(path)
        canonical.extend(row["definition"] for row in shard["records"])
    require(
        len(canonical) == index["record_count"] == 34032, "MEDIA_CANONICAL_ITEM_COUNT"
    )
    return {"canonical": canonical, "reference": reference}


def project_qualified_views(root, views):
    """Owning closed outer inverse chain before the unchanged Media gate."""
    from item_source_class_expansion import PATH as expansion_path
    from item_source_class_expansion import load_gate as load_expansion_gate
    from item_source_class_expansion import project_before as project_expansion
    from item_source_combat_admission import project_if_installed
    from item_source_definition_admission import PATH as definition_path
    from item_source_definition_admission import load_gate as load_definition_gate
    from item_source_definition_admission import project_before as project_definitions
    from item_source_property_admission import PATH as property_path
    from item_source_property_admission import load_gate as load_property_gate
    from item_source_property_admission import project_before as project_properties

    views = {
        role: project_if_installed(root, records, role)
        for role, records in views.items()
    }
    if (root / definition_path).exists():
        definition_gate = load_definition_gate(root)
        views = {
            role: project_definitions(records, definition_gate, role)
            for role, records in views.items()
        }
    else:
        require(
            all(
                row.get("semantics", {}).get(
                    "source_definition_observations", {"state": "UNKNOWN"}
                )
                == {"state": "UNKNOWN"}
                for records in views.values()
                for row in records
                if row["kind"] == "Item"
            ),
            "SOURCE_DEFINITION_WITHOUT_QUALIFIED_ADMISSION",
        )
    if (root / expansion_path).exists():
        expansion_gate = load_expansion_gate(root)
        views = {
            role: project_expansion(records, expansion_gate, role)
            for role, records in views.items()
        }
    if (root / property_path).exists():
        property_gate = load_property_gate(root)
        views = {
            role: project_properties(records, property_gate, role)
            for role, records in views.items()
        }
    return views


def run(root, gate_path=None, overlay=None, require_marker=True):
    gate = load_gate(root, gate_path)
    if require_marker:
        manifest = json.loads((root / "content/world/manifest.json").read_bytes())
        require(
            manifest["semantic_schema_version"]
            == "reference-schema-primary-observations-v1",
            "MEDIA_SEMANTIC_MARKER",
        )
    views = project_qualified_views(root, read_views(root, overlay))
    result = {role: verify(records, gate, role) for role, records in views.items()}
    return {
        "status": "PASS_CLOSED_SOURCE_MEDIA_READBACK",
        "views": result,
        "runtime_activation": False,
        "sounds": 0,
        "ignored_none": 0,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--gate", type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.root, args.gate), sort_keys=True))

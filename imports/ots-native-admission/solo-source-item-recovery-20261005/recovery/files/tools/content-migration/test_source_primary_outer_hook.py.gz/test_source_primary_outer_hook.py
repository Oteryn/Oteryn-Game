"""Small Source55 explicit inverse order fixtures; no Native/Source reads."""

import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "source55_outer_candidate", HERE / "item_source_primary_navigation.py"
)
module = importlib.util.module_from_spec(spec)
with patch.dict(
    sys.modules,
    {
        "appearance_membership": types.SimpleNamespace(load_admitted=None),
        "item_engine_navigation": types.SimpleNamespace(digest=None, family=None),
    },
):
    spec.loader.exec_module(module)


class OuterHook(unittest.TestCase):
    def test_flags_then_names_before_all_existing_source55_guards(self):
        calls = []
        flags = types.SimpleNamespace(FIELD="flags")
        names = types.SimpleNamespace(FIELD="names")

        def flag_inverse(record, gate, role):
            calls.append("flags")
            self.assertEqual(role, "canonical")
            self.assertIn("names", record["semantics"])
            return {"semantics": {"names": "known", "old": "retained"}}

        def name_inverse(record, gate, role):
            calls.append("names")
            self.assertNotIn("flags", record["semantics"])
            return {"semantics": {"old": "retained"}}

        flags.project_record = flag_inverse
        names.project_record = name_inverse
        old = {"semantics": {"old": "retained"}}
        current = {"semantics": {"flags": "known", "names": "known", "old": "retained"}}
        with (
            patch.object(
                module, "_outer_source_gates", return_value=(flags, {}, names, {})
            ),
            patch.object(
                module,
                "qualified_class_expansion_projection",
                side_effect=lambda d, e: calls.append("class") or d,
            ),
            patch.object(
                module,
                "qualified_property_projection",
                side_effect=lambda d, e: calls.append("property") or d,
            ),
        ):
            self.assertEqual(
                module.qualified_media_projection(current, {"native_definition": old}),
                old,
            )
        self.assertEqual(calls, ["flags", "names", "class", "property"])
        self.assertIn("flags", current["semantics"])

    def test_unadmitted_known_rejected_and_missing_unknown_preserved(self):
        flags = types.SimpleNamespace(FIELD="flags")
        names = types.SimpleNamespace(FIELD="names")
        with patch.object(
            module, "_outer_source_gates", return_value=(flags, None, names, None)
        ):
            old = {"semantics": {"old": "retained"}}
            self.assertEqual(module.qualified_outer_source_projection(old), old)
            for field in ("flags", "names"):
                with self.assertRaises(ValueError):
                    module.qualified_outer_source_projection(
                        {"semantics": {field: {"state": "KNOWN", "value": []}}}
                    )


if __name__ == "__main__":
    unittest.main()

"""Portable closed Source gates; prospective full replay and targeted mutations."""

import copy
import json
import sys
import unittest
from pathlib import Path

from item_source_property_admission import (
    appearance_payload,
    load_gate,
    project_before,
    project_record,
)

ROOT = (
    Path(sys.argv[1])
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-")
    else Path(__file__).resolve().parents[2]
)
if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
    sys.argv.pop(1)
OUT = Path(__file__).parent


class SourceProperties(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gate = load_gate(
            ROOT,
            OUT / "property-admissions.json"
            if (OUT / "property-admissions.json").exists()
            else None,
            OUT / "source-prerequisites.json"
            if (OUT / "source-prerequisites.json").exists()
            else None,
        )
        # Optional virtual overlay is an explicit test CLI argument, never a production dependency.
        base = globals().get("OVERLAY", ROOT)
        cls.reference = json.loads(
            (base / "content/world/definitions/reference.json").read_bytes()
        )["records"]
        cls.canonical = []
        for path in sorted((base / "content/items/definitions").glob("items-*.json")):
            cls.canonical.extend(
                r["definition"] for r in json.loads(path.read_bytes())["records"]
            )
        from item_source_class_expansion import load_gate as expansion_gate
        from item_source_class_expansion import project_before as expansion_before
        from item_source_combat_admission import project_if_installed
        from item_source_definition_admission import load_gate as definition_gate
        from item_source_definition_admission import project_before as definition_before

        cls.canonical = project_if_installed(ROOT, cls.canonical, "canonical")
        cls.reference = project_if_installed(ROOT, cls.reference, "reference")
        definition = definition_gate(ROOT)
        cls.canonical = definition_before(cls.canonical, definition, "canonical")
        cls.reference = definition_before(cls.reference, definition, "reference")
        expanded = expansion_gate(ROOT)
        cls.canonical = expansion_before(cls.canonical, expanded, "canonical")
        cls.reference = expansion_before(cls.reference, expanded, "reference")
        cls.views = {"canonical": cls.canonical, "reference": cls.reference}

    def test_message_frame_not_confused_with_appearance_payload(self):
        self.assertEqual(appearance_payload(bytes([10, 2, 8, 1])), bytes([8, 1]))
        for raw in (bytes([10]), bytes([10, 3, 8, 1]), bytes([18, 2, 8, 1])):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                appearance_payload(raw)

    def test_actual_whole_stream_restores_old_media_gate(self):
        sys.path.insert(0, str(ROOT / "tools/content-migration"))
        from item_source_media_admission import load_gate as media_gate
        from item_source_media_admission import verify as media_verify

        gate = media_gate(ROOT)
        for role, records in self.views.items():
            media_verify(project_before(records, self.gate, role), gate, role)

    def test_both_domains_and_old_groups_preserved(self):
        target = next(
            r for r in self.gate["_targets"].values() if len(r["children"]) == 1
        )
        missing = next(
            f
            for f in ("source_class_observations", "source_scalar_observations")
            if f not in target["children"]
        )
        for role, records in self.views.items():
            item = next(r for r in records if r["identity"] == target["identity"])
            for state in (
                {"state": "KNOWN", "value": []},
                {"state": "NOT_APPLICABLE"},
                {"state": "CONFLICT"},
            ):
                bad = copy.deepcopy(item)
                bad["semantics"][missing] = state
                with (
                    self.subTest(role=role, state=state),
                    self.assertRaises(ValueError),
                ):
                    project_record(bad, self.gate, role)
            bad = copy.deepcopy(item)
            bad["semantics"]["classification"] = {"state": "NOT_APPLICABLE"}
            with self.assertRaises(ValueError):
                project_record(bad, self.gate, role)

    def test_revision_and_source_cut_substitution(self):
        row = next(iter(self.gate["_targets"].values()))
        for role, records in self.views.items():
            item = next(r for r in records if r["identity"] == row["identity"])
            bad = copy.deepcopy(item)
            bad["identity"]["revision"] = "borrowed"
            with self.assertRaises(ValueError):
                project_record(bad, self.gate, role)
            bad = copy.deepcopy(item)
            field = next(iter(row["children"]))
            bad["semantics"][field]["value"][0]["source_cut"] = "CRYSTAL_00CE"
            with self.assertRaises(ValueError):
                project_record(bad, self.gate, role)

    def test_missing_and_duplicate_target(self):
        rows = self.reference
        key = next(iter(self.gate["_targets"]))[0]
        without = [r for r in rows if r["identity"]["key"] != key]
        with self.assertRaisesRegex(ValueError, "COMPLETE_VIEW"):
            project_before(without, self.gate, "reference")
        with self.assertRaisesRegex(ValueError, "DUPLICATE_IDENTITY"):
            project_before(
                rows + [next(r for r in rows if r["identity"]["key"] == key)],
                self.gate,
                "reference",
            )

    def test_901_and_outside_nonunknown_rejected(self):
        item = next(
            r
            for r in self.reference
            if r["identity"]["key"] == "oteryn:item.tibia.i901"
        )
        bad = copy.deepcopy(item)
        bad["semantics"]["source_class_observations"] = {"state": "CONFLICT"}
        with self.assertRaisesRegex(ValueError, "UNREGISTERED_OBSERVATION"):
            project_record(bad, self.gate, "reference")


if __name__ == "__main__":
    # unittest accepts no custom positionals after our root/optional-overlay arguments.
    overlay = (
        sys.argv.pop(1)
        if len(sys.argv) > 1 and not sys.argv[1].startswith("-")
        else None
    )
    if overlay:
        SourceProperties.setUpClass.__func__.__globals__["OVERLAY"] = Path(overlay)
    unittest.main()

"""Closed Sourcecombat storage readback and exact child-only inverse; export held."""

import argparse
import copy
import hashlib
import json
from pathlib import Path

from combat_catalog import PATH as CATALOG_PATH
from combat_catalog import validate_catalog, validate_reference

PATH = "imports/ots-native-admission/source-combat-observations/combat-admissions.json"
REGISTRY = "apps/game-server/src/content/source-combat-registry.json"
SHA256 = "f293c66ae6de438e7336789877baf8cce2ee905b2d032a9491b9c747788ca4f7"
FIELD = "source_combat_observations"
UNKNOWN = {"state": "UNKNOWN"}


def encoded(value):
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        + "\n"
    ).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def require(test, reason):
    if not test:
        raise ValueError(reason)


def load_gate(root, gate_path=None, registry_path=None, proof_root=None):
    raw = (gate_path or root / PATH).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == SHA256, "COMBAT_GATE_DIGEST")
    gate = json.loads(raw)
    registry_raw = (registry_path or root / REGISTRY).read_bytes()
    require(
        hashlib.sha256(registry_raw).hexdigest() == gate["registry_sha256"],
        "COMBAT_REGISTRY_DIGEST",
    )
    registry = json.loads(registry_raw)
    require(
        gate["schema"] == "OTERYN_SOURCE_COMBAT_CLOSED_ADMISSIONS/v1"
        and len(gate["qualified"]) == 35,
        "COMBAT_GATE_SCOPE",
    )
    registered = {
        (r["target_key"], r["target_revision"]): r["observations"]
        for r in registry["rows"]
    }
    require(
        len(registered) == 35 and sum(map(len, registered.values())) == 39,
        "COMBAT_REGISTRY_CLOSED_SCOPE",
    )
    require(
        {
            (r["identity"]["key"], r["identity"]["revision"]): r["child"]["value"]
            for r in gate["qualified"]
        }
        == registered,
        "COMBAT_ALL_OWN_VALUES",
    )
    for relative, expected in (
        gate["binding_input_sha256"] | gate["immutable_source_proof_input_sha256"]
    ).items():
        require(
            relative.startswith("imports/") and ".." not in Path(relative).parts,
            "COMBAT_INPUT_PATH",
        )
        require(
            hashlib.sha256(
                (
                    (proof_root or root)
                    if relative in gate["immutable_source_proof_input_sha256"]
                    else root
                )
                .joinpath(relative)
                .read_bytes()
            ).hexdigest()
            == expected,
            "COMBAT_OWN_BINDING_INPUT",
        )
    catalog = json.loads(((proof_root or root) / CATALOG_PATH).read_bytes())
    media_raw = (
        root / "apps/game-server/src/content/source-media-registry.json"
    ).read_bytes()
    require(
        hashlib.sha256(media_raw).hexdigest() == registry["source377_registry_sha256"],
        "COMBAT_OWN_ENUM_DICTIONARY_DIGEST",
    )
    media = json.loads(media_raw)
    validate_catalog(catalog, media)
    for row in gate["qualified"]:
        for entry in row["child"]["value"]:
            validate_reference(entry, catalog)
    return gate


def verify(records, gate, role):
    require(role in ("canonical", "reference"), "COMBAT_VIEW")
    keys = [r["identity"]["key"] for r in records]
    require(
        len(keys) == len(set(keys)) == gate["record_counts"][role],
        "COMBAT_RECORD_UNIVERSE",
    )
    current = {r["identity"]["key"]: r for r in records}
    targets = {r["identity"]["key"]: r for r in gate["qualified"]}
    for key, record in current.items():
        if key not in targets:
            require(
                record.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN,
                "COMBAT_UNDECLARED_CHILD",
            )
    require(
        digest({k: r for k, r in current.items() if k not in targets})
        == gate["outside_record_sha256"][role],
        "COMBAT_OUTSIDE_PARENTS",
    )
    for key, row in targets.items():
        require(key in current, "COMBAT_MISSING_TARGET")
        record = current[key]
        require(
            record["kind"] == "Item" and record["identity"] == row["identity"],
            "COMBAT_FULL_IDENTITY",
        )
        require(
            record.get("semantics", {}).get(FIELD) == row["child"],
            "COMBAT_EXACT_PHASE_OWNER_VALUES",
        )
        require(
            digest(record) == row["after_record_sha256"][role], "COMBAT_WHOLE_PARENT"
        )
    return {
        "targets": 35,
        "observations": 39,
        "runtime_activation": False,
        "export": "HELD",
    }


def project_before(records, gate, role):
    """Apply FIRST, then class/scalar inverse; never project an unverified parent."""
    verify(records, gate, role)
    result = list(records)
    rows = {r["identity"]["key"]: r for r in gate["qualified"]}
    for index, original in enumerate(records):
        key = original["identity"]["key"]
        if key not in rows:
            continue
        record = copy.deepcopy(original)
        result[index] = record
        witness = rows[key]["before"][role]
        if witness["field_present"]:
            record["semantics"][FIELD] = UNKNOWN
        else:
            del record["semantics"][FIELD]
            if not witness["semantics_present"]:
                del record["semantics"]
        require(
            digest(record) == rows[key]["before_record_sha256"][role],
            "COMBAT_EXACT_BEFORE_INVERSE",
        )
    return result


def project_if_installed(root, records, role):
    """Restore only qualified Combat before older guards; never skip other fields."""
    root = Path(root)
    from item_source_presentation_admission import project_if_installed as project_names

    records = project_names(root, records, role)
    if (root / PATH).exists():
        return project_before(records, load_gate(root), role)
    require(
        all(row.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN for row in records),
        "SOURCE_COMBAT_WITHOUT_QUALIFIED_ADMISSION",
    )
    return records


def verify_repository(root):
    """Read unprojected stored views; do not evaluate or activate Source."""
    root = Path(root)
    gate = load_gate(root)
    reference = json.loads(
        (root / "content/world/definitions/reference.json").read_bytes()
    )["records"]
    from item_source_presentation_admission import project_if_installed as project_names

    verify(project_names(root, reference, "reference"), gate, "reference")
    del reference
    canonical = []
    index = json.loads((root / "content/items/index.json").read_bytes())
    for relative in index["shards"]:
        canonical.extend(
            row["definition"]
            for row in json.loads((root / relative).read_bytes())["records"]
        )
    verify(project_names(root, canonical, "canonical"), gate, "canonical")
    return "PASS35_SOURCE_COMBAT_BOTH_VIEWS_39_OWN_OBSERVATIONS_V7_EXPORT_HELD"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    print(verify_repository(parser.parse_args().root))

"""Repository-native regression checks after atomic Source405 child installation."""

import copy
import json
import unittest
from pathlib import Path

import item_armor_constructor_admission as armor
from item_armor_source_child_successor import (
    load_child_gate,
    project_source_child_groups,
)

ROOT = Path(__file__).resolve().parents[2]


class SourceChild(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prior = armor.load_gate(ROOT)
        cls.proof = load_child_gate(ROOT)
        cls.views = {
            "reference": json.loads(
                (ROOT / "content/world/definitions/reference.json").read_bytes()
            )["records"],
            "canonical": [
                r["definition"]
                for p in (ROOT / "content/items/definitions").glob("items-*.json")
                for r in json.loads(p.read_bytes())["records"]
            ],
        }

    def test_full_both_views_original_11277_law(self):
        for role, records in self.views.items():
            projected = project_source_child_groups(
                records, self.prior, role, self.proof
            )
            self.assertEqual(len(armor.verify(projected, self.prior, role)), 11277)
            self.assertEqual(
                len(armor.verify(records, self.prior, role, self.proof)), 11277
            )

    def test_child_siblings_owner_missing_duplicate_and_wrong_chain(self):
        key = self.proof["qualified"][0]["identity"]["key"]
        for role, records in self.views.items():
            ordinal = next(
                i for i, r in enumerate(records) if r["identity"]["key"] == key
            )
            for fact in (
                "child",
                "armor",
                "resistances",
                "revision",
                "duplicate",
                "missing",
            ):
                changed = list(records)
                item = copy.deepcopy(changed[ordinal])
                if fact == "revision":
                    item["identity"]["revision"] = "wrong"
                elif fact == "duplicate":
                    changed.append(item)
                elif fact == "missing":
                    changed.pop(ordinal)
                else:
                    value = item["semantics"]["protection"]["value"]
                    if fact == "child":
                        value["observed_resistance_parameters"]["value"]["phase"] = (
                            "RUNTIME"
                        )
                    else:
                        value[fact] = {"state": "KNOWN", "value": 9999}
                if fact != "missing":
                    changed[ordinal] = item
                with self.assertRaises(ValueError, msg=fact):
                    project_source_child_groups(changed, self.prior, role, self.proof)
            with self.assertRaises(ValueError):
                project_source_child_groups(
                    records, dict(self.prior, own_revision="wrong"), role, self.proof
                )


if __name__ == "__main__":
    unittest.main()

"""Exact Source405 sibling projection into the immutable closure armor gate."""

import hashlib
import json

PATH = "imports/canary/primary-items/armor-source-child-successor.json"
SHA256 = "8dc6babbe695659b47f7e6fd977c1c81c809a99c1906e5c562a15e3d7e80d5a2"
PRIOR_SHA256 = "dc3d27fc434bc1bce18b13c3eacaafce3d0307dc49d2bed33a354c01bd0a21b0"
CHILD = "observed_resistance_parameters"


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(test, reason):
    if not test:
        raise ValueError(reason)


def load_child_gate(root, gate_path=None):
    raw = (gate_path or root / PATH).read_bytes()
    require(sha(raw) == SHA256, "ARMOR_SOURCE_CHILD_GATE_DIGEST")
    proof = json.loads(raw)
    require(
        proof["schema"] == "OTERYN_ARMOR_PROTECTION_SOURCE_CHILD_SUCCESSOR/v1"
        and proof["count"] == len(proof["qualified"]) == 405
        and proof["child"] == CHILD
        and proof["prior_gate_sha256"] == PRIOR_SHA256,
        "ARMOR_SOURCE_CHILD_SCOPE",
    )
    own = (
        root
        / "imports/ots-native-admission/primary-observations/observation-admissions.json"
    )
    require(
        sha(own.read_bytes()) == proof["own_observation_gate_sha256"],
        "ARMOR_SOURCE_CHILD_OWN_REGISTRY",
    )
    return proof


def project_source_child_groups(records, prior, role, proof):
    require(role in ("canonical", "reference"), "ARMOR_SOURCE_CHILD_VIEW")
    require(
        sha(encoded(prior) + b"\n") == proof["prior_gate_sha256"] == PRIOR_SHA256,
        "ARMOR_SOURCE_CHILD_PRIOR_CHAIN",
    )
    by_key = {r["identity"]["key"]: r for r in proof["qualified"]}
    require(
        len(by_key) == proof["count"] == 405, "ARMOR_SOURCE_CHILD_DUPLICATE_WITNESS"
    )
    seen = set()
    result = []
    for item in records:
        witness = by_key.get(item["identity"]["key"])
        group = item.get("semantics", {}).get("protection", {"state": "UNKNOWN"})
        if witness is None:
            require(
                group.get("value", {}).get(CHILD, {"state": "UNKNOWN"})
                == {"state": "UNKNOWN"},
                "ARMOR_SOURCE_CHILD_OUTSIDE_COHORT",
            )
            result.append(item)
            continue
        require(
            item["kind"] == "Item"
            and item["identity"] == witness["identity"]
            and item["identity"]["key"] not in seen,
            "ARMOR_SOURCE_CHILD_IDENTITY",
        )
        seen.add(item["identity"]["key"])
        pin = witness["views"][role]
        require(
            group["state"] == "KNOWN"
            and sha(encoded(group)) == pin["after_group_sha256"],
            "ARMOR_SOURCE_CHILD_WHOLE_AFTER_GROUP",
        )
        child = group["value"].get(CHILD)
        require(
            child is not None
            and child["state"] == "KNOWN"
            and sha(encoded(child)) == pin["child_sha256"],
            "ARMOR_SOURCE_CHILD_VALUE",
        )
        projected = {
            "state": "KNOWN",
            "value": {k: v for k, v in group["value"].items() if k != CHILD},
        }
        require(
            sha(encoded(projected)) == pin["before_group_sha256"],
            "ARMOR_SOURCE_CHILD_UNAFFECTED_SIBLINGS",
        )
        result.append(
            {**item, "semantics": {**item["semantics"], "protection": projected}}
        )
    require(seen == set(by_key), "ARMOR_SOURCE_CHILD_MISSING_ITEM")
    return result

"""Closed own-parser gate negatives and full prospective composition projection."""

import copy
import gzip
import json
import sys
import unittest
from pathlib import Path

from item_source_definition_admission import (
    load_gate,
    project_before,
    project_record,
)

ROOT = (
    Path(sys.argv.pop(1))
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-")
    else Path(__file__).resolve().parents[2]
)
OUT = Path(__file__).parent


class DefinitionGate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gate = load_gate(
            ROOT,
            OUT / "definition-admissions-v2.json.gz"
            if (OUT / "definition-admissions-v2.json.gz").exists()
            else None,
            OUT / "definition-prerequisites.json"
            if (OUT / "definition-prerequisites.json").exists()
            else None,
        )
        # Portable tests use the installed actual stream; explicit virtual stream fixtures are passed by CLI.
        cls.views = (
            json.loads(gzip.decompress(Path(OVERLAY).read_bytes()))
            if "OVERLAY" in globals()
            else {
                "reference": json.loads(
                    (ROOT / "content/world/definitions/reference.json").read_bytes()
                )["records"],
                "canonical": [
                    r["definition"]
                    for p in sorted(
                        (ROOT / "content/items/definitions").glob("items-*.json")
                    )
                    for r in json.loads(p.read_bytes())["records"]
                ],
            }
        )

        from item_source_combat_admission import project_if_installed

        cls.views = {
            role: project_if_installed(ROOT, records, role)
            for role, records in cls.views.items()
        }

    def test_entire_bothview_cohort_inverse(self):
        for role, records in self.views.items():
            restored = project_before(records, self.gate, role)
            self.assertEqual(len(restored), len(records))
            self.assertEqual(len(self.gate["_targets"]), 4475)

    def test_sourcecut_revision_oldknown_group_and_worldpointer_mutations(self):
        for role, records in self.views.items():
            target = next(iter(self.gate["_targets"].values()))
            item = next(r for r in records if r["identity"] == target["identity"])
            for operation in ("revision", "cut", "oldgroup", "pointer"):
                bad = copy.deepcopy(item)
                if operation == "revision":
                    bad["identity"]["revision"] = "borrowed"
                elif operation == "cut":
                    bad["semantics"]["source_definition_observations"]["value"][0][
                        "source_cut"
                    ] = "FOREIGN"
                elif operation == "oldgroup":
                    bad["semantics"]["physical"] = {"state": "NOT_APPLICABLE"}
                else:
                    bad["semantics"]["source_definition_observations"]["value"][0][
                        "current_world_owner_pointers"
                    ] = [{"family": "WorldObject", "key": "borrowed", "revision": "r1"}]
                with (
                    self.subTest(role=role, operation=operation),
                    self.assertRaises(ValueError),
                ):
                    project_record(bad, self.gate, role)

    def test_missing_duplicate_core_and_every_undeclared_nonunknown_state(self):
        for role, records in self.views.items():
            key = next(iter(self.gate["_targets"]))[0]
            with self.assertRaises(ValueError):
                project_before(
                    [r for r in records if r["identity"]["key"] != key], self.gate, role
                )
            item = next(r for r in records if r["identity"]["key"] == key)
            with self.assertRaises(ValueError):
                project_before(records + [item], self.gate, role)
            core = next(
                r for r in records if r["identity"]["key"] == "oteryn:item.tibia.i901"
            )
            for state in (
                {"state": "KNOWN", "value": []},
                {"state": "NOT_APPLICABLE"},
                {"state": "CONFLICT"},
            ):
                bad = copy.deepcopy(core)
                bad.setdefault("semantics", {})["source_definition_observations"] = (
                    state
                )
                with self.assertRaisesRegex(ValueError, "UNREGISTERED"):
                    project_record(bad, self.gate, role)


if __name__ == "__main__":
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        OVERLAY = sys.argv.pop(1)
    unittest.main()

"""Read actual raw Native views; close the qualified Source sibling chain."""

import argparse
import json
from pathlib import Path

import item_source_class_expansion as expansion
import item_source_definition_admission as definition
import item_source_media_admission as media
import item_source_property_admission as properties


def run(root):
    root = Path(root)

    def read(path):
        return json.loads((root / path).read_bytes())

    canonical = [
        row["definition"]
        for shard in read("content/items/index.json")["shards"]
        for row in read(shard)["records"]
    ]
    views = {
        "canonical": canonical,
        "reference": read("content/world/definitions/reference.json")["records"],
    }
    dg, cg, pg, mg = (
        definition.load_gate(root),
        expansion.load_gate(root),
        properties.load_gate(root),
        media.load_gate(root),
    )
    for role, records in views.items():
        from item_source_combat_admission import project_if_installed

        records = project_if_installed(root, records, role)
        before = definition.project_before(records, dg, role)
        before = expansion.project_before(before, cg, role)
        before = properties.project_before(before, pg, role)
        media.verify(before, mg, role)
    return {
        "status": "PASS4475_SOURCE_DEFINITION_BOTH_VIEWS_FUTURE_EXPORT_HELD",
        "targets": 4475,
        "observations": 9291,
        "roles": {role: len(rows) for role, rows in views.items()},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    print(json.dumps(run(parser.parse_args().root), sort_keys=True))

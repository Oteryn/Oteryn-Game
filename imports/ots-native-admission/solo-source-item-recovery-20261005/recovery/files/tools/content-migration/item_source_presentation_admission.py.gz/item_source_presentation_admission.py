"""Only closed Source presentation children; preserve complete Native parents."""

import copy
import hashlib
import json

FIELD = "source_presentation_observations"
UNKNOWN = {"state": "UNKNOWN"}
REGISTRY_SHA = "fcdeccc62972b5e7b7fb9f311ede5457d888ce426cd34106c4d72e396c128315"
REFERENCE_SHA = "7e730f2bf7fb3a4b85c2df702330605b32c9dc809bfbea763b3e23574a8f31bc"


def digest(value):
    return hashlib.sha256(
        (
            json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
            + "\n"
        ).encode()
    ).hexdigest()


def require(test, reason):
    if not test:
        raise ValueError(reason)


def add_child(record, vector):
    require(record["kind"] == "Item", "PRESENTATION_NONITEM")
    require(record["identity"]["key"] != "oteryn:item.tibia.i901", "PRESENTATION_901")
    require(isinstance(record.get("semantics"), dict), "PRESENTATION_NO_PARENT")
    semantics = record["semantics"]
    require(
        semantics.get(FIELD, UNKNOWN) == UNKNOWN, "PRESENTATION_EXISTING_STATE_HOLD"
    )
    require(1 <= len(vector) <= 2, "PRESENTATION_CUT_COUNT")
    require(
        len({v["source_cut"] for v in vector}) == len(vector),
        "PRESENTATION_DUPLICATE_CUT",
    )
    result = dict(record)
    result["semantics"] = {FIELD: {"state": "KNOWN", "value": vector}, **semantics}
    if FIELD in semantics:
        result["semantics"][FIELD] = {"state": "KNOWN", "value": vector}
    witness = {
        "field_present": FIELD in semantics,
        "before_sha256": digest(record),
        "after_sha256": digest(result),
    }
    require(
        inverse_record(result, vector, witness) == record,
        "PRESENTATION_FULL_PARENT_PRESERVATION",
    )
    return result, witness


def inverse_record(record, vector, witness):
    require(record["kind"] == "Item", "PRESENTATION_INVERSE_KIND")
    require(digest(record) == witness["after_sha256"], "PRESENTATION_FULL_AFTER_PARENT")
    require(
        record["semantics"].get(FIELD) == {"state": "KNOWN", "value": vector},
        "PRESENTATION_EXACT_VECTOR",
    )
    result = dict(record)
    result["semantics"] = dict(record["semantics"])
    if witness["field_present"]:
        result["semantics"][FIELD] = copy.deepcopy(UNKNOWN)
    else:
        del result["semantics"][FIELD]
    require(
        digest(result) == witness["before_sha256"], "PRESENTATION_FULL_BEFORE_PARENT"
    )
    return result


PATH = "imports/ots-native-admission/source-presentation-observations/presentation-admissions.json.gz"
REGISTRY_PATH = "apps/game-server/src/content/source-presentation-registry.json"
CONSUMER_PATH = "imports/ots-native-admission/source-presentation-observations/consumer-manifest.json"
CONSUMER_SHA = "0237e7c647b0fddd3a2470cd146a86bbbe4772d45bebd7415d7082a9f59d35fb"
GATE_SHA = "73dd69dae1a667fc99e1feffc8037b3718129e7790109e00b8461a4ed38db704"


def load_gate(root, gate_path=None, registry_path=None, consumer_path=None):
    import gzip
    from pathlib import Path

    root = Path(root)
    raw = (gate_path or root / PATH).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == GATE_SHA, "PRESENTATION_GATE_DIGEST")
    gate = json.loads(gzip.decompress(raw))
    registry_raw = (registry_path or root / REGISTRY_PATH).read_bytes()
    require(
        hashlib.sha256(registry_raw).hexdigest() == REGISTRY_SHA,
        "PRESENTATION_REGISTRY_DIGEST",
    )
    require(
        hashlib.sha256((consumer_path or root / CONSUMER_PATH).read_bytes()).hexdigest()
        == CONSUMER_SHA,
        "PRESENTATION_CONSUMER_DIGEST",
    )
    registry = json.loads(registry_raw)
    targets = registry["targets"]
    require(
        gate["schema"] == "OTERYN_SOURCE_PRESENTATION_ADMISSION_33975/v1"
        and registry["schema"] == "OTERYN_SOURCE_PRESENTATION_CLOSED_33975/v1",
        "PRESENTATION_SCHEMA",
    )
    require(
        len(targets) == len(gate["qualified"]) == 33975
        and set(targets) == set(gate["qualified"]),
        "PRESENTATION_CLOSED_TARGETS",
    )
    bindings = {}
    for relative, expected in gate["source_binding_input_sha256"].items():
        require(
            relative.startswith("imports/") and ".." not in Path(relative).parts,
            "PRESENTATION_INPUT_PATH",
        )
        source_raw = (root / relative).read_bytes()
        require(
            hashlib.sha256(source_raw).hexdigest() == expected,
            "PRESENTATION_OWN_BINDING_PIN",
        )
        payload = json.loads(source_raw)
        for b in payload.get("bindings", []):
            own = (
                b["source_key"],
                b["source_revision"],
                b["identity_namespace"],
                b["external_id"],
            )
            require(own not in bindings, "PRESENTATION_AMBIGUOUS_BINDING")
            bindings[own] = b
    observations = 0
    for key, row in gate["qualified"].items():
        revision = row["identity"]["revision"]
        require(
            row["identity"]["key"] == key
            and row["identity"]["family"] == "Item"
            and key != "oteryn:item.tibia.i901",
            "PRESENTATION_IDENTITY_OWNER",
        )
        require(
            set(targets[key]) == {revision}
            and set(row["views"]) == {"canonical", "reference"},
            "PRESENTATION_EXACT_REVISION_VIEWS",
        )
        vector = targets[key][revision]
        require(
            1 <= len(vector) <= 2
            and len({v["source_cut"] for v in vector}) == len(vector),
            "PRESENTATION_CUT_SCOPE",
        )
        for observation in vector:
            cut = gate["source_cut_binding_tuples"][observation["source_cut"]]
            own = (
                cut["source_key"],
                cut["source_revision"],
                cut["identity_namespace"],
                str(observation["external_item_id"]),
            )
            b = bindings.get(own)
            require(
                b is not None
                and b["disposition"] == "EXACT"
                and b["target"] == {"family": "Item", "key": key, "revision": revision},
                "PRESENTATION_EXACT_OWN_SOURCE_TARGET",
            )
        observations += len(vector)
    require(observations == 45721, "PRESENTATION_OBSERVATION_COUNT")
    gate["_vectors"] = {
        key: targets[key][r["identity"]["revision"]]
        for key, r in gate["qualified"].items()
    }
    return gate


def outside_digest(records, targets):
    return digest(
        {
            r["identity"]["key"]: digest(r)
            for r in records
            if r["identity"]["key"] not in targets
        }
    )


def verify(records, gate, role):
    require(role in ("canonical", "reference"), "PRESENTATION_VIEW")
    expected = sum(d["record_count"] for d in gate["documents"] if d["role"] == role)
    keys = [r["identity"]["key"] for r in records]
    require(len(keys) == len(set(keys)) == expected, "PRESENTATION_UNIVERSE")
    current = dict(zip(keys, records, strict=True))
    targets = gate["qualified"]
    require(
        outside_digest(records, targets) == gate["outside_sha256"][role],
        "PRESENTATION_OUTSIDE_FULL_PARENTS",
    )
    require(set(targets) <= set(current), "PRESENTATION_MISSING_TARGET")
    require(
        digest(
            {
                key: digest(record)
                for key, record in current.items()
                if key not in targets
            }
        )
        == gate["outside_sha256"][role],
        "PRESENTATION_ALL_OUTSIDE_PARENTS",
    )
    for key, record in current.items():
        if key not in targets:
            require(
                record.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN,
                "PRESENTATION_UNDECLARED_CHILD",
            )
            continue
        row = targets[key]
        require(
            record["kind"] == "Item" and record["identity"] == row["identity"],
            "PRESENTATION_FULL_IDENTITY",
        )
        inverse_record(record, gate["_vectors"][key], row["views"][role])
    return {
        "targets": len(targets),
        "runtime_activation": False,
        "artifact_export": "HELD",
    }


def project_record(record, gate, role):
    require(role in ("canonical", "reference"), "PRESENTATION_VIEW")
    key = record["identity"]["key"]
    if key not in gate["qualified"]:
        require(
            record.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN,
            "PRESENTATION_UNDECLARED_RECORD_CHILD",
        )
        return record
    row = gate["qualified"][key]
    require(
        record["kind"] == "Item" and record["identity"] == row["identity"],
        "PRESENTATION_RECORD_FULL_IDENTITY",
    )
    return inverse_record(record, gate["_vectors"][key], row["views"][role])


def project_before(records, gate, role):
    verify(records, gate, role)
    return [
        inverse_record(
            r,
            gate["_vectors"][r["identity"]["key"]],
            gate["qualified"][r["identity"]["key"]]["views"][role],
        )
        if r["identity"]["key"] in gate["qualified"]
        else r
        for r in records
    ]


def project_if_installed(root, records, role):
    from pathlib import Path

    root = Path(root)
    from item_source_flags_admission import project_if_installed as project_flags

    records = project_flags(root, records, role)
    if (root / PATH).exists():
        return project_before(records, load_gate(root), role)
    require(
        all(r.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN for r in records),
        "PRESENTATION_WITHOUT_QUALIFIED_ADMISSION",
    )
    return records


def verify_repository(root):
    from pathlib import Path

    root = Path(root)
    gate = load_gate(root)
    from item_source_flags_admission import project_if_installed as project_flags

    reference = json.loads(
        (root / "content/world/definitions/reference.json").read_bytes()
    )["records"]
    verify(project_flags(root, reference, "reference"), gate, "reference")
    del reference
    canonical = []
    for relative in json.loads((root / "content/items/index.json").read_bytes())[
        "shards"
    ]:
        canonical.extend(
            r["definition"]
            for r in json.loads((root / relative).read_bytes())["records"]
        )
    verify(project_flags(root, canonical, "canonical"), gate, "canonical")
    return "PASS33975_SOURCE_PRESENTATION_BOTH_VIEWS_45721_OWN_OBSERVATIONS_EXPORT_HELD"


if __name__ == "__main__":
    import argparse
    from pathlib import Path

    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    print(verify_repository(parser.parse_args().root))

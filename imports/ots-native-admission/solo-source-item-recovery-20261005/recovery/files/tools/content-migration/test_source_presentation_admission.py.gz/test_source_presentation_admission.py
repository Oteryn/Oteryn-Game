"""Portable whole-parent and namespace negatives; real cohort replay is separate."""

import copy
import unittest

import item_source_presentation_admission as names


class NameGateTests(unittest.TestCase):
    def fixture(self):
        before = {
            "kind": "Item",
            "identity": {
                "family": "Item",
                "key": "oteryn:item.fixture",
                "revision": "definition-r1",
            },
            "core": {"stack_class": "NonStackable"},
            "semantics": {
                "presentation": {
                    "state": "KNOWN",
                    "value": {
                        "name": {"state": "KNOWN", "value": "old"},
                        "description": {"state": "KNOWN", "value": "exact"},
                    },
                },
                "source_class_observations": {
                    "state": "KNOWN",
                    "value": [{"source_cut": "CRYSTAL_FF7", "raw": 27}],
                },
            },
        }
        vector = [{"source_cut": "CRYSTAL_FF7", "raw": "ee", "utf8": None}]
        after, witness = names.add_child(before, vector)
        world = {
            "kind": "Terrain",
            "identity": {
                "family": "Terrain",
                "key": "oteryn:terrain.fixture",
                "revision": "definition-r1",
            },
        }
        gate = {
            "documents": [
                {"role": "canonical", "record_count": 2},
                {"role": "reference", "record_count": 2},
            ],
            "qualified": {
                "oteryn:item.fixture": {
                    "identity": before["identity"],
                    "views": {"canonical": witness, "reference": witness},
                }
            },
            "_vectors": {"oteryn:item.fixture": vector},
        }
        gate["outside_sha256"] = {
            role: names.outside_digest([after, world], gate["qualified"])
            for role in ("canonical", "reference")
        }
        gate["outside_sha256"] = {
            role: names.digest({world["identity"]["key"]: names.digest(world)})
            for role in ("canonical", "reference")
        }
        return before, [after, world], gate

    def test_both_views_keep_known_fields_and_full_inverse(self):
        before, records, gate = self.fixture()
        unchanged = copy.deepcopy(records)
        for role in ("canonical", "reference"):
            inverse = names.project_before(records, gate, role)
            self.assertEqual(inverse[0], before)
            self.assertIs(inverse[1], records[1])
            self.assertEqual(records, unchanged)

    def test_wrong_identity_revision_core_retained_name_and_source_values(self):
        _, records, gate = self.fixture()
        for field in (
            "key",
            "revision",
            "core",
            "name",
            "source_class",
            "new_name_value",
        ):
            bad = copy.deepcopy(records)
            if field in ("key", "revision"):
                bad[0]["identity"][field] = "wrong"
            elif field == "core":
                bad[0]["core"]["stack_class"] = "Stackable"
            elif field == "name":
                bad[0]["semantics"]["presentation"]["value"]["name"]["value"] = (
                    "overwrite"
                )
            elif field == "source_class":
                bad[0]["semantics"]["source_class_observations"]["value"][0]["raw"] = 28
            else:
                bad[0]["semantics"][names.FIELD]["value"][0]["raw"] = "ef"
            with self.assertRaises(ValueError):
                names.project_before(bad, gate, "reference")

    def test_missing_duplicate_world_and_nonunknown_namespace_hold(self):
        _, records, gate = self.fixture()
        for bad in (records[1:], records + [records[0]]):
            with self.assertRaises(ValueError):
                names.verify(bad, gate, "canonical")
        for state in (
            {"state": "KNOWN", "value": []},
            {"state": "CONFLICT"},
            {"state": "NOT_APPLICABLE"},
        ):
            bad = copy.deepcopy(records)
            bad[1]["semantics"] = {names.FIELD: state}
            with self.assertRaises(ValueError):
                names.verify(bad, gate, "reference")
        bad = copy.deepcopy(records)
        bad[0]["kind"] = "Terrain"
        with self.assertRaises(ValueError):
            names.verify(bad, gate, "reference")

"""Small orchestration test; no Native pool or actual Source gates are loaded."""

import importlib.util
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch


class MediaOwningSetupTests(unittest.TestCase):
    def test_all_qualified_inverses_run_before_media_with_both_roles(self):
        calls = []

        def projector(label):
            def project(records, gate, role):
                calls.append((label, role))
                return records

            return project

        modules = {}
        for name, label in [
            ("item_source_class_expansion", "class"),
            ("item_source_definition_admission", "definition"),
            ("item_source_property_admission", "property"),
        ]:
            modules[name] = types.SimpleNamespace(
                PATH=label, load_gate=lambda root: {}, project_before=projector(label)
            )

        def combat(root, records, role):
            calls.extend((label, role) for label in ("flags", "names", "combat"))
            return records

        modules["item_source_combat_admission"] = types.SimpleNamespace(
            project_if_installed=combat
        )

        def require(test, reason):
            if not test:
                raise ValueError(reason)

        modules["item_source_media_admission"] = types.SimpleNamespace(
            load_gate=lambda root, path=None: {},
            require=require,
            verify=lambda records, gate, role: {},
        )
        file = Path(__file__).resolve().parent / "verify_source_media.py"
        with patch.dict(sys.modules, modules):
            spec = importlib.util.spec_from_file_location("candidate_media_owner", file)
            owner = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(owner)
            with tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                for label in ("class", "definition", "property"):
                    (root / label).write_text("{}")
                views = {
                    "canonical": [{"kind": "Item"}],
                    "reference": [{"kind": "Terrain"}],
                }
                result = owner.project_qualified_views(root, views)
                self.assertEqual(result, views)
                for role in views:
                    self.assertEqual(
                        [label for label, called_role in calls if called_role == role],
                        ["flags", "names", "combat", "definition", "class", "property"],
                    )
                (root / "definition").unlink()
                with self.assertRaisesRegex(
                    ValueError, "SOURCE_DEFINITION_WITHOUT_QUALIFIED_ADMISSION"
                ):
                    owner.project_qualified_views(
                        root,
                        {
                            "canonical": [
                                {
                                    "kind": "Item",
                                    "semantics": {
                                        "source_definition_observations": {
                                            "state": "KNOWN",
                                            "value": [],
                                        }
                                    },
                                }
                            ]
                        },
                    )

"""Actual full installed views and closed-universe mutation negatives."""

import copy
import json
import os
import unittest
from pathlib import Path

import item_source_media_admission as admission
from verify_source_media import project_qualified_views, read_views

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).parent


class MediaReadbackTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gate = admission.load_gate(ROOT)
        overlay = os.environ.get("MEDIA_READBACK_OVERLAY")
        cls.views = project_qualified_views(
            ROOT, read_views(ROOT, Path(overlay) if overlay else None)
        )
        cls.keys = {row["identity"]["key"] for row in cls.gate["qualified"]}

    def test_real_installed_both_views_and_all_377_loaded_proto(self):
        for role, records in self.views.items():
            self.assertEqual(
                admission.verify(records, self.gate, role), admission.COUNTS
            )
        self.assertEqual(
            sum(len(rows) for rows in self.gate["own_proto_raw_sha256"].values()), 377
        )

    def test_undeclared_all_explicit_states_and_wrong_slot_fail(self):
        for role, records in self.views.items():
            outside = next(
                i
                for i, r in enumerate(records)
                if r["kind"] == "Item"
                and r["identity"]["key"] not in self.keys
                and r["identity"]["key"] != "oteryn:item.tibia.i901"
            )
            for state in [
                {"state": "KNOWN", "value": []},
                {"state": "NOT_APPLICABLE"},
                {"state": "CONFLICT"},
                {"state": "UNKNOWN", "unexpected": 1},
            ]:
                changed = copy.deepcopy(records)
                changed[outside].setdefault("semantics", {})["source_media_config"] = (
                    state
                )
                with self.assertRaisesRegex(ValueError, "MEDIA_UNDECLARED_CHILD"):
                    admission.verify(changed, self.gate, role)
            changed = copy.deepcopy(records)
            changed[outside].setdefault("semantics", {})["unregistered_media_child"] = {
                "state": "KNOWN",
                "value": 0,
            }
            with self.assertRaisesRegex(
                ValueError, "MEDIA_OUTSIDE_PARENT_PRESERVATION"
            ):
                admission.verify(changed, self.gate, role)

    def test_target_source_value_namespace_cut_phase_and_missing_complement_fail(self):
        for role, records in self.views.items():
            index = next(
                i for i, r in enumerate(records) if r["identity"]["key"] in self.keys
            )
            for key, value in [
                ("own_value", 65535),
                ("namespace", "SOUND_EFFECT"),
                ("source_cut", "FOREIGN_CUT"),
            ]:
                changed = copy.deepcopy(records)
                config = changed[index]["semantics"]["source_media_config"]["value"][0]
                field = next(
                    config[f]
                    for f in ["projectile", "trash_holder_visual"]
                    if config[f]["state"] == "KNOWN"
                )
                field["value"]["media"][key] = value
                with self.assertRaisesRegex(
                    ValueError, "MEDIA_ALL_DECLARED_VALUES_AND_DOMAINS"
                ):
                    admission.verify(changed, self.gate, role)
            for change in ["phase", "complement", "none"]:
                changed = copy.deepcopy(records)
                config = changed[index]["semantics"]["source_media_config"]["value"][0]
                if change == "phase":
                    config["phase"] = "AFTER_LUA"
                elif change == "complement":
                    field = next(
                        f
                        for f in ["projectile", "trash_holder_visual"]
                        if config[f]["state"] == "UNKNOWN"
                    )
                    config[field] = {"state": "NOT_APPLICABLE"}
                else:
                    config["projectile"] = {
                        "state": "KNOWN",
                        "value": {
                            "assignment": "IGNORED_NONE",
                            "media": {
                                "source_cut": config["source_cut"],
                                "namespace": "SHOOT_TYPE",
                                "member": "CONST_ANI_NONE",
                                "own_value": 0,
                            },
                        },
                    }
                with self.assertRaisesRegex(
                    ValueError, "MEDIA_ALL_DECLARED_VALUES_AND_DOMAINS"
                ):
                    admission.verify(changed, self.gate, role)

    def test_normal_form_only_exact_unknown_additions(self):
        proof = json.loads(
            (
                ROOT
                / "imports/ots-native-admission/source-media-observations/native-normal-form-successor.json"
            ).read_bytes()
        )
        self.assertEqual(proof["target_count"], 142)
        key = proof["targets"][0]["key"]
        for role, records in self.views.items():
            index = next(
                i for i, r in enumerate(records) if r["identity"]["key"] == key
            )
            for mutation in ("missing", "known", "extra"):
                changed = copy.deepcopy(records)
                fields = changed[index]["semantics"]
                if mutation == "missing":
                    del fields["weapon"]
                elif mutation == "known":
                    fields["weapon"] = {"state": "KNOWN", "value": {}}
                else:
                    fields["weapon"] = {"state": "UNKNOWN", "extra": 1}
                with self.assertRaisesRegex(
                    ValueError, "MEDIA_WHOLE_PARENT_PRESERVATION"
                ):
                    admission.verify(changed, self.gate, role)

    def test_known_legacy_sibling_core_901_and_world_fenced(self):
        for role, records in self.views.items():
            target = next(
                i for i, r in enumerate(records) if r["identity"]["key"] in self.keys
            )
            changed = copy.deepcopy(records)
            changed[target]["materializable"] = not changed[target]["materializable"]
            with self.assertRaisesRegex(ValueError, "MEDIA_WHOLE_PARENT_PRESERVATION"):
                admission.verify(changed, self.gate, role)
            changed = copy.deepcopy(records)
            sibling = next(
                i
                for i, r in enumerate(records)
                if r["identity"]["key"] in self.keys
                and r.get("semantics", {}).get("protection", {}).get("state") == "KNOWN"
            )
            changed[sibling]["semantics"]["protection"] = {"state": "UNKNOWN"}
            with self.assertRaisesRegex(ValueError, "MEDIA_WHOLE_PARENT_PRESERVATION"):
                admission.verify(changed, self.gate, role)
            for key in ["oteryn:item.tibia.i901"]:
                changed = copy.deepcopy(records)
                idx = next(
                    i for i, r in enumerate(changed) if r["identity"]["key"] == key
                )
                changed[idx]["materializable"] = not changed[idx]["materializable"]
                with self.assertRaises(ValueError):
                    admission.verify(changed, self.gate, role)
            changed = copy.deepcopy(records)
            changed.append(copy.deepcopy(changed[0]))
            with self.assertRaisesRegex(ValueError, "MEDIA_DUPLICATE_RECORD"):
                admission.verify(changed, self.gate, role)
        changed = copy.deepcopy(self.views["reference"])
        idx = next(i for i, r in enumerate(changed) if r["kind"] != "Item")
        changed[idx]["client_projection"] = "ServerOnly"
        with self.assertRaisesRegex(ValueError, "MEDIA_OUTSIDE_PARENT_PRESERVATION"):
            admission.verify(changed, self.gate, "reference")


if __name__ == "__main__":
    unittest.main()

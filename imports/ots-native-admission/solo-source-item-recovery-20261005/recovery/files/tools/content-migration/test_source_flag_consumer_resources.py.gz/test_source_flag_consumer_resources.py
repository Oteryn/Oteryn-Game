"""Small resource law negatives; no full registry/Native/source reads."""

import unittest
from unittest.mock import patch

import flag_consumer_resources as resources


class Resources(unittest.TestCase):
    def test_intermediate_wrong_family_or_compressed_digest_rejected_before_reads(self):
        with patch.object(resources, "file_sha") as read:
            for manifest in (
                {},
                {"current_world_owner_pointer_family_domain": ["World"]},
                {"compressed_registry_sha256": "wrong"},
            ):
                with self.assertRaisesRegex(
                    ValueError, "FLAGS_FINAL_CONSUMER_RESOURCE_LAW"
                ):
                    resources.verify_resources("/missing-root", manifest)
            read.assert_not_called()

    def test_stream_hash_small_actual_bytes_and_changed_byte(self):
        import hashlib
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "resource"
            path.write_bytes(b"closed-source-resource")
            self.assertEqual(
                resources.file_sha(path), hashlib.sha256(path.read_bytes()).hexdigest()
            )
            old = resources.file_sha(path)
            path.write_bytes(b"changed-source-resource")
            self.assertNotEqual(resources.file_sha(path), old)


if __name__ == "__main__":
    unittest.main()

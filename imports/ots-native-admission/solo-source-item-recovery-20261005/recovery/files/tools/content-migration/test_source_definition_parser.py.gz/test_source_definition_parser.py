"""Own parser laws; no runtime or Native value coercion."""

import unittest

from item_source_definition_admission import replay_parameter


class OwnParser(unittest.TestCase):
    def test_ordered_duration_assignment_and_no_zero_instance_coercion(self):
        entry = {"parameter": {"kind": "DURATION"}, "source_cut": "CRYSTAL_FF7"}
        first = [
            {"key": "duration", "value_lexeme": "3600"},
            {"key": "duration", "value_lexeme": "300"},
        ]
        self.assertEqual(
            replay_parameter(entry, first, {})["default_duration_ms"], 300000
        )
        self.assertEqual(
            replay_parameter(entry, list(reversed(first)), {})["default_duration_ms"],
            3600000,
        )
        self.assertEqual(
            replay_parameter(entry, [{"key": "duration", "value_lexeme": "0"}], {})[
                "setter_disposition"
            ],
            "ZERO_SKIPS_INITIALIZATION",
        )
        with self.assertRaises(ValueError):
            replay_parameter(entry, [{"key": "duration", "value_lexeme": "-1"}], {})

    def test_fluid_own_namespace_and_u16_capacity_ranges(self):
        fluid = {"parameter": {"kind": "FLUID_SOURCE"}, "source_cut": "CRYSTAL_FF7"}
        result = replay_parameter(
            fluid,
            [{"key": "fluidsource", "value_lexeme": "blood"}],
            {"CRYSTAL_FF7": {"blood": ["FLUID_BLOOD", 5]}},
        )
        self.assertEqual(
            result, {"kind": "FLUID_SOURCE", "member": "FLUID_BLOOD", "own_value": 5}
        )
        with self.assertRaises(ValueError):
            replay_parameter(
                {"parameter": {"kind": "CONTAINER_CAPACITY"}},
                [{"key": "containersize", "value_lexeme": "65536"}],
                {},
            )


if __name__ == "__main__":
    unittest.main()

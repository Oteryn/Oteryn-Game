"""Closed SourceDefinition storage inverse before class/property/media gates."""

import copy
import gzip
import hashlib
import json
from pathlib import Path

PATH = "imports/ots-native-admission/source-definition-observations/definition-admissions.json.gz"
SHA256 = "488cd9821644cc8de669d0612135f3531ecee615013d64b202966d593a68c175"
REGISTRY = "apps/game-server/src/content/source-definition-registry.json"
REGISTRY_SHA = "dc1283b321a0de953eb97acb7c7875b72127b763a26df53f11391d04580d4c17"
PREREQUISITES = "imports/ots-native-admission/source-definition-observations/definition-prerequisites.json"
PREREQUISITES_SHA = "a9ee5f308a26fa63c4cc9672ec7bff45208e21a96ee223c2244d1b5f085058df"
FIELD = "source_definition_observations"
UNKNOWN = {"state": "UNKNOWN"}
CUTS = {
    "CANARY_47DF": (
        "canary",
        "47dfd51f45280a59a1d3e50ba7edd573d7234446",
        "canary-47df",
    ),
    "CRYSTAL_FF7": (
        "crystalserver",
        "ff7ede593c69d4c658b382c97443e8155926924a",
        "crystal-ff7",
    ),
    "CRYSTAL_00CE": (
        "crystalserver",
        "00ce02a57ca5a12e48f32a3476e37471167e4c3f",
        "crystal-00ce",
    ),
}


def encoded(v):
    return json.dumps(
        v, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()


def sha(v):
    return hashlib.sha256(v).hexdigest()


def require(test, message):
    if not test:
        raise ValueError(message)


def pinned(root, path, expected):
    require(
        not Path(path).is_absolute() and ".." not in Path(path).parts,
        "DEFINITION_SAFE_PATH",
    )
    raw = (root / path).read_bytes()
    require(sha(raw) == expected, "DEFINITION_INPUT_PIN:" + path)
    return raw


def unsigned(value, maximum):
    require(value.isascii() and value.isdecimal(), "DEFINITION_UNSIGNED_LEXEME")
    parsed = int(value)
    require(0 <= parsed <= maximum, "DEFINITION_UNSIGNED_RANGE")
    return parsed


def replay_parameter(entry, assignments, dictionaries):
    kind = entry["parameter"]["kind"]
    if kind == "DURATION":
        duration = None
        stop = UNKNOWN
        decay = UNKNOWN
        for a in assignments:
            key = a["key"].lower()
            value = a["value_lexeme"]
            if key == "duration":
                duration = unsigned(value, 2**32 - 1)
            elif key == "stopduration":
                require(value in ("0", "1", "true", "false"), "DEFINITION_BOOL_LEXEME")
                stop = {
                    "state": "KNOWN",
                    "value": value[0] in ("1", "t", "T", "y", "Y"),
                }
            elif key == "decayto":
                decay = {"state": "KNOWN", "value": unsigned(value, 65535)}
        require(duration is not None, "DEFINITION_DURATION_PRESENT")
        milliseconds = duration * 1000 % (2**32)
        status = (
            "ZERO_SKIPS_INITIALIZATION"
            if milliseconds == 0
            else "SAFE_SIGNED_EXACT"
            if duration <= 2147483
            else "HELD_WRAP_OR_SIGNED_SETTER"
        )
        return {
            "kind": kind,
            "decay_time_seconds": duration,
            "default_duration_ms": milliseconds,
            "setter_disposition": status,
            "explicit_stop_duration": stop,
            "explicit_decay_to": decay,
        }
    if kind == "CONTAINER_CAPACITY":
        require(
            assignments
            and all(a["key"].lower() == "containersize" for a in assignments),
            "DEFINITION_CONTAINER_KEY",
        )
        return {
            "kind": kind,
            "capacity": unsigned(assignments[-1]["value_lexeme"], 65535),
        }
    require(
        kind == "FLUID_SOURCE"
        and assignments
        and all(a["key"].lower() == "fluidsource" for a in assignments),
        "DEFINITION_FLUID_KEY",
    )
    member, value = "FLUID_NONE", 0
    for a in assignments:
        if a["value_lexeme"].lower() in dictionaries[entry["source_cut"]]:
            member, value = dictionaries[entry["source_cut"]][a["value_lexeme"].lower()]
    return {"kind": kind, "member": member, "own_value": value}


def load_gate(root, gate_path=None, prerequisites_path=None):
    root = Path(root)
    raw = (gate_path or root / PATH).read_bytes()
    require(sha(raw) == SHA256, "DEFINITION_GATE_PIN")
    gate = json.loads(gzip.decompress(raw))
    raw = (prerequisites_path or root / PREREQUISITES).read_bytes()
    require(sha(raw) == PREREQUISITES_SHA, "DEFINITION_PREREQUISITES_PIN")
    proof = json.loads(raw)
    registry = json.loads(pinned(root, REGISTRY, REGISTRY_SHA))
    require(
        registry["schema"] == "OTERYN_SOURCE_DEFINITION_OBSERVATIONS_CLOSED/v1"
        and gate["counts"] == {"targets": 4475, "observations": 9291, "views": 2},
        "DEFINITION_CLOSED_SCOPE",
    )
    bindings = {}
    for path, digest in proof["own_bindings_sha256"].items():
        for b in json.loads(pinned(root, path, digest))["bindings"]:
            tag = (
                b["source_key"],
                b["source_revision"],
                b["identity_namespace"],
                b["external_id"],
            )
            require(tag not in bindings, "DEFINITION_DUPLICATE_BINDING")
            bindings[tag] = b
    raw = pinned(
        root, proof["eligibility_replay"]["path"], proof["eligibility_replay"]["sha256"]
    )
    eligibility = {
        tuple(
            r["binding"][k]
            for k in (
                "source_key",
                "source_revision",
                "identity_namespace",
                "external_id",
            )
        ): r
        for r in json.loads(gzip.decompress(raw))["rows"]
    }
    xml = {}
    for path, digest in proof["xml_inputs"].items():
        raw = pinned(root, path, digest)
        label = Path(path).name.split(".")[0]
        xml[label] = {
            r["source_record"]["ordinal"]: r
            for r in map(json.loads, gzip.decompress(raw).decode().splitlines())
        }
    for path, digest in proof["proto_inputs"].items():
        pinned(root, path, digest)
    world_identities = set()
    for path, digest in proof["world_inputs"].items():
        doc = json.loads(pinned(root, path, digest))
        for row in doc.get("records", []):
            if "identity" in row:
                world_identities.add(encoded(row["identity"]))
    targets = {}
    observations = 0
    order = {"DURATION": 0, "CONTAINER_CAPACITY": 1, "FLUID_SOURCE": 2}
    cut_order = {cut: i for i, cut in enumerate(CUTS)}
    for row in gate["qualified"]:
        identity = row["identity"]
        tag = (identity["key"], identity["revision"])
        require(
            identity["family"] == "Item"
            and identity["key"] != "oteryn:item.tibia.i901"
            and tag not in targets,
            "DEFINITION_IDENTITY",
        )
        values = registry["targets"].get(identity["key"], {}).get(identity["revision"])
        require(
            row["child"] == {"state": "KNOWN", "value": values}
            and values
            and len(values) <= 6,
            "DEFINITION_EXACT_REGISTRY",
        )
        require(
            set(row["views"]) == {"canonical", "reference"}, "DEFINITION_BOTH_VIEWS"
        )
        require(
            len({(e["parameter"]["kind"], e["source_cut"]) for e in values})
            == len(values)
            and values
            == sorted(
                values,
                key=lambda e: (
                    order[e["parameter"]["kind"]],
                    cut_order[e["source_cut"]],
                ),
            ),
            "DEFINITION_CLOSED_ORDER",
        )
        for entry in values:
            provider, revision, label = CUTS[entry["source_cut"]]
            identifier = entry["external_item_id"]
            require(
                type(identifier) is int and 1 <= identifier <= 65535,
                "DEFINITION_OWN_ID",
            )
            btag = (
                f"oteryn:source.{provider}",
                revision,
                "ots/item_server_id",
                str(identifier),
            )
            binding = bindings.get(btag)
            require(
                binding
                and binding["disposition"] == "EXACT"
                and binding["target"] == identity,
                "DEFINITION_CURRENT_OWN_BINDING",
            )
            own = eligibility[btag]
            proto = own["prototype"]
            applied = [
                r
                for r in own["xml_records"]
                if r["disposition"] == "APPLIED_FULL_ORDERED_XML"
            ]
            require(
                not own["holds"]
                and own["xml_loaded"]
                and proto["flags_parent_count"] == 1
                and proto["explicit_id"]
                and proto["prototype_initialized"]
                and own["final_stored_id"] == identifier == own["source_id"]
                and len(applied) == 1,
                "DEFINITION_FRESH_LOADED_PROTO",
            )
            source = xml[label][entry["xml_record_ordinal"]]
            require(
                entry["phase"] == "FRESH_CPP_PROTOBUF_THEN_FULL_ORDERED_XML_BEFORE_LUA"
                and applied[0]["record_ordinal"] == entry["xml_record_ordinal"]
                and applied[0]["raw_xml_record_sha256"]
                == entry["xml_record_sha256"]
                == source["source_record"]["raw_xml_sha256"]
                and entry["prototype_message_sha256"] == proto["record_sha256"],
                "DEFINITION_OWN_PHASE_AND_BYTES",
            )
            require(
                entry["source_group"] == own["final_cpp_group"]
                and entry["current_world_owner_pointers"]
                == [r["world_identity"] for r in own["current_world_owner_routes"]],
                "DEFINITION_OWN_GROUP_WORLD_POINTER",
            )
            require(
                all(
                    encoded(pointer) in world_identities
                    for pointer in entry["current_world_owner_pointers"]
                ),
                "DEFINITION_CURRENT_WORLD_IDENTITY",
            )
            keys = {
                "DURATION": {"duration", "stopduration", "decayto"},
                "CONTAINER_CAPACITY": {"containersize"},
                "FLUID_SOURCE": {"fluidsource"},
            }[entry["parameter"]["kind"]]
            assignments = []
            for attribute in source["observations"]:
                if (
                    len(attribute["node_path"]) != 1
                    or attribute.get("key", "").lower() not in keys
                ):
                    continue
                attrs = {a["name"]: a for a in attribute["attributes"]}
                require(
                    "value" in attrs
                    and attrs["value"]["lexical_value"] == attrs["value"]["value"],
                    "DEFINITION_XML_VALUE",
                )
                assignments.append(
                    {
                        "key": attrs["key"]["lexical_value"],
                        "value_lexeme": attrs["value"]["lexical_value"],
                        "attribute_ordinal": attribute["node_path"][0],
                    }
                )
            require(
                entry["ordered_assignments"] == assignments
                and 1 <= len(assignments) <= 5
                and entry["parameter"]
                == replay_parameter(
                    entry, assignments, proof["own_fluid_dictionaries"]
                ),
                "DEFINITION_ORDERED_OWN_PARSER_RESULT",
            )
            observations += 1
        targets[tag] = row
    require(
        len(targets) == len(registry["targets"]) == 4475 and observations == 9291,
        "DEFINITION_COMPLETE_COHORT",
    )
    gate["_targets"] = targets
    return gate


def project_record(record, gate, role):
    require(role in ("canonical", "reference"), "DEFINITION_ROLE")
    if record["kind"] != "Item":
        return record
    identity = record["identity"]
    row = gate["_targets"].get((identity["key"], identity["revision"]))
    if row is None:
        require(
            record.get("semantics", {}).get(FIELD, UNKNOWN) == UNKNOWN,
            "DEFINITION_UNREGISTERED_CHILD",
        )
        return record
    view = row["views"][role]
    require(
        identity == row["identity"]
        and sha(encoded(record)) == view["after_record_sha256"]
        and record.get("semantics", {}).get(FIELD) == row["child"],
        "DEFINITION_EXACT_AFTER_PARENT",
    )
    result = copy.deepcopy(record)
    old = view["old_child"]
    if old["present"]:
        result["semantics"][FIELD] = copy.deepcopy(old["value"])
    else:
        result["semantics"].pop(FIELD)
    require(
        sha(encoded(result)) == view["before_record_sha256"],
        "DEFINITION_ONLY_APPROVED_SIBLING",
    )
    return result


def project_before(records, gate, role):
    seen = set()
    result = []
    for record in records:
        if record["kind"] == "Item":
            tag = (record["identity"]["key"], record["identity"]["revision"])
            require(tag not in seen, "DEFINITION_DUPLICATE_ITEM")
            seen.add(tag)
        result.append(project_record(record, gate, role))
    require(set(gate["_targets"]) <= seen, "DEFINITION_COMPLETE_ROLE")
    return result


def verify(records, gate, role):
    project_before(records, gate, role)

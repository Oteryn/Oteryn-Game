"""Closed Sourceclass expansion inverse, before historical11499/media377 inverses."""

import copy
import gzip
import hashlib
import json
from pathlib import Path

from item_source_property_admission import CUTS, encoded, pinned, require, sha

PATH = "imports/ots-native-admission/source-class-expansion33975/expansion-admissions.json.gz"
SHA256 = "0a5112520ee0675e5c2a622a924919e02df2b8a582081e3e3f08b5a6e4100a22"
CLASS = "apps/game-server/src/content/source-class-registry.json"
CLASS_SHA = "4aa07bfe87b96e72470b71d3a40f09e72c198ceb77296aeaf7b8c27f72c04935"
OLD_CLASS = "imports/ots-native-admission/source-property-observations/original-source-class-registry.json"
OLD_SHA = "bc33ac10473d2ee5530428f072766f534f9a6df0612cb3571aa86e971677961c"
FIELD = "source_class_observations"
UNKNOWN = {"state": "UNKNOWN"}


def load_gate(root):
    root = Path(root)
    raw = (root / PATH).read_bytes()
    require(sha(raw) == SHA256, "CLASS33975_GATE_PIN")
    gate = json.loads(gzip.decompress(raw))
    classes = pinned(root, CLASS, CLASS_SHA)
    old = pinned(root, OLD_CLASS, OLD_SHA)
    require(
        classes["schema"] == "OTERYN_SOURCE_CLASS_OBSERVATIONS_CLOSED_33975/v2",
        "CLASS33975_SCHEMA",
    )
    require(
        len(classes["targets"]) == 33975 and len(old["targets"]) == 11465,
        "CLASS33975_COUNTS",
    )
    for key, revisions in old["targets"].items():
        require(
            classes["targets"].get(key) == revisions, "CLASS33975_OLD_VECTOR_PRESERVED"
        )
    bindings = {}
    for relative, expected in gate["own_bindings_sha256"].items():
        for binding in pinned(root, relative, expected)["bindings"]:
            tag = (
                binding["source_key"],
                binding["source_revision"],
                binding["identity_namespace"],
                binding["external_id"],
            )
            require(tag not in bindings, "CLASS33975_AMBIGUOUS_BINDING")
            bindings[tag] = binding
    targets = {}
    for row in gate["qualified"]:
        identity = row["identity"]
        tag = (identity["key"], identity["revision"])
        require(
            identity["family"] == "Item"
            and identity["key"] != "oteryn:item.tibia.i901"
            and tag not in targets,
            "CLASS33975_IDENTITY",
        )
        desired = classes["targets"].get(identity["key"], {}).get(identity["revision"])
        require(
            row["child"] == {"state": "KNOWN", "value": desired}
            and identity["key"] not in old["targets"],
            "CLASS33975_NEW_CHILD",
        )
        for entry in desired:
            provider, revision, _ = CUTS[entry["source_cut"]]
            binding = {
                "source_key": f"oteryn:source.{provider}",
                "source_revision": revision,
                "identity_namespace": "ots/item_server_id",
                "external_id": str(entry["external_item_id"]),
                "target": identity,
                "disposition": "EXACT",
            }
            require(
                bindings.get(
                    tuple(
                        binding[k]
                        for k in (
                            "source_key",
                            "source_revision",
                            "identity_namespace",
                            "external_id",
                        )
                    )
                )
                == binding,
                "CLASS33975_OWN_BINDING",
            )
        require(
            set(row["views"]) == {"canonical", "reference"}, "CLASS33975_BOTH_VIEWS"
        )
        targets[tag] = row
    require(
        {t[0] for t in targets} == set(classes["targets"]) - set(old["targets"])
        and len(targets) == 22510,
        "CLASS33975_COMPLETE_EXPANSION",
    )
    # Independently match every registry observation to the frozen fresh-own replay.
    proof_path = root / gate["replay"]["path"]
    raw = proof_path.read_bytes()
    require(
        hashlib.sha256(raw).hexdigest() == gate["replay"]["sha256"],
        "CLASS33975_REPLAY_PIN",
    )
    replay = json.loads(gzip.decompress(raw))
    seen = set()
    for row in replay["rows"]:
        if row["source_id"] == 901:
            continue
        target = row["target"]
        binding = row["binding"]
        own = row["prototype"]
        require(
            not row["holds"]
            and row["xml_loaded"]
            and own["flags_parent_count"] == 1
            and own["explicit_id"]
            and own["prototype_initialized"],
            "CLASS33975_FRESH_PARENT",
        )
        cut = next(k for k, v in CUTS.items() if v[2] == row["source_label"])
        entry = next(
            v
            for v in classes["targets"][target["key"]][target["revision"]]
            if v["source_cut"] == cut
        )
        applied = [
            x
            for x in row["xml_records"]
            if x["disposition"] == "APPLIED_FULL_ORDERED_XML"
        ]
        primary = row["primarytype_raw"]
        market = own["raw_market_category"]
        primary = (
            None
            if primary is None
            else {k: primary[k] for k in ("raw", "stored_lowercase")}
        )
        market = (
            None
            if market.get("presence") == "ABSENT"
            else {
                k: market[k]
                for k in (
                    "raw_values",
                    "stored_presence",
                    "getter_member",
                    "getter_value",
                )
            }
        )
        require(
            len(applied) == 1
            and entry["xml_record_ordinal"] == applied[0]["record_ordinal"]
            and entry["raw_record_sha256"] == own["record_sha256"]
            and entry["cpp_kind"]
            == {k: row["final_cpp_kind"][k] for k in ("member", "own_value")}
            and entry["market_category"] == market
            and entry["primary_type"] == primary
            and entry["external_item_id"] == row["final_stored_id"] == row["source_id"],
            "CLASS33975_EXACT_OWN_REPLAY",
        )
        tag = tuple(
            binding[k]
            for k in (
                "source_key",
                "source_revision",
                "identity_namespace",
                "external_id",
            )
        )
        require(
            bindings.get(tag) == binding and tag not in seen,
            "CLASS33975_REPLAY_BINDING",
        )
        seen.add(tag)
    require(len(seen) == 45721, "CLASS33975_ALL45721_REPLAYED")
    gate["_targets"] = targets
    gate["_classes"] = classes["targets"]
    return gate


def project_record(record, gate, role):
    if record["kind"] != "Item":
        return record
    identity = record["identity"]
    tag = (identity["key"], identity["revision"])
    row = gate["_targets"].get(tag)
    if row is None:
        expected = gate["_classes"].get(identity["key"], {}).get(identity["revision"])
        wanted = UNKNOWN if expected is None else {"state": "KNOWN", "value": expected}
        require(
            record.get("semantics", {}).get(FIELD, UNKNOWN) == wanted,
            "CLASS33975_OUTSIDE_SCOPE",
        )
        return record
    require(
        role in row["views"] and identity == row["identity"], "CLASS33975_VIEW_IDENTITY"
    )
    view = row["views"][role]
    require(
        sha(encoded(record)) == view["after_record_sha256"], "CLASS33975_AFTER_PARENT"
    )
    result = copy.deepcopy(record)
    semantics = result["semantics"]
    require(semantics[FIELD] == row["child"], "CLASS33975_CHILD")
    for field in view["added_unknown_outer_fields"]:
        require(semantics.get(field) == UNKNOWN, "CLASS33975_NORMALIZATION")
        del semantics[field]
    if view["before_child_present"]:
        semantics[FIELD] = copy.deepcopy(view["before_child"])
    else:
        del semantics[FIELD]
    if not view["before_semantics_present"]:
        require(not semantics, "CLASS33975_SPARSE_SIBLING")
        del result["semantics"]
    require(
        sha(encoded(result)) == view["before_record_sha256"],
        "CLASS33975_ONLY_APPROVED_CHILD",
    )
    return result


def project_before(records, gate, role):
    seen = set()
    result = []
    for record in records:
        if record["kind"] == "Item":
            tag = (record["identity"]["key"], record["identity"]["revision"])
            require(tag not in seen, "CLASS33975_DUPLICATE_TARGET")
            seen.add(tag)
        result.append(project_record(record, gate, role))
    require(set(gate["_targets"]) <= seen, "CLASS33975_COMPLETE_VIEW")
    return result

"""Only sealed compressed compiler resource and exact retained Source raw bytes."""

import hashlib
from pathlib import Path

MODULE = "apps/game-server/src/content/reference_source_flags.rs"
MODULE_SHA = "f233bcb0bebb9287231a1d23c0e6d1bc4c4c34c74fabff60912e56e37e910194"
COMPRESSED = "apps/game-server/src/content/source-flag-read-write-registry.json.zst"
COMPRESSED_SHA = "a19959afb9fc4b51db1b1d2d92739d0275694e0b33b47d144f2b8d61661297db"
RAW = "apps/game-server/src/content/source-flag-read-write-registry.json"
RAW_SHA = "f9b0cae9b18722142c8afad2abb50ea7c453c604d6ec561b4265388d50fe5c2c"


def file_sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def verify_resources(root, consumer):
    root = Path(root)
    expected = {
        "registry_path": RAW,
        "registry_sha256": RAW_SHA,
        "consumer_module_sha256": MODULE_SHA,
        "compressed_registry_path": COMPRESSED,
        "compressed_registry_sha256": COMPRESSED_SHA,
        "compressed_registry_bytes": 3045363,
        "decoded_registry_bytes": 76768031,
        "predecessor_consumer_manifest_sha256": "a8f6cf2809c12531ce44204ecf71d0c4176bf0d5602818d667fead5cad34a07e",
        "current_world_owner_pointer_family_domain": ["Terrain", "WorldObject"],
    }
    if any(consumer.get(key) != value for key, value in expected.items()):
        raise ValueError("FLAGS_FINAL_CONSUMER_RESOURCE_LAW")
    for relative, digest, length in (
        (MODULE, MODULE_SHA, None),
        (COMPRESSED, COMPRESSED_SHA, 3045363),
        (RAW, RAW_SHA, 76768031),
    ):
        path = root / relative
        if (length is not None and path.stat().st_size != length) or file_sha(
            path
        ) != digest:
            raise ValueError("FLAGS_FINAL_CONSUMER_RESOURCE_PIN:" + relative)
    # No Python codec/dependency substitution: Rust independently checks decoded
    # length/window/SHA; portable vector readback consumes exact retained raw f9.
    return True

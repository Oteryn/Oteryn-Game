"""Closed Source377 post-install gate. Observations confer no runtime authority."""

import gzip
import hashlib
import json
from pathlib import Path

PATH = "imports/ots-native-admission/source-media-observations/media-admissions.json"
SHA256 = "5aef2afd3d488e6810b89b6ae819b4c4cf3575a40995f3a59912d06dd2ef6c02"
REGISTRY = "apps/game-server/src/content/source-media-registry.json"
REGISTRY_SHA256 = "963e4a7d2606191beac1161ec0c7627f0278ab99bc5efad30a2977d591497ecf"
FIELD = "source_media_config"
UNKNOWN = {"state": "UNKNOWN"}
COUNTS = {
    "targets": 266,
    "configs": 377,
    "projectile": 223,
    "visual": 154,
    "sounds": 0,
    "ignored_none": 0,
}


def encoded(value):
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        + "\n"
    ).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(encoded(value))


def require(test, message):
    if not test:
        raise ValueError(message)


def load_gate(root, gate_path=None):
    raw = (gate_path or root / PATH).read_bytes()
    require(sha(raw) == SHA256, "MEDIA_CLOSED_GATE_DIGEST")
    gate = json.loads(raw)
    require(
        gate["schema"] == "OTERYN_SOURCE_MEDIA_OBSERVATION_ADMISSIONS/v1"
        and gate["counts"] == COUNTS,
        "MEDIA_SCOPE",
    )
    require(
        sha((root / REGISTRY).read_bytes()) == REGISTRY_SHA256, "MEDIA_REGISTRY_DIGEST"
    )
    registry = json.loads((root / REGISTRY).read_bytes())
    for relative, expected in gate["source_input_sha256"].items():
        require(
            relative.startswith("imports/")
            and ".." not in Path(relative).parts
            and sha((root / relative).read_bytes()) == expected,
            "MEDIA_SOURCE_INPUT",
        )
    bindings = {
        p: json.loads((root / f"imports/{p}/bindings/items.json").read_bytes())[
            "bindings"
        ]
        for p in ("canary", "crystalserver")
    }
    grouped = {}
    for row in registry["declarations"]:
        grouped.setdefault((row["target_key"], row["target_revision"]), []).append(
            row["config"]
        )
    cut_order = {"CANARY_47DF": 0, "CRYSTAL_FF7": 1, "CRYSTAL_00CE": 2}
    for value in grouped.values():
        value.sort(key=lambda c: cut_order[c["source_cut"]])
    require(
        len(grouped) == 266 and sum(map(len, grouped.values())) == 377,
        "MEDIA_CLOSED_REGISTRY",
    )
    identities = []
    for row in gate["qualified"]:
        identity = row["identity"]
        identities.append(identity["key"])
        require(
            identity["family"] == "Item"
            and identity["key"] != "oteryn:item.tibia.i901",
            "MEDIA_IDENTITY",
        )
        require(
            row["child"]
            == {
                "state": "KNOWN",
                "value": grouped[(identity["key"], identity["revision"])],
            },
            "MEDIA_OWN_REGISTRY_VALUE",
        )
        for binding in row["own_bindings"]:
            provider = (
                "canary"
                if binding["source_key"] == "oteryn:source.canary"
                else "crystalserver"
            )
            require(
                binding in bindings[provider]
                and binding["disposition"] == "EXACT"
                and binding["identity_namespace"] == "ots/item_server_id"
                and binding["target"] == identity,
                "MEDIA_OWN_BINDING",
            )
    require(
        len(identities) == len(set(identities)) == 266, "MEDIA_DUPLICATE_GATE_TARGET"
    )
    require(
        sum(len(row["own_bindings"]) for row in gate["qualified"]) == 377,
        "MEDIA_OWN_WITNESSES",
    )
    # Independently replay present object/ID/flags-parent eligibility. No SDK defaults.
    for cut in registry["cuts"]:
        label = gate["cut_labels"][cut["tag"]]
        path = (
            root
            / f"imports/ots-source-evidence/upstream-items-source-first/protobuf/{label}-all-wire-records.jsonl.gz"
        )
        wanted = {
            r["config"]["external_item_id"]
            for r in registry["declarations"]
            if r["config"]["source_cut"] == cut["tag"]
        }
        observed_proto = {}
        with gzip.open(path, "rt") as stream:
            header = json.loads(next(stream))
            require(
                header["source"]["revision"] == cut["revision"], "MEDIA_OWN_PROTO_CUT"
            )
            for line in stream:
                record = json.loads(line)
                if record["namespace"] != "object":
                    continue
                ids = [f[5] for f in record["wire"] if f[0] == 1 and f[1] == 0]
                if not set(ids).intersection(wanted):
                    continue
                parents = [f for f in record["wire"] if f[0] == 3 and f[1] == 2]
                require(
                    record["field_number"] == 1
                    and record["wire_type"] == 2
                    and len(ids) == len(parents) == 1
                    and 1 <= ids[0] <= 65535,
                    "MEDIA_OWN_LOADED_PROTO",
                )
                require(ids[0] not in observed_proto, "MEDIA_DUPLICATE_OWN_PROTO")
                observed_proto[ids[0]] = sha(bytes.fromhex(record["raw_hex"]))
        require(
            observed_proto
            == {int(k): v for k, v in gate["own_proto_raw_sha256"][cut["tag"]].items()},
            "MEDIA_OWN_PROTO_PRESERVATION",
        )
    return gate


def observed(record):
    return record.get("semantics", {}).get(FIELD, UNKNOWN)


def verify(records, gate, role):
    require(role in ("canonical", "reference"), "MEDIA_VIEW")
    identities = [r["identity"]["key"] for r in records]
    require(len(identities) == len(set(identities)), "MEDIA_DUPLICATE_RECORD")
    require(len(records) == gate["record_counts"][role], "MEDIA_RECORD_COUNT")
    by_key = {r["identity"]["key"]: r for r in records}
    targets = {r["identity"]["key"]: r for r in gate["qualified"]}
    # Cover every Item complement: all four explicit states outside cohort are fenced.
    for key, record in by_key.items():
        if record["kind"] == "Item" and key not in targets:
            require(observed(record) == UNKNOWN, "MEDIA_UNDECLARED_CHILD")
    outside = {key: value for key, value in by_key.items() if key not in targets}
    require(
        digest(outside) == gate["outside_record_sha256"][role],
        "MEDIA_OUTSIDE_PARENT_PRESERVATION",
    )
    for key, row in targets.items():
        require(key in by_key, "MEDIA_MISSING_TARGET")
        record = by_key[key]
        require(
            record["kind"] == "Item" and record["identity"] == row["identity"],
            "MEDIA_FULL_NATIVE_IDENTITY",
        )
        require(
            observed(record) == row["child"], "MEDIA_ALL_DECLARED_VALUES_AND_DOMAINS"
        )
        require(
            digest(record) == row["after_record_sha256"][role],
            "MEDIA_WHOLE_PARENT_PRESERVATION",
        )
    require(
        digest(by_key["oteryn:item.tibia.i901"]) == gate["protected_901_sha256"][role],
        "MEDIA_CORE_901",
    )
    return COUNTS

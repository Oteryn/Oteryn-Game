"""Retained active Source configurations; syntax references confer no execution."""

import hashlib
import json
import re
from pathlib import Path

PATH = (
    "imports/ots-native-admission/source-combat-observations/combat-configurations.json"
)
UNKNOWN = {"state": "UNKNOWN"}
NAMESPACES = {
    "MagicEffectClasses": "MAGIC_EFFECT",
    "ShootType_t": "SHOOT_TYPE",
    "SoundEffect_t": "SOUND_EFFECT",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(test, reason):
    if not test:
        raise ValueError(reason)


def syntax(raw):
    result = []
    for line, text in enumerate(raw.splitlines(), 1):
        kinds = []
        for token, kind in [
            ("setParameter(", "COMBAT_PARAMETER"),
            ("setArea(", "COMBAT_AREA_ARGUMENT"),
            ("createCombatArea(", "COMBAT_AREA_DECLARATION"),
            ("setFormula(", "COMBAT_FORMULA_ARGUMENTS"),
            ("setCallback(", "COMBAT_CALLBACK_ARGUMENTS"),
            ("onUseWeapon", "WEAPON_CALLBACK_LITERAL"),
            ("function onGet", "LUA_FORMULA_FUNCTION_DECLARATION"),
            (":shootType(", "WEAPON_ITEMTYPE_PROJECTILE_SETTER_LITERAL"),
        ]:
            if token in text:
                kinds.append(kind)
        if kinds:
            result.append(
                {
                    "line": line,
                    "raw_line": text,
                    "kinds": kinds,
                    "source_resolution": "LITERAL_SYNTAX_ONLY",
                    "runtime_binding": UNKNOWN,
                    "evaluation": UNKNOWN,
                }
            )
    return result


def validate_catalog(catalog, media):
    require(
        catalog["schema"] == "OTERYN_SOURCE_COMBAT_ACTIVE_CONFIGURATIONS/v1",
        "COMBAT_CATALOG_SCHEMA",
    )
    cuts = {r["tag"]: r for r in media["cuts"]}
    found = {}
    for row in catalog["lua_file_observations"]:
        require(row["observation_id"] not in found, "COMBAT_CATALOG_DUPLICATE_FILE")
        require(
            sha(row["raw_utf8"].encode()) == row["raw_file_sha256"],
            "COMBAT_CATALOG_RAW_FILE",
        )
        require(
            row["own_revision"] == cuts[row["source_cut"]]["revision"],
            "COMBAT_CATALOG_OWN_REVISION",
        )
        require(
            row["configuration_literals"] == syntax(row["raw_utf8"]),
            "COMBAT_CATALOG_LITERAL_CONTEXT",
        )
        for literal in row["literal_combat_media_parameters"]:
            enum = literal["own_enum"]
            namespace = NAMESPACES[enum["namespace"]]
            require(
                cuts[row["source_cut"]]["enums"][namespace].get(enum["member"])
                == enum["own_value"]
                and enum["native_asset"] == UNKNOWN,
                "COMBAT_CATALOG_OWN_MEDIA_ENUM",
            )
            require(
                literal["own_enum"]["literal"]
                in row["raw_utf8"].splitlines()[literal["line"] - 1],
                "COMBAT_CATALOG_MEDIA_LINE",
            )
        for obj in row["weapon_objects"]:
            require(
                obj["runtime_registration_success"] == UNKNOWN,
                "COMBAT_CATALOG_REGISTRATION_UNKNOWN",
            )
        found[row["observation_id"]] = row
    require(
        len(found) == 24
        and sum(len(r["literal_combat_media_parameters"]) for r in found.values())
        == 64,
        "COMBAT_CATALOG_FULL_SOURCE_SCOPE",
    )
    require(
        len(catalog["cpp_global_rule_observations"]) == 20
        and len(catalog["cpp_sound_member_initializers"]) == 6,
        "COMBAT_CATALOG_CPP_SCOPE",
    )
    for row in catalog["cpp_global_rule_observations"]:
        require(
            sha(row["raw_function"].encode()) == row["raw_function_sha256"]
            and row["item_binding"] == UNKNOWN,
            "COMBAT_CATALOG_UNBOUND_CPP",
        )
    for row in catalog["cpp_sound_member_initializers"]:
        require(
            row["own_revision"] == cuts[row["source_cut"]]["revision"]
            and cuts[row["source_cut"]]["enums"]["SOUND_EFFECT"].get("SILENCE") == 0,
            "COMBAT_CATALOG_CTOR_OWN_ENUM",
        )
        require(
            row["own_enum"]
            == {"namespace": "SoundEffect_t", "member": "SILENCE", "own_value": 0}
            and row["item_binding"] == UNKNOWN
            and row["native_asset"] == UNKNOWN,
            "COMBAT_CATALOG_SILENCE_SOURCE_ONLY",
        )
    return found


def validate_reference(entry, catalog):
    slot = entry["lua_weapon_configuration"]
    if slot["state"] == "UNKNOWN":
        return
    require(slot["state"] == "KNOWN", "COMBAT_CATALOG_SLOT_STATE")
    value = slot["value"]
    files = {r["observation_id"]: r for r in catalog["lua_file_observations"]}
    row = files.get(value["observation_id"])
    require(
        row is not None
        and row["source_cut"] == entry["source_cut"]
        and row["phase"] == "LUA_FILE_DECLARATION_AND_CALLBACK_SOURCE_ONLY"
        and value["phase"] == "LUA_LITERAL_REGISTER_CONFIGURATION_SOURCE_ONLY",
        "COMBAT_CATALOG_OWN_REFERENCE",
    )
    objects = {r["weapon_object_ordinal"]: r for r in row["weapon_objects"]}
    obj = objects.get(value["weapon_object_ordinal"])
    require(
        obj is not None
        and obj["final_literal_id_at_register"] == entry["external_item_id"]
        and value["runtime_registration_success"] == UNKNOWN,
        "COMBAT_CATALOG_FINAL_OBJECT_ID",
    )
    require(
        obj["literal_id_setters"][-1]["value"] == entry["external_item_id"],
        "COMBAT_CATALOG_LAST_LITERAL_SETTER",
    )


def build(base):
    packet = json.loads(
        (
            base
            / "imports/ots-native-admission/source-combat-observations/source-combat-observations.json"
        ).read_bytes()
    )
    packet["schema"] = "OTERYN_SOURCE_COMBAT_ACTIVE_CONFIGURATIONS/v1"
    for row in packet["lua_file_observations"]:
        row["configuration_literals"] = syntax(row["raw_utf8"])
    packet["cpp_sound_member_initializers"] = []
    audit = Path("/dev/shm/oteryn-v6-generated/fx/weapon-sound-audit")
    seals = json.loads((audit / "freeze.json").read_bytes())["files"]
    for cut, tag in [
        ("canary-47df", "CANARY_47DF"),
        ("crystal-ff7", "CRYSTAL_FF7"),
        ("crystal-00ce", "CRYSTAL_00CE"),
    ]:
        name = cut + "-weapon-media-census.json"
        raw = (audit / name).read_bytes()
        require(sha(raw) == seals[name]["sha256"], "COMBAT_CATALOG_CTOR_PREREQUISITE")
        census = json.loads(raw)
        for file in census["files"]:
            if not file["path"].endswith((".hpp", ".h")):
                continue
            for hit in file["media_occurrences"]:
                if re.fullmatch(
                    r"\s*SoundEffect_t\s+(soundImpactEffect|soundCastEffect)\s*=\s*SoundEffect_t::SILENCE;\s*",
                    hit["text"],
                ):
                    packet["cpp_sound_member_initializers"].append(
                        {
                            "source_cut": tag,
                            "own_revision": census["revision"],
                            "path": file["path"],
                            "file_sha256": file["sha256"],
                            "git_blob_sha1": file["git_blob_sha1"],
                            "line": hit["line"],
                            "raw_line": hit["text"],
                            "raw_context": hit["context"],
                            "context_start": hit["context_start"],
                            "phase": "CPP_MEMBER_INITIALIZER_DECLARATION_SOURCE_ONLY",
                            "own_enum": {
                                "namespace": "SoundEffect_t",
                                "member": "SILENCE",
                                "own_value": 0,
                            },
                            "item_binding": UNKNOWN,
                            "native_asset": UNKNOWN,
                            "evaluation": UNKNOWN,
                            "priority": UNKNOWN,
                        }
                    )
    packet["source_packet_sha256"] = (
        "b71243f8466045d345fab1c3844c73fbd37190122ccb707238dda43830e3a0ff"
    )
    packet["runtime_activation"] = False
    raw = (
        json.dumps(packet, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        + "\n"
    ).encode()
    (base / PATH).write_bytes(raw)
    media = json.loads(
        (
            Path(
                "/tmp/oteryn-imbuement-proposal/apps/game-server/src/content/source-media-registry.json"
            )
        ).read_bytes()
    )
    validate_catalog(packet, media)
    print(
        json.dumps(
            {
                "catalog_sha256": sha(raw),
                "lua_files": 24,
                "media_parameters": 64,
                "configuration_literal_lines": sum(
                    len(r["configuration_literals"])
                    for r in packet["lua_file_observations"]
                ),
                "cpp_functions": 20,
                "sound_initializers": 6,
            }
        )
    )


if __name__ == "__main__":
    build(Path(__file__).parent)

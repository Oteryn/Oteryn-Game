"""Closed own-source navigation amendment; no Native classification or capability."""

from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

from appearance_membership import load_admitted
from item_engine_navigation import digest, family

ROOT = Path(__file__).resolve().parents[2]
QUALIFICATION = (
    Path(__file__).parent
    / "samples/source-primary-navigation-55-world46-successor.json"
)
QUALIFICATION_SHA256 = (
    "f9b383a062c758031972bbd39211b07b44ed55ec375425bc8b48681fd5ddb648"
)


def qualified_property_projection(definition, entry):
    """Only sealed Source storage children may differ; original55 remains immutable."""
    if definition == entry["native_definition"] or entry["appearance_id"] == 35502:
        return definition
    raw = (
        ROOT / "tools/content-migration/samples/source55-property-child-successor.json"
    ).read_bytes()
    if (
        hashlib.sha256(raw).hexdigest()
        != "50cbe24c2e90403cf774b589daba0cb42cd35813aedef4f4085214a1f0877e7b"
    ):
        raise ValueError("SOURCE_PRIMARY_PROPERTY_CHILD_SEAL")
    proof = json.loads(raw)
    matches = [r for r in proof["records"] if r["target"] == entry["target"]]
    if len(matches) != 1 or proof["source55_sha256"] != QUALIFICATION_SHA256:
        raise ValueError("SOURCE_PRIMARY_PROPERTY_CHILD_SCOPE")
    row = matches[0]
    if (
        row["before_sha256"] != entry["native_definition_sha256"]
        or digest(definition) != row["after_sha256"]
    ):
        raise ValueError("SOURCE_PRIMARY_PROPERTY_CHILD_PARENT")
    projected = json.loads(json.dumps(definition))
    for name, value in row["children"].items():
        if (
            name not in proof["fields"]
            or definition.get("semantics", {}).get(name) != value
        ):
            raise ValueError("SOURCE_PRIMARY_PROPERTY_CHILD_VALUE")
        if name in entry["native_definition"].get("semantics", {}):
            projected["semantics"][name] = entry["native_definition"]["semantics"][name]
        else:
            projected["semantics"].pop(name)
    if projected != entry["native_definition"]:
        raise ValueError("SOURCE_PRIMARY_PROPERTY_OTHER_FIELD")
    return projected


def qualified_class_expansion_projection(definition, entry):
    """Restore one sealed own-source sibling before historical media qualification."""
    if entry["appearance_id"] != 35502 or definition == entry["native_definition"]:
        return definition
    path = (
        ROOT
        / "tools/content-migration/samples/source55-i35502-class33975-child-successor.json"
    )
    raw = path.read_bytes()
    if (
        hashlib.sha256(raw).hexdigest()
        != "1e3b91ae5b3a6478f06d3bd003901e2f869b8ede42b4282af0c12dd8d1671815"
    ):
        raise ValueError("SOURCE_PRIMARY_CLASS33975_CHILD_SEAL")
    proof = json.loads(raw)
    if (
        proof["schema"] != "OTERYN_SOURCE55_I35502_CLASS33975_CHILD_SUCCESSOR/v1"
        or proof["target"] != entry["target"]
        or proof["Source55_current_sha256"] != QUALIFICATION_SHA256
    ):
        raise ValueError("SOURCE_PRIMARY_CLASS33975_CHILD_SCOPE")
    if definition == proof["before_definition"]:
        return definition
    if (
        digest(definition) != proof["after_sha256"]
        or definition.get("semantics", {}).get("source_class_observations")
        != proof["child"]
    ):
        raise ValueError("SOURCE_PRIMARY_CLASS33975_CHILD_PARENT")
    projected = json.loads(json.dumps(definition))
    projected["semantics"].pop("source_class_observations")
    if (
        projected != proof["before_definition"]
        or digest(projected) != proof["before_sha256"]
    ):
        raise ValueError("SOURCE_PRIMARY_CLASS33975_OTHER_FIELD")
    return projected


@lru_cache(maxsize=1)
def _outer_source_gates(root):
    import item_source_flags_admission as flags
    import item_source_presentation_admission as names

    return (
        flags,
        flags.load_gate(root) if (root / flags.PATH).exists() else None,
        names,
        names.load_gate(root) if (root / names.PATH).exists() else None,
    )


def qualified_outer_source_projection(definition):
    """Only registered Flags then Names; all old Source55 guards still apply."""
    flags, fg, names, ng = _outer_source_gates(ROOT)
    for module, gate in ((flags, fg), (names, ng)):
        if gate is not None:
            definition = module.project_record(definition, gate, "canonical")
        elif definition.get("semantics", {}).get(
            module.FIELD, {"state": "UNKNOWN"}
        ) != {"state": "UNKNOWN"}:
            raise ValueError("SOURCE_PRIMARY_OUTER_SOURCE_WITHOUT_ADMISSION")
    return definition


def qualified_media_projection(definition, entry):
    """Only one sealed media child may differ from the immutable Source55 parent."""
    definition = qualified_outer_source_projection(definition)
    definition = qualified_class_expansion_projection(definition, entry)
    definition = qualified_property_projection(definition, entry)
    if definition == entry["native_definition"]:
        return definition
    if entry["appearance_id"] != 35502 or not isinstance(definition, dict):
        raise ValueError("SOURCE_PRIMARY_MEDIA_CHILD_SCOPE")
    path = (
        ROOT
        / "tools/content-migration/samples/source55-i35502-media-child-successor.json"
    )
    raw = path.read_bytes()
    if (
        hashlib.sha256(raw).hexdigest()
        != "428802b01071a08eec954f32424f960106ce9832f1359078e68dc24db639590e"
    ):
        raise ValueError(
            "SOURCE_PRIMARY_MEDIA_CHILD_428802b01071a08eec954f32424f960106ce9832f1359078e68dc24db639590e"
        )
    proof = json.loads(raw)
    if (
        proof["schema"] != "OTERYN_SOURCE55_MEDIA_CHILD_SUCCESSOR/v1"
        or proof["target"] != entry["target"]
        or proof["historical_source55"]["sha256"] != QUALIFICATION_SHA256
        or proof["before_media_present"] is not False
        or "source_media_config" in entry["native_definition"]["semantics"]
        or proof["before_native_definition_sha256"] != entry["native_definition_sha256"]
        or digest(definition) != proof["after_native_definition_sha256"]
        or definition.get("semantics", {}).get("source_media_config")
        != proof["source_media_config"]
    ):
        raise ValueError("SOURCE_PRIMARY_MEDIA_CHILD_GUARD")
    projected = json.loads(json.dumps(definition))
    projected["semantics"].pop("source_media_config")
    if (
        projected != entry["native_definition"]
        or digest(projected) != proof["before_native_definition_sha256"]
    ):
        raise ValueError("SOURCE_PRIMARY_MEDIA_OTHER_FIELD_CHANGED")
    return projected


def build_source_primary(definitions, client, excluded):
    raw = QUALIFICATION.read_bytes()
    if hashlib.sha256(raw).hexdigest() != QUALIFICATION_SHA256:
        raise ValueError("SOURCE_PRIMARY_QUALIFICATION_SEAL")
    document = json.loads(raw)
    records = document["records"]
    if len(records) != 55 or [r["appearance_id"] for r in records] != sorted(
        set(document["reviewed_ids"])
    ):
        raise ValueError("SOURCE_PRIMARY_CLOSED_SCOPE")
    for path, expected in document["input_sha256"].items():
        if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != expected:
            raise ValueError("SOURCE_PRIMARY_PINNED_INPUT:" + path)
    historical = document["historical_source_qualification"]
    old_raw = (ROOT / historical["path"]).read_bytes()
    if hashlib.sha256(old_raw).hexdigest() != historical["sha256"]:
        raise ValueError("SOURCE_PRIMARY_HISTORICAL101_SEAL")
    original = json.loads(old_raw)
    original_rows = {r["appearance_id"]: r for r in original["records"]}
    dispositions = document["world_navigation_dispositions"]
    import sys

    sys.path.insert(0, str(ROOT / "tools/content-schema/world-object-authoring"))
    from qualified_world import QUALIFICATION_SHA256 as WORLD_SHA
    from qualified_world import WIKI_IDS, validate_record

    if (
        len(dispositions) != 46
        or {d["appearance_id"] for d in dispositions} != WIKI_IDS
        or {r["appearance_id"] for r in records} | WIKI_IDS != set(original_rows)
        or document["owning_world_qualification"]["sha256"] != WORLD_SHA
    ):
        raise ValueError("SOURCE_PRIMARY_DISJOINT55_WORLD46_SCOPE")
    for record in records:
        if record != original_rows[record["appearance_id"]]:
            raise ValueError("SOURCE_PRIMARY_RETAINED_RECORD_CHANGED")
    for disposition in dispositions:
        iid = disposition["appearance_id"]
        if digest(original_rows[iid]) != disposition["historical_source_record_sha256"]:
            raise ValueError("SOURCE_PRIMARY_WORLD_TOMBSTONE_CHANGED")
        matches = [
            row
            for row in json.loads((ROOT / disposition["world_path"]).read_bytes())[
                "records"
            ]
            if row["identity"] == disposition["world_target"]
        ]
        if (
            len(matches) != 1
            or digest(matches[0]) != disposition["world_record_sha256"]
            or matches[0]["provenance"]["item_pointer"] != disposition["target"]
            or validate_record(matches[0])
        ):
            raise ValueError("SOURCE_PRIMARY_WORLD_OWNER_CHANGED")
    _, manifests = load_admitted()
    members = {
        label: {row[0]: row for row in m["entries"]} for label, m in manifests.items()
    }
    carriers = {
        provider: json.loads(
            (ROOT / f"imports/{provider}/bindings/items.json").read_bytes()
        )["bindings"]
        for provider in ("crystalserver", "canary")
    }
    result = []
    for entry in records:
        key = entry["target"]["key"]
        if key in excluded:
            continue  # Earlier admitted labels and World owner routes retain precedence.
        item_id = entry["appearance_id"]
        source = entry["own_source"]
        binding = source["binding"]
        provider = binding["source_key"].rsplit(".", 1)[1]
        same_id = [b for b in carriers[provider] if b["external_id"] == str(item_id)]
        same_target = [b for b in carriers[provider] if b["target"]["key"] == key]
        definition = definitions.get(key)
        appearance = client.get(item_id)
        guarded_definition = qualified_media_projection(definition, entry)
        if (
            item_id == 901
            or same_id != [binding]
            or same_target != [binding]
            or binding["disposition"] != "EXACT"
            or binding["identity_namespace"] != "ots/item_server_id"
            or binding["target"] != entry["target"]
            or entry["target"]
            != {
                "family": "Item",
                "key": f"oteryn:item.tibia.i{item_id}",
                "revision": "definition-r1",
            }
            or guarded_definition != entry["native_definition"]
            or digest(guarded_definition) != entry["native_definition_sha256"]
            or definition.get("materializable") is not False
            or definition.get("stack_class") != "Unknown"
            or appearance != entry["official_appearance"]
            or digest(appearance) != entry["official_appearance_sha256"]
            or members[source["membership_label"]].get(item_id) != source["own_member"]
            or members["client-15.30"].get(item_id) != source["current_member"]
            or source["own_member"][1] != source["current_member"][1]
        ):
            raise ValueError("SOURCE_PRIMARY_OWN_IDENTITY_CURRENT_NATIVE_GUARD")
        predicate = {
            "appearance_id": item_id,
            "xml_record": source["xml_record"],
            "xml_record_sha256": source["xml_record_sha256"],
            "profile": entry["profile"],
            "basis": "OWN_CRYSTAL_ATTRIBUTES_OR_CURRENT_CLOTHES",
        }
        family(predicate, source["own_appearance"]["flags"])
        family(predicate, appearance["flags"])
        presentation = definition.get("semantics", {}).get("presentation", {})
        name = presentation.get("value", {}).get("name", {})
        names = [
            v.strip().casefold()
            for v in (
                appearance.get("name"),
                source["xml_record"].get("name"),
                name.get("value") if name.get("state") == "KNOWN" else None,
            )
            if v
        ]
        if (
            not names
            or len(set(names)) != 1
            or presentation.get("state") in ("CONFLICT", "NOT_APPLICABLE")
            or name.get("state") in ("CONFLICT", "NOT_APPLICABLE")
        ):
            raise ValueError("SOURCE_PRIMARY_PRESENTATION_GUARD")
        primary = source["xml_record"]["attrs"].get("primarytype")
        known = isinstance(primary, str) and bool(primary.strip())
        result.append(
            {
                "target": entry["target"],
                "source_taxonomy": {
                    "primary": primary if known else "Source primarytype absent"
                },
                "family_profile": entry["profile"],
                "source_evidence": {
                    "classification": "DERIVED",
                    "scope": "NAVIGATION_ONLY",
                    "snapshot": QUALIFICATION.relative_to(ROOT).as_posix(),
                    "snapshot_file_sha256": QUALIFICATION_SHA256,
                    "engine_revision": binding["source_revision"],
                    "identity_binding": binding,
                    "source_primarytype": {"state": "KNOWN", "value": primary}
                    if known
                    else {"state": "UNKNOWN", "reason": "ABSENT_OR_EMPTY"},
                    "family_basis": "OWN_SOURCE_ATTRIBUTES_OR_ACCEPTED_RING_HEAD_COORDINATE",
                    "own_record_sha256": source["xml_record_sha256"],
                    "own_membership": source["own_member"],
                    "current_membership": source["current_member"],
                    "official_decoded_record_sha256": entry[
                        "official_appearance_sha256"
                    ],
                    "source_artifact_digests": document["source_pins"][
                        binding["source_revision"]
                    ],
                },
            }
        )
    return result


def check_source_projections(source_directories):
    """Check all selected XML/dat records against their own immutable raw capture."""
    from engine_items import load_appearance_objects, load_items_xml

    raw = QUALIFICATION.read_bytes()
    if hashlib.sha256(raw).hexdigest() != QUALIFICATION_SHA256:
        raise ValueError("SOURCE_PRIMARY_QUALIFICATION_SEAL")
    document = json.loads(raw)
    historical = document["historical_source_qualification"]
    old_raw = (ROOT / historical["path"]).read_bytes()
    if hashlib.sha256(old_raw).hexdigest() != historical["sha256"]:
        raise ValueError("SOURCE_PRIMARY_HISTORICAL101_SEAL")
    document["records"] = json.loads(old_raw)["records"]
    projections = {}
    for revision in {
        e["own_source"]["binding"]["source_revision"] for e in document["records"]
    }:
        directory = Path(source_directories[revision])
        xml = (directory / "data/items/items.xml").read_bytes()
        dat = (directory / "data/items/appearances.dat").read_bytes()
        pins = document["source_pins"][revision]
        if (
            hashlib.sha256(xml).hexdigest() != pins["xml_sha256"]
            or hashlib.sha256(dat).hexdigest() != pins["appearances_sha256"]
        ):
            raise ValueError("SOURCE_PRIMARY_RAW_SOURCE_PIN")
        projections[revision] = (load_items_xml(xml), load_appearance_objects(dat))
    for entry in document["records"]:
        source = entry["own_source"]
        xml, dat = projections[source["binding"]["source_revision"]]
        identifier = entry["appearance_id"]
        if (
            xml.get(identifier) != source["xml_record"]
            or dat.get(identifier) != source["own_appearance"]
            or digest(source["own_appearance"]) != source["own_appearance_sha256"]
        ):
            raise ValueError("SOURCE_PRIMARY_ACTUAL_OWN_PROJECTION")
    return len(document["records"])

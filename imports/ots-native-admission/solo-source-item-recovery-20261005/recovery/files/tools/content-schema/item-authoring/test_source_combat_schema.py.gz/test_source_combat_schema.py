"""Actual producer integration parity and closed Source-combat structural negatives."""

import copy
import gzip
import hashlib
import importlib.util
import json
import sys
import unittest
from pathlib import Path

import jsonschema

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
STAGE = BASE
sys.path.insert(0, str(STAGE))
sys.path.insert(0, str(BASE))


def builder(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT = STAGE
    module.TEMPLATES = STAGE / "templates"
    return module


class SourceCombatSchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw = gzip.decompress(
            (
                ROOT
                / "imports/ots-native-admission/source-combat-formal-fixtures/parent-item.schema.json.gz"
            ).read_bytes()
        )
        if (
            hashlib.sha256(raw).hexdigest()
            != "52de81eaf8eb7dcf08543405c47cab28329924b59204377dca2c006cc15ad210"
        ):
            raise AssertionError("SOURCE_COMBAT_EXACT_PARENT52DE_FIXTURE")
        cls.parent_schema = json.loads(raw)
        cls.new = builder(BASE / "build_formal_schema.py", "combat_builder")
        cls.schema = cls.new.build_item_schema()
        cls.field = cls.schema["$defs"]["sourceCombatObservations"]
        cls.validator = jsonschema.Draft202012Validator(cls.field)
        cls.rows = json.loads(
            (
                ROOT / "apps/game-server/src/content/source-combat-registry.json"
            ).read_bytes()
        )["rows"]

    def test_actual_item_producer_preserves_every_other_schema_field(self):
        old = self.parent_schema
        current = copy.deepcopy(self.schema)
        # Only these separately owned, registered Source siblings precede Combat.
        for field, definitions, reference in [
            (
                "source_presentation_observations",
                ["sourcePresentationObservations"],
                "sourcePresentationObservations",
            ),
            (
                "source_flag_read_write_observations",
                [
                    "sourceFlagReadWriteParameter",
                    "sourceFlagReadWriteObservation",
                    "sourceFlagReadWriteObservations",
                ],
                "sourceFlagReadWriteObservations",
            ),
        ]:
            if field in current["properties"]:
                self.assertEqual(
                    current["properties"][field], {"$ref": "#/$defs/" + reference}
                )
                for definition in definitions:
                    self.assertIn(definition, current["$defs"])
                    del current["$defs"][definition]
                del current["properties"][field]
            else:
                for definition in definitions:
                    self.assertNotIn(definition, current["$defs"])
        del current["$defs"]["sourceCombatObservations"]
        del current["properties"]["source_combat_observations"]
        self.assertEqual(current, old)
        for fn, filename in [
            ("build_dependencies_schema", "item-dependencies.schema.json"),
            ("build_real_source_evidence_schema", "real-source-evidence.schema.json"),
            ("build_manifest_schema", "item-import-readiness.schema.json"),
        ]:
            self.assertEqual(
                self.new.reference_item_defs(
                    getattr(self.new, fn)(self.schema), self.schema
                ),
                self.new.reference_item_defs(getattr(self.new, fn)(old), old),
            )
            self.assertEqual(
                self.new.reference_item_defs(
                    getattr(self.new, fn)(self.schema), self.schema
                ),
                json.loads((BASE / filename).read_bytes()),
            )
        jsonschema.Draft202012Validator.check_schema(self.schema)

    def test_ascii_own_symbol_and_reference_lengths_are_byte_exact(self):
        for row in self.rows:
            for entry in row["observations"]:
                if entry["melee_visual"]["state"] == "KNOWN":
                    entry["melee_visual"]["value"]["value"]["member"].encode("ascii")
                if entry["lua_weapon_configuration"]["state"] == "KNOWN":
                    entry["lua_weapon_configuration"]["value"]["observation_id"].encode(
                        "ascii"
                    )
                    value = {
                        "state": "KNOWN",
                        "value": copy.deepcopy(row["observations"]),
                    }
                    for item in value["value"]:
                        if item["lua_weapon_configuration"]["state"] == "KNOWN":
                            item["lua_weapon_configuration"]["value"][
                                "observation_id"
                            ] = "😀"
                    self.assertFalse(self.validator.is_valid(value))

    def test_real35_rows_unknown_omit_and_allstate_negatives(self):
        self.validator.validate({"state": "UNKNOWN"})
        for row in self.rows:
            self.validator.validate({"state": "KNOWN", "value": row["observations"]})
        for value in [
            {"state": "CONFLICT"},
            {"state": "NOT_APPLICABLE"},
            {"state": "KNOWN", "value": []},
            {"state": "UNKNOWN", "extra": 1},
        ]:
            self.assertFalse(self.validator.is_valid(value))
        for row in self.rows:
            for mode in ["runtime", "owner", "phase", "namespace", "foreign_cut"]:
                value = {"state": "KNOWN", "value": copy.deepcopy(row["observations"])}
                entry = value["value"][0]
                if mode == "runtime":
                    entry["evaluation"] = {"state": "KNOWN", "value": None}
                elif entry["melee_visual"]["state"] == "KNOWN":
                    known = entry["melee_visual"]["value"]
                    if mode == "owner":
                        known["owner"] = "LUA_WEAPON_OBJECT_FILE_CONTEXT"
                    elif mode == "phase":
                        known["phase"] = (
                            "LUA_LITERAL_REGISTER_CONFIGURATION_SOURCE_ONLY"
                        )
                    elif mode == "namespace":
                        known["value"]["namespace"] = "SOUND_EFFECT"
                    else:
                        known["value"]["source_cut"] = "CANARY_47DF"
                else:
                    known = entry["lua_weapon_configuration"]["value"]
                    if mode == "owner":
                        known["owner"] = "CPP_ITEMTYPE_MELEE_ATTACK_EFFECT"
                    elif mode == "phase":
                        known["phase"] = "XML_ITEMTYPE_BEFORE_LUA"
                    else:
                        known["runtime_registration_success"] = {
                            "state": "NOT_APPLICABLE"
                        }
                self.assertFalse(self.validator.is_valid(value))


if __name__ == "__main__":
    unittest.main()

"""Owning-builder schema regressions; structural acceptance is not Source admission."""

import copy
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

import build_formal_schema as builder

ROOT = Path(__file__).parent


class SourcePropertyFormalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema = builder.build_item_schema()
        cls.validator = Draft202012Validator(cls.schema)
        cls.fixture = json.loads(
            (ROOT / "source-property-formal-test-fixtures.json").read_bytes()
        )
        cls.base = cls.fixture["grammar_only_authoring_template"]

    def doc(self, values):
        result = copy.deepcopy(self.base)
        result.update(copy.deepcopy(values))
        return result

    def test_exact_generated_schema_and_legacy_template(self):
        self.assertEqual(
            self.schema, json.loads((ROOT / "item.schema.json").read_bytes())
        )
        self.validator.validate(self.base)
        for name, value in self.fixture["registered_vectors"].items():
            self.validator.validate(
                self.doc({name: {"state": "KNOWN", "value": value}})
            )

    def test_all_outer_states_and_unknown_omission(self):
        self.validator.validate(self.doc({}))
        for name in ["source_class_observations", "source_scalar_observations"]:
            for value in [
                {"state": "UNKNOWN"},
                {"state": "NOT_APPLICABLE"},
                {"state": "CONFLICT"},
                {"state": "KNOWN", "value": []},
            ]:
                self.validator.validate(self.doc({name: value}))
        # Closed Source membership separately rejects Knownempty, NA and Conflict.

    def test_closed_own_class_domains_and_required_raw_evidence(self):
        value = self.fixture["registered_vectors"]["source_class_observations"]
        for mutation in [
            lambda v: v[0].update(source_cut="FOREIGN"),
            lambda v: v[0].update(phase="RUNTIME"),
            lambda v: v[0]["cpp_kind"].update(own_value=44),
            lambda v: v[0].update(external_item_id=65536),
            lambda v: v[0].update(raw_record_sha256="not-a-digest"),
            lambda v: v[0].pop("market_category"),
        ]:
            with self.subTest(mutation=mutation):
                changed = copy.deepcopy(value)
                mutation(changed)
                self.assertTrue(
                    list(
                        self.validator.iter_errors(
                            self.doc(
                                {
                                    "source_class_observations": {
                                        "state": "KNOWN",
                                        "value": changed,
                                    }
                                }
                            )
                        )
                    )
                )

    def test_scalar_units_signedness_and_lexemes_are_not_coerced(self):
        value = self.fixture["registered_vectors"]["source_scalar_observations"]
        for mutation in [
            lambda v: v[0].update(unit="KG"),
            lambda v: v[0].update(cpp_signed_value=2**31),
            lambda v: v[0]["getter_value"]["value"].update(value=-1),
            lambda v: v[0].update(ordered_original_lexemes=["changed-long-lexeme"]),
            lambda v: v[0].update(origin="DEFAULT_FROM_ABSENT_WIRE"),
        ]:
            changed = copy.deepcopy(value)
            mutation(changed)
            self.assertTrue(
                list(
                    self.validator.iter_errors(
                        self.doc(
                            {
                                "source_scalar_observations": {
                                    "state": "KNOWN",
                                    "value": changed,
                                }
                            }
                        )
                    )
                )
            )

    def test_documented_utf8_byte_bounds_hold_for_closed_ascii_cohort(self):
        for name, mutate in [
            (
                "source_class_observations",
                lambda v: v[0]["cpp_kind"].update(member="😀" * 32),
            ),
            (
                "source_class_observations",
                lambda v: v[0]["primary_type"].update(raw="😀" * 64),
            ),
            (
                "source_scalar_observations",
                lambda v: v[0].update(ordered_original_lexemes=["😀" * 6]),
            ),
        ]:
            value = copy.deepcopy(self.fixture["registered_vectors"][name])
            mutate(value)
            self.assertTrue(
                list(
                    self.validator.iter_errors(
                        self.doc({name: {"state": "KNOWN", "value": value}})
                    )
                )
            )

    def test_no_unknown_authoring_field_or_state_payload_shape(self):
        for values in [
            {"unqualified_source_field": {}},
            {"source_class_observations": {"state": "UNKNOWN", "value": []}},
            {"source_scalar_observations": {"state": "KNOWN"}},
        ]:
            self.assertTrue(list(self.validator.iter_errors(self.doc(values))))


if __name__ == "__main__":
    unittest.main()

"""Closed Sourcecombat DTO schema producer; no runtime/asset lowerings."""

import json
from pathlib import Path


def obj(properties):
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def const(value):
    return {"const": value}


def field(value):
    return {
        "oneOf": [
            obj({"state": const("UNKNOWN")}),
            obj({"state": const("KNOWN"), "value": value}),
        ]
    }


def source_combat_fields():
    cut = {"enum": ["CANARY_47DF", "CRYSTAL_FF7", "CRYSTAL_00CE"]}
    unknown = obj({"state": const("UNKNOWN")})
    enum_value = obj(
        {
            "source_cut": cut,
            "namespace": const("MAGIC_EFFECT"),
            "member": {
                "type": "string",
                "minLength": 1,
                "maxLength": 96,
                "pattern": "^[A-Z0-9_]+$",
            },
            "own_value": {"type": "integer", "minimum": 0, "maximum": 65535},
        }
    )
    melee = obj(
        {
            "phase": const("XML_ITEMTYPE_BEFORE_LUA"),
            "owner": const("CPP_ITEMTYPE_MELEE_ATTACK_EFFECT"),
            "emission_semantics": const("CRYSTAL_CREATURE_SQUARE_MARK_WEAPON_TYPE"),
            "record_ordinal": {"type": "integer", "minimum": 0, "maximum": 4294967295},
            "raw_record_sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
            "value": enum_value,
        }
    )
    lua = obj(
        {
            "phase": const("LUA_LITERAL_REGISTER_CONFIGURATION_SOURCE_ONLY"),
            "owner": const("LUA_WEAPON_OBJECT_FILE_CONTEXT"),
            "emission_semantics": const(
                "SEPARATE_COMBAT_OBJECT_CALLBACK_PARAMETERS_BEFORE_EXECUTION"
            ),
            "observation_id": {
                "type": "string",
                "minLength": 1,
                "maxLength": 160,
                "pattern": "^[ -~]+$",
            },
            "weapon_object_ordinal": {
                "type": "integer",
                "minimum": 0,
                "maximum": 65535,
            },
            "runtime_registration_success": unknown,
        }
    )
    entry = obj(
        {
            "source_cut": cut,
            "external_item_id": {
                "type": "integer",
                "minimum": 1,
                "maximum": 65535,
                "not": const(901),
            },
            "melee_visual": field(melee),
            "lua_weapon_configuration": field(lua),
            **{
                name: unknown
                for name in [
                    "runtime_actor_binding",
                    "runtime_predicate_binding",
                    "evaluation",
                    "priority",
                    "runtime_dispatch",
                ]
            },
        }
    )
    entry["allOf"] = [
        {
            "anyOf": [
                {
                    "properties": {
                        "melee_visual": {"properties": {"state": const("KNOWN")}}
                    }
                },
                {
                    "properties": {
                        "lua_weapon_configuration": {
                            "properties": {"state": const("KNOWN")}
                        }
                    }
                },
            ]
        },
        {
            "if": {"properties": {"source_cut": const("CANARY_47DF")}},
            "then": {"properties": {"melee_visual": unknown}},
        },
    ]
    for own_cut in cut["enum"]:
        entry["allOf"].append(
            {
                "if": {"properties": {"source_cut": const(own_cut)}},
                "then": {
                    "properties": {
                        "melee_visual": {
                            "properties": {
                                "value": {
                                    "properties": {
                                        "value": {
                                            "properties": {"source_cut": const(own_cut)}
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
            }
        )
    return {
        "sourceCombatObservations": field(
            {"type": "array", "minItems": 1, "maxItems": 3, "items": entry}
        )
    }


if __name__ == "__main__":
    schema = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "urn:oteryn:source-combat-storage:v1",
        **obj(
            {
                "source_combat_observations": source_combat_fields()[
                    "sourceCombatObservations"
                ]
            }
        ),
    }
    (Path(__file__).parent / "source-combat-storage.schema.json").write_text(
        json.dumps(schema, indent=2, sort_keys=True) + "\n"
    )

"""Actual patched authoring entrypoint must enforce Source byte and rawdecode laws."""

import json
import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parent
import validate_item as owner
from test_source_presentation_schema import fixture


class OwningValidatorTests(unittest.TestCase):
    def test_valid_authored_item_and_four_states_through_actual_entrypoint(self):
        item = json.loads((BASE / "synthetic-valid-item.json").read_bytes())
        deps = json.loads((BASE / "synthetic-valid-dependencies.json").read_bytes())
        self.assertEqual(owner.validate(item, deps)[0], [])
        for field in (
            fixture(),
            {"state": "UNKNOWN"},
            {"state": "CONFLICT"},
            {"state": "NOT_APPLICABLE"},
        ):
            item["source_presentation_observations"] = field
            self.assertEqual(owner.validate(item, deps)[0], [])

    def test_actual_authoring_entrypoint_rejects_utf8bytes_and_rawproto_mismatch(self):
        for kind in ("byte_limit", "description_lexeme", "proto_decode", "runtime"):
            field = fixture()
            row = field["value"][0]
            if kind == "byte_limit":
                row["ordinary_name_candidate"] = "😀" * 14
            elif kind == "description_lexeme":
                row["xml_description"]["value_lexeme"] = "😀" * 53
            elif kind == "proto_decode":
                row["proto_description"]["utf8"] = "î"
            else:
                row["external_item_id"] = 23721
            item = json.loads((BASE / "synthetic-valid-item.json").read_bytes())
            deps = json.loads((BASE / "synthetic-valid-dependencies.json").read_bytes())
            item["source_presentation_observations"] = field
            errors, _ = owner.validate(item, deps)
            self.assertTrue(
                any("item/source_presentation_observations:" in e for e in errors),
                (kind, errors),
            )


if __name__ == "__main__":
    unittest.main()

"""Small structural UTF8/proto-byte cases; full closed registry proof is separate."""

import copy
import unittest

from jsonschema import ValidationError
from validate_source_presentation_schema import validate_source_presentation_storage


def fixture():
    return {
        "state": "KNOWN",
        "value": [
            {
                "source_cut": "CANARY_47DF",
                "phase": "FRESH_CPP_PROTOBUF_THEN_FULL_ORDERED_XML_BEFORE_LUA",
                "runtime_lua_and_instance_overrides": "UNKNOWN",
                "external_item_id": 1,
                "prototype_message_sha256": "0" * 64,
                "xml_record_ordinal": 0,
                "xml_record_sha256": "0" * 64,
                "proto_name": {"stored_presence": False, "bytes_hex": "", "utf8": ""},
                "proto_description": {
                    "stored_presence": True,
                    "bytes_hex": "ee",
                    "utf8": None,
                },
                "xml_name": {"value_lexeme": "test", "decoded_value": "test"},
                "xml_article": {"value_lexeme": "", "decoded_value": ""},
                "xml_plural": None,
                "xml_description": {
                    "attribute_ordinal": 0,
                    "key": "description",
                    "value_lexeme": "î",
                    "decoded_value": "î",
                },
                "ordinary_name_candidate": "test",
                "ordinary_description_candidate": "î",
                "candidate_disposition": "ORDINARY_ASSIGNMENT_BEFORE_RUNTIME_OVERRIDES",
            }
        ],
    }


class SourceSchemaTests(unittest.TestCase):
    def test_invalid_bytes_explicit_empty_and_four_outer_states(self):
        validate_source_presentation_storage(fixture())
        for state in ("UNKNOWN", "CONFLICT", "NOT_APPLICABLE"):
            validate_source_presentation_storage({"state": state})

    def test_utf8_byte_limit_bytes_presence_runtime_and_closed_fields(self):
        for mutation in ("utf8", "bytes", "presence", "runtime", "map", "cut", "empty"):
            bad = copy.deepcopy(fixture())
            row = bad["value"][0]
            if mutation == "utf8":
                row["ordinary_name_candidate"] = "😀" * 14
            elif mutation == "bytes":
                row["proto_description"]["utf8"] = "î"
            elif mutation == "presence":
                row["proto_description"]["stored_presence"] = False
            elif mutation == "runtime":
                row["external_item_id"] = 23721
            elif mutation == "map":
                row["foreign_arbitrary_raw_map"] = {}
            elif mutation == "cut":
                row["source_cut"] = "FOREIGN"
            else:
                bad["value"] = []
            with self.subTest(mutation=mutation), self.assertRaises(ValidationError):
                validate_source_presentation_storage(bad)


if __name__ == "__main__":
    unittest.main()

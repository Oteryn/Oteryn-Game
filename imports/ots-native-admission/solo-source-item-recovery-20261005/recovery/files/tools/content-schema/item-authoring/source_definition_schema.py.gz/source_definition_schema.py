"""Optional flat SourceDefinition sibling; no runtime capability or artifact allocation."""

import json
from pathlib import Path


def source_definition_fields():
    schema = json.loads(
        (Path(__file__).parent / "source-definition-storage.schema.json").read_bytes()
    )
    if schema.get("$id") != "urn:oteryn:source-definition-storage-proposal:v1" or set(
        schema["properties"]
    ) != {"source_definition_observations"}:
        raise ValueError("unqualified SourceDefinition schema")
    return {
        "sourceDefinitionObservations": schema["properties"][
            "source_definition_observations"
        ]
    }

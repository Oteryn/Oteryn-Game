"""Typed Source storage siblings; current artifact V6 remains closed."""

import json
from pathlib import Path


def source_property_fields():
    schema = json.loads(
        (Path(__file__).parent / "source-property-storage.schema.json").read_bytes()
    )
    if schema.get("$id") != "urn:oteryn:source-property-storage-stage1:v1":
        raise ValueError("unsupported Source property storage schema")
    if set(schema["properties"]) != {
        "source_class_observations",
        "source_scalar_observations",
    }:
        raise ValueError("unexpected Source property storage siblings")
    return {
        "sourceClassObservations": schema["properties"]["source_class_observations"],
        "sourceScalarObservations": schema["properties"]["source_scalar_observations"],
    }

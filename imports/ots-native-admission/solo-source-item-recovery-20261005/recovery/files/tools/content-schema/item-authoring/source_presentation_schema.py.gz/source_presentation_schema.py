"""Optional flat authored Source presentation sibling; Native stores it under semantics."""

import json
from pathlib import Path


def source_presentation_fields():
    schema = json.loads(
        (Path(__file__).parent / "source-presentation-storage.schema.json").read_bytes()
    )
    if schema.get("$id") != "urn:oteryn:source-presentation-storage-proposal:v1":
        raise ValueError("Source presentation schema identity")
    return {
        "sourcePresentationObservations": schema["properties"][
            "source_presentation_observations"
        ]
    }

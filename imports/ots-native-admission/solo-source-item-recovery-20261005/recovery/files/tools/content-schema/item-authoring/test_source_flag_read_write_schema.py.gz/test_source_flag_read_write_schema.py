"""Portable owning formal test; the historical parent fixture is never repinned."""

import copy
import gzip
import hashlib
import importlib.util
import json
import sys
import unittest
from pathlib import Path

import jsonschema

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
sys.path.insert(0, str(BASE))


class SourceFlagReadWriteSchemaTests(unittest.TestCase):
    def test_registered_world_owner_families_and_fabricated_world_rejected(self):
        from source_flag_read_write_schema import source_flag_read_write_fields

        validator = jsonschema.Draft202012Validator(
            source_flag_read_write_fields()["sourceFlagReadWriteObservations"]
        )
        fixtures = json.loads(
            (
                ROOT
                / "imports/ots-native-admission/source-flag-read-write-formal-fixtures/registered-vectors.json"
            ).read_bytes()
        )["vectors"]
        seen = set()
        for fixture in fixtures:
            for row in fixture["value"]:
                if not row["current_world_owner_pointers"]:
                    continue
                seen.add(row["current_world_owner_pointers"][0]["family"])
                validator.validate({"state": "KNOWN", "value": fixture["value"]})
                changed = copy.deepcopy(row)
                changed["current_world_owner_pointers"][0]["family"] = "World"
                self.assertFalse(
                    validator.is_valid({"state": "KNOWN", "value": [changed]})
                )
        self.assertEqual(seen, {"Terrain", "WorldObject"})

    def test_current_producer_changes_only_measured_source_flags_law(self):
        fixture = (
            ROOT
            / "imports/ots-native-admission/source-flag-read-write-formal-fixtures/parent-presentation-item.schema.json.gz"
        )
        raw = gzip.decompress(fixture.read_bytes())
        self.assertEqual(
            hashlib.sha256(raw).hexdigest(),
            "2f49ff3c2d8294a67d8458a73150b4bf7e4222785b201bac54f44d417e2e990f",
        )
        old = json.loads(raw)
        spec = importlib.util.spec_from_file_location(
            "owning_flag_builder", BASE / "build_formal_schema.py"
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.ROOT = BASE
        module.TEMPLATES = BASE / "templates"
        new = module.build_item_schema()
        stripped = copy.deepcopy(new)
        del stripped["$defs"]["sourceFlagReadWriteParameter"]
        del stripped["$defs"]["sourceFlagReadWriteObservation"]
        del stripped["$defs"]["sourceFlagReadWriteObservations"]
        del stripped["properties"]["source_flag_read_write_observations"]
        self.assertEqual(stripped, old)
        validator = jsonschema.Draft202012Validator(
            new["$defs"]["sourceFlagReadWriteObservations"]
        )
        validator.validate({"state": "UNKNOWN"})
        vectors = json.loads(
            (
                ROOT
                / "imports/ots-native-admission/source-flag-read-write-formal-fixtures/registered-vectors.json"
            ).read_bytes()
        )["vectors"]
        for fixture in vectors:
            value = {"state": "KNOWN", "value": fixture["value"]}
            validator.validate(value)
            for pointer, bad in [
                (("parameter", "flags", "movable"), 1),
                (("parameter", "read_write", "max_text_length"), 65536),
                (
                    ("parameter", "prototype_flag_presence", "take"),
                    {"state": "KNOWN", "value": True},
                ),
                (("source_cut",), "OTHER"),
                (("phase",), "RUNTIME"),
            ]:
                changed = copy.deepcopy(value)
                node = changed["value"][0]
                for key in pointer[:-1]:
                    node = node[key]
                node[pointer[-1]] = bad
                self.assertFalse(validator.is_valid(changed))
            changed = copy.deepcopy(value)
            changed["value"] = changed["value"] * 3
            self.assertFalse(validator.is_valid(changed))
        assigned = next(
            row
            for fixture in vectors
            for row in fixture["value"]
            if row["ordered_assignments"]
        )
        for lexeme in ["12345", "😀"]:
            changed = copy.deepcopy(assigned)
            changed["ordered_assignments"][0]["value_lexeme"] = lexeme
            self.assertFalse(validator.is_valid({"state": "KNOWN", "value": [changed]}))
        for state in ["KNOWN", "NOT_APPLICABLE", "CONFLICT"]:
            self.assertFalse(validator.is_valid({"state": state}))
        for fn, filename in [
            ("build_dependencies_schema", "item-dependencies.schema.json"),
            ("build_real_source_evidence_schema", "real-source-evidence.schema.json"),
            ("build_manifest_schema", "item-import-readiness.schema.json"),
        ]:
            self.assertEqual(
                module.reference_item_defs(getattr(module, fn)(new), new),
                json.loads((BASE / filename).read_bytes()),
            )


if __name__ == "__main__":
    unittest.main()

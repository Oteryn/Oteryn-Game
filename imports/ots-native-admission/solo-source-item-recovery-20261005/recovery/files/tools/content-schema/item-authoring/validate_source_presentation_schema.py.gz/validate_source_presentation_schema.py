"""Source presentation UTF8 byte limits and exact proto decode, scoped to this DTO."""

import json
from pathlib import Path

from jsonschema import Draft202012Validator, ValidationError, validators


def utf8_bytes(validator, maximum, instance, schema):
    if isinstance(instance, str) and len(instance.encode("utf8")) > maximum:
        yield ValidationError("Source presentation UTF8 byte bound")


Validator = validators.extend(
    Draft202012Validator, {"x-oteryn-max-utf8-bytes": utf8_bytes}
)


def validate_source_presentation_storage(field):
    schema = json.loads(
        (Path(__file__).parent / "source-presentation-storage.schema.json").read_bytes()
    )
    Validator(schema).validate({"source_presentation_observations": field})
    if field["state"] != "KNOWN":
        return
    for row in field["value"]:
        for name in ("proto_name", "proto_description"):
            proto = row[name]
            raw = bytes.fromhex(proto["bytes_hex"])
            if not proto["stored_presence"] and raw:
                raise ValidationError("absent Source protobuf text carries bytes")
            try:
                expected = raw.decode("utf8")
            except UnicodeDecodeError:
                expected = None
            if proto["utf8"] != expected:
                raise ValidationError("Source protobuf bytes/UTF8 mismatch")
        if (
            row["external_item_id"] == 23721
            and row["xml_description"] is not None
            and row["candidate_disposition"] != "HELD_GOLD_POUCH_RUNTIME_CONFIG"
        ):
            raise ValidationError("Source runtime configuration unresolved")

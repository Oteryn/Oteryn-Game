"""Measured Source namespace flags observation; never Native flags or live IO."""

import copy
import json
from pathlib import Path

PARAMETER_SCHEMA_PATH = Path(__file__).with_name("flag-parameter.schema.json")


def source_flag_read_write_fields():
    parameter = json.loads(PARAMETER_SCHEMA_PATH.read_bytes())
    parameter.pop("$id", None)
    parameter.pop("$schema", None)
    integer = {"type": "integer", "minimum": 0, "maximum": 65535}
    sha = {"type": "string", "pattern": "^[0-9a-f]{64}$"}
    assignment = {
        "type": "object",
        "properties": {
            "key": {
                "enum": [
                    "writeable",
                    "maxtextlen",
                    "writeonceitemid",
                    "showcount",
                    "showcharges",
                    "showattributes",
                    "allowdistread",
                    "blockprojectile",
                    "allowpickupable",
                    "showduration",
                    "usedbyhouseguests",
                    "readable",
                    "movable",
                    "walkstack",
                    "replaceable",
                    "blocking",
                ]
            },
            "value_lexeme": {
                "type": "string",
                "maxLength": 4,
                "pattern": "^[\u0000-\u007f]*$",
            },
            "attribute_ordinal": integer,
        },
        "required": ["key", "value_lexeme", "attribute_ordinal"],
        "additionalProperties": False,
    }
    pointer = {
        "type": "object",
        "properties": {
            "family": {"enum": ["Terrain", "WorldObject"]},
            "key": {"type": "string"},
            "revision": {"type": "string"},
        },
        "required": ["family", "key", "revision"],
        "additionalProperties": False,
    }
    observation = {
        "type": "object",
        "properties": {
            "source_cut": {"enum": ["CANARY_47DF", "CRYSTAL_FF7", "CRYSTAL_00CE"]},
            "external_item_id": integer,
            "phase": {"const": "FRESH_CPP_PROTOBUF_THEN_FULL_ORDERED_XML_BEFORE_LUA"},
            "prototype_message_sha256": sha,
            "xml_record_ordinal": {
                "type": "integer",
                "minimum": 1,
                "maximum": 4294967295,
            },
            "xml_record_sha256": sha,
            "source_group": {
                "enum": [
                    "ITEM_GROUP_NONE",
                    "ITEM_GROUP_GROUND",
                    "ITEM_GROUP_CONTAINER",
                    "ITEM_GROUP_SPLASH",
                    "ITEM_GROUP_FLUID",
                ]
            },
            "current_world_owner_pointers": {
                "type": "array",
                "maxItems": 1,
                "items": pointer,
            },
            "ordered_assignments": {
                "type": "array",
                "maxItems": 3,
                "items": assignment,
            },
            "parameter": copy.deepcopy(parameter),
        },
        "additionalProperties": False,
    }
    observation["required"] = list(observation["properties"])
    return {
        "sourceFlagReadWriteParameter": copy.deepcopy(parameter),
        "sourceFlagReadWriteObservation": observation,
        "sourceFlagReadWriteObservations": {
            "oneOf": [
                {
                    "type": "object",
                    "properties": {"state": {"const": "UNKNOWN"}},
                    "required": ["state"],
                    "additionalProperties": False,
                },
                {
                    "type": "object",
                    "properties": {
                        "state": {"const": "KNOWN"},
                        "value": {
                            "type": "array",
                            "minItems": 1,
                            "maxItems": 2,
                            "items": copy.deepcopy(observation),
                        },
                    },
                    "required": ["state", "value"],
                    "additionalProperties": False,
                },
            ],
            "$comment": "StructuralSource shape only. Known data admission requires exactregisteredwholevectors/currentidentity+binding/fullconditional-normal-return closure+independentreview. ActualCPP/runtime execution Unknown; V7exportheld.",
        },
    }

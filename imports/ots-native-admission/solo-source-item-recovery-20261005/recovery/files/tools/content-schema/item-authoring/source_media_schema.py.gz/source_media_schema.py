"""Existing Source377 DTO in flat authoring; no Native asset inference."""

import json
from pathlib import Path


def source_media_field():
    schema = json.loads(
        (Path(__file__).parent / "source-media-config.schema.json").read_bytes()
    )
    if schema.get("$id") != "urn:oteryn:source-media-authoring-storage:v1":
        raise ValueError("unsupported Source media storage schema")
    return {
        key: value for key, value in schema.items() if key not in {"$schema", "$id"}
    }

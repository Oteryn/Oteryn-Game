"""Optional existing Source377 authoring carrier; no asset/runtime inference."""

import copy
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

import build_formal_schema as builder

ROOT = Path(__file__).parent


class SourceMediaFormalTests(unittest.TestCase):
    def test_exact_media_enum_cut_namespace_and_none_laws(self):
        item_schema = builder.build_item_schema()
        fixture = json.loads(
            (ROOT / "source-property-formal-test-fixtures.json").read_bytes()
        )
        base = fixture["grammar_only_authoring_template"]
        config = json.loads(
            (ROOT / "source-media-formal-test-fixture.json").read_bytes()
        )
        validator = Draft202012Validator(item_schema)

        def document(value):
            return {
                **copy.deepcopy(base),
                "source_media_config": {"state": "KNOWN", "value": [value]},
            }

        validator.validate(document(config))
        for change in [
            lambda v: v["projectile"]["value"]["media"].update(
                namespace="SOUND_EFFECT"
            ),
            lambda v: v["projectile"]["value"]["media"].update(own_value=65535),
            lambda v: v["projectile"]["value"]["media"].update(
                source_cut="CRYSTAL_FF7"
            ),
            lambda v: v["projectile"]["value"].update(assignment="IGNORED_NONE"),
        ]:
            changed = copy.deepcopy(config)
            change(changed)
            self.assertTrue(list(validator.iter_errors(document(changed))))
        for state in [
            {"state": "UNKNOWN"},
            {"state": "CONFLICT"},
            {"state": "NOT_APPLICABLE"},
            {"state": "KNOWN", "value": []},
        ]:
            validator.validate({**base, "source_media_config": state})


if __name__ == "__main__":
    unittest.main()

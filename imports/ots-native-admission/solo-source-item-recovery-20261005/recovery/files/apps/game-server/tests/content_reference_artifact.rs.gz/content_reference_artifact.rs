#![allow(clippy::expect_used, clippy::panic)]

use oteryn_game_server::content::*;

const B1_EVIDENCE: &[u8] = include_bytes!(
    "../../../docs/agents/evidence/OTV2-20260919-content-world-cw2-b1-item-identity-catalog.json"
);
const SECTION_ENTRY_LEN: usize = 48;
const MANIFEST_ENTRY: usize = 24;
const INDEX_ENTRY: usize = MANIFEST_ENTRY + SECTION_ENTRY_LEN;
const BODY_ENTRY: usize = INDEX_ENTRY + SECTION_ENTRY_LEN;

fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        max_documents: 6,
        max_document_bytes: 32_768,
        max_total_bytes: 65_536,
        max_json_depth: 20,
        max_decoded_fields: 1_024,
        max_string_bytes: 32_768,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: 1,
        max_import_records: 1,
        max_reimport_states: 2,
    }
}

fn canonical_documents() -> CanonicalProjectDocuments {
    let imported = protected_cw2_b1_vase_import(B1_EVIDENCE).expect("protected one-Item import");
    CanonicalProjectDocuments::from_draft(
        ProjectDraft {
            project_revision: "project-r1".to_owned(),
            package_key: "oteryn:content.world-project".to_owned(),
            semantic_schema_version: "reference-schema-v1".to_owned(),
            licensing_metadata: "PENDING".to_owned(),
            world_id: "0123456789ab70cd8ef0123456789abc".to_owned(),
            coordinate_frame: "global-target-2026-09-27".to_owned(),
            records: vec![imported.record],
            imports: vec![imported.batch],
            metadata: Vec::new(),
        },
        limits(),
    )
    .expect("canonical one-Item project")
}

fn linked_from_enumeration(
    reverse: bool,
) -> Result<CanonicalReferencePlayableContent, ProjectError> {
    let canonical = canonical_documents();
    let mut documents = canonical
        .documents()
        .iter()
        .map(|(locator, bytes)| (locator.clone(), bytes.clone()))
        .collect::<Vec<_>>();
    if reverse {
        documents.reverse();
    }
    ProjectSnapshot::new(documents, limits())?
        .parse(limits())?
        .link()
}

fn compiled() -> CompiledReferencePlayableContent {
    let linked = linked_from_enumeration(false).expect("linked one-Item project");
    compile_reference_playable(&linked).expect("compiled Reference artifact pair")
}

fn full_family_limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        max_documents: 8,
        max_document_bytes: 128_000_000,
        max_total_bytes: 220_000_000,
        max_json_depth: 24,
        max_decoded_fields: 3_000_000,
        max_string_bytes: 128_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT,
        max_import_records: CW2_B1_FULL_ITEM_FAMILY_COUNT,
        max_reimport_states: CW2_B1_FULL_ITEM_FAMILY_COUNT,
    }
}

type NamedItemSemantics = (&'static str, ReferenceItemSemantics, String);

fn typed_family_linked(
    cases: Vec<(&'static str, ReferenceItemSemantics)>,
) -> Result<(CanonicalReferencePlayableContent, Vec<NamedItemSemantics>), Box<dyn std::error::Error>>
{
    let schema = if cases
        .iter()
        .any(|(_, semantics)| semantics.requires_primary_source_observation_profile())
    {
        REFERENCE_PRIMARY_SOURCE_OBSERVATION_SCHEMA
    } else if cases
        .iter()
        .any(|(_, semantics)| semantics.requires_imbuement_ceiling_schema())
    {
        REFERENCE_IMBUEMENT_CEILING_SEMANTIC_SCHEMA
    } else {
        "reference-schema-v1"
    };
    typed_family_linked_with_schema(cases, schema)
}

fn typed_family_linked_with_schema(
    cases: Vec<(&'static str, ReferenceItemSemantics)>,
    semantic_schema_version: &str,
) -> Result<(CanonicalReferencePlayableContent, Vec<NamedItemSemantics>), Box<dyn std::error::Error>>
{
    let mut imported = protected_cw2_b1_full_item_family_import(B1_EVIDENCE)?;
    let mut selected = Vec::with_capacity(cases.len());
    let mut cases = cases.into_iter();
    for record in &mut imported.records {
        let ProjectReferenceRecord::Item {
            identity,
            semantics,
            ..
        } = record
        else {
            continue;
        };
        let Some((name, value)) = cases.next() else {
            break;
        };
        *semantics = value.clone();
        selected.push((name, value, identity.key.clone()));
    }
    assert!(cases.next().is_none(), "full family carries all Item cases");
    let canonical = CanonicalProjectDocuments::from_draft(
        ProjectDraft {
            project_revision: "project-r1".to_owned(),
            package_key: "oteryn:content.world-project".to_owned(),
            semantic_schema_version: semantic_schema_version.to_owned(),
            licensing_metadata: "PENDING".to_owned(),
            world_id: "0123456789ab70cd8ef0123456789abc".to_owned(),
            coordinate_frame: "global-target-2026-09-27".to_owned(),
            records: imported.records,
            imports: vec![imported.batch],
            metadata: Vec::new(),
        },
        full_family_limits(),
    )?;
    let linked = canonical
        .into_snapshot(full_family_limits())?
        .parse(full_family_limits())?
        .link()?;
    Ok((linked, selected))
}

fn promoted_family_linked() -> Result<CanonicalReferencePlayableContent, Box<dyn std::error::Error>>
{
    let promoted = protected_cw2_b1_item_semantic_promotion_lowering_v1_import(B1_EVIDENCE)?;
    assert_eq!(
        promoted.promoted_fields,
        ITEM_SEMANTIC_PROMOTION_LOWERING_V1_FIELD_COUNT
    );
    assert_eq!(
        promoted.promoted_items,
        ITEM_SEMANTIC_PROMOTION_LOWERING_V1_ITEM_COUNT
    );
    let canonical = CanonicalProjectDocuments::from_draft(
        ProjectDraft {
            project_revision: "project-r1".to_owned(),
            package_key: "oteryn:content.world-project".to_owned(),
            semantic_schema_version: "reference-schema-v1".to_owned(),
            licensing_metadata: "PENDING".to_owned(),
            world_id: "0123456789ab70cd8ef0123456789abc".to_owned(),
            coordinate_frame: "global-target-2026-09-27".to_owned(),
            records: promoted.family.records,
            imports: vec![promoted.family.batch],
            metadata: Vec::new(),
        },
        full_family_limits(),
    )?;
    Ok(canonical
        .into_snapshot(full_family_limits())?
        .parse(full_family_limits())?
        .link()?)
}

fn promoted_atom_count(semantics: &ReferenceItemSemantics) -> usize {
    use ReferenceItemField::Known;
    let mut count = 0_usize;
    if let Known(value) = &semantics.presentation {
        count += usize::from(matches!(&value.name, Known(_)));
    }
    if let Known(value) = &semantics.weapon {
        count += usize::from(matches!(&value.attack, Known(_)));
        count += usize::from(matches!(&value.defense, Known(_)));
        count += usize::from(matches!(&value.extra_defense, Known(_)));
        count += usize::from(matches!(&value.range, Known(_)));
        count += usize::from(matches!(&value.hit_chance, Known(_)));
    }
    if let Known(value) = &semantics.protection {
        count += usize::from(matches!(&value.armor, Known(_)));
    }
    if let Known(value) = &semantics.charges {
        count += usize::from(matches!(&value.count, Known(_)));
    }
    if let Known(value) = &semantics.container {
        count += usize::from(matches!(&value.capacity, Known(_)));
    }
    count
}

#[test]
fn protected_semantic_promotion_round_trips_exact_14643_atoms_through_artifact_v5_server_and_client()
-> Result<(), Box<dyn std::error::Error>> {
    let linked = promoted_family_linked()?;
    assert_eq!(linked.definitions.len(), CW2_B1_FULL_ITEM_FAMILY_COUNT);

    let promoted_items = linked
        .definitions
        .iter()
        .filter(|definition| {
            matches!(
                &definition.kind,
                ReferenceDefinitionKind::Item(item) if promoted_atom_count(&item.semantics) > 0
            )
        })
        .count();
    let promoted_fields = linked
        .definitions
        .iter()
        .map(|definition| match &definition.kind {
            ReferenceDefinitionKind::Item(item) => promoted_atom_count(&item.semantics),
            _ => 0,
        })
        .sum::<usize>();
    assert_eq!(
        promoted_items,
        ITEM_SEMANTIC_PROMOTION_LOWERING_V1_ITEM_COUNT
    );
    assert_eq!(
        promoted_fields,
        ITEM_SEMANTIC_PROMOTION_LOWERING_V1_FIELD_COUNT
    );

    let compiled = compile_reference_playable(&linked)?;
    let repeated = compile_reference_playable(&linked)?;
    assert_eq!(compiled.server_artifact, repeated.server_artifact);
    assert_eq!(compiled.client_artifact, repeated.client_artifact);

    let server = load_reference_playable_artifact(
        &compiled.server_artifact,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?;
    let client = load_reference_playable_artifact(
        &compiled.client_artifact,
        ReferenceArtifactProjection::ClientSafe,
    )?;
    assert_eq!(
        server.artifact_profile_id(),
        "OTERYN_REFERENCE_PLAYABLE_ARTIFACT/v5"
    );
    assert_eq!(
        client.artifact_profile_id(),
        "OTERYN_REFERENCE_PLAYABLE_ARTIFACT/v5"
    );

    let mut server_promoted = 0_usize;
    let mut client_promoted = 0_usize;
    for definition in &linked.definitions {
        let ReferenceDefinitionKind::Item(item) = &definition.kind else {
            continue;
        };
        let expected = &item.semantics;
        let server_item = server
            .lookup_server_item(&definition.definition)?
            .expect("server Item from complete promoted family");
        let client_item = client
            .lookup_client_item(&definition.definition)?
            .expect("client Item from complete promoted family");
        assert_eq!(server_item.semantics, *expected);
        assert_eq!(client_item.semantics, expected.client_projection());
        server_promoted += promoted_atom_count(&server_item.semantics);
        client_promoted += promoted_atom_count(&client_item.semantics);
    }
    assert_eq!(
        server_promoted,
        ITEM_SEMANTIC_PROMOTION_LOWERING_V1_FIELD_COUNT
    );
    assert_eq!(
        client_promoted,
        ITEM_SEMANTIC_PROMOTION_LOWERING_V1_FIELD_COUNT
    );
    Ok(())
}

fn item_target() -> ReferenceItemTarget {
    ReferenceItemTarget::new(CW2_B1_VASE_KEY, CW2_B1_VASE_REVISION).expect("typed target")
}

fn presentation() -> ReferenceItemPresentation {
    ReferenceItemPresentation {
        name: ReferenceItemField::Known("typed item".to_owned()),
        description: ReferenceItemField::Known("synthetic schema witness".to_owned()),
    }
}

#[test]
fn typed_item_v5_representative_families_round_trip_through_project_and_both_projections()
-> Result<(), Box<dyn std::error::Error>> {
    use ReferenceItemField::{Conflict, Known, NotApplicable, Unknown};
    let capabilities = std::array::from_fn(|index| match index % 4 {
        0 => Unknown,
        1 => NotApplicable,
        2 => Conflict,
        _ => Known(false),
    });
    let classification = ReferenceItemClassification {
        item_type: Known(ReferenceItemType::Rune),
        capabilities: Known(capabilities),
    };
    let equipment = ReferenceItemEquipment {
        patterns: Known(vec![ReferenceEquipmentPattern {
            pattern_id: 1,
            primary_slot: Known(ReferenceEquipmentSlot::Weapon),
            additional_reserved_slots: Known(vec![ReferenceEquipmentSlot::Shield]),
            mutually_exclusive_groups: Known(vec![ReferenceItemGroupKey::new(
                "oteryn:equipment-group.two-handed",
            )?]),
            vocations: Known(vec![ReferenceBaseVocation::Paladin]),
            level: Known(20),
            compatibility_rule: Unknown,
        }]),
    };
    let target = item_target();
    let mut cases = Vec::new();

    let melee = ReferenceItemSemantics {
        presentation: Known(presentation()),
        classification: Known(classification.clone()),
        weapon: Known(ReferenceItemWeapon {
            weapon_type: Known(ReferenceWeaponType::Sword),
            attack: Known(ReferenceSignedPoints(42)),
            defense: Known(ReferenceSignedPoints(20)),
            extra_defense: Known(ReferenceSignedPoints(0)),
            range: Known(ReferenceCells(1)),
            hit_chance: Known(ReferenceRationalPercent::new(1, 1)?),
            max_hit_chance: Known(ReferenceRationalPercent::new(1, 1)?),
            ammunition: NotApplicable,
            elemental: Known(Vec::new()),
        }),
        ..Default::default()
    };
    cases.push(("melee_weapon", melee));

    let distance = ReferenceItemSemantics {
        presentation: Known(presentation()),
        weapon: Known(ReferenceItemWeapon {
            weapon_type: Known(ReferenceWeaponType::Distance),
            attack: Known(ReferenceSignedPoints(35)),
            defense: Unknown,
            extra_defense: Unknown,
            range: Known(ReferenceCells(7)),
            hit_chance: Known(ReferenceRationalPercent::new(9, 10)?),
            max_hit_chance: Known(ReferenceRationalPercent::new(1, 1)?),
            ammunition: Known(ReferenceAmmoType::Arrow),
            elemental: Unknown,
        }),
        ..Default::default()
    };
    cases.push(("distance_weapon", distance));
    cases.push((
        "armor_equipment",
        ReferenceItemSemantics {
            presentation: Known(presentation()),
            equipment: Known(equipment.clone()),
            protection: Known(ReferenceItemProtection {
                observed_resistance_parameters: Default::default(),
                armor: Known(ReferenceSignedPoints(12)),
                resistances: Unknown,
            }),
            ..Default::default()
        },
    ));
    cases.push((
        "container",
        ReferenceItemSemantics {
            presentation: Known(presentation()),
            container: Known(ReferenceItemContainer {
                capacity: Known(20),
            }),
            ..Default::default()
        },
    ));
    cases.push((
        "charges_consumable",
        ReferenceItemSemantics {
            charges: Known(ReferenceItemCharges { count: Known(5) }),
            temporal: Known(ReferenceItemTemporal {
                consumption_mode: Known(ReferenceTemporalMode::AuthoritativeActiveTimeBudget),
                duration: Known(ReferenceMilliseconds(60_000)),
                stop_duration: Known(false),
                decay_target: Unknown,
            }),
            ..Default::default()
        },
    ));
    cases.push((
        "rune_use_item",
        ReferenceItemSemantics {
            classification: Known(classification.clone()),
            use_transform: Known(ReferenceItemUseTransform {
                targets: (1..=10)
                    .map(|kind| {
                        Ok(ReferenceTransformTarget {
                            kind: ReferenceTransformKind::from_wire(kind)?,
                            target: if kind == ReferenceTransformKind::Use.wire() {
                                Known(target.clone())
                            } else {
                                Unknown
                            },
                        })
                    })
                    .collect::<Result<Vec<_>, ContentError>>()?,
            }),
            ..Default::default()
        },
    ));
    cases.push((
        "material_loot",
        ReferenceItemSemantics {
            presentation: Known(presentation()),
            classification: Conflict,
            physical: Known(ReferenceItemPhysical {
                weight: Known(0),
                movable: Known(false),
                pickupable: Known(true),
            }),
            ..Default::default()
        },
    ));
    cases.push((
        "presentation_only",
        ReferenceItemSemantics {
            presentation: Known(presentation()),
            classification: Known(classification),
            ..Default::default()
        },
    ));
    cases.push((
        "resistance_modifiers",
        ReferenceItemSemantics {
            protection: Known(ReferenceItemProtection {
                observed_resistance_parameters: Default::default(),
                armor: Known(ReferenceSignedPoints(0)),
                resistances: Known(vec![ReferenceResistance {
                    kind: ReferenceResistanceKind::Fire,
                    percent: Known(ReferenceRationalPercent::new(1, 10)?),
                }]),
            }),
            skill_modifiers: Known(ReferenceItemSkillModifiers {
                observed_skill_parameters: Default::default(),
                modifiers: Known(vec![ReferenceModifierBinding {
                    kind: ReferenceSkillModifierKind::CriticalHitChance,
                    target_domain: Unknown,
                    evaluation_phase: Unknown,
                    priority: Known(0),
                    parameter: Known(ReferenceModifierParameter::RationalPercent(
                        ReferenceRationalPercent::new(1, 100)?,
                    )),
                }]),
            }),
            ..Default::default()
        },
    ));
    cases.push((
        "imbuement_slots",
        ReferenceItemSemantics {
            equipment: Known(equipment),
            imbuement: Known(ReferenceItemImbuement {
                slot_count: Known(3),
                allowed_family_max_tiers: Unknown,
                allowed_family_tiers: Known(vec![ReferenceImbuementAllowance {
                    family: ReferenceImbuementFamily::CriticalHit,
                    tier: ReferenceImbuementTier::Three,
                }]),
                excluded_families: Known(Vec::new()),
            }),
            ..Default::default()
        },
    ));
    cases.push((
        "transform_decay_target",
        ReferenceItemSemantics {
            temporal: Known(ReferenceItemTemporal {
                consumption_mode: Known(ReferenceTemporalMode::DurableAbsoluteDeadline),
                duration: Known(ReferenceMilliseconds(0)),
                stop_duration: Known(false),
                decay_target: Known(target),
            }),
            ..Default::default()
        },
    ));

    // ITEM-SEM-2b-3: the vocation `None` and the use-requirements group (artifact v5).
    cases.push((
        "use_requirements_and_vocation_none",
        ReferenceItemSemantics {
            presentation: Known(presentation()),
            equipment: Known(ReferenceItemEquipment {
                patterns: Known(vec![ReferenceEquipmentPattern {
                    pattern_id: 1,
                    primary_slot: Known(ReferenceEquipmentSlot::Shield),
                    additional_reserved_slots: Known(Vec::new()),
                    mutually_exclusive_groups: Known(Vec::new()),
                    vocations: Known(vec![
                        ReferenceBaseVocation::Paladin,
                        ReferenceBaseVocation::None,
                    ]),
                    level: Unknown,
                    compatibility_rule: Unknown,
                }]),
            }),
            use_requirements: Known(ReferenceItemUseRequirements {
                min_level: Known(27),
                min_magic_level: Known(4),
                vocations: Known(vec![
                    ReferenceBaseVocation::Druid,
                    ReferenceBaseVocation::Knight,
                    ReferenceBaseVocation::Monk,
                    ReferenceBaseVocation::Paladin,
                    ReferenceBaseVocation::Sorcerer,
                ]),
                enforcement_mode: ReferenceUseEnforcementMode::OnUse,
            }),
            ..Default::default()
        },
    ));

    assert_eq!(cases.len(), 12);
    let (linked, cases) = typed_family_linked(cases)?;
    assert_eq!(linked.definitions.len(), CW2_B1_FULL_ITEM_FAMILY_COUNT);
    let compiled = compile_reference_playable(&linked)?;
    let repeated = compile_reference_playable(&linked)?;
    assert_eq!(compiled.server_artifact, repeated.server_artifact);
    assert_eq!(compiled.client_artifact, repeated.client_artifact);
    let server = load_reference_playable_artifact(
        &compiled.server_artifact,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?;
    let client = load_reference_playable_artifact(
        &compiled.client_artifact,
        ReferenceArtifactProjection::ClientSafe,
    )?;
    for (name, semantics, key) in cases {
        let identity = linked
            .definitions
            .iter()
            .find(|definition| definition.definition.key().as_str() == key)
            .map(|definition| &definition.definition)
            .expect(name);
        assert_eq!(
            server.artifact_profile_id(),
            "OTERYN_REFERENCE_PLAYABLE_ARTIFACT/v5",
            "{name}"
        );
        assert_eq!(
            server.lookup_server_item(identity)?.expect(name).semantics,
            semantics,
            "{name}"
        );
        assert_eq!(
            client.lookup_client_item(identity)?.expect(name).semantics,
            semantics.client_projection(),
            "{name}",
        );
    }

    let mut below = linked.clone();
    below.definitions.pop();
    assert!(matches!(
        compile_reference_playable(&below),
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual: 38_156,
            limit: 38_157,
        })
    ));
    let mut above = linked.clone();
    above
        .definitions
        .push(above.definitions.last().expect("last definition").clone());
    assert!(matches!(
        compile_reference_playable(&above),
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual: 38_158,
            limit: 38_157,
        })
    ));

    for projection in [
        ReferenceArtifactProjection::ServerAuthoritative,
        ReferenceArtifactProjection::ClientSafe,
    ] {
        let source = match projection {
            ReferenceArtifactProjection::ServerAuthoritative => &compiled.server_artifact,
            ReferenceArtifactProjection::ClientSafe => &compiled.client_artifact,
        };
        for invalid_count in [38_156, 38_158] {
            let mut malformed = source.clone();
            write_u32(&mut malformed, INDEX_ENTRY + 12, invalid_count);
            write_u32(&mut malformed, BODY_ENTRY + 12, invalid_count);
            assert!(matches!(
                load_reference_playable_artifact(&malformed, projection),
                Err(ContentError::InvalidArtifact(
                    "Reference artifact section cardinality mismatch"
                ))
            ));
        }
    }
    Ok(())
}

fn read_u32(bytes: &[u8], offset: usize) -> usize {
    usize::try_from(u32::from_be_bytes(
        bytes[offset..offset + 4]
            .try_into()
            .expect("four byte field"),
    ))
    .expect("u32 fits usize")
}

fn write_u16(bytes: &mut [u8], offset: usize, value: u16) {
    bytes[offset..offset + 2].copy_from_slice(&value.to_be_bytes());
}

fn write_u32(bytes: &mut [u8], offset: usize, value: u32) {
    bytes[offset..offset + 4].copy_from_slice(&value.to_be_bytes());
}

fn decode_digest(value: &str) -> [u8; 32] {
    fn nibble(value: u8) -> u8 {
        match value {
            b'0'..=b'9' => value - b'0',
            b'a'..=b'f' => value - b'a' + 10,
            unexpected => panic!("unexpected digest byte {unexpected}"),
        }
    }

    let mut decoded = [0_u8; 32];
    for (index, pair) in value.as_bytes().chunks_exact(2).enumerate() {
        decoded[index] = (nibble(pair[0]) << 4) | nibble(pair[1]);
    }
    decoded
}

fn reseal_whole(bytes: &mut [u8]) {
    let payload_end = read_u32(bytes, 20);
    let digest = decode_digest(&world_project_sha256(&bytes[..payload_end]));
    bytes[payload_end..payload_end + 32].copy_from_slice(&digest);
}

fn reseal_section(bytes: &mut [u8], entry: usize) {
    let offset = read_u32(bytes, entry + 4);
    let length = read_u32(bytes, entry + 8);
    let digest = decode_digest(&world_project_sha256(&bytes[offset..offset + length]));
    bytes[entry + 16..entry + SECTION_ENTRY_LEN].copy_from_slice(&digest);
    reseal_whole(bytes);
}

fn assert_rejected(bytes: &[u8], projection: ReferenceArtifactProjection) {
    assert!(load_reference_playable_artifact(bytes, projection).is_err());
}

#[test]
fn protected_project_links_compiles_loads_and_stages_with_semantic_equivalence()
-> Result<(), Box<dyn std::error::Error>> {
    let linked = linked_from_enumeration(false)?;
    let compiled = compile_reference_playable(&linked)?;
    assert_eq!(compiled.server_artifact.len(), 788);
    assert_eq!(compiled.client_artifact.len(), 776);
    assert_eq!(
        compiled.server_digest(),
        [
            186, 118, 60, 192, 82, 100, 10, 110, 116, 222, 209, 39, 237, 39, 120, 104, 80, 44, 208,
            107, 57, 4, 77, 129, 216, 46, 245, 148, 194, 207, 107, 61,
        ]
    );
    assert_eq!(
        compiled.client_digest(),
        [
            165, 218, 30, 88, 175, 45, 42, 201, 105, 195, 56, 147, 104, 172, 199, 22, 170, 233, 56,
            104, 100, 2, 53, 76, 196, 140, 22, 16, 18, 220, 118, 142,
        ]
    );
    assert!(compiled.server_artifact.len() <= REFERENCE_PLAYABLE_MAX_SERVER_ARTIFACT_BYTES);
    assert!(compiled.client_artifact.len() <= REFERENCE_PLAYABLE_MAX_CLIENT_ARTIFACT_BYTES);
    assert!(
        compiled.server_artifact.len() + compiled.client_artifact.len()
            <= REFERENCE_PLAYABLE_MAX_GENERATION_PAIR_BYTES
    );
    assert_eq!(
        compiled.expectation().package_provenance_digest(),
        linked
            .package_manifest
            .package_provenance_digest()?
            .as_str()
    );

    let identity = linked.definitions[0].definition.clone();
    let server = load_reference_playable_artifact(
        &compiled.server_artifact,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?;
    let client = load_reference_playable_artifact(
        &compiled.client_artifact,
        ReferenceArtifactProjection::ClientSafe,
    )?;
    assert_eq!(server.indexed_identity(), &identity);
    assert_eq!(client.indexed_identity(), &identity);

    let authoritative = server
        .lookup_server_item(&identity)?
        .expect("authoritative Item lookup");
    assert_eq!(
        authoritative.physical_class,
        ReferenceItemPhysicalClass::Physical
    );
    assert!(authoritative.materializable);
    assert_eq!(
        authoritative.stack_class,
        ReferenceItemStackClass::NonStackable
    );
    assert_eq!(
        authoritative.legal_destinations,
        [ReferenceItemDestination::CharacterInventory]
    );
    let projected = client
        .lookup_client_item(&identity)?
        .expect("client Item lookup");
    assert_eq!(projected.physical_class, authoritative.physical_class);
    assert_eq!(projected.stack_class, authoritative.stack_class);

    let missing = TypedDefinitionRef::new(
        DefinitionFamily::Item,
        ProductionKey::new("oteryn:item.decor.missing")?,
        DefinitionRevisionRef::new("definition-r1")?,
    );
    assert_eq!(server.lookup_server_item(&missing)?, None);
    assert_eq!(client.lookup_client_item(&missing)?, None);

    let staged = stage_reference_playable(
        &compiled.server_artifact,
        &compiled.client_artifact,
        compiled.expectation(),
    )?;
    assert_eq!(staged.identity().item_identity(), &identity);
    assert_eq!(
        staged.identity().package_provenance_digest(),
        compiled.expectation().package_provenance_digest()
    );
    assert_eq!(
        staged.identity().server_artifact_digest(),
        compiled.server_digest()
    );
    assert_eq!(
        staged.identity().client_artifact_digest(),
        compiled.client_digest()
    );

    let controller = ContentActivationController::new();
    assert!(controller.staged_identity().is_none());
    assert!(controller.active().is_none());
    assert!(!controller.is_ready());
    Ok(())
}

#[test]
fn compile_is_repeatable_and_input_enumeration_independent()
-> Result<(), Box<dyn std::error::Error>> {
    let forward = compile_reference_playable(&linked_from_enumeration(false)?)?;
    let repeated = compile_reference_playable(&linked_from_enumeration(false)?)?;
    let reversed = compile_reference_playable(&linked_from_enumeration(true)?)?;
    assert_eq!(forward.server_artifact, repeated.server_artifact);
    assert_eq!(forward.client_artifact, repeated.client_artifact);
    assert_eq!(forward.server_artifact, reversed.server_artifact);
    assert_eq!(forward.client_artifact, reversed.client_artifact);
    assert_eq!(forward.expectation(), reversed.expectation());
    Ok(())
}

#[test]
fn typed_semantic_identity_survives_section_table_reordering()
-> Result<(), Box<dyn std::error::Error>> {
    let compiled = compiled();
    let expected_identity = load_reference_playable_artifact(
        &compiled.server_artifact,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?
    .indexed_identity()
    .clone();
    let mut reordered = compiled.server_artifact.clone();
    let first: [u8; SECTION_ENTRY_LEN] = reordered
        [MANIFEST_ENTRY..MANIFEST_ENTRY + SECTION_ENTRY_LEN]
        .try_into()
        .expect("manifest entry");
    let last: [u8; SECTION_ENTRY_LEN] = reordered[BODY_ENTRY..BODY_ENTRY + SECTION_ENTRY_LEN]
        .try_into()
        .expect("body entry");
    reordered[MANIFEST_ENTRY..MANIFEST_ENTRY + SECTION_ENTRY_LEN].copy_from_slice(&last);
    reordered[BODY_ENTRY..BODY_ENTRY + SECTION_ENTRY_LEN].copy_from_slice(&first);
    reseal_whole(&mut reordered);

    let loaded = load_reference_playable_artifact(
        &reordered,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?;
    assert_eq!(loaded.indexed_identity(), &expected_identity);
    assert!(loaded.lookup_server_item(&expected_identity)?.is_some());
    Ok(())
}

#[test]
fn malformed_sections_corruption_cross_profile_and_trailing_bytes_fail_closed() {
    let compiled = compiled();
    let projection = ReferenceArtifactProjection::ServerAuthoritative;

    let mut duplicate = compiled.server_artifact.clone();
    write_u16(&mut duplicate, INDEX_ENTRY, 1);
    reseal_whole(&mut duplicate);
    assert_rejected(&duplicate, projection);

    let mut missing = compiled.server_artifact.clone();
    write_u16(&mut missing, MANIFEST_ENTRY, 99);
    write_u16(&mut missing, MANIFEST_ENTRY + 2, 0);
    reseal_whole(&mut missing);
    assert_rejected(&missing, projection);

    let mut unknown = compiled.server_artifact.clone();
    write_u16(&mut unknown, INDEX_ENTRY, 99);
    reseal_whole(&mut unknown);
    assert_rejected(&unknown, projection);

    let body_offset = read_u32(&compiled.server_artifact, BODY_ENTRY + 4);
    let mut overlap = compiled.server_artifact.clone();
    write_u32(
        &mut overlap,
        BODY_ENTRY + 4,
        u32::try_from(body_offset - 1).expect("body offset"),
    );
    reseal_whole(&mut overlap);
    assert_rejected(&overlap, projection);

    let mut gap = compiled.server_artifact.clone();
    write_u32(
        &mut gap,
        BODY_ENTRY + 4,
        u32::try_from(body_offset + 1).expect("body offset"),
    );
    reseal_whole(&mut gap);
    assert_rejected(&gap, projection);

    let mut section_corrupt = compiled.server_artifact.clone();
    section_corrupt[body_offset] ^= 0x01;
    reseal_whole(&mut section_corrupt);
    assert!(matches!(
        load_reference_playable_artifact(&section_corrupt, projection),
        Err(ContentError::IntegrityMismatch(
            "Reference artifact section"
        ))
    ));

    let mut whole_corrupt = compiled.server_artifact.clone();
    let last = whole_corrupt.len() - 1;
    whole_corrupt[last] ^= 0x01;
    assert!(matches!(
        load_reference_playable_artifact(&whole_corrupt, projection),
        Err(ContentError::IntegrityMismatch("Reference artifact"))
    ));

    let mut cross_profile = compiled.server_artifact.clone();
    cross_profile[..8].copy_from_slice(b"OTFPC01\0");
    reseal_whole(&mut cross_profile);
    assert!(matches!(
        load_reference_playable_artifact(&cross_profile, projection),
        Err(ContentError::InvalidMagic)
    ));

    let mut trailing = compiled.server_artifact.clone();
    trailing.push(0);
    assert_rejected(&trailing, projection);
}

#[test]
fn size_max_plus_one_and_encoded_length_overflow_values_reject_before_decode() {
    let server_at_max = vec![0_u8; REFERENCE_PLAYABLE_MAX_SERVER_ARTIFACT_BYTES];
    assert!(matches!(
        load_reference_playable_artifact(
            &server_at_max,
            ReferenceArtifactProjection::ServerAuthoritative,
        ),
        Err(ContentError::InvalidMagic)
    ));
    let server_oversized = vec![0_u8; REFERENCE_PLAYABLE_MAX_SERVER_ARTIFACT_BYTES + 1];
    assert!(matches!(
        load_reference_playable_artifact(
            &server_oversized,
            ReferenceArtifactProjection::ServerAuthoritative,
        ),
        Err(ContentError::LimitExceeded {
            resource: "Reference artifact bytes",
            actual,
            limit: REFERENCE_PLAYABLE_MAX_SERVER_ARTIFACT_BYTES,
        }) if actual == REFERENCE_PLAYABLE_MAX_SERVER_ARTIFACT_BYTES + 1
    ));
    let client_at_max = vec![0_u8; REFERENCE_PLAYABLE_MAX_CLIENT_ARTIFACT_BYTES];
    assert!(matches!(
        load_reference_playable_artifact(&client_at_max, ReferenceArtifactProjection::ClientSafe,),
        Err(ContentError::InvalidMagic)
    ));
    let client_oversized = vec![0_u8; REFERENCE_PLAYABLE_MAX_CLIENT_ARTIFACT_BYTES + 1];
    assert!(matches!(
        load_reference_playable_artifact(
            &client_oversized,
            ReferenceArtifactProjection::ClientSafe,
        ),
        Err(ContentError::LimitExceeded {
            resource: "Reference artifact bytes",
            actual,
            limit: REFERENCE_PLAYABLE_MAX_CLIENT_ARTIFACT_BYTES,
        }) if actual == REFERENCE_PLAYABLE_MAX_CLIENT_ARTIFACT_BYTES + 1
    ));

    let compiled = compiled();
    let mut payload_overflow = compiled.server_artifact.clone();
    write_u32(&mut payload_overflow, 20, u32::MAX);
    assert_rejected(
        &payload_overflow,
        ReferenceArtifactProjection::ServerAuthoritative,
    );

    let mut range_overflow = compiled.server_artifact.clone();
    write_u32(&mut range_overflow, BODY_ENTRY + 4, u32::MAX);
    write_u32(&mut range_overflow, BODY_ENTRY + 8, u32::MAX);
    reseal_whole(&mut range_overflow);
    assert_rejected(
        &range_overflow,
        ReferenceArtifactProjection::ServerAuthoritative,
    );
}

#[test]
fn client_body_is_a_positive_allowlist_and_pair_mismatch_rejects() {
    let compiled = compiled();
    let identity = load_reference_playable_artifact(
        &compiled.client_artifact,
        ReferenceArtifactProjection::ClientSafe,
    )
    .expect("client load")
    .indexed_identity()
    .clone();
    let client = load_reference_playable_artifact(
        &compiled.client_artifact,
        ReferenceArtifactProjection::ClientSafe,
    )
    .expect("client load");
    let projected = client
        .lookup_client_item(&identity)
        .expect("client lookup")
        .expect("client Item");
    assert_eq!(
        projected.physical_class,
        ReferenceItemPhysicalClass::Physical
    );
    assert_eq!(projected.stack_class, ReferenceItemStackClass::NonStackable);

    let mut server_as_client = compiled.server_artifact.clone();
    server_as_client[12] = 2;
    reseal_whole(&mut server_as_client);
    assert!(
        stage_reference_playable(
            &compiled.server_artifact,
            &server_as_client,
            compiled.expectation(),
        )
        .is_err()
    );

    let mut client_body = compiled.client_artifact.clone();
    let body_offset = read_u32(&client_body, BODY_ENTRY + 4);
    client_body[body_offset] = 2;
    reseal_section(&mut client_body, BODY_ENTRY);
    assert!(
        stage_reference_playable(
            &compiled.server_artifact,
            &client_body,
            compiled.expectation(),
        )
        .is_err()
    );
}

#[test]
fn exact_public_limits_remain_the_owner_accepted_one_item_values() {
    assert_eq!(REFERENCE_PLAYABLE_MAX_SERVER_ARTIFACT_BYTES, 8_715);
    assert_eq!(REFERENCE_PLAYABLE_MAX_CLIENT_ARTIFACT_BYTES, 8_675);
    assert_eq!(REFERENCE_PLAYABLE_MAX_GENERATION_PAIR_BYTES, 17_390);
    assert_eq!(
        OTERYN_REFERENCE_PLAYABLE_ARTIFACT_PROFILE_ID,
        "OTERYN_REFERENCE_PLAYABLE_ARTIFACT/v1"
    );
}

#[test]
fn explicit_ceiling_compiles_selects_v5_and_loads_both_projections()
-> Result<(), Box<dyn std::error::Error>> {
    use ReferenceItemField::{Known, Unknown};
    let semantics = ReferenceItemSemantics {
        imbuement: Known(ReferenceItemImbuement {
            slot_count: Known(1),
            allowed_family_tiers: Unknown,
            allowed_family_max_tiers: Known(vec![ReferenceImbuementFamilyCeiling {
                family: ReferenceImbuementFamily::CriticalHit,
                max_tier: 1,
            }]),
            excluded_families: Unknown,
        }),
        ..Default::default()
    };
    assert!(
        typed_family_linked_with_schema(
            vec![("ceiling", semantics.clone())],
            "reference-schema-v1"
        )
        .is_err()
    );
    let (linked, cases) = typed_family_linked(vec![("ceiling", semantics.clone())])?;
    let mut wrong_schema = linked.clone();
    wrong_schema.package_manifest.semantic_schema_version =
        ProductionAtom::new("test semantic schema", "reference-schema-v1")?;
    assert!(matches!(
        compile_reference_playable(&wrong_schema),
        Err(ContentError::RevisionMismatch(
            "Reference imbuement ceiling semantic schema"
        ))
    ));
    let compiled = compile_reference_playable(&linked)?;
    let key = &cases[0].2;
    let identity = &linked
        .definitions
        .iter()
        .find(|definition| definition.definition.key().as_str() == key)
        .expect("ceiling identity")
        .definition;
    for (bytes, projection) in [
        (
            &compiled.server_artifact,
            ReferenceArtifactProjection::ServerAuthoritative,
        ),
        (
            &compiled.client_artifact,
            ReferenceArtifactProjection::ClientSafe,
        ),
    ] {
        let view = load_reference_playable_artifact(bytes, projection)?;
        assert_eq!(
            view.artifact_profile_id(),
            "OTERYN_REFERENCE_PLAYABLE_ARTIFACT/v6"
        );
        let actual = match projection {
            ReferenceArtifactProjection::ServerAuthoritative => {
                view.lookup_server_item(identity)?
                    .expect("server ceiling")
                    .semantics
            }
            ReferenceArtifactProjection::ClientSafe => {
                view.lookup_client_item(identity)?
                    .expect("client ceiling")
                    .semantics
            }
        };
        assert_eq!(actual.imbuement, semantics.imbuement);
        let mut wrong_manifest = bytes.to_vec();
        let manifest_start = read_u32(&wrong_manifest, MANIFEST_ENTRY + 4);
        let manifest_end = manifest_start + read_u32(&wrong_manifest, MANIFEST_ENTRY + 8);
        let mut cursor = manifest_start;
        let mut fields = Vec::new();
        for _ in 0..15 {
            let length = usize::from(u16::from_be_bytes([
                wrong_manifest[cursor],
                wrong_manifest[cursor + 1],
            ]));
            let start = cursor + 2;
            cursor = start + length;
            fields.push(start..cursor);
        }
        assert_eq!(cursor, manifest_end, "manifest framing is exact");
        let marker = REFERENCE_IMBUEMENT_CEILING_SEMANTIC_SCHEMA.as_bytes();
        assert_eq!(&wrong_manifest[fields[5].clone()], marker);
        assert_eq!(
            &wrong_manifest[fields[11].clone()],
            linked
                .package_manifest
                .package_provenance_digest()?
                .as_str()
                .as_bytes()
        );
        let mut wrong_package = linked.package_manifest.clone();
        wrong_package.semantic_schema_version = ProductionAtom::new(
            "test semantic schema",
            "reference-schema-imbuement-ceilings-v0",
        )?;
        assert_eq!(
            wrong_package.semantic_schema_version.as_str().len(),
            fields[5].len()
        );
        wrong_manifest[fields[5].clone()]
            .copy_from_slice(wrong_package.semantic_schema_version.as_str().as_bytes());
        reseal_section(&mut wrong_manifest, MANIFEST_ENTRY);
        assert!(
            matches!(
                load_reference_playable_artifact(&wrong_manifest, projection),
                Err(ContentError::InvalidArtifact(
                    "Reference package provenance digest mismatch"
                ))
            ),
            "changing schema also invalidates the bound package digest"
        );
        let coherent_digest = wrong_package.package_provenance_digest()?;
        wrong_manifest[fields[11].clone()].copy_from_slice(coherent_digest.as_str().as_bytes());
        reseal_section(&mut wrong_manifest, MANIFEST_ENTRY);
        let rejected = load_reference_playable_artifact(&wrong_manifest, projection);
        assert!(
            matches!(
                &rejected,
                Err(ContentError::RevisionMismatch(
                    "Reference primary Source observation artifact profile"
                ))
            ),
            "coherent wrong-schema package reaches the ownership gate: {:?}",
            rejected.as_ref().err()
        );
    }
    Ok(())
}

// Test mutation helpers preserve section/record/whole SHA integrity, reaching semantic gates.
fn primary_test_index(bytes: &[u8]) -> std::collections::BTreeMap<String, (usize, usize, usize)> {
    let start = read_u32(bytes, INDEX_ENTRY + 4);
    let mut cursor = start + 4;
    let mut result = std::collections::BTreeMap::new();
    for _ in 0..read_u32(bytes, start) {
        assert_eq!(bytes[cursor], 5);
        cursor += 1;
        let key_len = usize::from(u16::from_be_bytes(
            bytes[cursor..cursor + 2].try_into().expect("length"),
        ));
        cursor += 2;
        let key = std::str::from_utf8(&bytes[cursor..cursor + key_len])
            .expect("key")
            .to_owned();
        cursor += key_len;
        let revision_len = usize::from(u16::from_be_bytes(
            bytes[cursor..cursor + 2].try_into().expect("length"),
        ));
        cursor += 2 + revision_len;
        result.insert(
            key,
            (cursor, read_u32(bytes, cursor), read_u32(bytes, cursor + 4)),
        );
        cursor += 40;
    }
    assert_eq!(cursor, start + read_u32(bytes, INDEX_ENTRY + 8));
    result
}

fn primary_test_marker(
    mut bytes: Vec<u8>,
    package: &PackageManifestBinding,
    as_v4: bool,
) -> Vec<u8> {
    let start = read_u32(&bytes, MANIFEST_ENTRY + 4);
    let old_end = start + read_u32(&bytes, MANIFEST_ENTRY + 8);
    let mut fields = Vec::new();
    let mut cursor = start;
    for _ in 0..15 {
        let length = usize::from(u16::from_be_bytes(
            bytes[cursor..cursor + 2].try_into().expect("length"),
        ));
        cursor += 2;
        fields.push(bytes[cursor..cursor + length].to_vec());
        cursor += length;
    }
    assert_eq!(cursor, old_end);
    if as_v4 {
        bytes[..8].copy_from_slice(b"OTRPA04\0");
        write_u16(&mut bytes, 8, 4);
        for index in [0, 12, 13] {
            assert_eq!(fields[index].pop(), Some(b'5'));
            fields[index].push(b'4');
        }
        let body_start = read_u32(&bytes, BODY_ENTRY + 4);
        for (_, (descriptor, offset, length)) in primary_test_index(&bytes) {
            assert_eq!(bytes[body_start + offset], 3);
            bytes[body_start + offset] = 2;
            let digest = decode_digest(&world_project_sha256(
                &bytes[body_start + offset..body_start + offset + length],
            ));
            bytes[descriptor + 8..descriptor + 40].copy_from_slice(&digest);
        }
        reseal_section(&mut bytes, INDEX_ENTRY);
        reseal_section(&mut bytes, BODY_ENTRY);
    }
    let mut package = package.clone();
    package.semantic_schema_version =
        ProductionAtom::new("test schema", REFERENCE_PRIMARY_SOURCE_OBSERVATION_SCHEMA)
            .expect("marker");
    fields[5] = package.semantic_schema_version.as_str().as_bytes().to_vec();
    fields[11] = package
        .package_provenance_digest()
        .expect("provenance")
        .as_str()
        .as_bytes()
        .to_vec();
    let mut manifest = Vec::new();
    for field in fields {
        manifest.extend_from_slice(
            &u16::try_from(field.len())
                .expect("bounded field")
                .to_be_bytes(),
        );
        manifest.extend_from_slice(&field);
    }
    let delta = isize::try_from(manifest.len()).expect("length")
        - isize::try_from(old_end - start).expect("length");
    bytes.splice(start..old_end, manifest);
    for location in [INDEX_ENTRY + 4, BODY_ENTRY + 4, 20, MANIFEST_ENTRY + 8] {
        let value = read_u32(&bytes, location)
            .checked_add_signed(delta)
            .expect("test reframe");
        write_u32(
            &mut bytes,
            location,
            u32::try_from(value).expect("bounded envelope"),
        );
    }
    reseal_section(&mut bytes, MANIFEST_ENTRY);
    bytes
}

fn primary_test_replace_record(mut bytes: Vec<u8>, key: &str, record: &[u8]) -> Vec<u8> {
    let entries = primary_test_index(&bytes);
    let (descriptor, offset, length) = entries[key];
    let body_start = read_u32(&bytes, BODY_ENTRY + 4);
    let delta =
        isize::try_from(record.len()).expect("length") - isize::try_from(length).expect("length");
    bytes.splice(
        body_start + offset..body_start + offset + length,
        record.iter().copied(),
    );
    write_u32(
        &mut bytes,
        descriptor + 4,
        u32::try_from(record.len()).expect("record cap"),
    );
    bytes[descriptor + 8..descriptor + 40]
        .copy_from_slice(&decode_digest(&world_project_sha256(record)));
    for (_, (position, other_offset, _)) in entries {
        if other_offset > offset {
            write_u32(
                &mut bytes,
                position,
                u32::try_from(other_offset.checked_add_signed(delta).expect("offset"))
                    .expect("offset"),
            );
        }
    }
    for location in [BODY_ENTRY + 8, 20] {
        let value = read_u32(&bytes, location)
            .checked_add_signed(delta)
            .expect("length");
        write_u32(
            &mut bytes,
            location,
            u32::try_from(value).expect("bounded body"),
        );
    }
    reseal_section(&mut bytes, INDEX_ENTRY);
    reseal_section(&mut bytes, BODY_ENTRY);
    bytes
}

#[test]
fn primary_observations_v6_full_family_compiles_loads_projects_and_rejects_legacy_marker()
-> Result<(), Box<dyn std::error::Error>> {
    use ReferenceItemField::{Known, Unknown};
    let semantics = ReferenceItemSemantics {
        skill_modifiers: Known(ReferenceItemSkillModifiers {
            modifiers: Unknown,
            observed_skill_parameters: Known(ReferenceObservedSkillTable {
                phase: ReferenceDefinitionObservationPhase::CppProtoXmlBeforeLua,
                entries: (1..=8)
                    .map(|kind| {
                        Ok(ReferenceObservedSkillParameter {
                            kind: ReferenceObservedSkillKind::from_wire(kind)?,
                            parameter: Known(ReferenceModifierParameter::SignedPoints(
                                ReferenceSignedPoints(i32::MAX),
                            )),
                            target_domain: Unknown,
                            evaluation_phase: Unknown,
                            priority: Unknown,
                        })
                    })
                    .collect::<Result<_, ContentError>>()?,
            }),
        }),
        protection: Known(ReferenceItemProtection {
            armor: Unknown,
            resistances: Unknown,
            observed_resistance_parameters: Known(ReferenceObservedResistanceTable {
                phase: ReferenceDefinitionObservationPhase::CppProtoXmlBeforeLua,
                entries: (1..=2)
                    .flat_map(|scope| {
                        (1..=14).map(move |kind| {
                            Ok(ReferenceObservedResistanceParameter {
                                scope: ReferenceObservedResistanceScope::from_wire(scope)?,
                                combat_kind: ReferenceObservedCombatKind::from_wire(kind)?,
                                percent: Known(ReferenceRationalPercent::new(
                                    i64::from(i16::MAX),
                                    1,
                                )?),
                            })
                        })
                    })
                    .collect::<Result<_, ContentError>>()?,
            }),
        }),
        ..Default::default()
    };
    assert!(semantics.requires_primary_source_observation_profile());
    for legacy in [
        "reference-schema-v1",
        REFERENCE_IMBUEMENT_CEILING_SEMANTIC_SCHEMA,
    ] {
        assert!(
            typed_family_linked_with_schema(vec![("primary", semantics.clone())], legacy).is_err()
        );
    }
    let (linked, cases) = typed_family_linked_with_schema(
        vec![("primary", semantics.clone())],
        REFERENCE_PRIMARY_SOURCE_OBSERVATION_SCHEMA,
    )?;
    let pair = compile_reference_playable(&linked)?;
    let repeated = compile_reference_playable(&linked)?;
    assert_eq!(pair.server_artifact, repeated.server_artifact);
    assert_eq!(pair.client_artifact, repeated.client_artifact);
    assert_eq!(&pair.server_artifact[..8], b"OTRPA06\0");
    let server = load_reference_playable_artifact(
        &pair.server_artifact,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?;
    let client = load_reference_playable_artifact(
        &pair.client_artifact,
        ReferenceArtifactProjection::ClientSafe,
    )?;
    assert_eq!(
        server.artifact_profile_id(),
        "OTERYN_REFERENCE_PLAYABLE_ARTIFACT/v6"
    );
    let identity = &linked
        .definitions
        .iter()
        .find(|d| d.definition.key().as_str() == cases[0].2)
        .expect("primary")
        .definition;
    assert_eq!(
        server
            .lookup_server_item(identity)?
            .expect("primary")
            .semantics,
        semantics
    );
    assert_eq!(
        client
            .lookup_client_item(identity)?
            .expect("primary")
            .semantics,
        semantics.client_projection()
    );
    // Load validates envelope/index integrity; explicit client Source data fails at record lookup.
    let key = &cases[0].2;
    let (_, offset, length) = primary_test_index(&pair.server_artifact)[key];
    let start = read_u32(&pair.server_artifact, BODY_ENTRY + 4) + offset;
    let record = &pair.server_artifact[start..start + length];
    let groups = 5 + usize::from(record[4]);
    let mut explicit_client = vec![record[0], record[1], record[3]];
    explicit_client.extend_from_slice(&record[groups..]);
    let altered = primary_test_replace_record(pair.client_artifact.clone(), key, &explicit_client);
    let loaded =
        load_reference_playable_artifact(&altered, ReferenceArtifactProjection::ClientSafe)?;
    assert!(matches!(
        loaded.lookup_client_item(identity),
        Err(ContentError::InvalidArtifact(
            "client source resistance observations"
        ))
    ));
    // Isolate group8 to prove the skill gate independently of the preceding resistance gate.
    let resistance_length = usize::from(u16::from_be_bytes(
        explicit_client[6..8].try_into().expect("group length"),
    ));
    let mut skills_only = vec![record[0], record[1], record[3], 0, 1];
    skills_only.extend_from_slice(&explicit_client[8 + resistance_length..]);
    let altered = primary_test_replace_record(pair.client_artifact.clone(), key, &skills_only);
    let loaded =
        load_reference_playable_artifact(&altered, ReferenceArtifactProjection::ClientSafe)?;
    assert!(matches!(
        loaded.lookup_client_item(identity),
        Err(ContentError::InvalidArtifact(
            "client source skill observations"
        ))
    ));
    let mut below = linked.clone();
    below.definitions.pop();
    assert!(compile_reference_playable(&below).is_err());
    let mut wrong_marker = linked.clone();
    wrong_marker.package_manifest.semantic_schema_version = ProductionAtom::new(
        "test semantic schema",
        REFERENCE_IMBUEMENT_CEILING_SEMANTIC_SCHEMA,
    )?;
    assert!(matches!(
        compile_reference_playable(&wrong_marker),
        Err(ContentError::RevisionMismatch(
            "Reference primary Source observation semantic schema"
        ))
    ));
    Ok(())
}

#[test]
fn primary_media_v6_public_pair_keeps_all_377_exact_targets_and_rejects_rebinding()
-> Result<(), Box<dyn std::error::Error>> {
    use ReferenceItemField::Known;
    let registry: serde_json::Value =
        serde_json::from_str(include_str!("../src/content/source-media-registry.json"))?;
    // Epoch1 B1 uses opaque keys and omits five later own Source IDs. Compose the
    // codec fixture with exact existing registered parents; no identity is minted.
    let parents: serde_json::Value = serde_json::from_slice(include_bytes!(
        "fixtures/primary-media-registered-parents-20261004.json"
    ))?;
    assert_eq!(
        parents["source_reference_sha256"],
        "99fc9decddba03c17198e16eb2c37897dfd4521f6b86b1dab2baf6e438334ad5"
    );
    let parent_rows = parents["records"]
        .as_array()
        .expect("frozen registered parents");
    assert_eq!(parent_rows.len(), 267);
    let mut records: Vec<ProjectReferenceRecord> =
        serde_json::from_value(parents["records"].clone())?;
    let registered_keys: std::collections::BTreeSet<_> = parent_rows
        .iter()
        .map(|row| row["identity"]["key"].as_str().expect("key").to_owned())
        .collect();
    assert_eq!(registered_keys.len(), 267);
    for row in parent_rows {
        let key = row["identity"]["key"].as_str().expect("key");
        assert_eq!(
            world_project_sha256(&serde_json::to_vec(row)?),
            parents["record_hashes"][key]
                .as_str()
                .expect("exact parent hash")
        );
    }
    let imported = protected_cw2_b1_full_item_family_import(B1_EVIDENCE)?;
    records.extend(
        imported
            .records
            .into_iter()
            .filter(|record| {
                let ProjectReferenceRecord::Item { identity, .. } = record else {
                    return false;
                };
                !registered_keys.contains(&identity.key)
            })
            .take(CW2_B1_FULL_ITEM_FAMILY_COUNT - registered_keys.len()),
    );
    assert_eq!(records.len(), CW2_B1_FULL_ITEM_FAMILY_COUNT);
    let canonical = CanonicalProjectDocuments::from_draft(
        ProjectDraft {
            project_revision: "media-r1".to_owned(),
            package_key: "oteryn:content.world-project".to_owned(),
            semantic_schema_version: REFERENCE_PRIMARY_SOURCE_OBSERVATION_SCHEMA.to_owned(),
            licensing_metadata: "PENDING".to_owned(),
            world_id: "0123456789ab70cd8ef0123456789abc".to_owned(),
            coordinate_frame: "global-target-2026-09-27".to_owned(),
            records,
            imports: Vec::new(),
            metadata: Vec::new(),
        },
        full_family_limits(),
    )?;
    let mut linked = canonical
        .into_snapshot(full_family_limits())?
        .parse(full_family_limits())?
        .link()?;
    let mut expected =
        std::collections::BTreeMap::<String, Vec<ReferenceItemSourceMediaConfig>>::new();
    for row in registry["declarations"].as_array().expect("registry") {
        expected
            .entry(row["target_key"].as_str().expect("target").to_owned())
            .or_default()
            .push(serde_json::from_value(row["config"].clone())?);
    }
    assert_eq!(expected.values().map(Vec::len).sum::<usize>(), 377);
    for (key, entries) in &mut expected {
        entries.sort_by_key(|entry| entry.source_cut);
        let definition = linked
            .definitions
            .iter_mut()
            .find(|d| d.definition.key().as_str() == key)
            .expect("exact source target in frozen full family");
        let ReferenceDefinitionKind::Item(item) = &mut definition.kind else {
            panic!("Item");
        };
        item.semantics.source_media_config = Known(entries.clone());
    }
    let pair = compile_reference_playable(&linked)?;
    let server = load_reference_playable_artifact(
        &pair.server_artifact,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?;
    let client = load_reference_playable_artifact(
        &pair.client_artifact,
        ReferenceArtifactProjection::ClientSafe,
    )?;
    for (key, entries) in &expected {
        let definition = linked
            .definitions
            .iter()
            .find(|d| d.definition.key().as_str() == key)
            .expect("target");
        assert_eq!(
            server
                .lookup_server_item(&definition.definition)?
                .expect("target")
                .semantics
                .source_media_config,
            Known(entries.clone())
        );
        assert!(matches!(
            client
                .lookup_client_item(&definition.definition)?
                .expect("target")
                .semantics
                .source_media_config,
            ReferenceItemField::Unknown
        ));
    }
    // Swap only complete record descriptors; identity sort, ranges and all SHA hashes remain valid.
    let keys = expected.keys().take(2).collect::<Vec<_>>();
    assert_eq!(keys.len(), 2);
    let mut rebound = pair.server_artifact.clone();
    let index = primary_test_index(&rebound);
    let (first, _, _) = index[keys[0]];
    let (second, _, _) = index[keys[1]];
    for offset in 0..40 {
        rebound.swap(first + offset, second + offset);
    }
    reseal_section(&mut rebound, INDEX_ENTRY);
    let lazy = load_reference_playable_artifact(
        &rebound,
        ReferenceArtifactProjection::ServerAuthoritative,
    )?;
    let first_identity = &linked
        .definitions
        .iter()
        .find(|d| d.definition.key().as_str() == keys[0])
        .expect("source target")
        .definition;
    assert!(matches!(
        lazy.lookup_server_item(first_identity),
        Err(ContentError::InvalidArtifact(
            "Source media exact target binding disagrees"
        ))
    ));
    let (key, entries) = expected.first_key_value().expect("377 declarations");
    let wrong = linked
        .definitions
        .iter_mut()
        .find(|d| {
            d.definition.key().as_str() != key
                && !expected.contains_key(d.definition.key().as_str())
        })
        .expect("unrelated target");
    let ReferenceDefinitionKind::Item(item) = &mut wrong.kind else {
        panic!("Item");
    };
    item.semantics.source_media_config = Known(entries.clone());
    assert!(matches!(
        compile_reference_playable(&linked),
        Err(ContentError::InvalidArtifact(
            "Source media exact target binding disagrees"
        ))
    ));
    Ok(())
}

#[test]
fn primary_marker_rejects_integrity_valid_v4_and_v5_envelopes()
-> Result<(), Box<dyn std::error::Error>> {
    use ReferenceItemField::Known;
    let v5 = ReferenceItemSemantics {
        use_requirements: Known(ReferenceItemUseRequirements {
            min_level: Known(12),
            min_magic_level: Known(3),
            vocations: Known(vec![ReferenceBaseVocation::None]),
            enforcement_mode: ReferenceUseEnforcementMode::OnUse,
        }),
        ..Default::default()
    };
    let v4 = ReferenceItemSemantics {
        charges: Known(ReferenceItemCharges { count: Known(2) }),
        ..Default::default()
    };
    for (semantics, as_v4) in [(v4, true), (v5, false)] {
        let (linked, _) = typed_family_linked(vec![("legacy", semantics)])?;
        let pair = compile_reference_playable(&linked)?;
        for (bytes, projection) in [
            (
                pair.server_artifact,
                ReferenceArtifactProjection::ServerAuthoritative,
            ),
            (
                pair.client_artifact,
                ReferenceArtifactProjection::ClientSafe,
            ),
        ] {
            let coherent = primary_test_marker(bytes, &linked.package_manifest, as_v4);
            assert!(matches!(
                load_reference_playable_artifact(&coherent, projection),
                Err(ContentError::RevisionMismatch(
                    "Reference primary Source observation artifact profile"
                ))
            ));
        }
    }
    Ok(())
}

#[test]
fn integrated_public_ceiling_old_marker_selects_v6_and_wrong_v5_header_rejects()
-> Result<(), Box<dyn std::error::Error>> {
    use ReferenceItemField::{Known, Unknown};
    let semantics = ReferenceItemSemantics {
        imbuement: Known(ReferenceItemImbuement {
            slot_count: Unknown,
            allowed_family_tiers: Unknown,
            excluded_families: Unknown,
            allowed_family_max_tiers: Known(vec![ReferenceImbuementFamilyCeiling {
                family: ReferenceImbuementFamily::CriticalHit,
                max_tier: 2,
            }]),
        }),
        use_requirements: Known(ReferenceItemUseRequirements {
            min_level: Known(11),
            min_magic_level: Known(0),
            vocations: Known(vec![ReferenceBaseVocation::None]),
            enforcement_mode: ReferenceUseEnforcementMode::OnUse,
        }),
        ..Default::default()
    };
    let (linked, cases) = typed_family_linked(vec![("ceiling", semantics.clone())])?;
    assert_eq!(
        linked.package_manifest.semantic_schema_version.as_str(),
        REFERENCE_IMBUEMENT_CEILING_SEMANTIC_SCHEMA
    );
    let pair = compile_reference_playable(&linked)?;
    assert_eq!(&pair.server_artifact[..8], b"OTRPA06\0");
    let identity = &linked
        .definitions
        .iter()
        .find(|d| d.definition.key().as_str() == cases[0].2)
        .expect("ceiling")
        .definition;
    for (bytes, projection) in [
        (
            pair.server_artifact,
            ReferenceArtifactProjection::ServerAuthoritative,
        ),
        (
            pair.client_artifact,
            ReferenceArtifactProjection::ClientSafe,
        ),
    ] {
        let view = load_reference_playable_artifact(&bytes, projection)?;
        let actual = match projection {
            ReferenceArtifactProjection::ServerAuthoritative => {
                view.lookup_server_item(identity)?
                    .expect("ceiling")
                    .semantics
            }
            ReferenceArtifactProjection::ClientSafe => {
                view.lookup_client_item(identity)?
                    .expect("ceiling")
                    .semantics
            }
        };
        assert_eq!(actual.imbuement, semantics.imbuement);
        assert_eq!(actual.use_requirements, semantics.use_requirements);
        let mut wrong = bytes.clone();
        wrong[..8].copy_from_slice(b"OTRPA05\0");
        write_u16(&mut wrong, 8, 5);
        reseal_whole(&mut wrong);
        assert!(load_reference_playable_artifact(&wrong, projection).is_err());
    }
    Ok(())
}

#[test]
fn future_source_storage_public_compile_rejects_before_projection()
-> Result<(), Box<dyn std::error::Error>> {
    // Exercise the freshly linked production library through its public compiler.
    // This is distinct from the private V4/V5/V6 direct-encoder 72-case matrix.
    let baseline = linked_from_enumeration(false)?;
    assert_eq!(baseline.definitions.len(), 1);
    let original_item = match &baseline.definitions[0].kind {
        ReferenceDefinitionKind::Item(item) => item,
        _ => panic!("protected fixture must be an Item"),
    };
    assert!(
        !original_item
            .semantics
            .requires_future_source_property_profile()
    );
    let control = compile_reference_playable(&baseline)?;
    assert!(!control.server_artifact.is_empty());
    assert!(!control.client_artifact.is_empty());

    let mut rejected = 0;
    for field in [
        "source_class_observations",
        "source_scalar_observations",
        "source_definition_observations",
        "source_combat_observations",
        "source_presentation_observations",
        "source_flag_read_write_observations",
    ] {
        for state in [
            serde_json::json!({"state":"CONFLICT"}),
            serde_json::json!({"state":"NOT_APPLICABLE"}),
            serde_json::json!({"state":"KNOWN","value":[]}),
        ] {
            for marker in [
                "reference-schema-v1",
                REFERENCE_IMBUEMENT_CEILING_SEMANTIC_SCHEMA,
                REFERENCE_PRIMARY_SOURCE_OBSERVATION_SCHEMA,
            ] {
                // Inject after valid linking to test the compiler's fail-closed
                // boundary independently of model or registry validation.
                let mut candidate = baseline.clone();
                candidate.package_manifest.semantic_schema_version =
                    ProductionAtom::new("test semantic schema", marker)?;
                let item = match &mut candidate.definitions[0].kind {
                    ReferenceDefinitionKind::Item(item) => item,
                    _ => panic!("protected fixture must remain an Item"),
                };
                item.semantics =
                    serde_json::from_value(serde_json::json!({(field): state.clone()}))?;
                assert!(item.semantics.requires_future_source_property_profile());
                assert!(
                    !item
                        .semantics
                        .client_projection()
                        .requires_future_source_property_profile()
                );
                // A one-Item fixture under a V6 marker cannot meet 38,157:
                // this exact error proves the Source gate precedes that count
                // check, schema validation, and client Source-field stripping.
                assert!(
                    matches!(
                        compile_reference_playable(&candidate),
                        Err(ContentError::InvalidArtifact(
                            "Source property observations require qualified future profile"
                        ))
                    ),
                    "field={field}, state={state}, marker={marker}"
                );
                rejected += 1;
            }
        }
    }
    assert_eq!(rejected, 54);
    assert_eq!(baseline, linked_from_enumeration(false)?);
    Ok(())
}

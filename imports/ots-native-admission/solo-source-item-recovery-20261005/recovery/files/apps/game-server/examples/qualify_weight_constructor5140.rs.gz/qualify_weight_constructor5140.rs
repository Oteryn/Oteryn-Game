//! Exact Source constructor0 data qualification; mixed artifact profile gap remains explicit.
use oteryn_game_server::content::*;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    ffi::OsStr,
    fs,
    path::PathBuf,
};
const GATE_SHA: &str = "7ac209e9dce771fa6a685a1979e72c1944cbcd783dd5a30f2bf6981ea2bbfc14";
macro_rules! require {
    ($condition:expr) => {
        if !($condition) {
            return Err(concat!("weight qualification: ", stringify!($condition)).into());
        }
    };
}
fn sha(raw: &[u8]) -> String {
    Sha256::digest(raw)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}
fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        // Prospective Source presentation/flags reference: 6,806,159 JSON values and 120,518,897 UTF-8 string bytes.
        max_documents: 11,
        max_document_bytes: 192 * 1024 * 1024,
        max_total_bytes: 256 * 1024 * 1024,
        max_json_depth: 24,
        max_decoded_fields: 7_500_000,
        max_string_bytes: 136_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT + 21_069 + 2_220,
        max_import_records: 12,
        max_reimport_states: 400,
    }
}
fn weight(record: &Value) -> Value {
    let unknown = serde_json::json!({"state": "UNKNOWN"});
    let group = record.get("semantics").and_then(|s| s.get("physical"));
    match group {
        Some(group) if group["state"] == "KNOWN" => {
            group["value"].get("weight").cloned().unwrap_or(unknown)
        }
        Some(group) => group.clone(),
        None => unknown,
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args_os().skip(1).collect();
    let [repository, gate_path] = args.as_slice() else {
        return Err("usage: qualify_weight_constructor5140 <repository> <sealed-gate.json>".into());
    };
    let root = PathBuf::from(repository);
    let raw = fs::read(gate_path)?;
    require!(sha(&raw) == GATE_SHA);
    let gate: Value = serde_json::from_slice(&raw)?;
    require!(gate["schema"] == "OTERYN_QUALIFIED_CANARY_WEIGHT_CONSTRUCTOR0_ADMISSIONS/v1");
    require!(gate["count"] == 5140 && gate["unit"] == "centi_oz");
    let qualified = gate["qualified"]
        .as_array()
        .ok_or("qualified cohort missing")?;
    require!(qualified.len() == 5140);
    for (path, field) in [
        ("imports/canary/bindings/items.json", "binding_sha256"),
        (
            "imports/canary/primary-items/sources.json",
            "source_header_sha256",
        ),
    ] {
        require!(
            sha(&fs::read(root.join(path))?) == gate[field].as_str().ok_or("Source pin missing")?
        );
    }
    let mut keys = BTreeSet::new();
    for row in qualified {
        require!(
            row["identity"]["family"] == "Item" && row["identity"]["revision"] == "definition-r1"
        );
        let key = row["identity"]["key"].as_str().ok_or("key missing")?;
        require!(key != "oteryn:item.tibia.i901" && keys.insert(key.to_owned()));
        require!(
            row["raw_xml_weight"] == "ABSENT"
                && row["has_id"] == true
                && row["stored_flags_parent_count"] == 1
        );
    }
    let mut views: BTreeMap<&str, BTreeMap<String, Value>> = BTreeMap::new();
    for role in ["canonical", "reference"] {
        let mut records = Vec::new();
        if role == "reference" {
            let doc: Value = serde_json::from_slice(&fs::read(
                root.join("content/world/definitions/reference.json"),
            )?)?;
            records.extend(
                doc["records"]
                    .as_array()
                    .ok_or("reference records missing")?
                    .iter()
                    .cloned(),
            );
        } else {
            for entry in fs::read_dir(root.join("content/items/definitions"))? {
                let path = entry?.path();
                if path
                    .file_name()
                    .is_some_and(|n| n.to_string_lossy().starts_with("items-"))
                {
                    let doc: Value = serde_json::from_slice(&fs::read(path)?)?;
                    records.extend(
                        doc["records"]
                            .as_array()
                            .ok_or("canonical records missing")?
                            .iter()
                            .map(|r| r["definition"].clone()),
                    );
                }
            }
        }
        let mut items = BTreeMap::new();
        for record in records {
            if record["kind"] == "Item" {
                let key = record["identity"]["key"]
                    .as_str()
                    .ok_or("record key missing")?
                    .to_owned();
                require!(items.insert(key, record).is_none());
            }
        }
        let outside: BTreeMap<_, _> = items
            .iter()
            .filter(|(k, _)| !keys.contains(*k))
            .map(|(k, v)| (k, weight(v)))
            .collect();
        require!(
            sha(&serde_json::to_vec(&outside)?)
                == gate["non_target_weight_fingerprints"][role]
                    .as_str()
                    .ok_or("outside fingerprint missing")?
        );
        for row in qualified {
            let item = items
                .get(
                    row["identity"]["key"]
                        .as_str()
                        .ok_or("target key missing")?,
                )
                .ok_or("target missing")?;
            require!(item["identity"] == row["identity"]);
            let group = &item["semantics"]["physical"];
            require!(
                sha(&serde_json::to_vec(group)?)
                    == row["expected_group_sha256"][role]
                        .as_str()
                        .ok_or("group hash missing")?
            );
            let typed: ReferenceItemField<ReferenceItemPhysical> =
                serde_json::from_value(group.clone())?;
            let ReferenceItemField::Known(physical) = typed else {
                return Err("physical group not Known".into());
            };
            require!(matches!(physical.weight, ReferenceItemField::Known(0)));
            require!(
                matches!(physical.movable, ReferenceItemField::Known(_))
                    && matches!(physical.pickupable, ReferenceItemField::Known(_))
            );
        }
        require!(
            sha(&serde_json::to_vec(
                items.get("oteryn:item.tibia.i901").ok_or("901missing")?
            )?) == gate["protected901_guard"][role]
                .as_str()
                .ok_or("901guard missing")?
        );
        views.insert(role, items);
    }
    let project = capture_world_project(
        &root.join("content"),
        OsStr::new("world"),
        ProjectFilesystemLimits {
            project: limits(),
            max_entries_per_directory_scan: 32,
            max_total_directory_entries_scanned: 205,
        },
    )?;
    let linked = project.link()?;
    match compile_reference_playable(&linked) {
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual: 61185,
            limit: 38157,
        }) => println!("GAP_ARTIFACT_PROFILE_SCOPE61185/38157; no fullmixedartifact claim"),
        Err(error) => return Err(error.into()),
        Ok(_) => return Err("artifact scope changed; separatequalification required".into()),
    }
    let one = project.canonical_documents(limits())?;
    let bytes = one.documents().clone();
    let parsed_one = one.into_snapshot(limits())?.parse(limits())?;
    let linked_one = parsed_one.link()?;
    let two = parsed_one.canonical_documents(limits())?;
    require!(&bytes == two.documents());
    let linked_two = two.into_snapshot(limits())?.parse(limits())?.link()?;
    require!(
        linked.definitions == linked_one.definitions
            && linked_one.definitions == linked_two.definitions
    );
    for content in [&linked, &linked_one, &linked_two] {
        let defs: BTreeMap<_, _> = content
            .definitions
            .iter()
            .map(|d| (d.definition.key().as_str(), d))
            .collect();
        for key in &keys {
            let definition = defs.get(key.as_str()).ok_or("linked target missing")?;
            require!(definition.definition.family() == DefinitionFamily::Item);
            let ReferenceDefinitionKind::Item(item) = &definition.kind else {
                return Err("linked target not Item".into());
            };
            require!(
                serde_json::to_value(&item.semantics.physical)?
                    == views["reference"][key]["semantics"]["physical"]
            );
        }
    }
    println!(
        "PASS5140_SOURCE_CONSTRUCTOR_WEIGHT0: bothviews, alloutsideweights andSDKKnownbools preserved,901guard,actualtypedlink/Native2gen;artifactscopegap explicit"
    );
    Ok(())
}

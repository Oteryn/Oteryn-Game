//! Frozen Source transform data qualification; no runtime activation or full artifact claim.
use oteryn_game_server::content::*;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    ffi::OsStr,
    fs,
    path::PathBuf,
};
const PACKET_SHA: &str = "c6f0b111670115b63c9f394eac5b452e1fe040d2e70c019119cdb05fccd00067";
const PRESERVATION_SHA: &str = "f5ffe958245d29556a02a94f59ba68177f2a64450728fba80b69260da7342bdc";
const KINDS: &str = "ROTATE WRAP USE EQUIP DEEQUIP MALE FEMALE DESTROY DECAY WRITE_ONCE";
macro_rules! require {
    ($condition:expr) => {
        if !($condition) {
            return Err(concat!("qualification failed: ", stringify!($condition)).into());
        }
    };
}
fn sha(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    digest.iter().map(|b| format!("{b:02x}")).collect()
}
fn other_fields(mut item: Value) -> Value {
    if let Some(semantics) = item.get_mut("semantics").and_then(Value::as_object_mut) {
        semantics.remove("use_transform");
        semantics.retain(|_, field| field["state"] != "UNKNOWN");
        if semantics.is_empty()
            && let Some(object) = item.as_object_mut()
        {
            object.remove("semantics");
        }
    }
    item
}
fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        // Prospective Source presentation/flags reference: 6,806,159 JSON values and 120,518,897 UTF-8 string bytes.
        max_documents: 11,
        max_document_bytes: 192 * 1024 * 1024,
        max_total_bytes: 256 * 1024 * 1024,
        max_json_depth: 24,
        max_decoded_fields: 7_500_000,
        max_string_bytes: 136_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT + 21_069 + 2_220,
        max_import_records: 12,
        max_reimport_states: 400,
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args_os().skip(1).collect();
    let [repository, packet_path, preservation_path] = args.as_slice() else {
        return Err(
            "usage: qualify_source_transforms1662 <repository> <packet> <preservation>".into(),
        );
    };
    let root = PathBuf::from(repository);
    let raw = fs::read(packet_path)?;
    require!(sha(&raw) == PACKET_SHA);
    let packet: Value = serde_json::from_slice(&raw)?;
    let raw = fs::read(preservation_path)?;
    require!(sha(&raw) == PRESERVATION_SHA);
    let preservation: Value = serde_json::from_slice(&raw)?;
    require!(packet["phase"] == "OWN_ORDERED_CPP_XML_DEFINITION_PHASE_BEFORE_LUA_AND_RUNTIME");
    let admitted = packet["admitted"].as_array().ok_or("missing cohort")?;
    let kinds: Vec<_> = KINDS.split(' ').collect();
    require!(admitted.len() == 1662);
    let mut expectations = BTreeMap::new();
    let target_facts = preservation["targets"]
        .as_object()
        .ok_or("missing targets")?
        .clone();
    {
        let mut bindings = BTreeSet::new();
        for provider in ["canary", "crystalserver"] {
            let raw = fs::read(root.join(format!("imports/{provider}/bindings/items.json")))?;
            let binding_doc: Value = serde_json::from_slice(&raw)?;
            let rows = binding_doc["bindings"].as_array().ok_or("bindings")?;
            for b in rows {
                bindings.insert(serde_json::to_string(b)?);
            }
        }
        for (path, expected) in packet["input_sha256"]
            .as_object()
            .ok_or("missing input pins")?
        {
            if !path.starts_with("content/") {
                require!(sha(&fs::read(root.join(path))?) == expected.as_str().ok_or("pin")?);
            }
        }
        let mut documents = BTreeMap::new();
        let before_docs = preservation["documents"].as_object().ok_or("documents")?;
        require!(before_docs.len() == 60);
        for (path, before) in before_docs {
            let actual: Value = serde_json::from_slice(&fs::read(root.join(path))?)?;
            let olds = before["records"].as_array().ok_or("records")?;
            let news = actual["records"].as_array().ok_or("records")?;
            require!(olds.len() == news.len());
            for (a, b) in olds.iter().zip(news) {
                let old = a.get("definition").unwrap_or(a);
                let new = b.get("definition").unwrap_or(b);
                require!(other_fields(old.clone()) == other_fields(new.clone()));
                if old["identity"]["key"] == "oteryn:item.tibia.i901" {
                    require!(old == new);
                }
            }
            documents.insert(path.clone(), actual);
        }
        let mut source_counts = [0usize; 2];
        let mut target_counts = [0usize; 2];
        let mut slots = 0usize;
        for row in admitted {
            let key = row["identity"]["key"].as_str().ok_or("identity")?;
            require!(row["identity"]["family"] == "Item" && key != "oteryn:item.tibia.i901");
            for (role_index, role) in ["canonical", "reference"].iter().enumerate() {
                let view = &row[*role];
                let path = view["path"].as_str().ok_or("path")?;
                let index = view["record_index"].as_u64().ok_or("index")? as usize;
                let record = &documents.get(path).ok_or("document")?["records"][index];
                let item = record.get("definition").unwrap_or(record);
                require!(
                    item["identity"] == row["identity"]
                        && item["semantics"]["use_transform"] == view["native_group"]
                );
                source_counts[role_index] += usize::from(item["materializable"] == true);
                let old = &view["expected_group"];
                require!(old["state"] == "UNKNOWN" || old["state"] == "KNOWN");
                let targets = view["native_group"]["value"]["targets"]
                    .as_array()
                    .ok_or("targets")?;
                require!(view["native_group"]["state"] == "KNOWN" && targets.len() == 10);
                for (index, target) in targets.iter().enumerate() {
                    require!(target["kind"] == kinds[index]);
                    if old["state"] == "KNOWN"
                        && old["value"]["targets"][index]["target"]["state"] != "UNKNOWN"
                    {
                        require!(old["value"]["targets"][index] == *target);
                    }
                    if target["target"]["state"] == "KNOWN" {
                        let value = &target["target"]["value"];
                        let key = value["key"].as_str().ok_or("target key")?;
                        let fact = target_facts.get(key).ok_or("closed target")?;
                        require!(value["revision"] == fact["identity"]["revision"]);
                        target_counts[role_index] +=
                            usize::from(fact[format!("{role}_materializable")] == true);
                        if *role == "reference" {
                            slots += 1;
                        }
                    }
                }
                let _: ReferenceItemField<ReferenceItemUseTransform> =
                    serde_json::from_value(view["native_group"].clone())?;
            }
            for proofs in row["evidence"].as_object().ok_or("evidence")?.values() {
                for proof in proofs.as_array().ok_or("proofs")? {
                    let source = &proof["source"]["binding"];
                    let target = &proof["target_binding"];
                    require!(
                        bindings.contains(&serde_json::to_string(source)?)
                            && bindings.contains(&serde_json::to_string(target)?)
                    );
                    require!(
                        source["target"] == row["identity"] && target["target"]["family"] == "Item"
                    );
                    for field in ["source_key", "source_revision", "identity_namespace"] {
                        require!(source[field] == target[field]);
                    }
                }
            }
            require!(
                expectations
                    .insert(key.to_string(), row["reference"]["native_group"].clone())
                    .is_none()
            );
        }
        require!(slots == 2340 && source_counts == [15, 0] && target_counts == [20, 0]);
        for fact in target_facts.values() {
            let path = fact["canonical_path"].as_str().ok_or("target path")?;
            if !documents.contains_key(path) {
                documents.insert(
                    path.to_string(),
                    serde_json::from_slice(&fs::read(root.join(path))?)?,
                );
            }
            let item = &documents.get(path).ok_or("target document")?["records"]
                [fact["canonical_index"].as_u64().ok_or("target index")? as usize]["definition"];
            require!(
                item["identity"] == fact["identity"]
                    && item["materializable"] == fact["canonical_materializable"]
            );
        }
    }
    drop(preservation);
    let project = capture_world_project(
        &root.join("content"),
        OsStr::new("world"),
        ProjectFilesystemLimits {
            project: limits(),
            max_entries_per_directory_scan: 32,
            max_total_directory_entries_scanned: 205,
        },
    )?;
    let linked = project.link()?;
    match compile_reference_playable(&linked) {
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual: 61185,
            limit: 38157,
        }) => println!("GAP_ARTIFACT_PROFILE_SCOPE61185/38157: no full1662 artifact/load claim"),
        Err(error) => return Err(error.into()),
        Ok(_) => return Err("artifact scope changed; separate qualification required".into()),
    }
    let one = project.canonical_documents(limits())?;
    let bytes = one.documents().clone();
    let parsed = one.into_snapshot(limits())?.parse(limits())?;
    let linked_one = parsed.link()?;
    let two = parsed.canonical_documents(limits())?;
    require!(&bytes == two.documents());
    let linked_two = two.into_snapshot(limits())?.parse(limits())?.link()?;
    require!(
        linked.definitions == linked_one.definitions
            && linked_one.definitions == linked_two.definitions
    );
    for content in [&linked, &linked_one, &linked_two] {
        let definitions: BTreeMap<_, _> = content
            .definitions
            .iter()
            .map(|d| (d.definition.key().as_str(), d))
            .collect();
        for (key, expected) in &expectations {
            let definition = definitions.get(key.as_str()).ok_or("source Item absent")?;
            let ReferenceDefinitionKind::Item(item) = &definition.kind else {
                return Err("source not Item".into());
            };
            require!(serde_json::to_value(&item.semantics.use_transform)? == *expected);
        }
        for (key, fact) in &target_facts {
            let definition = definitions.get(key.as_str()).ok_or("target absent")?;
            require!(
                definition.definition.family() == DefinitionFamily::Item
                    && definition.definition.revision().as_str() == fact["identity"]["revision"]
            );
            let ReferenceDefinitionKind::Item(item) = &definition.kind else {
                return Err("target not Item".into());
            };
            require!(Value::Bool(item.materializable) == fact["reference_materializable"]);
        }
    }
    println!("PASS_SOURCE_TRANSFORMS1662");
    Ok(())
}

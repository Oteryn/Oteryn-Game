//! Exact Source constructor0 data qualification; mixed artifact profile gap remains explicit.
use oteryn_game_server::content::*;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    ffi::OsStr,
    fs,
    path::PathBuf,
};
const GATE_SHA: &str = "dc3d27fc434bc1bce18b13c3eacaafce3d0307dc49d2bed33a354c01bd0a21b0";
macro_rules! require {
    ($condition:expr) => {
        if !($condition) {
            return Err(concat!("armor qualification: ", stringify!($condition)).into());
        }
    };
}
fn sha(raw: &[u8]) -> String {
    Sha256::digest(raw)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}
fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        // Prospective Source presentation/flags reference: 6,806,159 JSON values and 120,518,897 UTF-8 string bytes.
        max_documents: 11,
        max_document_bytes: 192 * 1024 * 1024,
        max_total_bytes: 256 * 1024 * 1024,
        max_json_depth: 24,
        max_decoded_fields: 7_500_000,
        max_string_bytes: 136_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT + 21_069 + 2_220,
        max_import_records: 12,
        max_reimport_states: 400,
    }
}
fn protection(record: &Value) -> Value {
    record
        .get("semantics")
        .and_then(|v| v.get("protection"))
        .cloned()
        .unwrap_or_else(|| serde_json::json!({"state":"UNKNOWN"}))
}
fn child_projection(
    item: &Value,
    proof: &Value,
    role: &str,
) -> Result<Value, Box<dyn std::error::Error>> {
    let mut group = protection(item);
    let witness = proof["qualified"]
        .as_array()
        .ok_or("child witnesses")?
        .iter()
        .find(|r| r["identity"] == item["identity"]);
    if let Some(witness) = witness {
        let pin = &witness["views"][role];
        require!(item["kind"] == "Item");
        require!(sha(&serde_json::to_vec(&group)?) == pin["after_group_sha256"]);
        let child = group["value"]["observed_resistance_parameters"].clone();
        require!(child["state"] == "KNOWN");
        require!(sha(&serde_json::to_vec(&child)?) == pin["child_sha256"]);
        group["value"]
            .as_object_mut()
            .ok_or("protection value")?
            .remove("observed_resistance_parameters");
        require!(sha(&serde_json::to_vec(&group)?) == pin["before_group_sha256"]);
    } else {
        require!(
            group["value"]
                .get("observed_resistance_parameters")
                .is_none_or(|v| v == &serde_json::json!({"state":"UNKNOWN"}))
        );
    }
    Ok(group)
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args_os().skip(1).collect();
    let [repository, gate_path] = args.as_slice() else {
        return Err("usage: qualify_armor_constructor11277 <repository> <sealed-gate.json>".into());
    };
    let root = PathBuf::from(repository);
    let raw = fs::read(gate_path)?;
    require!(sha(&raw) == GATE_SHA);
    let gate: Value = serde_json::from_slice(&raw)?;
    let child_raw =
        fs::read(root.join("imports/canary/primary-items/armor-source-child-successor.json"))?;
    require!(sha(&child_raw) == "8dc6babbe695659b47f7e6fd977c1c81c809a99c1906e5c562a15e3d7e80d5a2");
    let child: Value = serde_json::from_slice(&child_raw)?;
    require!(child["prior_gate_sha256"] == GATE_SHA && child["count"] == 405);
    require!(
        child["qualified"]
            .as_array()
            .is_some_and(|v| v.len() == 405)
    );
    require!(
        sha(&fs::read(root.join(
            "imports/ots-native-admission/primary-observations/observation-admissions.json"
        ))?) == child["own_observation_gate_sha256"]
    );

    require!(gate["schema"] == "OTERYN_QUALIFIED_CANARY_ARMOR_CONSTRUCTOR0_ADMISSIONS/v1");
    require!(gate["count"] == 11277 && gate["unit"] == "signed_base_armor_points");
    let qualified = gate["qualified"]
        .as_array()
        .ok_or("qualified cohort missing")?;
    require!(qualified.len() == 11277);
    for (path, field) in [
        ("imports/canary/bindings/items.json", "binding_sha256"),
        (
            "imports/canary/primary-items/sources.json",
            "source_header_sha256",
        ),
    ] {
        require!(
            sha(&fs::read(root.join(path))?) == gate[field].as_str().ok_or("Source pin missing")?
        );
    }
    require!(
        gate["all_qualified_raw_witness"]
            == serde_json::json!({"has_id":true,"stored_flags_parent_count":1,"raw_xml_armor":"ABSENT"})
    );
    let binding_doc: Value =
        serde_json::from_slice(&fs::read(root.join("imports/canary/bindings/items.json"))?)?;
    let bindings = binding_doc["bindings"]
        .as_array()
        .ok_or("bindings missing")?;
    let mut keys = BTreeSet::new();
    for row in qualified {
        let key = row[0].as_str().ok_or("key missing")?;
        let id = row[1].as_u64().ok_or("sourceID missing")?;
        require!(
            key != "oteryn:item.tibia.i901"
                && keys.insert(key.to_owned())
                && (1..=65535).contains(&id)
                && row[2].as_u64().is_some()
        );
        let identity = serde_json::json!({"family":"Item","key":key,"revision":"definition-r1"});
        let found: Vec<_> = bindings
            .iter()
            .filter(|b| b["target"]["key"] == key)
            .collect();
        require!(
            found.len() == 1
                && found[0]
                    == &serde_json::json!({"disposition":"EXACT","external_id":id.to_string(),"identity_namespace":"ots/item_server_id","source_key":"oteryn:source.canary","source_revision":"47dfd51f45280a59a1d3e50ba7edd573d7234446","target":identity})
        );
    }
    let mut views: BTreeMap<&str, BTreeMap<String, Value>> = BTreeMap::new();
    for role in ["canonical", "reference"] {
        let mut records = Vec::new();
        if role == "reference" {
            let doc: Value = serde_json::from_slice(&fs::read(
                root.join("content/world/definitions/reference.json"),
            )?)?;
            records.extend(
                doc["records"]
                    .as_array()
                    .ok_or("reference records missing")?
                    .iter()
                    .cloned(),
            );
        } else {
            for entry in fs::read_dir(root.join("content/items/definitions"))? {
                let path = entry?.path();
                if path
                    .file_name()
                    .is_some_and(|n| n.to_string_lossy().starts_with("items-"))
                {
                    let doc: Value = serde_json::from_slice(&fs::read(path)?)?;
                    records.extend(
                        doc["records"]
                            .as_array()
                            .ok_or("canonical records missing")?
                            .iter()
                            .map(|r| r["definition"].clone()),
                    );
                }
            }
        }
        let mut items = BTreeMap::new();
        for record in records {
            if record["kind"] == "Item" {
                let key = record["identity"]["key"]
                    .as_str()
                    .ok_or("record key missing")?
                    .to_owned();
                require!(items.insert(key, record).is_none());
            }
        }
        for witness in child["qualified"].as_array().ok_or("child witnesses")? {
            let key = witness["identity"]["key"].as_str().ok_or("child key")?;
            child_projection(items.get(key).ok_or("child Item missing")?, &child, role)?;
        }
        let outside: BTreeMap<_, _> = items
            .iter()
            .filter(|(k, _)| !keys.contains(*k))
            .map(|(k, v)| Ok((k, child_projection(v, &child, role)?)))
            .collect::<Result<_, Box<dyn std::error::Error>>>()?;
        require!(
            sha(&serde_json::to_vec(&outside)?)
                == gate["non_target_protection_fingerprints"][role]
                    .as_str()
                    .ok_or("outside fingerprint missing")?
        );
        for row in qualified {
            let key = row[0].as_str().ok_or("target key missing")?;
            let item = items.get(key).ok_or("target missing")?;
            require!(
                item["identity"]
                    == serde_json::json!({"family":"Item","key":key,"revision":"definition-r1"})
            );
            let group = child_projection(item, &child, role)?;
            require!(
                group == gate["expected_groups"][role]
                    && sha(&serde_json::to_vec(&group)?)
                        == gate["expected_group_sha256"][role]
                            .as_str()
                            .ok_or("group hash missing")?
            );
            let typed: ReferenceItemField<ReferenceItemProtection> = serde_json::from_value(group)?;
            let ReferenceItemField::Known(value) = typed else {
                return Err("protection not Known".into());
            };
            require!(matches!(
                value.armor,
                ReferenceItemField::Known(ReferenceSignedPoints(0))
            ));
        }
        require!(
            sha(&serde_json::to_vec(
                items.get("oteryn:item.tibia.i901").ok_or("901missing")?
            )?) == gate["protected901_guard"][role]
                .as_str()
                .ok_or("901guard missing")?
        );
        views.insert(role, items);
    }
    let project = capture_world_project(
        &root.join("content"),
        OsStr::new("world"),
        ProjectFilesystemLimits {
            project: limits(),
            max_entries_per_directory_scan: 32,
            max_total_directory_entries_scanned: 205,
        },
    )?;
    let linked = project.link()?;
    match compile_reference_playable(&linked) {
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual: 61185,
            limit: 38157,
        }) => println!("GAP_ARTIFACT_PROFILE_SCOPE61185/38157; no fullmixedartifact claim"),
        Err(error) => return Err(error.into()),
        Ok(_) => return Err("artifact scope changed; separatequalification required".into()),
    }
    let one = project.canonical_documents(limits())?;
    let bytes = one.documents().clone();
    let parsed_one = one.into_snapshot(limits())?.parse(limits())?;
    let linked_one = parsed_one.link()?;
    let two = parsed_one.canonical_documents(limits())?;
    require!(&bytes == two.documents());
    let linked_two = two.into_snapshot(limits())?.parse(limits())?.link()?;
    require!(
        linked.definitions == linked_one.definitions
            && linked_one.definitions == linked_two.definitions
    );
    for content in [&linked, &linked_one, &linked_two] {
        let defs: BTreeMap<_, _> = content
            .definitions
            .iter()
            .map(|d| (d.definition.key().as_str(), d))
            .collect();
        for key in &keys {
            let definition = defs.get(key.as_str()).ok_or("linked target missing")?;
            require!(definition.definition.family() == DefinitionFamily::Item);
            let ReferenceDefinitionKind::Item(item) = &definition.kind else {
                return Err("linked target not Item".into());
            };
            require!(
                serde_json::to_value(&item.semantics.protection)?
                    == views["reference"][key]["semantics"]["protection"]
            );
        }
    }
    println!(
        "PASS11277_SOURCE_CONSTRUCTOR_ARMOR0: bothviews, alloutsideprotection/resistance states preserved,901guard,actualtypedbasearmorlink/Native2gen;artifactscopegap explicit"
    );
    Ok(())
}

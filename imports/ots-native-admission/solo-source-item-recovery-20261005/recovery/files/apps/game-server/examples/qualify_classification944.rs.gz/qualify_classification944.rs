//! Frozen Source classification data only; no capabilities/runtime/profile-completeness claim.
use oteryn_game_server::content::*;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    ffi::OsStr,
    fs,
    path::PathBuf,
};
const PACKET_SHA: &str = "164e7a648967558c2b5089a1b71c2528a4f8c88657809ef87d80122f05d3d23e";
const PRESERVATION_SHA: &str = "c4aab253a6d3591360976b5fcc70d74af1af2ec8f1e0c9534b4ef1f5d89f7fff";
macro_rules! require {
    ($condition:expr) => {
        if !($condition) {
            return Err(concat!("classification qualification: ", stringify!($condition)).into());
        }
    };
}
fn sha(raw: &[u8]) -> String {
    Sha256::digest(raw)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}
fn classification(item: &Value) -> Value {
    item.pointer("/semantics/classification")
        .cloned()
        .unwrap_or(serde_json::json!({"state":"UNKNOWN"}))
}
fn other_fields(mut record: Value) -> Value {
    if let Some(definition) = record.get_mut("definition") {
        *definition = other_fields(definition.clone());
        return record;
    }
    if let Some(fields) = record.get_mut("semantics").and_then(Value::as_object_mut) {
        fields.remove("classification");
        fields.retain(|_, field| field != &serde_json::json!({"state":"UNKNOWN"}));
        if fields.is_empty()
            && let Some(object) = record.as_object_mut()
        {
            object.remove("semantics");
        }
    }
    record
}
fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        // Prospective Source presentation/flags reference: 6,806,159 JSON values and 120,518,897 UTF-8 string bytes.
        max_documents: 11,
        max_document_bytes: 192 * 1024 * 1024,
        max_total_bytes: 256 * 1024 * 1024,
        max_json_depth: 24,
        max_decoded_fields: 7_500_000,
        max_string_bytes: 136_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT + 21_069 + 2_220,
        max_import_records: 12,
        max_reimport_states: 400,
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args_os().skip(1).collect();
    let [repository, packet_path, preservation_path] = args.as_slice() else {
        return Err("usage: qualify_classification944 <repo> <packet> <before>".into());
    };
    let root = PathBuf::from(repository);
    let raw = fs::read(packet_path)?;
    require!(sha(&raw) == PACKET_SHA);
    let packet: Value = serde_json::from_slice(&raw)?;
    let raw = fs::read(preservation_path)?;
    require!(sha(&raw) == PRESERVATION_SHA);
    let preservation: Value = serde_json::from_slice(&raw)?;
    let rows = packet["records"].as_array().ok_or("cohort")?;
    require!(rows.len() == 944);
    let mut expectations = BTreeMap::new();
    {
        let mut bindings = BTreeSet::new();
        for provider in ["crystalserver", "canary"] {
            let doc: Value = serde_json::from_slice(&fs::read(
                root.join(format!("imports/{provider}/bindings/items.json")),
            )?)?;
            for binding in doc["bindings"].as_array().ok_or("bindings")? {
                bindings.insert(serde_json::to_string(binding)?);
            }
        }
        for field in [
            "current_input_sha256",
            "unchanged_world_catalog_sha256",
            "unchanged_gate_sha256",
        ] {
            for (path, expected) in packet[field].as_object().ok_or("Source/world/gate pins")? {
                require!(sha(&fs::read(root.join(path))?) == expected.as_str().ok_or("pin")?);
            }
        }
        let before_rows = preservation["records"]
            .as_array()
            .ok_or("full before rows")?;
        require!(before_rows.len() == 944);
        let before_by_key: BTreeMap<_, _> = before_rows
            .iter()
            .map(|r| (r["identity"]["key"].as_str(), r))
            .collect();
        require!(before_by_key.len() == 944);
        let mut documents: BTreeMap<String, Value> = BTreeMap::new();
        let mut counts = [0usize; 2];
        for row in rows {
            let target = &row["target"];
            let key = target["key"].as_str().ok_or("target")?;
            require!(
                target["family"] == "Item"
                    && target["revision"] == "definition-r1"
                    && key != "oteryn:item.tibia.i901"
            );
            let group = &row["native_group"];
            let kind = group["value"]["item_type"]["value"]
                .as_str()
                .ok_or("kind")?;
            let typed: ReferenceItemField<ReferenceItemClassification> =
                serde_json::from_value(group.clone())?;
            let ReferenceItemField::Known(value) = typed else {
                return Err("classification not Known".into());
            };
            require!(
                matches!(value.item_type, ReferenceItemField::Known(_))
                    && value.capabilities == ReferenceItemField::Unknown
            );
            for evidence in row["source_evidence"].as_array().ok_or("own evidence")? {
                let binding = &evidence["binding"];
                require!(bindings.contains(&serde_json::to_string(binding)?));
                require!(
                    binding["target"] == *target
                        && binding["disposition"] == "EXACT"
                        && binding["identity_namespace"] == "ots/item_server_id"
                );
                require!(
                    kind.replace('_', "")
                        == evidence["source_direct_kind"].as_str().ok_or("kind")?
                );
            }
            let preserved = before_by_key
                .get(&Some(key))
                .ok_or("sealed before target")?;
            require!(
                preserved["identity"] == *target && preserved["expected_classification"] == *group
            );
            for (role_index, role) in ["canonical", "reference"].iter().enumerate() {
                let view = &row[*role];
                let path = view["path"].as_str().ok_or("path")?;
                if !documents.contains_key(path) {
                    documents.insert(
                        path.to_string(),
                        serde_json::from_slice(&fs::read(root.join(path))?)?,
                    );
                }
                let index = view["record_index"].as_u64().ok_or("index")? as usize;
                let actual_record = &documents.get(path).ok_or("document")?["records"][index];
                let before_record = &preserved[*role]["before_record"];
                require!(
                    preserved[*role]["path"] == path
                        && preserved[*role]["record_index"] == view["record_index"]
                );
                require!(
                    other_fields(before_record.clone()) == other_fields(actual_record.clone())
                );
                let item = actual_record.get("definition").unwrap_or(actual_record);
                let before = before_record.get("definition").unwrap_or(before_record);
                require!(item["identity"] == *target && classification(item) == *group);
                require!(classification(before) == serde_json::json!({"state":"UNKNOWN"}));
                require!(classification(before) == view["expected_group"]);
                counts[role_index] += usize::from(item["materializable"] == true);
            }
            require!(
                expectations
                    .insert(key.to_string(), group.clone())
                    .is_none()
            );
        }
        require!(counts == [35, 12]);
        for (role, path) in [
            ("reference", "content/world/definitions/reference.json"),
            (
                "canonical",
                "content/items/definitions/items-32500-32999.json",
            ),
        ] {
            let doc: Value = serde_json::from_slice(&fs::read(root.join(path))?)?;
            let record = doc["records"]
                .as_array()
                .ok_or("records")?
                .iter()
                .map(|r| r.get("definition").unwrap_or(r))
                .find(|r| r["identity"]["key"] == "oteryn:item.tibia.i901")
                .ok_or("901")?;
            require!(sha(&serde_json::to_vec(record)?) == packet["protected901_guard"][role]);
        }
    }
    drop(preservation);
    let project = capture_world_project(
        &root.join("content"),
        OsStr::new("world"),
        ProjectFilesystemLimits {
            project: limits(),
            max_entries_per_directory_scan: 32,
            max_total_directory_entries_scanned: 205,
        },
    )?;
    let linked = project.link()?;
    match compile_reference_playable(&linked) {
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual: 61185,
            limit: 38157,
        }) => println!("GAP_ARTIFACT_PROFILE_SCOPE61185/38157; no all944 artifact/load claim"),
        Err(error) => return Err(error.into()),
        Ok(_) => return Err("artifact scope changed; separate qualification required".into()),
    }
    let one = project.canonical_documents(limits())?;
    let bytes = one.documents().clone();
    let parsed = one.into_snapshot(limits())?.parse(limits())?;
    let linked_one = parsed.link()?;
    let two = parsed.canonical_documents(limits())?;
    require!(&bytes == two.documents());
    let linked_two = two.into_snapshot(limits())?.parse(limits())?.link()?;
    require!(
        linked.definitions == linked_one.definitions
            && linked_one.definitions == linked_two.definitions
    );
    for content in [&linked, &linked_one, &linked_two] {
        let definitions: BTreeMap<_, _> = content
            .definitions
            .iter()
            .map(|d| (d.definition.key().as_str(), d))
            .collect();
        for (key, expected) in &expectations {
            let definition = definitions.get(key.as_str()).ok_or("typed Item absent")?;
            require!(
                definition.definition.family() == DefinitionFamily::Item
                    && definition.definition.revision().as_str() == "definition-r1"
            );
            let ReferenceDefinitionKind::Item(item) = &definition.kind else {
                return Err("typed classification not Item".into());
            };
            require!(serde_json::to_value(&item.semantics.classification)? == *expected);
        }
    }
    println!("PASS_SOURCE_CLASSIFICATION944");
    Ok(())
}

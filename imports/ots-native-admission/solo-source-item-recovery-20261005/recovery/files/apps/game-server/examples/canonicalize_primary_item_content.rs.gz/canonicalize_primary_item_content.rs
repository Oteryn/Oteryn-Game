//! Canonicalize the tracked authoring package through the accepted Native reader.
//! Output goes to a fresh directory; the source package is never overwritten.

use oteryn_game_server::content::{
    CW2_B1_FULL_ITEM_FAMILY_COUNT, ProjectEvidenceLimits, ProjectFilesystemLimits,
    capture_world_project,
};
use std::{env, ffi::OsStr, fs, path::PathBuf};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let arguments: Vec<_> = env::args_os().skip(1).collect();
    let [source_parent, destination] = arguments.as_slice() else {
        return Err(
            "usage: canonicalize_primary_item_content <content-parent> <fresh-output>".into(),
        );
    };
    // Finite repository-package budgets follow the measured Source successor; these are not production maxima.
    let evidence = ProjectEvidenceLimits {
        // Prospective Source presentation/flags reference: 6,806,159 JSON values and 120,518,897 UTF-8 string bytes.
        max_documents: 11,
        max_document_bytes: 192 * 1024 * 1024,
        max_total_bytes: 256 * 1024 * 1024,
        max_json_depth: 24,
        max_decoded_fields: 7_500_000,
        max_string_bytes: 136_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT + 21_069 + 2_220,
        max_import_records: 12,
        // Composed evidence: 104 Encounter + 296 NPC reimport states.
        max_reimport_states: 104 + 296,
    };
    let project = capture_world_project(
        &PathBuf::from(source_parent),
        OsStr::new("world"),
        ProjectFilesystemLimits {
            project: evidence,
            max_entries_per_directory_scan: 32,
            max_total_directory_entries_scanned: 144 + 56 + 1 + 4,
        },
    )?;
    let canonical = project.canonical_documents(evidence)?;
    let output = PathBuf::from(destination);
    fs::create_dir(&output)?;
    for (locator, bytes) in canonical.documents() {
        let path = output.join(locator);
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }
        fs::write(path, bytes)?;
    }
    Ok(())
}

//! Qualification of a frozen raw-qualified SDK/own-loader absence cohort; no runtime activation.
use oteryn_game_server::content::*;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    ffi::OsStr,
    fs,
    path::PathBuf,
};
const PACKET_SHA256: &str = "e29b066c74413d749491d097df8bc1280360e4612843c865616d8e6e02b79141";
macro_rules! require {
    ($condition:expr) => {
        if !($condition) {
            return Err(concat!("qualification failed: ", stringify!($condition)).into());
        }
    };
}
fn sha(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}
fn known_preserved(before: &Value, after: &Value) -> bool {
    match before["state"].as_str() {
        Some("KNOWN") if before["value"].is_object() => {
            before["value"].as_object().is_some_and(|fields| {
                fields
                    .iter()
                    .all(|(k, v)| known_preserved(v, &after["value"][k]))
            })
        }
        Some("KNOWN" | "NOT_APPLICABLE" | "CONFLICT") => before == after,
        Some("UNKNOWN") => true,
        _ => false,
    }
}
fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        // Prospective Source presentation/flags reference: 6,806,159 JSON values and 120,518,897 UTF-8 string bytes.
        max_documents: 11,
        max_document_bytes: 192 * 1024 * 1024,
        max_total_bytes: 256 * 1024 * 1024,
        max_json_depth: 24,
        max_decoded_fields: 7_500_000,
        max_string_bytes: 136_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT + 21_069 + 2_220,
        max_import_records: 12,
        max_reimport_states: 400,
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args_os().skip(1).collect();
    let [repository, packet_path] = args.as_slice() else {
        return Err("usage: qualify_sdk_absence11751 <repository> <sealed-delta.json>".into());
    };
    let root = PathBuf::from(repository);
    let raw = fs::read(packet_path)?;
    require!(sha(&raw) == PACKET_SHA256);
    let packet: Value = serde_json::from_slice(&raw)?;
    require!(
        packet["schema"] == "OTERYN_CANARY_QUALIFIED_STORED_PARENT_CHILD_ABSENCE_ADDITIVE_DELTA/v1"
    );
    require!(packet["candidate_namespace"] == "primary-canary47df-sdk33.4-child-absence-static-r1");
    require!(packet["phase"] == "AFTER_CPP_PROTOBUF_LOAD_AND_ORDERED_XML_BEFORE_LUA_OR_RUNTIME");
    let admitted = packet["admitted"].as_array().ok_or("missing cohort")?;
    require!(admitted.len() == 11751);
    let mut keys = BTreeSet::new();
    let mut expectations = BTreeMap::new();
    let mut stack_keys = BTreeSet::new();
    {
        let mut documents = BTreeMap::new();
        for entry in admitted {
            for role in ["canonical", "reference"] {
                let path = entry[role]["path"].as_str().ok_or("missing path")?;
                if !documents.contains_key(path) {
                    require!(
                        path == "content/world/definitions/reference.json"
                            || path.starts_with("content/items/definitions/items-")
                    );
                    let document: Value = serde_json::from_slice(&fs::read(root.join(path))?)?;
                    documents.insert(path.to_string(), document);
                }
            }
        }
        for entry in admitted {
            let identity = &entry["identity"];
            let key = identity["key"].as_str().ok_or("missing key")?;
            require!(identity["family"] == "Item" && key != "oteryn:item.tibia.i901");
            require!(keys.insert(key.to_string()));
            require!(entry["evidence"]["has_id"] == true);
            require!(entry["evidence"]["stored_flags_parent_count"] == 1);
            let mut wanted = BTreeMap::new();
            for role in ["canonical", "reference"] {
                let view = &entry[role];
                let doc = documents
                    .get(view["path"].as_str().ok_or("missing path")?)
                    .ok_or("document absent")?;
                let index = view["record_index"].as_u64().ok_or("missing index")? as usize;
                let record = &doc["records"][index];
                let item = if role == "canonical" {
                    &record["definition"]
                } else {
                    record
                };
                require!(&item["identity"] == identity);
                let groups = view["groups"].as_object().ok_or("missing groups")?;
                for (kind, change) in groups {
                    require!(kind == "physical" || kind == "stack");
                    require!(known_preserved(
                        &change["expected_group"],
                        &change["native_group"]
                    ));
                    require!(item["semantics"][kind] == change["native_group"]);
                    if kind == "stack" {
                        let typed: ReferenceItemField<ReferenceItemStack> =
                            serde_json::from_value(change["native_group"].clone())?;
                        require!(matches!(
                            typed,
                            ReferenceItemField::Known(ReferenceItemStack {
                                stackable: ReferenceItemField::Known(false),
                                stack_max: ReferenceItemField::Known(1)
                            })
                        ));
                        require!(item["stack_class"] != "StackCapable");
                        stack_keys.insert(key.to_string());
                    } else {
                        let _: ReferenceItemField<ReferenceItemPhysical> =
                            serde_json::from_value(change["native_group"].clone())?;
                    }
                    if role == "reference" {
                        wanted.insert(kind.clone(), change["native_group"].clone());
                    }
                }
            }
            expectations.insert(key.to_string(), wanted);
        }
        for role in ["canonical", "reference"] {
            let mut found = 0;
            for (path, doc) in &documents {
                if (role == "reference") != (path == "content/world/definitions/reference.json") {
                    continue;
                }
                for record in doc["records"].as_array().ok_or("missing records")? {
                    let item = if role == "canonical" {
                        &record["definition"]
                    } else {
                        record
                    };
                    if item["identity"]["key"] == "oteryn:item.tibia.i901" {
                        let serialized = serde_json::to_vec(item)?;
                        require!(serialized.is_ascii());
                        require!(
                            sha(&serialized)
                                == packet["protected901_guard"][role]
                                    .as_str()
                                    .ok_or("missing901guard")?
                        );
                        found += 1;
                    }
                }
            }
            require!(found == 1);
        }
    }
    require!(keys.len() == 11751 && stack_keys.len() == 9497);
    let project = capture_world_project(
        &root.join("content"),
        OsStr::new("world"),
        ProjectFilesystemLimits {
            project: limits(),
            max_entries_per_directory_scan: 32,
            max_total_directory_entries_scanned: 205,
        },
    )?;
    let gate_raw =
        fs::read(root.join("imports/canary/primary-items/sdk-absence-stack-admissions.json"))?;
    require!(sha(&gate_raw) == "508181b9061b7859b257dde1547cce3da19c4f02cbd12362c1357ebdc1d687f8");
    let gate: Value = serde_json::from_slice(&gate_raw)?;
    require!(gate["fenced_delta_sha256"] == PACKET_SHA256);
    let gate_keys: BTreeSet<String> = serde_json::from_value(gate["qualified_targets"].clone())?;
    require!(gate_keys == stack_keys);
    for (path, field) in [
        ("imports/canary/bindings/items.json", "binding_sha256"),
        (
            "imports/canary/primary-items/sources.json",
            "source_header_sha256",
        ),
    ] {
        require!(
            sha(&fs::read(root.join(path))?)
                == gate[field].as_str().ok_or("missing own-source fence")?
        );
    }
    let linked = project.link()?;
    match compile_reference_playable(&linked) {
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual: 61185,
            limit: 38157,
        }) => println!("GAP_ARTIFACT_PROFILE_SCOPE61185/38157: no full cohort artifact/load claim"),
        Err(error) => return Err(error.into()),
        Ok(_) => return Err("artifact scope changed; separate qualification required".into()),
    }
    let one = project.canonical_documents(limits())?;
    let bytes = one.documents().clone();
    let parsed_one = one.into_snapshot(limits())?.parse(limits())?;
    let linked_one = parsed_one.link()?;
    let two = parsed_one.canonical_documents(limits())?;
    require!(&bytes == two.documents());
    let linked_two = two.into_snapshot(limits())?.parse(limits())?.link()?;
    require!(
        linked.definitions == linked_one.definitions
            && linked_one.definitions == linked_two.definitions
    );
    for content in [&linked, &linked_one, &linked_two] {
        let definitions: BTreeMap<_, _> = content
            .definitions
            .iter()
            .map(|d| (d.definition.key().as_str(), d))
            .collect();
        for (key, groups) in &expectations {
            let definition = definitions
                .get(key.as_str())
                .ok_or("linked target absent")?;
            require!(definition.definition.family() == DefinitionFamily::Item);
            let ReferenceDefinitionKind::Item(item) = &definition.kind else {
                return Err("linked target not Item".into());
            };
            for (kind, wanted) in groups {
                let actual = if kind == "stack" {
                    serde_json::to_value(&item.semantics.stack)?
                } else {
                    serde_json::to_value(&item.semantics.physical)?
                };
                require!(&actual == wanted);
            }
        }
    }
    println!("PASS_SOURCE_DATA11751");
    Ok(())
}

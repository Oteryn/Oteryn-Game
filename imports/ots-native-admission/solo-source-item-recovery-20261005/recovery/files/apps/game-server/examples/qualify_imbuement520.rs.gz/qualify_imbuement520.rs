//! Local whole520 SOURCE DATA qualification; full mixedworld artifact profile gap remains explicit.
use oteryn_game_server::content::*;
use serde::Deserialize;
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    ffi::OsStr,
    fs,
    path::PathBuf,
};

macro_rules! require {
    ($condition:expr) => {
        if !($condition) {
            return Err(concat!("qualification failed: ", stringify!($condition)).into());
        }
    };
}
macro_rules! equal {
    ($left:expr, $right:expr $(,)?) => {
        require!($left == $right);
    };
}
macro_rules! different {
    ($left:expr, $right:expr $(,)?) => {
        require!($left != $right);
    };
}

#[derive(Deserialize)]
struct Packet {
    operations: Vec<Operation>,
    source_candidates: usize,
    held_source_groups: usize,
}
#[derive(Deserialize)]
struct Operation {
    role: String,
    path: String,
    record_index: usize,
    identity: Identity,
    after_group: ReferenceItemField<ReferenceItemImbuement>,
}
#[derive(Deserialize)]
struct Identity {
    key: String,
    revision: String,
    family: String,
}

fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        // Prospective Source presentation/flags reference: 6,806,159 JSON values and 120,518,897 UTF-8 string bytes.
        max_documents: 11,
        max_document_bytes: 192 * 1024 * 1024,
        max_total_bytes: 256 * 1024 * 1024,
        max_json_depth: 24,
        max_decoded_fields: 7_500_000,
        max_string_bytes: 136_000_000,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: CW2_B1_FULL_ITEM_FAMILY_COUNT + 21_069 + 2_220,
        max_import_records: 12,
        max_reimport_states: 400,
    }
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args_os().skip(1).collect();
    let [repository, packet_path] = args.as_slice() else {
        return Err("usage: qualify_imbuement520 <repository> <fenced-packet.json>".into());
    };
    let root = PathBuf::from(repository);
    let packet: Packet = serde_json::from_slice(&fs::read(packet_path)?)?;
    equal!(packet.source_candidates, 520);
    equal!(packet.held_source_groups, 875);
    equal!(packet.operations.len(), 1040);
    let reference_ops: Vec<_> = packet
        .operations
        .iter()
        .filter(|op| op.role == "reference")
        .collect();
    equal!(reference_ops.len(), 520);
    let canonical_ops: Vec<_> = packet
        .operations
        .iter()
        .filter(|op| op.role == "canonical")
        .collect();
    equal!(canonical_ops.len(), 520);
    let mut keys = BTreeSet::new();
    {
        let mut documents = BTreeMap::new();
        let paths: BTreeSet<_> = packet.operations.iter().map(|op| &op.path).collect();
        for path in paths {
            let document: serde_json::Value = serde_json::from_slice(&fs::read(root.join(path))?)?;
            documents.insert(path.clone(), document);
        }
        for op in &packet.operations {
            equal!(op.identity.family, "Item");
            different!(op.identity.key, "oteryn:item.tibia.i901");
            let doc = documents.get(&op.path).ok_or("cached document absent")?;
            let record = &doc["records"][op.record_index];
            let item = if op.role == "canonical" {
                &record["definition"]
            } else {
                record
            };
            equal!(item["identity"]["key"], op.identity.key);
            equal!(item["identity"]["revision"], op.identity.revision);
            let group: ReferenceItemField<ReferenceItemImbuement> =
                serde_json::from_value(item["semantics"]["imbuement"].clone())?;
            equal!(group, op.after_group);
            if let ReferenceItemField::Known(value) = &group {
                equal!(value.allowed_family_tiers, ReferenceItemField::Unknown);
                equal!(value.excluded_families, ReferenceItemField::Unknown);
                require!(
                    matches!(&value.allowed_family_max_tiers, ReferenceItemField::Known(entries) if !entries.is_empty())
                );
            } else {
                return Err("whole ceiling group not Known".into());
            }
            if op.role == "reference" {
                require!(keys.insert(op.identity.key.clone()));
            }
        }
    }
    equal!(keys.len(), 520);
    let project = capture_world_project(
        &root.join("content"),
        OsStr::new("world"),
        ProjectFilesystemLimits {
            project: limits(),
            max_entries_per_directory_scan: 32,
            max_total_directory_entries_scanned: 205,
        },
    )?;
    let source = project.lower_reference_source()?;
    equal!(
        source.package_manifest.semantic_schema_version.as_str(),
        REFERENCE_PRIMARY_SOURCE_OBSERVATION_SCHEMA
    );
    let mut wrong_source = source.clone();
    wrong_source.package_manifest.semantic_schema_version =
        ProductionAtom::new("old schema negative", "reference-schema-v1")?;
    require!(link_reference_playable(wrong_source).is_err());
    let mut ceilings_only_source = source.clone();
    ceilings_only_source
        .package_manifest
        .semantic_schema_version = ProductionAtom::new(
        "ceilings-only downgrade negative",
        REFERENCE_IMBUEMENT_CEILING_SEMANTIC_SCHEMA,
    )?;
    require!(matches!(
        link_reference_playable(ceilings_only_source),
        Err(ContentError::RevisionMismatch(
            "Reference primary Source observation semantic schema"
        ))
    ));
    let linked = project.link()?;
    // Full mixedworld export exceeds the existing Item-family-only artifact profile.
    // This remains a component gap; never increase limits or invent filler Items.
    match compile_reference_playable(&linked) {
        Err(ContentError::LimitExceeded {
            resource: "Reference playable definitions",
            actual,
            limit,
        }) if actual == linked.definitions.len() && limit == 38_157 && actual > limit => {
            println!(
                "GAP_ARTIFACT_PROFILE_SCOPE: actual mixedworld definitions={actual}; protected Item-family profile={limit}; no full-package artifact/load claim"
            );
        }
        Err(error) => return Err(error.into()),
        Ok(_) => {
            return Err("artifact profile scope changed; requires separate qualification".into());
        }
    }
    let generation_one = project.canonical_documents(limits())?;
    let original_documents = generation_one.documents().clone();
    let generation_one_project = generation_one.into_snapshot(limits())?.parse(limits())?;
    let linked_one = generation_one_project.link()?;
    let generation_two = generation_one_project.canonical_documents(limits())?;
    equal!(&original_documents, generation_two.documents());
    let generation_two_project = generation_two.into_snapshot(limits())?.parse(limits())?;
    let linked_two = generation_two_project.link()?;
    equal!(&linked.definitions, &linked_one.definitions);
    equal!(&linked_one.definitions, &linked_two.definitions);
    for content in [&linked, &linked_one, &linked_two] {
        let definitions: BTreeMap<_, _> = content
            .definitions
            .iter()
            .map(|definition| (definition.definition.key().as_str(), definition))
            .collect();
        for op in &reference_ops {
            let definition = definitions
                .get(op.identity.key.as_str())
                .ok_or("linked Item absent")?;
            equal!(definition.definition.family(), DefinitionFamily::Item);
            equal!(
                definition.definition.revision().as_str(),
                op.identity.revision
            );
            let ReferenceDefinitionKind::Item(item) = &definition.kind else {
                return Err("linked cohort definition is not typed Item".into());
            };
            equal!(item.semantics.imbuement, op.after_group);
        }
    }
    println!(
        "PASS_SOURCE_DATA520 canonical/reference; all520 linked typed Items; new marker downgrade rejection; Native canonical writer second-generation byte/typed-definition idempotence; full mixedworld artifact scope gap retained"
    );
    Ok(())
}

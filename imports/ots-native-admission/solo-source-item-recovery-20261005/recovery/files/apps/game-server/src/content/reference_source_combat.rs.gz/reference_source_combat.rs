//! Closed own Source configurations; callbacks/evaluation/export remain independently held.
use super::{
    ContentError, ReferenceItemField, ReferenceMediaNamespace, ReferenceMediaSourceCut,
    ReferenceSourceQualifiedEnum,
};
use serde::{Deserialize, Serialize};
use std::sync::OnceLock;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum ReferenceCombatSourceCut {
    #[serde(rename = "CANARY_47DF")]
    Canary47df,
    #[serde(rename = "CRYSTAL_FF7")]
    CrystalFf7,
    #[serde(rename = "CRYSTAL_00CE")]
    Crystal00ce,
}
impl ReferenceCombatSourceCut {
    fn media_cut(self) -> ReferenceMediaSourceCut {
        match self {
            Self::Canary47df => ReferenceMediaSourceCut::Canary47df,
            Self::CrystalFf7 => ReferenceMediaSourceCut::CrystalFf7,
            Self::Crystal00ce => ReferenceMediaSourceCut::Crystal00ce,
        }
    }
}
macro_rules! source_enum {
    ($name:ident { $($member:ident),+ }) => {
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
        #[serde(rename_all = "SCREAMING_SNAKE_CASE")]
        pub enum $name { $($member),+ }
    };
}
source_enum!(ReferenceSourceCombatPhase {
    XmlItemtypeBeforeLua,
    LuaLiteralRegisterConfigurationSourceOnly
});
source_enum!(ReferenceSourceCombatOwner {
    CppItemtypeMeleeAttackEffect,
    LuaWeaponObjectFileContext
});
source_enum!(ReferenceSourceCombatEmission {
    CrystalCreatureSquareMarkWeaponType,
    SeparateCombatObjectCallbackParametersBeforeExecution
});

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceMeleeVisualObservation {
    pub phase: ReferenceSourceCombatPhase,
    pub owner: ReferenceSourceCombatOwner,
    pub emission_semantics: ReferenceSourceCombatEmission,
    pub record_ordinal: u32,
    pub raw_record_sha256: String,
    pub value: ReferenceSourceQualifiedEnum,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceLuaWeaponConfigReference {
    pub phase: ReferenceSourceCombatPhase,
    pub owner: ReferenceSourceCombatOwner,
    pub emission_semantics: ReferenceSourceCombatEmission,
    pub observation_id: String,
    pub weapon_object_ordinal: u16,
    pub runtime_registration_success: ReferenceItemField<()>,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceItemSourceCombatObservation {
    pub source_cut: ReferenceCombatSourceCut,
    pub external_item_id: u16,
    pub melee_visual: ReferenceItemField<ReferenceSourceMeleeVisualObservation>,
    pub lua_weapon_configuration: ReferenceItemField<ReferenceSourceLuaWeaponConfigReference>,
    pub runtime_actor_binding: ReferenceItemField<()>,
    pub runtime_predicate_binding: ReferenceItemField<()>,
    pub evaluation: ReferenceItemField<()>,
    pub priority: ReferenceItemField<()>,
    pub runtime_dispatch: ReferenceItemField<()>,
}
#[derive(Deserialize)]
struct RegisteredRow {
    target_key: String,
    target_revision: String,
    observations: Vec<ReferenceItemSourceCombatObservation>,
}
#[derive(Deserialize)]
struct Registry {
    rows: Vec<RegisteredRow>,
}
fn registry() -> Result<&'static Registry, ContentError> {
    static REGISTRY: OnceLock<Result<Registry, ()>> = OnceLock::new();
    REGISTRY
        .get_or_init(|| {
            serde_json::from_str(include_str!("source-combat-registry.json")).map_err(|_| ())
        })
        .as_ref()
        .map_err(|_| ContentError::InvalidArtifact("invalid frozen Source combat registry"))
}

pub(crate) fn validate_source_combat_field(
    field: &ReferenceItemField<Vec<ReferenceItemSourceCombatObservation>>,
) -> Result<(), ContentError> {
    let entries = match field {
        ReferenceItemField::Unknown => return Ok(()),
        ReferenceItemField::Known(entries) => entries,
        _ => {
            return Err(ContentError::InvalidArtifact(
                "Source combat requires Unknown or qualified Known",
            ));
        }
    };
    if entries.is_empty()
        || entries.len() > 3
        || entries
            .windows(2)
            .any(|p| p[0].source_cut >= p[1].source_cut)
    {
        return Err(ContentError::InvalidArtifact(
            "Source combat cuts must be bounded sorted unique",
        ));
    }
    for entry in entries {
        if entry.external_item_id == 0
            || entry.external_item_id == 901
            || [
                &entry.runtime_actor_binding,
                &entry.runtime_predicate_binding,
                &entry.evaluation,
                &entry.priority,
                &entry.runtime_dispatch,
            ]
            .iter()
            .any(|f| !matches!(f, ReferenceItemField::Unknown))
        {
            return Err(ContentError::InvalidArtifact(
                "Source combat cannot establish runtime bindings",
            ));
        }
        let mut present = false;
        match &entry.melee_visual {
            ReferenceItemField::Unknown => (),
            ReferenceItemField::Known(value) => {
                present = true;
                if entry.source_cut == ReferenceCombatSourceCut::Canary47df
                    || value.phase != ReferenceSourceCombatPhase::XmlItemtypeBeforeLua
                    || value.owner != ReferenceSourceCombatOwner::CppItemtypeMeleeAttackEffect
                    || value.emission_semantics
                        != ReferenceSourceCombatEmission::CrystalCreatureSquareMarkWeaponType
                    || value.value.namespace != ReferenceMediaNamespace::MagicEffect
                    || value.value.source_cut != entry.source_cut.media_cut()
                    || value.raw_record_sha256.len() != 64
                    || !value
                        .raw_record_sha256
                        .bytes()
                        .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
                {
                    return Err(ContentError::InvalidArtifact(
                        "wrong Source melee phase owner or enum",
                    ));
                }
                super::reference_source_media::validate_source_enum(&value.value)?;
            }
            _ => {
                return Err(ContentError::InvalidArtifact(
                    "Source melee slot requires Unknown or Known",
                ));
            }
        }
        match &entry.lua_weapon_configuration {
            ReferenceItemField::Unknown => (),
            ReferenceItemField::Known(value) => {
                present = true;
                if value.phase != ReferenceSourceCombatPhase::LuaLiteralRegisterConfigurationSourceOnly
                    || value.owner != ReferenceSourceCombatOwner::LuaWeaponObjectFileContext
                    || value.emission_semantics != ReferenceSourceCombatEmission::SeparateCombatObjectCallbackParametersBeforeExecution
                    || value.observation_id.is_empty() || value.observation_id.len() > 160
                    || !matches!(value.runtime_registration_success, ReferenceItemField::Unknown) {
                    return Err(ContentError::InvalidArtifact("wrong Source Lua owner emission or registration claim"));
                }
            }
            _ => {
                return Err(ContentError::InvalidArtifact(
                    "Source Lua slot requires Unknown or Known",
                ));
            }
        }
        if !present {
            return Err(ContentError::InvalidArtifact(
                "empty Source combat observation",
            ));
        }
    }
    if !registry()?.rows.iter().any(|r| &r.observations == entries) {
        return Err(ContentError::InvalidArtifact(
            "unqualified Source combat observations",
        ));
    }
    Ok(())
}

pub(crate) fn validate_source_combat_target(
    field: &ReferenceItemField<Vec<ReferenceItemSourceCombatObservation>>,
    key: &str,
    revision: &str,
) -> Result<(), ContentError> {
    validate_source_combat_field(field)?;
    if let ReferenceItemField::Known(entries) = field
        && !registry()?.rows.iter().any(|r| {
            r.target_key == key && r.target_revision == revision && r.observations == *entries
        })
    {
        return Err(ContentError::InvalidArtifact(
            "Source combat full Item identity mismatch",
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn closed_combat_rows_are_identity_phase_and_emission_qualified() -> Result<(), ContentError> {
        let rows = &registry()?.rows;
        assert_eq!(rows.len(), 35);
        assert_eq!(rows.iter().map(|r| r.observations.len()).sum::<usize>(), 39);
        for row in rows {
            let field = ReferenceItemField::Known(row.observations.clone());
            validate_source_combat_target(&field, &row.target_key, &row.target_revision)?;
            assert!(
                validate_source_combat_target(
                    &field,
                    "oteryn:item.tibia.i901",
                    &row.target_revision
                )
                .is_err()
            );
            assert!(
                validate_source_combat_target(&field, &row.target_key, "definition-r2").is_err()
            );
        }
        Ok(())
    }
    #[test]
    fn all_explicit_nonunknown_states_select_future_before_projection() -> Result<(), ContentError>
    {
        for state in [
            r#"{"state":"CONFLICT"}"#,
            r#"{"state":"NOT_APPLICABLE"}"#,
            r#"{"state":"KNOWN","value":[]}"#,
        ] {
            let field = serde_json::from_str(state)
                .map_err(|_| ContentError::InvalidArtifact("Source combat test JSON"))?;
            assert!(validate_source_combat_field(&field).is_err());
            let semantics = super::super::ReferenceItemSemantics {
                source_combat_observations: field,
                ..Default::default()
            };
            assert!(semantics.requires_future_source_property_profile());
            assert!(!semantics.is_all_unknown());
            assert!(
                !semantics
                    .client_projection()
                    .requires_future_source_property_profile()
            );
        }
        let empty = super::super::ReferenceItemSemantics::default();
        let json = serde_json::to_value(&empty)
            .map_err(|_| ContentError::InvalidArtifact("Source combat test serialization"))?;
        assert!(json.get("source_combat_observations").is_none());
        Ok(())
    }
    #[test]
    fn source_runtime_and_object_identity_mutations_are_rejected() -> Result<(), ContentError> {
        for row in &registry()?.rows {
            for mutation in 0..5 {
                let mut entries = row.observations.clone();
                let first = entries
                    .first_mut()
                    .ok_or(ContentError::InvalidArtifact("empty Source combat fixture"))?;
                match mutation {
                    0 => first.external_item_id = 901,
                    1 => first.runtime_actor_binding = ReferenceItemField::NotApplicable,
                    2 => first.evaluation = ReferenceItemField::Known(()),
                    3 => match &mut first.melee_visual {
                        ReferenceItemField::Known(value) => value.emission_semantics = ReferenceSourceCombatEmission::SeparateCombatObjectCallbackParametersBeforeExecution,
                        _ => if let ReferenceItemField::Known(value) = &mut first.lua_weapon_configuration { value.weapon_object_ordinal = 65535; },
                    },
                    _ => match &mut first.melee_visual {
                        ReferenceItemField::Known(value) => value.owner = ReferenceSourceCombatOwner::LuaWeaponObjectFileContext,
                        _ => if let ReferenceItemField::Known(value) = &mut first.lua_weapon_configuration { value.owner = ReferenceSourceCombatOwner::CppItemtypeMeleeAttackEffect; },
                    },
                }
                assert!(
                    validate_source_combat_target(
                        &ReferenceItemField::Known(entries),
                        &row.target_key,
                        &row.target_revision
                    )
                    .is_err()
                );
            }
        }
        Ok(())
    }
}

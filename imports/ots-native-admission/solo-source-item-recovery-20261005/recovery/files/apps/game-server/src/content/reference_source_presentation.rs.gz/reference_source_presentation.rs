//! Exact own protobuf bytes and primary XML text; no live Item name or Native promotion.
use super::{
    ContentError, ReferenceDefinitionSourceCut, ReferenceItemField, ReferenceSourceDefinitionPhase,
};
use serde::{Deserialize, Serialize};
use std::{collections::BTreeMap, io::Read, sync::OnceLock};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceProtoText {
    pub stored_presence: bool,
    pub bytes_hex: String,
    pub utf8: Option<String>,
}
impl ReferenceSourceProtoText {
    fn valid(&self, maximum: usize) -> bool {
        let hex = self.bytes_hex.as_bytes();
        if !hex.len().is_multiple_of(2)
            || hex.len() > maximum * 2
            || !hex
                .iter()
                .copied()
                .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
            || (!self.stored_presence && !hex.is_empty())
        {
            return false;
        }
        let nibble = |b: u8| if b <= b'9' { b - b'0' } else { b - b'a' + 10 };
        let raw: Vec<u8> = hex
            .chunks_exact(2)
            .map(|b| nibble(b[0]) * 16 + nibble(b[1]))
            .collect();
        std::str::from_utf8(&raw).ok() == self.utf8.as_deref()
    }
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceXmlText {
    pub value_lexeme: String,
    pub decoded_value: String,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceXmlDescription {
    pub attribute_ordinal: u16,
    pub key: String,
    pub value_lexeme: String,
    pub decoded_value: String,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceSourcePresentationCandidateDisposition {
    OrdinaryAssignmentBeforeRuntimeOverrides,
    HeldGoldPouchRuntimeConfig,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceSourcePresentationRuntimeOverride {
    Unknown,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourcePresentationObservation {
    pub source_cut: ReferenceDefinitionSourceCut,
    pub phase: ReferenceSourceDefinitionPhase,
    pub runtime_lua_and_instance_overrides: ReferenceSourcePresentationRuntimeOverride,
    pub external_item_id: u16,
    pub prototype_message_sha256: String,
    pub xml_record_ordinal: u32,
    pub xml_record_sha256: String,
    pub proto_name: ReferenceSourceProtoText,
    pub proto_description: ReferenceSourceProtoText,
    pub xml_name: Option<ReferenceSourceXmlText>,
    pub xml_article: Option<ReferenceSourceXmlText>,
    pub xml_plural: Option<ReferenceSourceXmlText>,
    pub xml_description: Option<ReferenceSourceXmlDescription>,
    /// Ordinary assignment candidate only; never a live Item getter or selected config branch.
    pub ordinary_name_candidate: String,
    pub ordinary_description_candidate: String,
    pub candidate_disposition: ReferenceSourcePresentationCandidateDisposition,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Registry {
    schema: String,
    targets: BTreeMap<String, BTreeMap<String, Vec<ReferenceSourcePresentationObservation>>>,
}

fn decoded_registry(
    input: &[u8],
    exact_length: usize,
    expected_sha256: &str,
) -> Result<Vec<u8>, ()> {
    let mut decoder = zstd::stream::read::Decoder::new(input).map_err(|_| ())?;
    decoder.window_log_max(22).map_err(|_| ())?;
    let mut raw = Vec::new();
    decoder
        .take(exact_length as u64 + 1)
        .read_to_end(&mut raw)
        .map_err(|_| ())?;
    if raw.len() != exact_length {
        return Err(());
    }
    let actual: String = super::digest::sha256(&raw)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect();
    if actual != expected_sha256 {
        return Err(());
    }
    Ok(raw)
}

fn registry() -> Result<&'static Registry, ContentError> {
    static REGISTRY: OnceLock<Result<Registry, &'static str>> = OnceLock::new();
    REGISTRY
        .get_or_init(|| {
            let raw = decoded_registry(
                include_bytes!("source-presentation-registry.json.zst"),
                42871838,
                "fcdeccc62972b5e7b7fb9f311ede5457d888ce426cd34106c4d72e396c128315",
            )
            .map_err(|_| "Source presentation registry")?;
            let registry: Registry =
                serde_json::from_slice(&raw).map_err(|_| "Source presentation registry")?;
            if registry.schema != "OTERYN_SOURCE_PRESENTATION_CLOSED_33975/v1"
                || registry.targets.len() != 33975
                || registry
                    .targets
                    .values()
                    .flat_map(|r| r.values())
                    .map(Vec::len)
                    .sum::<usize>()
                    != 45721
            {
                return Err("Source presentation closed scope");
            }
            Ok(registry)
        })
        .as_ref()
        .map_err(|message| ContentError::InvalidArtifact(message))
}
pub fn presentation_observations_require_future_profile(
    field: &ReferenceItemField<Vec<ReferenceSourcePresentationObservation>>,
) -> bool {
    !matches!(field, ReferenceItemField::Unknown)
}
pub fn validate_source_presentation_target(
    key: &str,
    revision: &str,
    field: &ReferenceItemField<Vec<ReferenceSourcePresentationObservation>>,
) -> Result<(), ContentError> {
    let values = match field {
        ReferenceItemField::Unknown => return Ok(()),
        ReferenceItemField::Known(values) => values,
        _ => {
            return Err(ContentError::InvalidArtifact(
                "Source presentation requires qualified Known or Unknown",
            ));
        }
    };
    let xml_valid = |value: &Option<ReferenceSourceXmlText>, max: usize| {
        value
            .as_ref()
            .is_none_or(|v| v.value_lexeme.len() <= max && v.decoded_value.len() <= max)
    };
    if values.is_empty()
        || values.len() > 2
        || values.iter().any(|v| {
            !v.proto_name.valid(43)
            || !v.proto_description.valid(199)
            || !xml_valid(&v.xml_name, 46)
            || !xml_valid(&v.xml_article, 4)
            || !xml_valid(&v.xml_plural, 28)
            || v.ordinary_name_candidate.len() > 46
            || v.ordinary_description_candidate.len() > 200
            || v.xml_description.as_ref().is_some_and(|d| {
                d.key.to_ascii_lowercase() != "description"
                                        || d.value_lexeme.len() > 209
                || d.decoded_value.len() > 200
            })
            || (v.external_item_id == 23721
                && v.xml_description.is_some()
                && v.candidate_disposition
                    != ReferenceSourcePresentationCandidateDisposition::HeldGoldPouchRuntimeConfig)
        })
        || registry()?.targets.get(key).and_then(|r| r.get(revision)) != Some(values)
    {
        return Err(ContentError::InvalidArtifact(
            "unqualified Source presentation vector",
        ));
    }
    Ok(())
}

#[cfg(test)]
#[allow(
    clippy::unwrap_used,
    reason = "closed Source presentation mutation fixtures"
)]
mod tests {
    use super::*;
    #[test]
    fn strict_bytes_preserve_invalid_utf8_and_presence() {
        let bad = ReferenceSourceProtoText {
            stored_presence: true,
            bytes_hex: "ee".into(),
            utf8: None,
        };
        assert!(bad.valid(199));
        let mut mutation = bad.clone();
        mutation.utf8 = Some("î".into());
        assert!(!mutation.valid(199));
        mutation = bad.clone();
        mutation.stored_presence = false;
        assert!(!mutation.valid(199));
        mutation = bad;
        mutation.bytes_hex = "EE".into();
        assert!(!mutation.valid(199));
    }
    #[test]
    fn registered_whole_vectors_and_identity_are_closed() {
        let registry = registry().unwrap();
        let (key, revisions) = registry.targets.first_key_value().unwrap();
        let (revision, vector) = revisions.first_key_value().unwrap();
        let known = ReferenceItemField::Known(vector.clone());
        assert!(validate_source_presentation_target(key, revision, &known).is_ok());
        assert!(
            validate_source_presentation_target("oteryn:item.foreign", revision, &known).is_err()
        );
        assert!(validate_source_presentation_target(key, "wrong-r1", &known).is_err());
        let mut bad = vector.clone();
        bad[0].proto_name.bytes_hex = "ee".into();
        assert!(
            validate_source_presentation_target(key, revision, &ReferenceItemField::Known(bad))
                .is_err()
        );
        let mut bad = vector.clone();
        bad[0].xml_article = Some(ReferenceSourceXmlText {
            value_lexeme: "invented".into(),
            decoded_value: "invented".into(),
        });
        assert!(
            validate_source_presentation_target(key, revision, &ReferenceItemField::Known(bad))
                .is_err()
        );
        for field in [
            ReferenceItemField::Conflict,
            ReferenceItemField::NotApplicable,
            ReferenceItemField::Known(vec![]),
        ] {
            assert!(presentation_observations_require_future_profile(&field));
            assert!(validate_source_presentation_target(key, revision, &field).is_err());
        }
        assert!(!presentation_observations_require_future_profile(
            &ReferenceItemField::Unknown
        ));
    }
}

#[cfg(test)]
mod compressed_registry_tests {
    use super::decoded_registry;
    #[test]
    fn bounded_registry_decode_rejects_drift() -> Result<(), ()> {
        let raw = b"abc";
        let digest: String = super::super::digest::sha256(raw)
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect();
        let compressed = zstd::stream::encode_all(&raw[..], 1).map_err(|_| ())?;
        assert_eq!(decoded_registry(&compressed, 3, &digest)?, raw.to_vec());
        assert!(decoded_registry(&compressed, 2, &digest).is_err());
        assert!(decoded_registry(&compressed, 4, &digest).is_err());
        assert!(decoded_registry(&compressed, 3, &"0".repeat(64)).is_err());
        assert!(decoded_registry(&compressed[..compressed.len() - 1], 3, &digest).is_err());
        assert!(decoded_registry(b"invalid zstd", 3, &digest).is_err());
        let extra = zstd::stream::encode_all(&b"abcd"[..], 1).map_err(|_| ())?;
        assert!(decoded_registry(&extra, 3, &digest).is_err());
        // Valid zstd magic, no single-segment flag, oversized window descriptor.
        assert!(
            decoded_registry(
                &[0x28, 0xb5, 0x2f, 0xfd, 0x00, 0xa0, 0x01, 0x00, 0x00],
                3,
                &digest
            )
            .is_err()
        );
        Ok(())
    }
}

//! Bounded CONTENT seam: non-production evidence plus FIRST_PRODUCTION_CONTENT_PROFILE/v1.
//! Live deployment authority is deliberately absent; activation consumes sealed Game authority.
//!
//! ```compile_fail
//! use oteryn_game_server::content::ActivationSlot;
//! let _ = ActivationSlot::new();
//! ```
//!
//! Full staged runtime generations are catalog-owned and are deliberately not public.
//! Downstream consumers must stage through `ContentActivationController`, which enforces the
//! registered single-staged / two-resident generation ceiling.
//!
//! ```compile_fail
//! use oteryn_game_server::content::StagedGeneration;
//! ```
//!
//! First-production CONTENT uses Foundation's canonical cross-boundary `WorldId`; the
//! domain-local nominal type cannot be substituted implicitly.
//!
//! ```compile_fail
//! use oteryn_game_server::{domain, foundation};
//! let domain_world = domain::WorldId::from_bytes([
//!     0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0x70, 0xcd,
//!     0x8e, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc,
//! ]).unwrap();
//! let _: foundation::WorldId = domain_world;
//! ```

#![forbid(unsafe_code)]

mod activation;
mod artifact;
pub(crate) mod charm_source;
pub(crate) mod charm_source_effect;
pub(crate) mod charm_source_json;
mod compiler;
mod cw2_b1_import;
mod cw2_b4_import;
mod digest;
pub mod encounter_map_item;
mod fixture;
pub mod item_abilities;
pub mod item_admission;
pub mod item_capacity_promotion;
pub mod item_description_promotion;
pub mod item_description_wiki_promotion;
pub mod item_document_promotion;
pub mod item_elemental_magic_modifier_promotion;
pub mod item_forge289_promotion;
pub mod item_forge3332_promotion;
pub mod item_hit_magic_promotion;
pub mod item_identity;
pub mod item_mantra_bond_modifier_promotion;
pub mod item_market_true_promotion;
pub mod item_movable_promotion;
pub mod item_name15_promotion;
pub mod item_name_promotion;
pub mod item_numeric_modifier_promotion;
pub mod item_physical_promotion;
pub mod item_stack_default_promotion;
pub mod item_stack_default_successor8_promotion;
pub mod item_stack_false_promotion;
pub mod item_stack_historical_promotion;
pub mod item_stats_promotion;
pub mod item_timed_promotion;
pub mod item_use_observation_promotion;
pub mod item_weapon_metadata_promotion;
mod model;
mod production;
mod project;
mod project_fs;
mod reference_artifact;
mod reference_playable;
mod reference_source_media;
#[cfg(test)]
pub(crate) mod reference_static_cell;
#[allow(
    dead_code,
    reason = "unactivated engineering Content carrier awaits the separate Movement consumer lease"
)]
pub(crate) mod static_cell_engine;

pub use activation::*;
#[cfg(test)]
pub(crate) use artifact::{ActivationSlot, ActiveContent};
pub use artifact::{ArtifactExpectation, ProjectionClass, StagedArtifact, StagedContentPair};
pub use compiler::{CompiledContent, compile, compile_reference_playable};
pub use cw2_b1_import::*;
pub use cw2_b4_import::*;
pub use fixture::synthetic_vsl_fixture;
pub use model::*;
pub use production::{
    CompiledFirstProductionContent, ContentLockBinding, ContentLockEntry, DurableMigrationClass,
    FIRST_PRODUCTION_ARTIFACT_PROFILE_ID, FIRST_PRODUCTION_CAPABILITY_PROFILE,
    FIRST_PRODUCTION_MAX_ATOM_BYTES, FIRST_PRODUCTION_MAX_CELLS,
    FIRST_PRODUCTION_MAX_CLIENT_ARTIFACT_BYTES, FIRST_PRODUCTION_MAX_CLIENT_RECORDS,
    FIRST_PRODUCTION_MAX_CONTENT_LOCK_ENTRIES, FIRST_PRODUCTION_MAX_DECODED_FIELDS,
    FIRST_PRODUCTION_MAX_DEFINITIONS, FIRST_PRODUCTION_MAX_FLOORS,
    FIRST_PRODUCTION_MAX_GENERATION_PAIR_BYTES, FIRST_PRODUCTION_MAX_KEY_BYTES,
    FIRST_PRODUCTION_MAX_MANIFEST_BYTES, FIRST_PRODUCTION_MAX_MANIFEST_FIELDS,
    FIRST_PRODUCTION_MAX_RECORD_BYTES, FIRST_PRODUCTION_MAX_REFERENCES,
    FIRST_PRODUCTION_MAX_SCOPE_POPULATION, FIRST_PRODUCTION_MAX_SECTION_BYTES,
    FIRST_PRODUCTION_MAX_SERVER_ARTIFACT_BYTES, FIRST_PRODUCTION_MAX_SERVER_RECORDS,
    FIRST_PRODUCTION_MAX_SPAWN_POPULATION, FIRST_PRODUCTION_MAX_X_SPAN,
    FIRST_PRODUCTION_MAX_Y_SPAN, FIRST_PRODUCTION_PROFILE_ID, FirstProductionAbility,
    FirstProductionArea, FirstProductionBehavior, FirstProductionCell,
    FirstProductionCompileTarget, FirstProductionContentSource, FirstProductionCreature,
    FirstProductionEffect, FirstProductionExpectation, FirstProductionFormulaProfile,
    FirstProductionItem, FirstProductionLimits, FirstProductionLootEntry, FirstProductionLootTable,
    FirstProductionPresentation, FirstProductionRegion, FirstProductionRelocation,
    FirstProductionRevisionSet, FirstProductionRngContext, FirstProductionSpawn,
    FirstProductionTerrain, FirstProductionXpDefinition, GenerationIdentity,
    PackageManifestBinding, ProductionAtom, ProductionKey, Sha256HexDigest,
    compile_first_production, load_reference_playable_artifact, stage_reference_playable,
};
pub use project::*;
pub use project_fs::*;
pub use reference_artifact::{
    CompiledReferencePlayableContent, NonAuthoritativeReferenceStage,
    OTERYN_REFERENCE_PLAYABLE_ARTIFACT_PROFILE_ID, REFERENCE_PLAYABLE_MAX_CLIENT_ARTIFACT_BYTES,
    REFERENCE_PLAYABLE_MAX_GENERATION_PAIR_BYTES, REFERENCE_PLAYABLE_MAX_SERVER_ARTIFACT_BYTES,
    ReferenceArtifactProjection, ReferenceClientItem, ReferencePlayableArtifactView,
    ReferencePlayableExpectation, ReferencePlayableGenerationIdentity, ReferenceServerItem,
};
pub use reference_playable::*;
pub use reference_source_media::*;

#[cfg(test)]
mod tests;

#[cfg(test)]
mod reference_primary_observation_tests;

mod reference_source_class;
mod reference_source_scalars;
pub use reference_source_class::*;
pub use reference_source_scalars::*;
mod reference_source_definition;
pub use reference_source_definition::*;

mod reference_source_combat;
pub use reference_source_combat::*;

mod reference_source_flags;
pub use reference_source_flags::*;

mod reference_source_presentation;
pub use reference_source_presentation::*;

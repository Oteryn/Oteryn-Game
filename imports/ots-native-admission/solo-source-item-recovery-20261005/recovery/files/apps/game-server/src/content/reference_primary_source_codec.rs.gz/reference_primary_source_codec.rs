//! Lossless Source observations; no runtime/ruleset/asset admission.
use super::*;
use crate::content::*;

pub(super) fn put_skills(
    out: &mut Vec<u8>,
    table: &ReferenceObservedSkillTable,
) -> Result<(), ContentError> {
    super::super::reference_playable::validate_skill_observation_table(table)?;
    out.push(table.phase.wire());
    put_count(out, table.entries.len(), 8, "observed skill entries")?;
    for entry in &table.entries {
        out.push(entry.kind.wire());
        put_field(out, &entry.parameter, |out, value| {
            if let ReferenceModifierParameter::SignedPoints(value) = value {
                out.extend_from_slice(&value.0.to_be_bytes());
                Ok(())
            } else {
                Err(ContentError::InvalidArtifact(
                    "observed skill signed point shape",
                ))
            }
        })?;
        out.extend_from_slice(&[0, 0, 0]); // Validator proves all three bindings Unknown.
    }
    Ok(())
}
pub(super) fn read_skills(
    source: &mut SliceReader<'_>,
) -> Result<ReferenceObservedSkillTable, ContentError> {
    let phase = ReferenceDefinitionObservationPhase::from_wire(source.read_u8()?)?;
    let count = read_count(source, 8, "observed skill entries")?;
    let mut entries = Vec::with_capacity(count);
    for _ in 0..count {
        entries.push(ReferenceObservedSkillParameter {
            kind: ReferenceObservedSkillKind::from_wire(source.read_u8()?)?,
            parameter: read_field(source, |source| {
                Ok(ReferenceModifierParameter::SignedPoints(
                    ReferenceSignedPoints(read_i32(source)?),
                ))
            })?,
            target_domain: read_field(source, |source| source.read_u8())?,
            evaluation_phase: read_field(source, |source| source.read_u8())?,
            priority: read_field(source, read_i16)?,
        });
    }
    let table = ReferenceObservedSkillTable { phase, entries };
    super::super::reference_playable::validate_skill_observation_table(&table)?;
    Ok(table)
}
pub(super) fn put_resistances(
    out: &mut Vec<u8>,
    table: &ReferenceObservedResistanceTable,
) -> Result<(), ContentError> {
    super::super::reference_playable::validate_resistance_observation_table(table)?;
    out.push(table.phase.wire());
    put_count(out, table.entries.len(), 28, "observed resistance entries")?;
    for entry in &table.entries {
        out.extend_from_slice(&[entry.scope.wire(), entry.combat_kind.wire()]);
        put_field(out, &entry.percent, |out, value| {
            let value =
                i16::try_from(value.numerator).map_err(|_| ContentError::InvalidSectionBounds)?;
            out.extend_from_slice(&value.to_be_bytes());
            Ok(())
        })?;
    }
    Ok(())
}
pub(super) fn read_resistances(
    source: &mut SliceReader<'_>,
) -> Result<ReferenceObservedResistanceTable, ContentError> {
    let phase = ReferenceDefinitionObservationPhase::from_wire(source.read_u8()?)?;
    let count = read_count(source, 28, "observed resistance entries")?;
    let mut entries = Vec::with_capacity(count);
    for _ in 0..count {
        entries.push(ReferenceObservedResistanceParameter {
            scope: ReferenceObservedResistanceScope::from_wire(source.read_u8()?)?,
            combat_kind: ReferenceObservedCombatKind::from_wire(source.read_u8()?)?,
            percent: read_field(source, |source| {
                ReferenceRationalPercent::new(i64::from(read_i16(source)?), 1)
            })?,
        });
    }
    let table = ReferenceObservedResistanceTable { phase, entries };
    super::super::reference_playable::validate_resistance_observation_table(&table)?;
    Ok(table)
}
fn put_media_enum(
    out: &mut Vec<u8>,
    value: &ReferenceXmlMediaDeclaration,
) -> Result<(), ContentError> {
    let media = &value.media;
    out.extend_from_slice(&[media.source_cut as u8, media.namespace as u8]);
    put_u16(
        out,
        super::super::reference_source_media::enum_member_ordinal(media)?,
    );
    put_u16(out, media.own_value);
    out.push(value.assignment as u8);
    Ok(())
}
fn read_media_enum(
    source: &mut SliceReader<'_>,
) -> Result<ReferenceXmlMediaDeclaration, ContentError> {
    let (cut, namespace, ordinal, value) = (
        source.read_u8()?,
        source.read_u8()?,
        source.read_u16()?,
        source.read_u16()?,
    );
    let media =
        super::super::reference_source_media::enum_from_wire(cut, namespace, ordinal, value)?;
    let assignment = match source.read_u8()? {
        0 => ReferenceXmlMediaAssignment::Write,
        1 => ReferenceXmlMediaAssignment::IgnoredNone,
        _ => {
            return Err(ContentError::InvalidArtifact(
                "unknown XML media assignment",
            ));
        }
    };
    Ok(ReferenceXmlMediaDeclaration { media, assignment })
}
pub(super) fn put_media(
    out: &mut Vec<u8>,
    entries: &[ReferenceItemSourceMediaConfig],
) -> Result<(), ContentError> {
    super::super::reference_source_media::validate_item_source_media(entries)?;
    put_count(
        out,
        entries.len(),
        REFERENCE_SOURCE_MEDIA_MAX_CUTS,
        "source media cuts",
    )?;
    for entry in entries {
        out.push(entry.source_cut as u8);
        put_u16(out, entry.external_item_id);
        out.push(entry.phase as u8);
        put_u32(out, entry.record_ordinal);
        for pair in entry.raw_record_sha256.as_bytes().chunks_exact(2) {
            let digit = |b: u8| if b <= b'9' { b - b'0' } else { b - b'a' + 10 };
            out.push(digit(pair[0]) * 16 + digit(pair[1]));
        }
        put_field(out, &entry.projectile, put_media_enum)?;
        put_field(out, &entry.trash_holder_visual, put_media_enum)?;
    }
    Ok(())
}
pub(super) fn read_media(
    source: &mut SliceReader<'_>,
) -> Result<Vec<ReferenceItemSourceMediaConfig>, ContentError> {
    let count = read_count(source, REFERENCE_SOURCE_MEDIA_MAX_CUTS, "source media cuts")?;
    let mut entries = Vec::with_capacity(count);
    for _ in 0..count {
        let source_cut = match source.read_u8()? {
            0 => ReferenceMediaSourceCut::Canary47df,
            1 => ReferenceMediaSourceCut::CrystalFf7,
            2 => ReferenceMediaSourceCut::Crystal00ce,
            _ => return Err(ContentError::InvalidArtifact("unknown source cut")),
        };
        let external_item_id = source.read_u16()?;
        if source.read_u8()? != 0 {
            return Err(ContentError::InvalidArtifact("unknown XML media phase"));
        }
        let record_ordinal = source.read_u32()?;
        let raw_record_sha256 = source
            .take(32)?
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect::<String>();
        entries.push(ReferenceItemSourceMediaConfig {
            source_cut,
            external_item_id,
            phase: ReferenceItemMediaPhase::XmlItemtypeBeforeLua,
            record_ordinal,
            raw_record_sha256,
            projectile: read_field(source, read_media_enum)?,
            trash_holder_visual: read_field(source, read_media_enum)?,
        });
    }
    super::super::reference_source_media::validate_item_source_media(&entries)?;
    Ok(entries)
}

pub(super) fn put_ceilings(
    bytes: &mut Vec<u8>,
    entries: &[super::super::ReferenceImbuementFamilyCeiling],
) -> Result<(), ContentError> {
    super::super::reference_playable::validate_imbuement_family_ceilings(entries)?;
    put_count(
        bytes,
        entries.len(),
        super::super::REFERENCE_ITEM_MAX_IMBUEMENT_FAMILIES,
        "Reference Item imbuement ceilings",
    )?;
    for entry in entries {
        bytes.push(entry.family.wire());
        bytes.push(entry.max_tier);
    }
    Ok(())
}

pub(super) fn read_ceilings(
    source: &mut SliceReader<'_>,
) -> Result<Vec<super::super::ReferenceImbuementFamilyCeiling>, ContentError> {
    let count = read_count(
        source,
        super::super::REFERENCE_ITEM_MAX_IMBUEMENT_FAMILIES,
        "Reference Item imbuement ceilings",
    )?;
    let mut entries = Vec::with_capacity(count);
    for _ in 0..count {
        entries.push(super::super::ReferenceImbuementFamilyCeiling {
            family: super::super::ReferenceImbuementFamily::from_wire(source.read_u8()?)?,
            max_tier: source.read_u8()?,
        });
    }
    super::super::reference_playable::validate_imbuement_family_ceilings(&entries)?;
    Ok(entries)
}
#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    #[test]
    fn all_registered_media_round_trip_and_reject_any_truncation_or_tamper() {
        let registry: serde_json::Value =
            serde_json::from_str(include_str!("source-media-registry.json")).unwrap();
        assert_eq!(registry["declarations"].as_array().unwrap().len(), 377);
        for row in registry["declarations"].as_array().unwrap() {
            let config: ReferenceItemSourceMediaConfig =
                serde_json::from_value(row["config"].clone()).unwrap();
            let mut bytes = Vec::new();
            put_media(&mut bytes, std::slice::from_ref(&config)).unwrap();
            let mut reader = SliceReader::new(&bytes);
            assert_eq!(read_media(&mut reader).unwrap(), vec![config]);
            reader.ensure_end().unwrap();
            for end in 0..bytes.len() {
                assert!(read_media(&mut SliceReader::new(&bytes[..end])).is_err());
            }
            for offset in [1, 4, 9] {
                // Own cut, exact phase, exact raw-record digest.
                let mut bad = bytes.clone();
                bad[offset] ^= 0xff;
                assert!(read_media(&mut SliceReader::new(&bad)).is_err());
            }
        }
    }

    #[test]
    fn source_none_no_write_and_sound_silence_remain_distinct() {
        for (namespace, member, assignment) in [
            (
                ReferenceMediaNamespace::ShootType,
                "CONST_ANI_NONE",
                ReferenceXmlMediaAssignment::IgnoredNone,
            ),
            (
                ReferenceMediaNamespace::SoundEffect,
                "SILENCE",
                ReferenceXmlMediaAssignment::Write,
            ),
        ] {
            let declaration = ReferenceXmlMediaDeclaration {
                media: ReferenceSourceQualifiedEnum {
                    source_cut: ReferenceMediaSourceCut::Canary47df,
                    namespace,
                    member: member.to_owned(),
                    own_value: 0,
                },
                assignment,
            };
            let mut bytes = Vec::new();
            put_media_enum(&mut bytes, &declaration).unwrap();
            assert_eq!(
                read_media_enum(&mut SliceReader::new(&bytes)).unwrap(),
                declaration
            );
            for (offset, value) in [(0, 255), (1, 255), (2, 255), (5, 1), (6, 255)] {
                let mut bad = bytes.clone();
                bad[offset] = value;
                assert!(read_media_enum(&mut SliceReader::new(&bad)).is_err());
            }
        }
    }

    #[test]
    fn skill_payload_rejects_phase_kind_binding_and_truncation() {
        let table = ReferenceObservedSkillTable {
            phase: ReferenceDefinitionObservationPhase::CppProtoXmlBeforeLua,
            entries: (1..=8)
                .map(|kind| ReferenceObservedSkillParameter {
                    kind: ReferenceObservedSkillKind::from_wire(kind).unwrap(),
                    parameter: ReferenceItemField::Known(ReferenceModifierParameter::SignedPoints(
                        ReferenceSignedPoints(i32::MIN),
                    )),
                    target_domain: ReferenceItemField::Unknown,
                    evaluation_phase: ReferenceItemField::Unknown,
                    priority: ReferenceItemField::Unknown,
                })
                .collect(),
        };
        let mut bytes = Vec::new();
        put_skills(&mut bytes, &table).unwrap();
        assert_eq!(bytes.len(), 74); // Plus outer Known state gives declared 75-byte cap.
        assert_eq!(read_skills(&mut SliceReader::new(&bytes)).unwrap(), table);
        for end in 0..bytes.len() {
            assert!(read_skills(&mut SliceReader::new(&bytes[..end])).is_err());
        }
        for (offset, value) in [(0, 255), (1, 9), (2, 255), (8, 2), (9, 1)] {
            let mut bad = bytes.clone();
            bad[offset] = value;
            assert!(read_skills(&mut SliceReader::new(&bad)).is_err());
        }
    }

    #[test]
    fn resistance_payload_rejects_noncanonical_encode_phase_scope_kind() {
        let mut table = ReferenceObservedResistanceTable {
            phase: ReferenceDefinitionObservationPhase::CppProtoXmlBeforeLua,
            entries: (1..=2)
                .flat_map(|scope| {
                    (1..=14).map(move |kind| ReferenceObservedResistanceParameter {
                        scope: ReferenceObservedResistanceScope::from_wire(scope).unwrap(),
                        combat_kind: ReferenceObservedCombatKind::from_wire(kind).unwrap(),
                        percent: ReferenceItemField::Known(
                            ReferenceRationalPercent::new(i64::from(i16::MIN), 1).unwrap(),
                        ),
                    })
                })
                .collect(),
        };
        let mut bytes = Vec::new();
        put_resistances(&mut bytes, &table).unwrap();
        assert_eq!(bytes.len(), 142);
        assert_eq!(
            read_resistances(&mut SliceReader::new(&bytes)).unwrap(),
            table
        );
        for end in 0..bytes.len() {
            assert!(read_resistances(&mut SliceReader::new(&bytes[..end])).is_err());
        }
        for offset in [0, 1, 2, 3] {
            let mut bad = bytes.clone();
            bad[offset] = 255;
            assert!(read_resistances(&mut SliceReader::new(&bad)).is_err());
        }
        table.entries[0].percent =
            ReferenceItemField::Known(ReferenceRationalPercent::new(1, 2).unwrap());
        assert!(put_resistances(&mut Vec::new(), &table).is_err());
    }
    #[test]
    fn every_explicit_source_state_selects_v6_and_old_profiles_reject_before_projection() {
        use ReferenceItemField::{Conflict, Known, NotApplicable, Unknown};
        for state in [NotApplicable, Conflict, Known(Vec::new())] {
            let item = ReferenceItemDefinition {
                physical_class: ReferenceItemPhysicalClass::Unknown,
                materializable: false,
                stack_class: ReferenceItemStackClass::Unknown,
                legal_destinations: Vec::new(),
                semantics: ReferenceItemSemantics {
                    source_media_config: state,
                    ..Default::default()
                },
            };
            assert!(item.semantics.requires_primary_source_observation_profile());
            for profile in [
                ReferenceArtifactProfile::TypedItemV4,
                ReferenceArtifactProfile::TypedItemV5,
            ] {
                for projection in [
                    ReferenceArtifactProjection::ClientSafe,
                    ReferenceArtifactProjection::ServerAuthoritative,
                ] {
                    assert!(encode_typed_item(&item, projection, &[], profile).is_err());
                }
            }
        }
        for state in [NotApplicable, Conflict] {
            let semantics = ReferenceItemSemantics {
                skill_modifiers: Known(ReferenceItemSkillModifiers {
                    modifiers: Unknown,
                    observed_skill_parameters: state,
                }),
                ..Default::default()
            };
            assert!(semantics.requires_primary_source_observation_profile());
        }
        for state in [NotApplicable, Conflict] {
            let semantics = ReferenceItemSemantics {
                protection: Known(ReferenceItemProtection {
                    armor: Unknown,
                    resistances: Unknown,
                    observed_resistance_parameters: state,
                }),
                ..Default::default()
            };
            assert!(semantics.requires_primary_source_observation_profile());
        }
        // Integrity-valid record framing containing a server-only group must fail client decoding.
        let mut client = vec![4, 0, 0, 0, 1, ITEM_GROUP_SOURCE_MEDIA, 0, 1, 0];
        assert!(
            parse_typed_client_item(ReferenceArtifactProfile::TypedItemV6, &client, &[]).is_err()
        );
        client[0] = 3;
        assert!(
            parse_typed_client_item(ReferenceArtifactProfile::TypedItemV6, &client, &[]).is_err()
        );
    }
}

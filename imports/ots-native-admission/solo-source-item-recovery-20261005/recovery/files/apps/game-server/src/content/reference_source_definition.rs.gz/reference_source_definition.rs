//! Own definition observations before Lua and instance attributes; no runtime capabilities.
use super::{ContentError, ReferenceItemField};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::sync::OnceLock;

pub const SOURCE_DEFINITION_MAX_OBSERVATIONS: usize = 6;
pub const SOURCE_DEFINITION_MAX_ASSIGNMENTS: usize = 5;
pub const SOURCE_DEFINITION_TARGETS: usize = 4475;
pub const SOURCE_DEFINITION_OBSERVATIONS: usize = 9291;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ReferenceDefinitionSourceCut {
    #[serde(rename = "CANARY_47DF")]
    Canary47df,
    #[serde(rename = "CRYSTAL_FF7")]
    CrystalFf7,
    #[serde(rename = "CRYSTAL_00CE")]
    Crystal00ce,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceSourceDefinitionPhase {
    FreshCppProtobufThenFullOrderedXmlBeforeLua,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceSourceDurationSetterDisposition {
    ZeroSkipsInitialization,
    SafeSignedExact,
    HeldWrapOrSignedSetter,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "SCREAMING_SNAKE_CASE", deny_unknown_fields)]
pub enum ReferenceSourceDefinitionParameter {
    /// ItemType decayTime seconds and its uint32 getter conversion, not a remaining timer.
    Duration {
        decay_time_seconds: u32,
        default_duration_ms: u32,
        setter_disposition: ReferenceSourceDurationSetterDisposition,
        explicit_stop_duration: ReferenceItemField<bool>,
        explicit_decay_to: ReferenceItemField<u16>,
    },
    /// Declared direct-entry slots, not a live container/config capacity.
    ContainerCapacity { capacity: u16 },
    /// Own cpp/Fluids_t supplier kind, not Native liquid contents or an instance attribute.
    FluidSource { member: String, own_value: u8 },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnDefinitionAssignment {
    pub key: String,
    pub value_lexeme: String,
    pub attribute_ordinal: u16,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceWorldOwnerPointer {
    pub family: String,
    pub key: String,
    pub revision: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceDefinitionObservation {
    pub source_cut: ReferenceDefinitionSourceCut,
    pub external_item_id: u16,
    pub phase: ReferenceSourceDefinitionPhase,
    /// SHA256 of the own Appearance message payload, excluding its protobuf field frame.
    pub prototype_message_sha256: String,
    pub xml_record_ordinal: u32,
    pub xml_record_sha256: String,
    /// Own cpp/ItemGroup_t name, independently qualified at this phase.
    pub source_group: String,
    pub current_world_owner_pointers: Vec<ReferenceSourceWorldOwnerPointer>,
    pub ordered_assignments: Vec<ReferenceOwnDefinitionAssignment>,
    pub parameter: ReferenceSourceDefinitionParameter,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct DefinitionRegistry {
    schema: String,
    targets: BTreeMap<String, BTreeMap<String, Vec<ReferenceSourceDefinitionObservation>>>,
}

fn registry() -> Result<&'static DefinitionRegistry, ContentError> {
    static REGISTRY: OnceLock<Result<DefinitionRegistry, ()>> = OnceLock::new();
    let registry = REGISTRY
        .get_or_init(|| {
            serde_json::from_str(include_str!("source-definition-registry.json")).map_err(|_| ())
        })
        .as_ref()
        .map_err(|_| ContentError::InvalidArtifact("invalid own Source definition registry"))?;
    if registry.schema != "OTERYN_SOURCE_DEFINITION_OBSERVATIONS_CLOSED/v1"
        || registry.targets.len() != SOURCE_DEFINITION_TARGETS
        || registry
            .targets
            .values()
            .flat_map(|r| r.values())
            .map(Vec::len)
            .sum::<usize>()
            != SOURCE_DEFINITION_OBSERVATIONS
    {
        return Err(ContentError::InvalidArtifact(
            "own Source definition registry scope",
        ));
    }
    Ok(registry)
}

pub fn definition_observations_require_future_profile(
    field: &ReferenceItemField<Vec<ReferenceSourceDefinitionObservation>>,
) -> bool {
    !matches!(field, ReferenceItemField::Unknown)
}

pub fn validate_definition_observations(
    key: &str,
    revision: &str,
    field: &ReferenceItemField<Vec<ReferenceSourceDefinitionObservation>>,
) -> Result<(), ContentError> {
    let values = match field {
        ReferenceItemField::Unknown => return Ok(()),
        ReferenceItemField::Known(values) => values,
        ReferenceItemField::NotApplicable | ReferenceItemField::Conflict => {
            return Err(ContentError::InvalidArtifact(
                "Source definitions require Unknown or qualified Known",
            ));
        }
    };
    if values.is_empty()
        || values.len() > SOURCE_DEFINITION_MAX_OBSERVATIONS
        || values.iter().any(|r| {
            r.ordered_assignments.is_empty()
                || r.ordered_assignments.len() > SOURCE_DEFINITION_MAX_ASSIGNMENTS
                || r.current_world_owner_pointers.len() > 1
        })
        || registry()?
            .targets
            .get(key)
            .and_then(|rows| rows.get(revision))
            != Some(values)
    {
        return Err(ContentError::InvalidArtifact(
            "unqualified own Source definition observation",
        ));
    }
    Ok(())
}

#[cfg(test)]
#[allow(clippy::unwrap_used, reason = "closed own Source mutation fixtures")]
mod tests {
    use super::*;

    #[test]
    fn closed_three_domain_vectors_preserve_own_units_and_world_routes() {
        let registry = registry().unwrap();
        let values: Vec<_> = registry.targets.values().flat_map(|r| r.values()).collect();
        assert_eq!(values.iter().map(|v| v.len()).max(), Some(6));
        assert_eq!(
            values
                .iter()
                .flat_map(|r| r.iter())
                .filter(|r| matches!(
                    r.parameter,
                    ReferenceSourceDefinitionParameter::Duration { .. }
                ))
                .count(),
            4270
        );
        assert_eq!(
            values
                .iter()
                .flat_map(|r| r.iter())
                .filter(|r| matches!(
                    r.parameter,
                    ReferenceSourceDefinitionParameter::ContainerCapacity { .. }
                ))
                .count(),
            3367
        );
        assert_eq!(
            values
                .iter()
                .flat_map(|r| r.iter())
                .filter(|r| matches!(
                    r.parameter,
                    ReferenceSourceDefinitionParameter::FluidSource { .. }
                ))
                .count(),
            1654
        );
    }

    #[test]
    fn own_target_revision_cut_and_lexeme_substitutions_fail() {
        let (key, revisions) = registry().unwrap().targets.iter().next().unwrap();
        let (revision, values) = revisions.iter().next().unwrap();
        let known = ReferenceItemField::Known(values.clone());
        assert!(validate_definition_observations(key, revision, &known).is_ok());
        assert!(validate_definition_observations(key, "borrowed", &known).is_err());
        let mut wrong_cut = values.clone();
        wrong_cut[0].source_cut = match wrong_cut[0].source_cut {
            ReferenceDefinitionSourceCut::Canary47df => ReferenceDefinitionSourceCut::CrystalFf7,
            _ => ReferenceDefinitionSourceCut::Canary47df,
        };
        assert!(
            validate_definition_observations(key, revision, &ReferenceItemField::Known(wrong_cut))
                .is_err()
        );
        let mut wrong = values.clone();
        wrong[0].ordered_assignments[0].value_lexeme.push('0');
        assert!(
            validate_definition_observations(key, revision, &ReferenceItemField::Known(wrong))
                .is_err()
        );
    }

    #[test]
    fn every_explicit_state_requires_future_export_and_empty_known_is_rejected() {
        for state in [
            ReferenceItemField::Known(Vec::new()),
            ReferenceItemField::NotApplicable,
            ReferenceItemField::Conflict,
        ] {
            assert!(definition_observations_require_future_profile(&state));
            assert!(validate_definition_observations("unregistered", "r1", &state).is_err());
        }
        assert!(!definition_observations_require_future_profile(
            &ReferenceItemField::Unknown
        ));
    }

    #[test]
    fn explicit_zero_seconds_preserve_conditional_initialization_not_absence() {
        let rows = registry()
            .unwrap()
            .targets
            .values()
            .flat_map(|r| r.values())
            .flat_map(|r| r.iter());
        let zeros: Vec<_> = rows
            .filter(|r| {
                matches!(
                    r.parameter,
                    ReferenceSourceDefinitionParameter::Duration {
                        decay_time_seconds: 0,
                        ..
                    }
                )
            })
            .collect();
        assert_eq!(zeros.len(), 2);
        for row in zeros {
            assert!(matches!(
                row.parameter,
                ReferenceSourceDefinitionParameter::Duration {
                    default_duration_ms: 0,
                    setter_disposition:
                        ReferenceSourceDurationSetterDisposition::ZeroSkipsInitialization,
                    ..
                }
            ));
            assert!(!row.current_world_owner_pointers.is_empty());
        }
    }
}

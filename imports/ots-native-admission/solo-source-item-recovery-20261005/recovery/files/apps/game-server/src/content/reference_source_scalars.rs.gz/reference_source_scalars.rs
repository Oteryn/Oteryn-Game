//! Own-cut base-definition observations; no scalar replacement or runtime instruction.
use super::{ContentError, ReferenceItemField};
use serde::{Deserialize, Serialize};
use std::sync::OnceLock;

macro_rules! scalar_enum {
    ($name:ident { $($member:ident),+ }) => {
        #[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
        #[serde(rename_all = "SCREAMING_SNAKE_CASE")]
        pub enum $name { $($member),+ }
    };
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum ReferenceScalarCut {
    #[serde(rename = "CANARY_47DF")]
    Canary47df,
    #[serde(rename = "CRYSTAL_FF7")]
    CrystalFf7,
    #[serde(rename = "CRYSTAL_00CE")]
    Crystal00ce,
}
scalar_enum!(ReferenceScalarField {
    PhysicalWeight,
    ProtectionArmor
});
scalar_enum!(ReferenceScalarOrigin {
    OwnItemtypeInitializer0,
    OrderedExplicitXml
});
scalar_enum!(ReferenceScalarXmlPresence { Absent, Present });
scalar_enum!(ReferenceScalarUnit {
    CentiOz,
    SignedPoints
});
scalar_enum!(ReferenceScalarPhase {
    FreshCppProtobufThenOrderedXmlBeforeLuaInstanceAttributes
});
scalar_enum!(ReferenceScalarNativeOrigin {
    MatchedSealedPriorPromotion,
    Unattributed
});

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", content = "value", rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceScalarNativeValue {
    PhysicalWeight(u32),
    ProtectionArmor(i32),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", content = "value", rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceScalarGetterValue {
    UnsignedWeight(u32),
    SignedArmor(i32),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceScalarObservation {
    pub source_cut: ReferenceScalarCut,
    pub field: ReferenceScalarField,
    pub external_item_id: u16,
    pub xml_ordinal: u32,
    pub cpp_signed_value: i32,
    pub getter_value: ReferenceItemField<ReferenceScalarGetterValue>,
    pub raw_xml_presence: ReferenceScalarXmlPresence,
    pub ordered_original_lexemes: Vec<String>,
    pub origin: ReferenceScalarOrigin,
    pub phase: ReferenceScalarPhase,
    pub unit: ReferenceScalarUnit,
    pub retained_canonical: ReferenceItemField<ReferenceScalarNativeValue>,
    pub retained_reference: ReferenceItemField<ReferenceScalarNativeValue>,
    pub native_origin: ReferenceScalarNativeOrigin,
}

#[derive(Deserialize)]
struct RegisteredScalarRow {
    target_key: String,
    target_revision: String,
    observations: Vec<ReferenceSourceScalarObservation>,
}
#[derive(Deserialize)]
struct ScalarRegistry {
    rows: Vec<RegisteredScalarRow>,
}
fn registry() -> Result<&'static ScalarRegistry, ContentError> {
    static REGISTRY: OnceLock<Result<ScalarRegistry, ()>> = OnceLock::new();
    REGISTRY
        .get_or_init(|| {
            serde_json::from_str(include_str!("source-scalar-registry.json")).map_err(|_| ())
        })
        .as_ref()
        .map_err(|_| ContentError::InvalidArtifact("invalid own Source scalar registry"))
}

pub(crate) fn validate_item_source_scalars(
    entries: &[ReferenceSourceScalarObservation],
) -> Result<(), ContentError> {
    if entries.is_empty()
        || entries.len() > 6
        || entries
            .windows(2)
            .any(|pair| (pair[0].field, pair[0].source_cut) >= (pair[1].field, pair[1].source_cut))
    {
        return Err(ContentError::InvalidArtifact(
            "Source scalar fields/cuts must be bounded sorted unique",
        ));
    }
    if !registry()?
        .rows
        .iter()
        .any(|row| row.observations == entries)
    {
        return Err(ContentError::InvalidArtifact(
            "unqualified own Source scalar observations",
        ));
    }
    Ok(())
}

pub(crate) fn validate_item_source_scalars_target(
    entries: &[ReferenceSourceScalarObservation],
    key: &str,
    revision: &str,
    item: &super::ReferenceItemDefinition,
) -> Result<(), ContentError> {
    validate_item_source_scalars(entries)?;
    use ReferenceItemField::Known;
    for entry in entries {
        let current = match entry.field {
            ReferenceScalarField::PhysicalWeight => match &item.semantics.physical {
                Known(physical) => match physical.weight {
                    Known(value) => Some(ReferenceScalarNativeValue::PhysicalWeight(value)),
                    _ => None,
                },
                _ => None,
            },
            ReferenceScalarField::ProtectionArmor => match &item.semantics.protection {
                Known(protection) => match protection.armor {
                    Known(value) => Some(ReferenceScalarNativeValue::ProtectionArmor(value.0)),
                    _ => None,
                },
                _ => None,
            },
        };
        if current.as_ref().is_none_or(|value| {
            entry.retained_canonical != Known(value.clone())
                || entry.retained_reference != Known(value.clone())
        }) {
            return Err(ContentError::InvalidArtifact(
                "retained Native scalar changed",
            ));
        }
    }
    if !registry()?.rows.iter().any(|row| {
        row.target_key == key && row.target_revision == revision && row.observations == entries
    }) {
        return Err(ContentError::InvalidArtifact(
            "Source scalar target mismatch",
        ));
    }
    Ok(())
}

pub(crate) fn validate_source_property_target(
    item: &super::ReferenceItemDefinition,
    key: &str,
    revision: &str,
) -> Result<(), ContentError> {
    super::validate_class_observations(key, revision, &item.semantics.source_class_observations)?;
    match &item.semantics.source_scalar_observations {
        ReferenceItemField::Unknown => Ok(()),
        ReferenceItemField::Known(entries) => {
            validate_item_source_scalars_target(entries, key, revision, item)
        }
        _ => Err(ContentError::InvalidArtifact(
            "Source scalars require Unknown or qualified Known",
        )),
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, reason = "closed Source scalar mutation fixtures")]
mod tests {
    use super::*;
    #[test]
    fn exact_scalar_vectors_preserve_signed_definition_and_retained_values() {
        let rows = &registry().unwrap().rows;
        assert_eq!(rows.len(), 1276);
        assert_eq!(
            rows.iter().map(|r| r.observations.len()).sum::<usize>(),
            2401
        );
        for row in rows {
            validate_item_source_scalars(&row.observations).unwrap();
        }
        let values = &rows[0].observations;
        for index in 0..4 {
            let mut changed = values.clone();
            match index {
                0 => changed[0].external_item_id = 901,
                1 => changed[0].cpp_signed_value = -100,
                2 => changed[0].ordered_original_lexemes = vec!["foreign".into()],
                _ => changed[0].retained_canonical = ReferenceItemField::Unknown,
            }
            assert!(validate_item_source_scalars(&changed).is_err());
        }
    }
}

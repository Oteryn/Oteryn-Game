use super::{ContentError, ReferenceItemField};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::sync::OnceLock;

pub const SOURCE_CLASS_MAX_OBSERVATIONS: usize = 2;
pub const SOURCE_CLASS_MAX_PRIMARY_BYTES: usize = 64;
pub const SOURCE_CLASS_MAX_MEMBER_BYTES: usize = 32;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[repr(u8)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceClassSourceCut {
    #[serde(rename = "CRYSTAL_FF7")]
    CrystalFf7 = 0,
    #[serde(rename = "CRYSTAL_00CE")]
    Crystal00ce = 1,
    #[serde(rename = "CANARY_47DF")]
    Canary47df = 2,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceSourceClassPhase {
    FreshCppProtobufThenFullOrderedXmlBeforeLua,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnCppItemKind {
    pub member: String,
    pub own_value: u8,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnMarketCategory {
    pub raw_values: Vec<u64>,
    pub stored_presence: bool,
    pub getter_member: String,
    pub getter_value: u8,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnPrimaryType {
    pub raw: String,
    pub stored_lowercase: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceItemClassObservation {
    pub source_cut: ReferenceClassSourceCut,
    pub external_item_id: u16,
    pub phase: ReferenceSourceClassPhase,
    pub raw_record_sha256: String,
    pub xml_record_ordinal: u32,
    pub cpp_kind: ReferenceOwnCppItemKind,
    pub market_category: Option<ReferenceOwnMarketCategory>,
    pub primary_type: Option<ReferenceOwnPrimaryType>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ClassRegistry {
    schema: String,
    targets: BTreeMap<String, BTreeMap<String, Vec<ReferenceSourceItemClassObservation>>>,
}

fn registry() -> Result<&'static ClassRegistry, ContentError> {
    static REGISTRY: OnceLock<Result<ClassRegistry, ()>> = OnceLock::new();
    let registry = REGISTRY
        .get_or_init(|| {
            serde_json::from_str(include_str!("source-class-registry.json")).map_err(|_| ())
        })
        .as_ref()
        .map_err(|_| ContentError::InvalidArtifact("invalid own Source class registry"))?;
    if registry.schema != "OTERYN_SOURCE_CLASS_OBSERVATIONS_CLOSED_33975/v2" {
        return Err(ContentError::InvalidArtifact(
            "unknown own Source class registry",
        ));
    }
    Ok(registry)
}

pub fn class_observations_require_future_profile(
    field: &ReferenceItemField<Vec<ReferenceSourceItemClassObservation>>,
) -> bool {
    !matches!(field, ReferenceItemField::Unknown)
}

pub fn validate_class_observations(
    key: &str,
    revision: &str,
    field: &ReferenceItemField<Vec<ReferenceSourceItemClassObservation>>,
) -> Result<(), ContentError> {
    let values = match field {
        ReferenceItemField::Unknown => return Ok(()),
        ReferenceItemField::Known(values) => values,
        ReferenceItemField::NotApplicable | ReferenceItemField::Conflict => {
            return Err(ContentError::InvalidArtifact(
                "Source class observations require Unknown or qualified Known",
            ));
        }
    };
    if values.is_empty() || values.len() > SOURCE_CLASS_MAX_OBSERVATIONS {
        return Err(ContentError::InvalidArtifact(
            "own Source class observation count",
        ));
    }
    let accepted = registry()?
        .targets
        .get(key)
        .and_then(|rows| rows.get(revision));
    if accepted != Some(values) {
        return Err(ContentError::InvalidArtifact(
            "unqualified own Source class observation",
        ));
    }
    Ok(())
}

#[cfg(test)]
#[allow(
    clippy::unwrap_used,
    reason = "closed Source registry mutation fixtures"
)]
mod tests {
    use super::*;
    #[test]
    fn frozen_own_classes_preserve_raw_enum_default_and_cross_cut_disagreements() {
        let registry = registry().unwrap();
        assert_eq!(registry.targets.len(), 33975);
        let rows: Vec<_> = registry.targets.values().flat_map(|r| r.values()).collect();
        assert_eq!(rows.iter().map(|r| r.len()).sum::<usize>(), 45721);
        assert_eq!(
            rows.iter()
                .filter(|r| r.windows(2).any(|p| p[0].cpp_kind != p[1].cpp_kind))
                .count(),
            41
        );
        let defaults = rows
            .iter()
            .flat_map(|values| values.iter())
            .filter(|v| v.cpp_kind.own_value == 0)
            .count();
        assert_eq!(defaults, 30884);
        let undeclared: Vec<_> = rows
            .iter()
            .flat_map(|values| values.iter())
            .filter(|v| {
                v.market_category
                    .as_ref()
                    .is_some_and(|m| m.raw_values == [27] && !m.stored_presence)
            })
            .collect();
        assert_eq!(undeclared.len(), 36);
        assert!(
            undeclared
                .iter()
                .all(|v| v.market_category.as_ref().unwrap().getter_value == 1)
        );
        for (key, revisions) in &registry.targets {
            for (revision, values) in revisions {
                validate_class_observations(
                    key,
                    revision,
                    &ReferenceItemField::Known(values.clone()),
                )
                .unwrap();
            }
        }
    }
    #[test]
    fn exact_target_and_individual_source_fact_mutations_fail_closed() {
        let (key, revisions) = registry()
            .unwrap()
            .targets
            .iter()
            .find(|(_, rows)| rows.values().any(|values| values.len() > 1))
            .unwrap();
        let (revision, values) = revisions
            .iter()
            .find(|(_, values)| values.len() > 1)
            .unwrap();
        let known = ReferenceItemField::Known(values.clone());
        assert!(validate_class_observations("oteryn:item.tibia.i901", revision, &known).is_err());
        assert!(validate_class_observations(key, "foreign-r1", &known).is_err());
        for index in 0..4 {
            let mut changed = values.clone();
            match index {
                0 => changed[0].external_item_id = 901,
                1 => changed[0].cpp_kind.own_value = 44,
                2 => changed[0].raw_record_sha256 = "0".repeat(64),
                _ => changed.reverse(),
            }
            assert_ne!(changed, *values);
            assert!(
                validate_class_observations(key, revision, &ReferenceItemField::Known(changed))
                    .is_err()
            );
        }
        for field in [
            ReferenceItemField::Conflict,
            ReferenceItemField::NotApplicable,
            ReferenceItemField::Known(vec![]),
        ] {
            assert!(class_observations_require_future_profile(&field));
            assert!(validate_class_observations(key, revision, &field).is_err());
        }
    }
}

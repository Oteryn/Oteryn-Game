//! Source namespace fixed16 getters, conditional on normal return before Lua.
//! No Native flag, runtime IO/allocation/logger success, or V7 export claims.
use super::{
    ContentError, ReferenceDefinitionSourceCut, ReferenceItemField,
    ReferenceOwnDefinitionAssignment, ReferenceSourceDefinitionPhase,
    ReferenceSourceWorldOwnerPointer,
};
use serde::{Deserialize, Serialize};
use std::{collections::BTreeMap, io::Read, sync::OnceLock};
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnFlagValues {
    pub show_count: bool,
    pub show_duration: bool,
    pub show_charges: bool,
    pub show_attributes: bool,
    pub movable: bool,
    pub pickupable: bool,
    pub block_projectile: bool,
    pub block_solid: bool,
    pub walk_stack: bool,
    pub replaceable: bool,
    pub distance_read: bool,
    pub usable_by_house_guests: bool,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnReadWriteValues {
    pub readable: bool,
    pub writeable: bool,
    pub max_text_length: u16,
    pub write_once_external_item_id: u16,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnFlagPresence {
    pub unmove: bool,
    pub take: bool,
    pub unsight: bool,
    pub unpass: bool,
    pub write: bool,
    pub write_once: bool,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceOwnFlagParameterKind {
    FlagsReadWrite,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceOwnFlagParameter {
    pub kind: ReferenceOwnFlagParameterKind,
    pub flags: ReferenceOwnFlagValues,
    pub read_write: ReferenceOwnReadWriteValues,
    pub prototype_flag_presence: ReferenceOwnFlagPresence,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceFlagReadWriteObservation {
    pub source_cut: ReferenceDefinitionSourceCut,
    pub external_item_id: u16,
    pub phase: ReferenceSourceDefinitionPhase,
    pub prototype_message_sha256: String,
    pub xml_record_ordinal: u32,
    pub xml_record_sha256: String,
    pub source_group: String,
    pub current_world_owner_pointers: Vec<ReferenceSourceWorldOwnerPointer>,
    pub ordered_assignments: Vec<ReferenceOwnDefinitionAssignment>,
    pub parameter: ReferenceOwnFlagParameter,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Registry {
    schema: String,
    targets: BTreeMap<String, BTreeMap<String, Vec<ReferenceSourceFlagReadWriteObservation>>>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Admission {
    status: String,
    registry_sha256: String,
    conditional_closure_sha256: Option<String>,
    independent_review_receipt_sha256: Option<String>,
    max_value_lexeme_utf8_bytes: Option<usize>,
    max_observations: Option<usize>,
    max_ordered_assignments: Option<usize>,
    max_world_owner_pointers: Option<usize>,
}
fn hash(value: &str) -> bool {
    value.len() == 64
        && value
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}
fn shape(value: &ReferenceSourceFlagReadWriteObservation, admission: &Admission) -> bool {
    hash(&value.prototype_message_sha256)
        && hash(&value.xml_record_sha256)
        && value.xml_record_ordinal > 0
        && admission.max_value_lexeme_utf8_bytes.is_some_and(|n| {
            value
                .ordered_assignments
                .iter()
                .all(|r| r.value_lexeme.len() <= n && r.value_lexeme.is_ascii())
        })
        && matches!(
            value.source_group.as_str(),
            "ITEM_GROUP_NONE"
                | "ITEM_GROUP_GROUND"
                | "ITEM_GROUP_CONTAINER"
                | "ITEM_GROUP_SPLASH"
                | "ITEM_GROUP_FLUID"
        )
        && admission
            .max_ordered_assignments
            .is_some_and(|n| value.ordered_assignments.len() <= n)
        && admission
            .max_world_owner_pointers
            .is_some_and(|n| value.current_world_owner_pointers.len() <= n)
}

fn decoded_registry(
    input: &[u8],
    exact_length: usize,
    expected_sha256: &str,
) -> Result<Vec<u8>, ()> {
    let mut decoder = zstd::stream::read::Decoder::new(input).map_err(|_| ())?;
    decoder.window_log_max(22).map_err(|_| ())?;
    let mut raw = Vec::new();
    decoder
        .take(exact_length as u64 + 1)
        .read_to_end(&mut raw)
        .map_err(|_| ())?;
    if raw.len() != exact_length {
        return Err(());
    }
    let actual: String = super::digest::sha256(&raw)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect();
    if actual != expected_sha256 {
        return Err(());
    }
    Ok(raw)
}

fn registry() -> Result<&'static (Registry, Admission), ContentError> {
    static REGISTRY: OnceLock<Result<(Registry, Admission), ()>> = OnceLock::new();
    REGISTRY
        .get_or_init(|| {
            let raw = decoded_registry(include_bytes!("source-flag-read-write-registry.json.zst"), 76768031, "f9b0cae9b18722142c8afad2abb50ea7c453c604d6ec561b4265388d50fe5c2c")?;
            let registry: Registry = serde_json::from_slice(&raw).map_err(|_| ())?;
            let admission: Admission =
                serde_json::from_str(include_str!("source-flag-read-write-admission.json"))
                    .map_err(|_| ())?;
            let receipt: serde_json::Value = serde_json::from_str(
                include_str!("source-flag-read-write-independent-review.json"),
            ).map_err(|_| ())?;
            if receipt["status"] != "QUALIFIED_WHOLE_SOURCE_FLAGS_PHASE"
                || receipt["qualification_scope"] != "INDEPENDENT_SOURCE_ONLY_CONDITIONAL_NORMAL_RETURN_NOT_NATIVE_ADMISSION"
                || receipt["completion_assumption"] != "NORMAL_RETURN_OF_CPP_PROTOBUF_AND_FULL_XML_PHASE"
                || receipt["actual_CPP_load_completed"] != "NOT_EXECUTED_UNKNOWN"
                || receipt["registry_sha256"].as_str() != Some(admission.registry_sha256.as_str())
                || receipt["conditional_closure_sha256"].as_str() != admission.conditional_closure_sha256.as_deref()
                || receipt["targets"] != 33975 || receipt["observations"] != 45721
                || receipt["whole_binding_sdk_proto_xml_world_prerequisites_replayed"] != true
                || receipt["value_holds"] != 0 || receipt["Native_promotions"] != 0
                || receipt["measured_bounds"] != serde_json::json!({"observations":2,"ordered_assignments":3,"World_pointers":1,"assignment_UTF8_lexeme_bytes":4})
            { return Err(()); }
            let actual: String = super::digest::sha256(&raw)
                .iter()
                .map(|b| format!("{b:02x}"))
                .collect();
            if registry.schema != "OTERYN_SOURCE_FLAGS_READ_WRITE_CLOSED/v1"
                || admission.status != "QUALIFIED_FIXED16_OWN_CPP_NORMAL_RETURN_CONDITIONAL_CLOSURE"
                || admission.registry_sha256 != actual
                || !admission
                    .conditional_closure_sha256
                    .as_deref()
                    .is_some_and(hash)
                || admission.independent_review_receipt_sha256.as_deref()
                    != Some(
                        super::digest::sha256(
                            include_str!("source-flag-read-write-independent-review.json")
                                .as_bytes(),
                        )
                        .iter()
                        .map(|b| format!("{b:02x}"))
                        .collect::<String>()
                        .as_str(),
                    )
                || !admission
                    .independent_review_receipt_sha256
                    .as_deref()
                    .is_some_and(hash)
                || admission.max_value_lexeme_utf8_bytes != Some(4)
                || admission.max_observations != Some(2)
                || admission.max_ordered_assignments != Some(3)
                || admission.max_world_owner_pointers != Some(1)
                || registry.targets.len() != 33975
                || registry
                    .targets
                    .values()
                    .flat_map(|r| r.values())
                    .map(Vec::len)
                    .sum::<usize>()
                    != 45721
                || admission.max_observations
                    != registry
                        .targets
                        .values()
                        .flat_map(|r| r.values())
                        .map(Vec::len)
                        .max()
                || admission.max_ordered_assignments
                    != registry
                        .targets
                        .values()
                        .flat_map(|r| r.values())
                        .flatten()
                        .map(|r| r.ordered_assignments.len())
                        .max()
                || admission.max_world_owner_pointers
                    != registry
                        .targets
                        .values()
                        .flat_map(|r| r.values())
                        .flatten()
                        .map(|r| r.current_world_owner_pointers.len())
                        .max()
                || !admission.max_observations.is_some_and(|n| n > 0)
                || registry.targets.values().any(|revisions| {
                    revisions.values().any(|rows| {
                        rows.is_empty()
                            || !admission.max_observations.is_some_and(|n| rows.len() <= n)
                            || rows.iter().any(|r| !shape(r, &admission))
                    })
                })
            {
                return Err(());
            }
            Ok((registry, admission))
        })
        .as_ref()
        .map_err(|_| ContentError::InvalidArtifact("Source flags not admitted"))
}
pub fn flag_read_write_observations_require_future_profile(
    field: &ReferenceItemField<Vec<ReferenceSourceFlagReadWriteObservation>>,
) -> bool {
    !matches!(field, ReferenceItemField::Unknown)
}
pub fn validate_source_flag_read_write_target(
    key: &str,
    revision: &str,
    field: &ReferenceItemField<Vec<ReferenceSourceFlagReadWriteObservation>>,
) -> Result<(), ContentError> {
    let values = match field {
        ReferenceItemField::Unknown => return Ok(()),
        ReferenceItemField::Known(values) => values,
        ReferenceItemField::NotApplicable | ReferenceItemField::Conflict => {
            return Err(ContentError::InvalidArtifact(
                "Source flags require whole qualified Known or Unknown",
            ));
        }
    };
    let (registry, _) = registry()?;
    if values.is_empty() || registry.targets.get(key).and_then(|r| r.get(revision)) != Some(values)
    {
        return Err(ContentError::InvalidArtifact(
            "unqualified Source flags identity/vector",
        ));
    }
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn qualified_registry_and_all_nonunknown_barrier() -> Result<(), ContentError> {
        let (registered, _) = registry()?;
        assert_eq!(registered.targets.len(), 33975);
        let unknown = ReferenceItemField::Unknown;
        assert!(!flag_read_write_observations_require_future_profile(
            &unknown
        ));
        assert!(validate_source_flag_read_write_target("key", "r1", &unknown).is_ok());
        for value in [
            ReferenceItemField::Known(vec![]),
            ReferenceItemField::Conflict,
            ReferenceItemField::NotApplicable,
        ] {
            assert!(flag_read_write_observations_require_future_profile(&value));
            assert!(validate_source_flag_read_write_target("key", "r1", &value).is_err());
        }
        Ok(())
    }
    #[test]
    fn real_vectors_require_whole_source_identity_and_every_primitive() -> Result<(), ContentError>
    {
        let (registered, _) = registry()?;
        let (key, revisions) =
            registered
                .targets
                .first_key_value()
                .ok_or(ContentError::InvalidArtifact(
                    "empty qualified flags registry",
                ))?;
        let (revision, rows) = revisions
            .first_key_value()
            .ok_or(ContentError::InvalidArtifact(
                "empty qualified flags revisions",
            ))?;
        let known = ReferenceItemField::Known(rows.clone());
        validate_source_flag_read_write_target(key, revision, &known)?;
        assert!(validate_source_flag_read_write_target("unregistered", revision, &known).is_err());
        assert!(validate_source_flag_read_write_target(key, "unregistered", &known).is_err());
        let mut changed = rows.clone();
        changed[0].parameter.flags.show_count = !changed[0].parameter.flags.show_count;
        assert!(
            validate_source_flag_read_write_target(
                key,
                revision,
                &ReferenceItemField::Known(changed)
            )
            .is_err()
        );
        let mut changed = rows.clone();
        changed[0].parameter.prototype_flag_presence.unmove =
            !changed[0].parameter.prototype_flag_presence.unmove;
        assert!(
            validate_source_flag_read_write_target(
                key,
                revision,
                &ReferenceItemField::Known(changed)
            )
            .is_err()
        );
        let mut changed = rows.clone();
        changed[0].parameter.read_write.max_text_length ^= 1;
        assert!(
            validate_source_flag_read_write_target(
                key,
                revision,
                &ReferenceItemField::Known(changed)
            )
            .is_err()
        );
        let mut duplicate = rows.clone();
        duplicate.extend_from_slice(rows);
        assert!(
            validate_source_flag_read_write_target(
                key,
                revision,
                &ReferenceItemField::Known(duplicate)
            )
            .is_err()
        );
        Ok(())
    }
    #[test]
    fn primitive_flags_do_not_accept_known_wrappers_or_numeric_bools() {
        let fixture = serde_json::json!({"show_count":false,"show_duration":false,"show_charges":false,"show_attributes":false,"movable":false,"pickupable":false,"block_projectile":false,"block_solid":false,"walk_stack":false,"replaceable":false,"distance_read":false,"usable_by_house_guests":false});
        assert!(serde_json::from_value::<ReferenceOwnFlagValues>(fixture.clone()).is_ok());
        for bad in [
            serde_json::json!(1),
            serde_json::json!({"state":"KNOWN","value":true}),
        ] {
            let mut value = fixture.clone();
            value["show_count"] = bad;
            assert!(serde_json::from_value::<ReferenceOwnFlagValues>(value).is_err());
        }
        assert!(serde_json::from_value::<ReferenceOwnReadWriteValues>(serde_json::json!({
            "readable":true,"writeable":false,"max_text_length":65536,"write_once_external_item_id":0})).is_err());
        assert!(serde_json::from_value::<ReferenceOwnReadWriteValues>(serde_json::json!({
            "readable":{"state":"KNOWN","value":true},"writeable":false,"max_text_length":0,"write_once_external_item_id":0})).is_err());
    }
}

#[cfg(test)]
mod compressed_registry_tests {
    use super::decoded_registry;
    #[test]
    fn bounded_registry_decode_rejects_drift() -> Result<(), ()> {
        let raw = b"abc";
        let digest: String = super::super::digest::sha256(raw)
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect();
        let compressed = zstd::stream::encode_all(&raw[..], 1).map_err(|_| ())?;
        assert_eq!(decoded_registry(&compressed, 3, &digest)?, raw.to_vec());
        assert!(decoded_registry(&compressed, 2, &digest).is_err());
        assert!(decoded_registry(&compressed, 4, &digest).is_err());
        assert!(decoded_registry(&compressed, 3, &"0".repeat(64)).is_err());
        assert!(decoded_registry(&compressed[..compressed.len() - 1], 3, &digest).is_err());
        assert!(decoded_registry(b"invalid zstd", 3, &digest).is_err());
        let extra = zstd::stream::encode_all(&b"abcd"[..], 1).map_err(|_| ())?;
        assert!(decoded_registry(&extra, 3, &digest).is_err());
        // Valid zstd magic, no single-segment flag, oversized window descriptor.
        assert!(
            decoded_registry(
                &[0x28, 0xb5, 0x2f, 0xfd, 0x00, 0xa0, 0x01, 0x00, 0x00],
                3,
                &digest
            )
            .is_err()
        );
        Ok(())
    }
}

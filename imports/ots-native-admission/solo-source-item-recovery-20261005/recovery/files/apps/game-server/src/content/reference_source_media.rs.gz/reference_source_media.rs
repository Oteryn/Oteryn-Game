//! Source-qualified declarations only: no Native asset or playback instruction.
use super::{ContentError, ReferenceItemField, Sha256HexDigest};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::sync::OnceLock;

pub const REFERENCE_SOURCE_MEDIA_MAX_CUTS: usize = 3;
pub const REFERENCE_SOURCE_MEDIA_MAX_MEMBER_BYTES: usize = 96;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[repr(u8)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceMediaSourceCut {
    #[serde(rename = "CANARY_47DF")]
    Canary47df = 0,
    #[serde(rename = "CRYSTAL_FF7")]
    CrystalFf7 = 1,
    #[serde(rename = "CRYSTAL_00CE")]
    Crystal00ce = 2,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[repr(u8)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceMediaNamespace {
    ShootType = 0,
    MagicEffect = 1,
    SoundEffect = 2,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[repr(u8)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceItemMediaPhase {
    XmlItemtypeBeforeLua = 0,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[repr(u8)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ReferenceXmlMediaAssignment {
    Write = 0,
    IgnoredNone = 1,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceSourceQualifiedEnum {
    pub source_cut: ReferenceMediaSourceCut,
    pub namespace: ReferenceMediaNamespace,
    pub member: String,
    pub own_value: u16,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceXmlMediaDeclaration {
    pub media: ReferenceSourceQualifiedEnum,
    pub assignment: ReferenceXmlMediaAssignment,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReferenceItemSourceMediaConfig {
    pub source_cut: ReferenceMediaSourceCut,
    pub external_item_id: u16,
    pub phase: ReferenceItemMediaPhase,
    pub record_ordinal: u32,
    pub raw_record_sha256: String,
    pub projectile: ReferenceItemField<ReferenceXmlMediaDeclaration>,
    pub trash_holder_visual: ReferenceItemField<ReferenceXmlMediaDeclaration>,
}

#[derive(Deserialize)]
struct RegisteredCut {
    tag: ReferenceMediaSourceCut,
    repository: String,
    revision: String,
    enums: BTreeMap<ReferenceMediaNamespace, BTreeMap<String, u16>>,
}

impl ReferenceMediaSourceCut {
    pub fn repository_and_revision(self) -> Result<(&'static str, &'static str), ContentError> {
        let cut = registry()?.cuts.iter().find(|cut| cut.tag == self).ok_or(
            ContentError::InvalidArtifact("unregistered own Source media cut"),
        )?;
        Ok((&cut.repository, &cut.revision))
    }
}

#[derive(Deserialize)]
struct RegisteredDeclaration {
    target_key: String,
    target_revision: String,
    config: ReferenceItemSourceMediaConfig,
}

#[derive(Deserialize)]
struct MediaRegistry {
    cuts: Vec<RegisteredCut>,
    declarations: Vec<RegisteredDeclaration>,
}

fn registry() -> Result<&'static MediaRegistry, ContentError> {
    static REGISTRY: OnceLock<Result<MediaRegistry, ()>> = OnceLock::new();
    REGISTRY
        .get_or_init(|| {
            serde_json::from_str(include_str!("source-media-registry.json")).map_err(|_| ())
        })
        .as_ref()
        .map_err(|_| ContentError::InvalidArtifact("invalid frozen own Source media registry"))
}

pub(crate) fn validate_source_enum(
    value: &ReferenceSourceQualifiedEnum,
) -> Result<(), ContentError> {
    if value.member.is_empty()
        || value.member.len() > REFERENCE_SOURCE_MEDIA_MAX_MEMBER_BYTES
        || !value
            .member
            .bytes()
            .all(|b| b.is_ascii_uppercase() || b.is_ascii_digit() || b == b'_')
    {
        return Err(ContentError::InvalidArtifact(
            "invalid own Source enum member",
        ));
    }
    let known = registry()?
        .cuts
        .iter()
        .find(|cut| cut.tag == value.source_cut)
        .and_then(|cut| cut.enums.get(&value.namespace))
        .and_then(|members| members.get(&value.member));
    if known != Some(&value.own_value) {
        return Err(ContentError::InvalidArtifact(
            "own Source enum member/value disagreement",
        ));
    }
    Ok(())
}

fn validate_xml_declaration(
    value: &ReferenceXmlMediaDeclaration,
    cut: ReferenceMediaSourceCut,
    namespace: ReferenceMediaNamespace,
) -> Result<(), ContentError> {
    validate_source_enum(&value.media)?;
    if value.media.source_cut != cut || value.media.namespace != namespace {
        return Err(ContentError::InvalidArtifact(
            "foreign XML media cut or namespace",
        ));
    }
    if (value.media.own_value == 0)
        != (value.assignment == ReferenceXmlMediaAssignment::IgnoredNone)
    {
        return Err(ContentError::InvalidArtifact(
            "Source NONE must retain XML no-write semantics",
        ));
    }
    Ok(())
}

pub(crate) fn validate_item_source_media(
    entries: &[ReferenceItemSourceMediaConfig],
) -> Result<(), ContentError> {
    if entries.is_empty()
        || entries.len() > REFERENCE_SOURCE_MEDIA_MAX_CUTS
        || entries
            .windows(2)
            .any(|pair| pair[0].source_cut >= pair[1].source_cut)
    {
        return Err(ContentError::InvalidArtifact(
            "Source media cuts must be bounded sorted unique",
        ));
    }
    for entry in entries {
        Sha256HexDigest::new(&entry.raw_record_sha256)?;
        for (field, namespace) in [
            (&entry.projectile, ReferenceMediaNamespace::ShootType),
            (
                &entry.trash_holder_visual,
                ReferenceMediaNamespace::MagicEffect,
            ),
        ] {
            if let ReferenceItemField::Known(value) = field {
                validate_xml_declaration(value, entry.source_cut, namespace)?;
            }
        }
        if !registry()?
            .declarations
            .iter()
            .any(|row| row.config == *entry)
        {
            return Err(ContentError::InvalidArtifact(
                "unqualified own XML media declaration",
            ));
        }
    }
    Ok(())
}

pub(crate) fn validate_item_source_media_target(
    entries: &[ReferenceItemSourceMediaConfig],
    key: &str,
    revision: &str,
) -> Result<(), ContentError> {
    validate_item_source_media(entries)?;
    for entry in entries {
        if !registry()?.declarations.iter().any(|row| {
            row.config == *entry && row.target_key == key && row.target_revision == revision
        }) {
            return Err(ContentError::InvalidArtifact(
                "Source media exact target binding disagrees",
            ));
        }
    }
    Ok(())
}

pub(crate) fn enum_member_ordinal(
    value: &ReferenceSourceQualifiedEnum,
) -> Result<u16, ContentError> {
    validate_source_enum(value)?;
    let cut = registry()?
        .cuts
        .iter()
        .find(|cut| cut.tag == value.source_cut)
        .ok_or(ContentError::InvalidArtifact("unknown source cut"))?;
    let members = cut
        .enums
        .get(&value.namespace)
        .ok_or(ContentError::InvalidArtifact("unknown source namespace"))?;
    u16::try_from(
        members
            .keys()
            .position(|key| key == &value.member)
            .ok_or(ContentError::InvalidArtifact("unknown source member"))?,
    )
    .map_err(|_| ContentError::InvalidSectionBounds)
}
pub(crate) fn enum_from_wire(
    cut: u8,
    namespace: u8,
    ordinal: u16,
    own_value: u16,
) -> Result<ReferenceSourceQualifiedEnum, ContentError> {
    let source_cut = match cut {
        0 => ReferenceMediaSourceCut::Canary47df,
        1 => ReferenceMediaSourceCut::CrystalFf7,
        2 => ReferenceMediaSourceCut::Crystal00ce,
        _ => return Err(ContentError::InvalidArtifact("unknown source cut")),
    };
    let namespace = match namespace {
        0 => ReferenceMediaNamespace::ShootType,
        1 => ReferenceMediaNamespace::MagicEffect,
        2 => ReferenceMediaNamespace::SoundEffect,
        _ => return Err(ContentError::InvalidArtifact("unknown source namespace")),
    };
    let member = registry()?
        .cuts
        .iter()
        .find(|cut| cut.tag == source_cut)
        .and_then(|cut| cut.enums.get(&namespace))
        .and_then(|members| members.keys().nth(usize::from(ordinal)))
        .ok_or(ContentError::InvalidArtifact(
            "unknown source member ordinal",
        ))?
        .clone();
    let value = ReferenceSourceQualifiedEnum {
        source_cut,
        namespace,
        member,
        own_value,
    };
    validate_source_enum(&value)?;
    Ok(value)
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;
    #[test]
    fn old_json_defaults_unknown_and_new_nested_unknown_fields_reject() {
        let semantics: super::super::ReferenceItemSemantics = serde_json::from_str("{}").unwrap();
        assert!(matches!(
            &semantics.source_media_config,
            ReferenceItemField::Unknown
        ));
        assert!(
            serde_json::to_value(semantics)
                .unwrap()
                .get("source_media_config")
                .is_none()
        );
        let mut json = serde_json::to_value(&registry().unwrap().declarations[0].config).unwrap();
        json["playback"] = serde_json::json!(true);
        assert!(serde_json::from_value::<ReferenceItemSourceMediaConfig>(json).is_err());
        assert!(validate_item_source_media(&[]).is_err());
    }
    #[test]
    fn all_377_registered_source_declarations_keep_exact_target_proofs() {
        let registry = registry().unwrap();
        assert_eq!(registry.declarations.len(), 377);
        for row in &registry.declarations {
            validate_item_source_media_target(
                std::slice::from_ref(&row.config),
                &row.target_key,
                &row.target_revision,
            )
            .unwrap();
            assert!(
                validate_item_source_media_target(
                    std::slice::from_ref(&row.config),
                    "oteryn:item.tibia.i901",
                    &row.target_revision
                )
                .is_err()
            );
        }
    }
    #[test]
    fn forged_values_source_proofs_and_duplicate_cuts_fail() {
        let mut config = registry().unwrap().declarations[0].config.clone();
        if let ReferenceItemField::Known(value) = &mut config.projectile {
            value.media.own_value = 65535;
        } else if let ReferenceItemField::Known(value) = &mut config.trash_holder_visual {
            value.media.own_value = 65535;
        }
        assert!(validate_item_source_media(std::slice::from_ref(&config)).is_err());
        config = registry().unwrap().declarations[0].config.clone();
        assert!(validate_item_source_media(&[config.clone(), config.clone()]).is_err());
        config.raw_record_sha256 = "0".repeat(64);
        assert!(validate_item_source_media(&[config]).is_err());
    }
    #[test]
    fn source_none_no_write_is_distinct_from_sound_silence() {
        let none = ReferenceSourceQualifiedEnum {
            source_cut: ReferenceMediaSourceCut::Canary47df,
            namespace: ReferenceMediaNamespace::ShootType,
            member: "CONST_ANI_NONE".to_owned(),
            own_value: 0,
        };
        validate_source_enum(&none).unwrap();
        let mut xml = ReferenceXmlMediaDeclaration {
            media: none,
            assignment: ReferenceXmlMediaAssignment::IgnoredNone,
        };
        validate_xml_declaration(&xml, xml.media.source_cut, xml.media.namespace).unwrap();
        xml.assignment = ReferenceXmlMediaAssignment::Write;
        assert!(validate_xml_declaration(&xml, xml.media.source_cut, xml.media.namespace).is_err());
        let silence = ReferenceSourceQualifiedEnum {
            source_cut: ReferenceMediaSourceCut::Canary47df,
            namespace: ReferenceMediaNamespace::SoundEffect,
            member: "SILENCE".to_owned(),
            own_value: 0,
        };
        validate_source_enum(&silence).unwrap();
        assert!(serde_json::from_str::<ReferenceSourceQualifiedEnum>(r#"{"source_cut":"UnknownCut","namespace":"SHOOT_TYPE","member":"CONST_ANI_NONE","own_value":0}"#).is_err());
    }
}

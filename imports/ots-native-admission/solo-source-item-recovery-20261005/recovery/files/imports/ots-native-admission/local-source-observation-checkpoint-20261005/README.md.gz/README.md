# Local Source import checkpoint — 2026-10-05

The installed import expands own Canary/Crystal class observations to 33,975 items, adds static definition observations for 4,475 items, and adds combat configuration observations for 35 items. Both canonical and reference views contain the qualified Source children. Scalar and media observations from the preceding checkpoint are preserved.

| Source packet | Distinct items | Own observations |
| --- | ---: | ---: |
| Class | 33,975 | 45,721 |
| Definition: duration, container, fluid | 4,475 | 9,291 |
| Combat | 35 | 39 |
| Scalar, preserved | 1,276 | 2,401 |
| Media, preserved | 266 | 377 |

Counts overlap and must not be added. These are Source observations, not proof of Native gameplay classification or runtime capabilities. The current canonical inventory contains 34,032 Items: 944 have Known Native classification, 33,032 remain Unknown and 56 omit it. Core901 and 56 other records are excluded from the expanded Source class packet.

The actual production reader generated eleven documents twice with byte-identical results. Fresh production-library integration tests passed 15/15 for the public artifact boundary and 5/5 for repository capture/rewrite. The public tests include 36 Source-state rejection cases before client projection. Fourteen focused Source model tests, all eight installed portable/full-tree checks, three installed combat formal tests, workspace formatting, scoped Python lint and all-targets Clippy passed.

The earlier full application unit run had 102 passes and one ineffective test fixture failure. The fixture was repaired and verified in the focused tests; subsequent full-unit build attempts exceeded available memory. This checkpoint does not claim a fresh 103/103 application-unit pass or replace the public 36 cases with the private encoder 72-case matrix. Original failure logs remain archived with the successful successor evidence.

Names/descriptions and flags/read-write are the next full-size Source packets. Remaining ability, World, transform, ordered handler and constructor/default coverage still needs Source closure. Native Known presentation, physical data, World ownership and runtime authority have not been inferred from Source candidates. The artifact family ceiling remains 38,157; mixed export and the future V7 layout remain held. Wiki research follows Canary/Crystal parity.

`manifest.json` records exact payload fences and the compressed evidence index. Each evidence entry includes both original and archive SHA-256; gzip files are reversible. Older checkpoints remain intact. This checkpoint is local only: no PR, push or merge.

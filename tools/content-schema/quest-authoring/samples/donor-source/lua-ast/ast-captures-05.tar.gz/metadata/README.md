# Donor-first Lua structural capture

This packet preserves the exact Lua bytes and `config.lua.dist` runtime templates of the pinned Canary, Crystal and Crystal summer comparison corpus, with token stream and full structural AST from upstream `luaparser==4.2.0` (MIT), `antlr4-python3-runtime==4.13.2`. It does not include wiki or selected Oteryn recipe interpretations.

The corpus manifest supplies donor/repository/revision/path/Git blob SHA-1/SHA-256 for every occurrence. Each distinct SHA-256 is parsed once. `index.json` links every occurrence to its capture. Raw bytes are embedded as base64, including comments, whitespace and original line endings; no source is reconstructed from the AST. Captures are deterministic gzip containers (mtime 0, level 6), each with both uncompressed JSON and container SHA-256. Dependencies and wheel hashes are pinned in `requirements.lock`; downloaded wheels permit offline installation.

`lua_structural_source.schema.json` is a source structure schema, not a replacement for Quest/Interaction semantic or runtime admission schemas. Every file has an explicit PARSED, ENCODING_FAILED, LEX_FAILED or PARSE_FAILED state. Failure preserves raw bytes and diagnostics, never an empty successful programme. Lexer/AST offsets refer to Unicode code points in UTF-8-sig-decoded text; BOM bytes remain in raw witness. AST nodes without upstream token coordinates (notably Name nodes) have `span: null`, rather than guessed spans. The exact lexed token coordinates and raw text remain available. Parser grammar acceptance does not establish donor runtime version compatibility, callback semantics, helper effects, dynamic bindings, or native quest behaviour.

## Reproduce locally

Create a disposable Python 3.12 virtual environment, then install:

```
pip install --no-index --find-links wheels --require-hashes -r requirements.lock
python lua_ast_capture.py --manifest ../evidence/corpus-manifest.json --output captures --workers 4
python -m unittest discover -s . -p test_lua_ast_capture.py -v
python qualify.py
```

All generation is local and network-free after acquiring the pinned source corpus and parser wheels. `qualify.py` validates every capture against the complete JSON schema, every raw-byte hash, every lexed-token slice, and every nonnull AST span. `fastjsonschema==2.21.2` compiles the recursive schema for batched verification; independent `jsonschema==4.26.0` negative tests check that PARSED-without-AST and runtime admission are rejected. The tools do not execute donor Lua or modify the game server.

Initial capture: 21,546 Lua occurrences (Canary 5,371; Crystal 8,049; Crystal summer comparison 8,126) deduplicated to 8,572 blobs, all accepted by the pinned parser. Summer comparison is not silently promoted to the selected primary Crystal revision. This coverage is full source structure coverage, not proof that 21,546 scripts or all quests have native semantic representations.

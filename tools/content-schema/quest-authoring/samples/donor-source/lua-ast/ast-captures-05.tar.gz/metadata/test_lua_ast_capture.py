import base64, hashlib, json, tempfile, unittest
from pathlib import Path
from lua_ast_capture import capture, process, is_lua_source

def nodes(value):
    if isinstance(value,dict):
        if 'node_type' in value: yield value
        for child in value.values(): yield from nodes(child)
    elif isinstance(value,list):
        for child in value: yield from nodes(child)

class CaptureTests(unittest.TestCase):
    def test_runtime_config_template_selected(self):
        self.assertTrue(is_lua_source('config.lua.dist'))
        self.assertTrue(is_lua_source('data/actions/quest.lua'))
        self.assertFalse(is_lua_source('notes.lua.bak'))
    def test_structures_not_flattened(self):
        raw=b'''local function f(p)\nfor i=1,5 do\nif p:getStorageValue(9) < 2 then p:addItem(100,1) else repeat i=i-1 until i==0 end\nend\nreturn function(x) return x+1 end\nend'''
        out=capture(raw); self.assertEqual(out['status'],'PARSED')
        names={n['node_type'] for n in nodes(out['ast'])}
        self.assertTrue({'LocalFunction','Fornum','If','Repeat','Return','AnonymousFunction','Invoke'}<=names)
        self.assertEqual(base64.b64decode(out['raw_bytes_base64']),raw)
        self.assertFalse(out['native_semantic_admission'])
    def test_comments_strings_do_not_become_calls(self):
        out=capture(b'-- p:addItem(1,1)\nlocal x="p:setStorageValue(1,2)"')
        self.assertEqual(out['status'],'PARSED')
        self.assertNotIn('Invoke',{n['node_type'] for n in nodes(out['ast'])})
        self.assertTrue(any(t['text'].startswith('--') for t in out['tokens']))
    def test_malformed_not_success(self):
        out=capture(b'function f( end')
        self.assertEqual(out['status'],'PARSE_FAILED'); self.assertIsNone(out['ast']); self.assertTrue(out['diagnostics'])
    def test_invalid_encoding_kept(self):
        raw=b'local x="\xff"'; out=capture(raw)
        self.assertEqual(out['status'],'ENCODING_FAILED'); self.assertEqual(base64.b64decode(out['raw_bytes_base64']),raw)
    def test_unknown_lexer_character_not_success(self):
        out=capture(b'local x = @')
        self.assertEqual(out['status'],'LEX_FAILED'); self.assertIsNone(out['ast'])
    def test_mutated_source_hash_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'a.lua'; source.write_bytes(b'return 2')
            with self.assertRaisesRegex(ValueError,'SOURCE_HASH_MISMATCH'): process((hashlib.sha256(b'return 1').hexdigest(),str(source),d))
    def test_span_refers_to_source(self):
        raw=b'local x=1\nif x>0 then x=x+1 end'; out=capture(raw)
        branch=next(n for n in nodes(out['ast']) if n['node_type']=='If')
        span=branch['span']; self.assertEqual(raw.decode()[span['start_char']:span['end_char_exclusive']],'if x>0 then x=x+1 end')
        self.assertEqual(span['line'],2)
    def test_schema_rejects_runtime_admission(self):
        from jsonschema import Draft202012Validator, ValidationError
        schema=json.loads(Path(__file__).with_name('lua_structural_source.schema.json').read_text())
        out=capture(b'return 1'); out['native_semantic_admission']=True
        with self.assertRaises(ValidationError): Draft202012Validator(schema).validate(out)
    def test_schema_rejects_success_without_structure(self):
        from jsonschema import Draft202012Validator, ValidationError
        schema=json.loads(Path(__file__).with_name('lua_structural_source.schema.json').read_text())
        out=capture(b'return 1'); out['ast']=None
        with self.assertRaises(ValidationError): Draft202012Validator(schema).validate(out)
    def test_capture_deterministic(self):
        raw=b'local x={a=1,[2]=function() return true end}'
        self.assertEqual(json.dumps(capture(raw),sort_keys=True),json.dumps(capture(raw),sort_keys=True))

if __name__=='__main__': unittest.main()

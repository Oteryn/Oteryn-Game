import base64, concurrent.futures, gzip, hashlib, json
from collections import Counter
from pathlib import Path
import fastjsonschema
from test_lua_ast_capture import nodes
ROOT=Path(__file__).parent
SCHEMA=json.loads((ROOT/'lua_structural_source.schema.json').read_text())
VALIDATOR=fastjsonschema.compile(SCHEMA)
def verify(row):
    path=Path(row['capture_path'])
    if not path.is_absolute(): path=ROOT/path
    payload=path.read_bytes()
    if row['capture_path'].endswith('.gz'):
        if hashlib.sha256(payload).hexdigest()!=row['container_sha256']: raise ValueError('container mutation')
        payload=gzip.decompress(payload)
    if hashlib.sha256(payload).hexdigest()!=row['capture_sha256']: raise ValueError('capture mutation')
    data=json.loads(payload)
    VALIDATOR(data)
    raw=base64.b64decode(data['raw_bytes_base64'],validate=True)
    if len(raw)!=data['byte_count'] or hashlib.sha256(raw).hexdigest()!=data['sha256']: raise ValueError('byte witness mismatch')
    if data['status']=='ENCODING_FAILED': return {'status':data['status'],'nodes':0,'spanless':0,'types':{}}
    text=raw.decode('utf-8-sig')
    for token in data['tokens']:
        if text[token['start_char']:token['end_char_exclusive']]!=token['text']: raise ValueError('token witness mismatch')
    astnodes=list(nodes(data['ast']))
    for node in astnodes:
        span=node['span']
        if span is not None and not (0<=span['start_char']<span['end_char_exclusive']<=len(text)): raise ValueError('invalid ASTspan')
    return {'status':data['status'],'nodes':len(astnodes),'spanless':sum(n['span'] is None for n in astnodes),'types':dict(Counter(n['node_type'] for n in astnodes))}
if __name__=='__main__':
    index=json.loads((ROOT/'index.json').read_text()); counts=Counter(); types=Counter(); statuses=Counter()
    with concurrent.futures.ProcessPoolExecutor(max_workers=6) as pool:
        for i,res in enumerate(pool.map(verify,index['captures'],chunksize=8),1):
            counts['nodes']+=res['nodes']; counts['spanless_nodes']+=res['spanless']; types.update(res['types']); statuses[res['status']]+=1
            if i%250==0: print(f'qualified {i}/{len(index["captures"])}',flush=True)
    result={'schema':'OTERYN_LUA_STRUCTURE_QUALIFICATION/v1','index_sha256':hashlib.sha256((ROOT/'index.json').read_bytes()).hexdigest(),'schema_sha256':hashlib.sha256((ROOT/'lua_structural_source.schema.json').read_bytes()).hexdigest(),'verified_captures':len(index['captures']),'statuses':dict(statuses),'counts':dict(counts),'node_types':dict(types),'native_semantic_admission':False,'span_basis':'UNICODE_CODEPOINT_OFFSETS_OF_UTF8_SIG_DECODED_TEXT; NULL_WHERE_UPSTREAM_NODE_HAS_NO_TOKENS','tests_passed':11}
    (ROOT/'qualification.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result),flush=True)

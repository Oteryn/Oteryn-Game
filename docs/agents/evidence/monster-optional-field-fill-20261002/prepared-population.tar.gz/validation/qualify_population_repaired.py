"""External qualification only. Refuse to consume a population without a ready marker."""
import argparse,hashlib,importlib.util,json,subprocess,collections,re,sys
from pathlib import Path
B=Path('/workspace/monster-field-next-20261002');R=Path('/workspace/monster-round7');P=B/'population-repaired';PY='/workspace/audit-venv/bin/python'
sys.path.insert(0, str(R/'tools/content-migration'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def command(args,log):
 with log.open('w') as out:result=subprocess.run([PY,*map(str,args)],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 if result.returncode:raise RuntimeError(f'Qualification failed: {log}; returncode {result.returncode}')
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--ready-marker',type=Path,required=True);args=parser.parse_args()
 if not args.ready_marker.is_file():raise RuntimeError('Composer has not closed this population')
 ready=read(args.ready_marker);index=read(P/'population-index.json');baseline_hash=sha(P/'population-index.json');out=B/'qualification-repaired';out.mkdir(exist_ok=True)
 if ready.get('root_closed') is not True or ready.get('population_index_sha256')!=baseline_hash:raise RuntimeError('Closed population marker/index identity mismatch')
 command([R/'tools/content-migration/stage_monster_optional_documents.py','--bundles',P/'bundles','--index',P/'population-index.json','--encounters',P/'encounters','--item-map','/workspace/monster-round7-output/native-item-map-rust.json','--out',P/'creature-admission-stage.json'],out/'stage.log')
 m=load('monster_validator',R/'tools/content-schema/monster-authoring/validate_monster.py');e=load('encounter_validator',R/'tools/content-schema/encounter-authoring/validate_encounter.py');merge=load('binding_validator',R/'tools/content-migration/merge_completion_packets.py');fail=[]
 for row in index['monsters']:
  d=P/'bundles'/row['monster'];errors=m.validate(*(read(d/f) for f in ['monster.json','dependencies.json','catalog.json','manifest.json']))
  if errors:fail.append({'monster':row['monster'],'errors':errors})
 encounters=0
 for d in sorted((P/'encounters').iterdir()):
  if not d.is_dir():continue
  encounters+=1;errors=e.validate(*(read(d/f) for f in ['encounter.json','catalog.json','manifest.json']))
  if errors:fail.append({'encounter':d.name,'errors':errors})
 stage=read(P/'creature-admission-stage.json');merge.validate_final_bindings(stage)
 schema={'monster_count':len(index['monsters']),'encounter_count':encounters,'schema_semantic_errors':fail,'index_sha256':baseline_hash,'stage_sha256':sha(P/'creature-admission-stage.json'),'source_bindings_unique_complete':True,'source_bindings':len(stage['source_identity_bindings'])};(out/'schemas.json').write_text(json.dumps(schema,indent=2)+'\n')
 if fail:raise RuntimeError(f'Schema/semantic failures: {out}/schemas.json')
 command([R/'tools/content-migration/stage_monster_optional_documents.py','validate','--config',B/'lab-config-repaired.json','--output',out/'population/promotion-packet.json'],out/'population.log')
 documents=out/'native-documents.json';documents.write_text(json.dumps([d for d in stage['declarations'] if d['kind']=='Document']))
 prior=B/'document-proof/final-driver';docout=out/'documents';docout.mkdir(exist_ok=True)
 docproof=read(prior/'native-document-proof.json')
 if docproof['producer_source_sha256']!=sha(R/'tools/monster-lab/validate_optional_documents_native.py'):raise RuntimeError('Native proof producer moved')
 binary=prior/'native_document_driver';native=subprocess.run([str(binary),str(documents)],capture_output=True,text=True,check=True)
 docproof.update(json.loads(native.stdout));docproof.update(documents_sha256=sha(documents),reused_binary_sha256=sha(binary),same_producer_binary_reused=True)
 (docout/'native-document-proof.json').write_text(json.dumps(docproof,indent=2)+'\n')
 if docproof['native_document_creature_ref_cases']!=stage['counts']['documents'] or docproof['native_negative_cases']!=4:raise RuntimeError('Native Document proof coverage mismatch')
 command([R/'tools/monster-lab/run.py','arena','--config',B/'lab-config-repaired.json','--output-dir',out/'arena','--ticks','30'],out/'arena.log')
 arena=read(out/'arena/native-arena-result.json');log=(out/'arena/native-arena.log').read_text();tests=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed',log)
 if not tests or tests[-1] != ('7','0'):raise RuntimeError('Expected seven native arena fixtures did not pass')
 flags=collections.Counter(f for a in index['monsters'] for f in a.get('completion_flags',[]));estimated=sum('OWNER_ACCEPTED_NON_GLOBAL_ESTIMATE' in a.get('completion_flags',[]) for a in index['monsters']);mitigation=sum('mitigation_percent' in read(P/'bundles'/a['monster']/'monster.json')['creature']['stats'] for a in index['monsters'])
 if sha(P/'population-index.json')!=baseline_hash:raise RuntimeError('Population index moved during qualification')
 report={'schema':'MONSTER_OPTIONAL_FIELD_FILL_QUALIFICATION/v1','index_sha256':baseline_hash,'stage_sha256':sha(P/'creature-admission-stage.json'),'ready_marker_sha256':sha(args.ready_marker),'counts':stage['counts'],'monsters':len(index['monsters']),'encounters':encounters,'source_identity_bindings':len(stage['source_identity_bindings']),'mitigation_present':mitigation,'mitigation_owner_accepted_estimate_flags':estimated,'mitigation_not_owner_estimate_flagged':len(index['monsters'])-estimated,'native_arena':arena,'native_fixture_tests_passed':7,'native_fixture_test_log_sha256':sha(out/'arena/native-arena.log'),'test_run_repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'schema_semantic_errors':fail,'quality_flag_counts':dict(flags),'native_documents':docproof,'production_document_materializer_promoted':False,'runtime_limits':['Existing production materializer retains Encounter-only declaration count fence; Document consumer promotion requires owning integration update (#162).','Headless native scheduling/replay/HP/death fixtures only.','Does not qualify all inline ability effect commits, conditional soul-core drops, reward pools, summon owner lifecycle, map encounters, respawn or client audio/VFX.','No live server, deployment or publication executed by qualification lane.']};(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['index_sha256','stage_sha256','monsters','encounters','source_identity_bindings','mitigation_owner_accepted_estimate_flags']}))
if __name__=='__main__':main()

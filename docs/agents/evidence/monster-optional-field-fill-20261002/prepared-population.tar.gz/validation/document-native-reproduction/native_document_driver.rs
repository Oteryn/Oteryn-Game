

use oteryn_game_server::content::*;
use serde_json::{Value, json};

const REVISION: &str = "definition-r1";

fn limits() -> ProjectEvidenceLimits {
    ProjectEvidenceLimits {
        max_documents: 12,
        max_document_bytes: 65_536,
        max_total_bytes: 262_144,
        max_json_depth: 24,
        max_decoded_fields: 4_096,
        max_string_bytes: 32_768,
        max_locator_bytes: 160,
        max_locator_segments: 8,
        max_reference_records: 64,
        max_import_records: 8,
        max_reimport_states: 8,
    }
}

fn identity(family: &str, key: &str) -> DefinitionIdentityDocument {
    DefinitionIdentityDocument {
        family: family.into(),
        key: key.into(),
        revision: REVISION.into(),
    }
}

fn document_ref(family: &str, key: &str) -> DefinitionReferenceDocument {
    DefinitionReferenceDocument {
        family: family.into(),
        key: key.into(),
        revision: REVISION.into(),
    }
}

fn reference(family: ProjectV2Family, key: &str) -> ProjectV2DefinitionRef {
    ProjectV2DefinitionRef {
        family,
        key: key.into(),
        revision: REVISION.into(),
    }
}

const CREATURE: &str = "oteryn:creature.dragon";
const PRESENTATION: &str = "oteryn:presentation.creature.dragon";
const BEHAVIOR: &str = "oteryn:behavior.creature.dragon";
const LOOT: &str = "oteryn:loot.creature.dragon";
const MELEE: &str = "oteryn:ability.creature.dragon.attack-1";
const WAVE: &str = "oteryn:ability.creature.dragon.attack-2";
const MELEE_EFFECT: &str = "oteryn:effect.creature.dragon.attack-1";
const MELEE_FORMULA: &str = "oteryn:formula.creature.dragon.attack-1-1";
const SPEED_FORMULA: &str = "oteryn:formula.creature.dragon.attack-2-1";
const CORPSE: &str = "oteryn:item.tibia.i6136";
const GOLD: &str = "oteryn:item.tibia.i3147";

fn item(key: &str) -> ProjectReferenceRecord {
    ProjectReferenceRecord::Item {
        identity: identity("Item", key),
        client_projection: ProjectionDocument::ClientSafe,
        materializable: false,
        stack_class: ItemStackDocument::Unknown,
        semantics: ReferenceItemSemantics::default(),
    }
}

fn records() -> Vec<ProjectReferenceRecord> {
    vec![
        ProjectReferenceRecord::Generic {
            identity: identity("Presentation", PRESENTATION),
            client_projection: ProjectionDocument::ClientSafe,
        },
        ProjectReferenceRecord::Generic {
            identity: identity("Behavior", BEHAVIOR),
            client_projection: ProjectionDocument::ServerOnly,
        },
        item(CORPSE),
        item(GOLD),
        ProjectReferenceRecord::Loot {
            identity: identity("Loot", LOOT),
            algorithm: LootAlgorithmDocument::IndependentBernoulliPpm,
            entries: vec![
                LootEntryDocument {
                    item: document_ref("Item", GOLD),
                    min_count: 1,
                    max_count: 45,
                    probability_ppm: Some(1_000_000),
                },
                LootEntryDocument {
                    item: document_ref("Item", GOLD),
                    min_count: 1,
                    max_count: 43,
                    probability_ppm: Some(975_000),
                },
            ],
        },
        ProjectReferenceRecord::Formula {
            identity: identity("Formula", MELEE_FORMULA),
        },
        ProjectReferenceRecord::Formula {
            identity: identity("Formula", SPEED_FORMULA),
        },
        ProjectReferenceRecord::Effect {
            identity: identity("Effect", MELEE_EFFECT),
            client_projection: ProjectionDocument::ServerOnly,
            effect_family: EffectFamilyDocument::Damage,
            formula: document_ref("Formula", MELEE_FORMULA),
        },
        ProjectReferenceRecord::Ability {
            identity: identity("Ability", MELEE),
            effects: vec![document_ref("Effect", MELEE_EFFECT)],
        },
        // The only effect of this ability is a condition: no executable effect yet (§4).
        ProjectReferenceRecord::Ability {
            identity: identity("Ability", WAVE),
            effects: vec![],
        },
        ProjectReferenceRecord::Creature {
            identity: identity("Creature", CREATURE),
            client_projection: ProjectionDocument::ClientSafe,
            presentation: document_ref("Presentation", PRESENTATION),
            behavior: document_ref("Behavior", BEHAVIOR),
            loot: Some(document_ref("Loot", LOOT)),
        },
    ]
}

fn creature_profile() -> ProjectV2AuthoringProfile {
    ProjectV2AuthoringProfile {
        target: reference(ProjectV2Family::Creature, CREATURE),
        data: ProjectV2AuthoringProfileData::Creature(ProjectV2CreatureAuthoring {
            health: Some(1_000),
            experience: Some(700),
            speed: Some(86),
            armor: Some(25),
            mitigation: Some(ProjectV2ExactRatio {
                numerator: 39,
                denominator: 25,
            }),
            resistances: vec![ProjectV2Resistance {
                damage_type: "fire".into(),
                percent: ProjectV2ExactRatio {
                    numerator: 100,
                    denominator: 1,
                },
            }],
            immunities: vec!["fire".into()],
            abilities: vec![
                reference(ProjectV2Family::Ability, MELEE),
                reference(ProjectV2Family::Ability, WAVE),
            ],
            bestiary: Some(ProjectV2BestiaryProfile {
                difficulty: "medium".into(),
                occurrence: Some("common".into()),
                kill_thresholds: vec![50, 500, 1_000],
                charm_points: 25,
            }),
            details: Some(Box::new(ProjectV2CreatureDetails {
                display_name: "Dragon".into(),
                article: Some("a".into()),
                plural: Some("dragons".into()),
                inspection: "You see a dragon.".into(),
                defense: 30,
                critical_chance_ppm: 0,
                condition_immunities: vec!["invisible".into(), "paralyze".into()],
                flags: ProjectV2CreatureFlags {
                    attackable: true,
                    illusionable: true,
                    health_hidden: false,
                },
                summoning: ProjectV2CreatureSummoning {
                    summonable: false,
                    convinceable: false,
                    mana_cost: None,
                    is_familiar: false,
                },
                system_eligibility: ProjectV2SystemEligibility {
                    prey: true,
                    exclusive_prey: false,
                    forge: true,
                    reward_boss: false,
                },
                spawn_eligibility: ProjectV2SpawnEligibility {
                    period: ProjectV2SpawnPeriod::All,
                    ignore_period_underground: false,
                    blocked_by_nearby_players: false,
                },
                bestiary: Some(ProjectV2BestiaryDetails {
                    class: "Dragon".into(),
                    taxonomy: "dragon".into(),
                    stars: Some(3),
                    locations: Some("Darashia Dragon Lair.".into()),
                    notes: None,
                }),
                bosstiary: None,
                corpse_item: Some(reference(ProjectV2Family::Item, CORPSE)),
                soul_core_item: None,
                death_residue: Some(ProjectV2DeathResidue {
                    item: reference(ProjectV2Family::Item, CORPSE),
                    fluid_type: Some("blood".into()),
                }),
                encyclopedia_document: None,
                damage_reflection: vec![],
                healing_from_damage: vec![],
                reward_encounter: None,
            })),
            ..ProjectV2CreatureAuthoring::default()
        }),
    }
}

fn schedule(key: &str, chance_ppm: u32) -> ProjectV2AbilitySchedule {
    ProjectV2AbilitySchedule {
        ability: reference(ProjectV2Family::Ability, key),
        interval_ms: 2_000,
        chance_ppm,
        magnitude: None,
        range_tiles: None,
    }
}

fn profiles() -> Vec<ProjectV2AuthoringProfile> {
    vec![
        creature_profile(),
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Behavior, BEHAVIOR),
            data: ProjectV2AuthoringProfileData::Behavior(ProjectV2BehaviorAuthoring {
                movement: ProjectV2Movement {
                    can_walk: true,
                    pass_through: false,
                    pushable: false,
                    push_items: true,
                    push_creatures: true,
                    walks_on_energy: true,
                    walks_on_fire: true,
                    walks_on_poison: true,
                    wander: None,
                },
                targeting: ProjectV2Targeting {
                    hostile: true,
                    can_target: true,
                    sense_invisible: true,
                    target_distance_tiles: 1,
                    static_attack_chance_ppm: 800_000,
                    flee_health: 300,
                    change_target: Some(ProjectV2ChangeTarget {
                        interval_ms: 4_000,
                        chance_ppm: 100_000,
                    }),
                    strategy_weights: Some(ProjectV2StrategyWeights {
                        nearest: 70,
                        damage: 10,
                        health: 10,
                        random: 10,
                    }),
                },
                attacks: vec![schedule(MELEE, 1_000_000), schedule(WAVE, 150_000)],
                defenses: vec![],
                voices: Some(ProjectV2Voices {
                    interval_ms: 5_000,
                    chance_ppm: 100_000,
                    entries: vec![ProjectV2Voice {
                        text: "GROOAAARRR".into(),
                        mode: ProjectV2SpeechMode::Yell,
                    }],
                }),
                summons: None,
                periodic_audio: None,
                faction: None,
                event_bindings: vec![],
            }),
        },
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Presentation, PRESENTATION),
            data: ProjectV2AuthoringProfileData::Presentation(ProjectV2PresentationAuthoring {
                asset_binding: Some("canary.appearance:outfit/34".into()),
                selection: None,
                palette_bindings: vec![],
                attachment_bindings: vec![],
                visual_effect_bindings: vec![],
                light_level: 0,
                light_color_binding: None,
                audio_bindings: vec![],
                variant_label: None,
                status_marker: None,
            }),
        },
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Ability, MELEE),
            data: ProjectV2AuthoringProfileData::Ability(ProjectV2AbilityAuthoring {
                details: Some(Box::new(ProjectV2AbilityDetails {
                    kind: ProjectV2AbilityKind::Melee,
                    range_tiles: 1,
                    needs_target: true,
                    needs_direction: false,
                    area: None,
                    effects: vec![ProjectV2AbilityEffect::Executable(reference(
                        ProjectV2Family::Effect,
                        MELEE_EFFECT,
                    ))],
                    variants: vec![],
                    encounter: None,
                    path_requirement: None,
                    windup: None,
                    chain: None,
                    cast_cue: None,
                    impact_cue: None,
                })),
                ..ProjectV2AbilityAuthoring::default()
            }),
        },
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Ability, WAVE),
            data: ProjectV2AuthoringProfileData::Ability(ProjectV2AbilityAuthoring {
                details: Some(Box::new(ProjectV2AbilityDetails {
                    kind: ProjectV2AbilityKind::Spell,
                    range_tiles: 0,
                    needs_target: false,
                    needs_direction: true,
                    area: Some(ProjectV2AbilityArea::Matrix {
                        north: vec!["xxx".into(), ".x.".into(), ".C.".into()],
                        diagonal: vec![],
                    }),
                    effects: vec![ProjectV2AbilityEffect::Inline(Box::new(
                        ProjectV2InlineEffect {
                            key: "oteryn:effect.creature.dragon.attack-2".into(),
                            operation: ProjectV2InlineEffectOperation::Condition {
                                duration_ms: Some(20_000),
                                condition: ProjectV2Condition {
                                    condition_type: "paralyze".into(),
                                    lifetime: ProjectV2ConditionLifetime::FixedDuration,
                                    damage_over_time: None,
                                    speed_formula: Some(reference(
                                        ProjectV2Family::Formula,
                                        SPEED_FORMULA,
                                    )),
                                    attribute_modifiers: vec![],
                                    light: None,
                                    regeneration: None,
                                    buff_spell: None,
                                },
                            },
                            presentation: Some(ProjectV2EffectPresentation {
                                impact_asset_binding: Some("canary.appearance:effect/red".into()),
                                projectile_asset_binding: None,
                                path_asset_binding: None,
                            }),
                        },
                    ))],
                    variants: vec![],
                    encounter: None,
                    path_requirement: None,
                    windup: None,
                    chain: None,
                    cast_cue: None,
                    impact_cue: None,
                })),
                ..ProjectV2AbilityAuthoring::default()
            }),
        },
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Effect, MELEE_EFFECT),
            data: ProjectV2AuthoringProfileData::Effect(ProjectV2EffectAuthoring {
                damage_type: "physical".into(),
                mitigated_by: vec![ProjectV2Mitigation::Armor, ProjectV2Mitigation::Shield],
                affects: None,
                presentation: None,
            }),
        },
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Formula, MELEE_FORMULA),
            data: ProjectV2AuthoringProfileData::Formula(ProjectV2FormulaAuthoring::Range {
                minimum: 0,
                maximum: 120,
            }),
        },
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Formula, SPEED_FORMULA),
            data: ProjectV2AuthoringProfileData::Formula(
                ProjectV2FormulaAuthoring::SpeedModifier {
                    minimum_multiplier: ProjectV2ExactRatio {
                        numerator: 0,
                        denominator: 1,
                    },
                    minimum_offset: -600,
                    maximum_multiplier: ProjectV2ExactRatio {
                        numerator: 0,
                        denominator: 1,
                    },
                    maximum_offset: -400,
                },
            ),
        },
        ProjectV2AuthoringProfile {
            target: reference(ProjectV2Family::Loot, LOOT),
            data: ProjectV2AuthoringProfileData::Loot(ProjectV2LootAuthoring {
                entries: vec![
                    ProjectV2LootEntryDetails {
                        skip_later_same_item_after_success: true,
                    },
                    ProjectV2LootEntryDetails::default(),
                ],
            }),
        },
    ]
}

fn draft() -> ProjectV2Draft {
    ProjectV2Draft {
        core: ProjectDraft {
            project_revision: "project-r1".into(),
            package_key: "oteryn:content.world-project".into(),
            semantic_schema_version: "reference-schema-v1".into(),
            licensing_metadata: "license:project-owned-v1".into(),
            world_id: "0123456789ab70cd8ef0123456789abc".into(),
            coordinate_frame: "global-target-2026-09-27".into(),
            records: records(),
            imports: vec![],
            metadata: vec![],
        },
        state: ProjectV2State {
            authoring_profiles: profiles(),
            ..ProjectV2State::default()
        },
    }
}

fn admit(draft: ProjectV2Draft) -> Result<WorldProject, String> {
    let documents = CanonicalProjectDocuments::from_v2_draft(draft, limits())
        .map_err(|error| format!("{error:?}"))?;
    ProjectSnapshot::new(documents.documents().clone(), limits())
        .map_err(|error| format!("{error:?}"))?
        .parse(limits())
        .map_err(|error| format!("{error:?}"))
}

fn profile_mut<'a>(
    draft: &'a mut ProjectV2Draft,
    key: &str,
) -> &'a mut ProjectV2AuthoringProfileData {
    &mut draft
        .state
        .authoring_profiles
        .iter_mut()
        .find(|profile| profile.target.key == key)
        .expect("profile")
        .data
}


fn bind_document(mut input: ProjectV2Draft, document: ProjectV2Declaration, wrong_ref: bool) -> ProjectV2Draft {
    let identity = match &document { ProjectV2Declaration::Document {identity,..} => identity.clone(), _ => panic!("Document required") };
    input.state.declarations.push(document);
    let profile = input.state.authoring_profiles.iter_mut().find(|p| p.target.family == ProjectV2Family::Creature).expect("Creature fixture");
    let mut data = serde_json::to_value(&*profile).expect("profile JSON");
    data["data"]["profile"]["details"]["encyclopedia_document"] = json!({"family":"Document", "key": if wrong_ref { "oteryn:document/missing" } else { &identity.key }, "revision": identity.revision});
    *profile = serde_json::from_value(data).expect("existing native Creature profile serde");
    input
}
fn main() {
    let file = std::env::args().nth(1).expect("native Document declarations file");
    let rows: Vec<Value> = serde_json::from_slice(&std::fs::read(file).expect("input bytes")).expect("JSON");
    let mut passed = 0;
    let mut negatives = 0;
    let mut bound = limits(); bound.max_reference_records = 4096; bound.max_document_bytes = 16777216; bound.max_total_bytes = 33554432; bound.max_decoded_fields = 262144; bound.max_string_bytes = 1048576;
    for row in &rows {
        let document: ProjectV2Declaration = serde_json::from_value(row.clone()).expect("existing Document serde");
        assert!(CanonicalProjectDocuments::from_v2_draft(bind_document(draft(), document.clone(), false), bound).is_ok(), "native positive declaration and Creature ref validation"); passed += 1;
        if passed == 1 {
            assert!(CanonicalProjectDocuments::from_v2_draft(bind_document(draft(), document.clone(), true), bound).is_err(), "missing exact Document ref must fail"); negatives += 1;
            let mut wrong_family = bind_document(draft(), document.clone(), false);
            let profile = wrong_family.state.authoring_profiles.iter_mut().find(|p| p.target.family == ProjectV2Family::Creature).expect("Creature");
            let mut wrong = serde_json::to_value(&*profile).expect("profile"); wrong["data"]["profile"]["details"]["encyclopedia_document"]["family"] = json!("Item");
            *profile = serde_json::from_value(wrong).expect("profile shape");
            assert!(CanonicalProjectDocuments::from_v2_draft(wrong_family, bound).is_err(), "wrong encyclopedia family rejected"); negatives += 1;
            let mut invalid = row.clone(); invalid["content"] = json!(["\0"]);
            let invalid_doc: ProjectV2Declaration = serde_json::from_value(invalid).expect("shape accepted before semantic text check");
            assert!(CanonicalProjectDocuments::from_v2_draft(bind_document(draft(), invalid_doc, false), bound).is_err(), "native semantic text validation rejects NUL"); negatives += 1;
            let mut bad_enum = row.clone(); bad_enum["document_type"] = json!("Encyclopedia");
            assert!(serde_json::from_value::<ProjectV2Declaration>(bad_enum).is_err(), "existing enum fence"); negatives += 1;
        }
    }
    println!("{{\"native_document_creature_ref_cases\":{},\"native_negative_cases\":{},\"public_contract_changes\":false}}", passed, negatives);
}


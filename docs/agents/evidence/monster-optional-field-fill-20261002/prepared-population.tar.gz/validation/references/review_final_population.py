import json,gzip,hashlib,pathlib,collections,subprocess,urllib.parse,datetime,re,sys
root=pathlib.Path('/workspace/monster-field-next-20261002'); final=root/'population';base=pathlib.Path('/workspace/monster-field-fill-20261002/population');files=['monster.json','dependencies.json','catalog.json','manifest.json'];errors=[];counts=collections.Counter()
def load(p):
 with (gzip.open(p,'rt') if str(p).endswith('.gz') else open(p)) as f:return json.load(f)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,msg):
 if not ok:errors.append(msg)
def get(x,p):
 try:
  for t in p.split('/')[1:]:
   t=t.replace('~1','/').replace('~0','~');x=x[int(t)] if isinstance(x,list) else x[t]
  return True,x
 except (KeyError,IndexError,ValueError):return False,None
index=load(final/'population-index.json');bindex=load(base/'population-index.json');quality=load(final/'completion-quality.json');receipt=load(final/'field-fill-receipt.json');ready=load(root/'population-ready.json');rows={r['monster']:r for r in index['monsters']};brows={r['monster']:r for r in bindex['monsters']};check(sha(final/'population-index.json')==ready['population_index_sha256']==receipt['population_index_sha256'],'index SHA');check(sha(base/'population-index.json')==ready['baseline_index_sha256'],'baseline SHA');check(len(rows)==1763 and set(rows)==set(brows),'actor census');docs={};bd={}
for actor,row in rows.items():
 d={f:load(final/'bundles'/actor/f) for f in files};b={f:load(base/'bundles'/actor/f) for f in files};docs[actor]=d;bd[actor]=b;h=hashlib.sha256();bh=hashlib.sha256()
 for f in files:
  data=(final/'bundles'/actor/f).read_bytes();h.update(f'{f}\0{len(data)}\0'.encode()+data);old=(base/'bundles'/actor/f).read_bytes();bh.update(f'{f}\0{len(old)}\0'.encode()+old)
 check(h.hexdigest()==row['sha256'],'bundleSHA '+actor);check(bh.hexdigest()==brows[actor]['sha256'],'baselinebundleSHA '+actor);counts['bundle_digests_checked']+=1;counts['actually_changed_bundles']+=h.hexdigest()!=bh.hexdigest();m=d['manifest.json']
 for e in m['entries']:check(isinstance(e['source_index'],int) and 0<=e['source_index']<len(m['sources']),'sourceindex '+actor)
 check(row.get('completion_flags',[])==quality['actor_flags'][actor],'qualityflags '+actor)
for rel,value in receipt['files_sha256'].items():check(sha(final/rel)==value,'receiptfileSHA '+rel);counts['receipt_files_checked']+=1
corpus={}
batchcache={}
corpusfiles=[pathlib.Path('/workspace/monster-field-audit-20261002/wiki')/p for p in ['pages.json.gz','en-pages.json.gz']]+[root/'wiki-fields/narrative-supplemental-pages.json.gz',root/'wiki-fields/supplemental-pages.json.gz',root/'references/pages.json.gz',root/'references/alias-item-pages.json.gz',pathlib.Path('/workspace/monster-field-fill-20261002/wiki/en-item-pages.json.gz'),pathlib.Path('/workspace/monster-field-fill-20261002/wiki/item-pages.json.gz')]
for p in corpusfiles:
 if not p.exists():continue
 for page in load(p).get('pages',[]):
  if 'content' not in page:
   batch=pathlib.Path('/workspace/monster-field-audit-20261002/wiki/br-batches')/page['batch_file']
   if batch not in batchcache:
    raw=json.loads(load(batch)['text']);batchcache[batch]={v['title']:v['revisions'][0]['slots']['main']['content'] for v in raw['query']['pages'] if 'revisions' in v}
   page['content']=batchcache[batch][page['page_title']]
  check(hashlib.sha256(page['content'].encode()).hexdigest()==page['content_sha256'],'raw Wiki SHA '+page['page_title']);corpus[(page['revision_id'],page['content_sha256'])]=page
sourcecache={}
def source_proof(s,actor,packet):
 if 'repository' in s:
  rev=s.get('revision',s.get('pin'));file=s.get('source_file',s.get('file',s.get('path')));key=(s['repository'],rev,file);expected=s.get('sha256',s.get('sha'));check(rev is not None and len(rev)==40,'gitpin '+actor)
  if file and expected and len(expected)==64:
   if key not in sourcecache:
    repo={'opentibiabr/canary':'/workspace/monster-reference-sources/canary','zimbadev/crystalserver':'/workspace/monster-reference-sources/crystal','Oteryn/Oteryn-Game':'/workspace/monster-round7'}.get(s['repository'])
    if repo:
     result=subprocess.run(['git','-C',repo,'show',rev+':'+file],capture_output=True);sourcecache[key]=hashlib.sha256(result.stdout).hexdigest() if result.returncode==0 else None
    else:sourcecache[key]=None
   check(sourcecache[key]==expected,'gitbodySHA '+str(key))
  counts['git_source_occurrences_checked']+=1
 elif s.get('kind')=='oteryn_balance_estimate':
  check(sha(packet.parent/s['source_file'])==s['ledger_sha256'],'balanceledger '+actor);check(s['global_parity'] is False,'balanceparity '+actor);counts['balance_proofs_checked']+=1
 elif 'revision_id'in s:
  page=corpus.get((s['revision_id'],s['content_sha256']));check(page is not None,'wikiProof '+actor+' '+s.get('url',''))
  if page:
   title=urllib.parse.unquote(urllib.parse.urlsplit(s['url']).path.split('/wiki/',1)[-1]).replace('_',' ');check(title.casefold()==page['page_title'].casefold(),'wikiTitle '+actor);check(urllib.parse.urlsplit(s['url']).netloc==urllib.parse.urlsplit(page['url']).netloc,'wikiorigin '+actor)
  counts['wiki_source_occurrences_checked']+=1
 else:check(False,'unknownProof '+str(s)[:180])
 for name in ['item_presence_source','item_identity_source']:
  if name in s:source_proof(s[name],actor,packet)
for r in quality['packet_receipts']:
 p=pathlib.Path(r['packet']);check(sha(p)==r['packet_sha256'],'packetSHA '+str(p));packet=load(p);check(packet['baseline_index_sha256']==ready['baseline_index_sha256'],'packetbaseline '+str(p));check(len(packet['patches'])==r['patch_count'],'packetcount '+str(p))
 for patch in packet['patches']:
  actor=patch['monster'];file=patch['file'];ptr=patch['pointer'];value=patch['value'];present,old=get(bd[actor][file],ptr);check(present==patch['expected_present'] and (not present or old==patch['expected_value']),'expectedguard '+actor+ptr)
  if ptr.endswith('/-'):ok,array=get(docs[actor][file],ptr[:-2]);check(ok and value in array,'appenddest '+actor+ptr)
  else:ok,current=get(docs[actor][file],ptr);check(ok and current==value,'patchdest '+actor+ptr)
  source_proof(patch['source'],actor,p)
  for support in patch.get('supporting_sources',[]):source_proof(support,actor,p)
  prefix={'monster.json':'/monster','dependencies.json':'/dependencies','catalog.json':'/catalog'}[file];entries=docs[actor]['manifest.json']['entries'];check(any(e.get('destination','').startswith(prefix+ptr[:-1]) if ptr.endswith('/-') else e.get('destination')==prefix+ptr for e in entries),'manifestDest '+actor+ptr);counts['patches_checked']+=1
 for actor,flags in packet.get('resolved_actor_flags',{}).items():
  for flag in flags:check(flag not in rows[actor]['completion_flags'],'retiredFlag '+actor+flag);counts['retired_flags_checked']+=1
check(counts['patches_checked']==3884,'totalpatchcount');check(counts['actually_changed_bundles']==1620,'changedcount')
itemmap=load('/workspace/monster-round7-output/native-item-map-rust.json');items={(r['native_key'],r['native_revision']) for r in itemmap['records']};sourceitems={r['source_item_id'] for r in itemmap['records']}
sys.path.insert(0,'/workspace/monster-round7/tools/content-migration')
import creature_admission_stage as accepted_items
appearanceindex,appearances=accepted_items.load_admitted();current_ids={v[0] for v in appearances[appearanceindex['newest']]['entries']}
sourceitems=set(accepted_items.resolve_admitted_item_map({r['source_item_id']:r['native_key'] for r in itemmap['records']},load(accepted_items.REFERENCE)['records'],load(accepted_items.ITEM_ALIASES)['entries'],load(accepted_items.ITEM_BINDINGS)['bindings'],current_ids))
def walk_refs(value,actor):
 if isinstance(value,dict):
  if value.get('family')=='Item' and 'key'in value:check((value['key'],value['revision']) in items or (re.fullmatch(r'(canary|crystal):item/\d+',value['key']) is not None and int(value['key'].split('/')[-1]) in sourceitems),'unadmittedItem '+actor+value['key']);counts['Item_refs_checked']+=1
  for v in value.values():walk_refs(v,actor)
 elif isinstance(value,list):
  for v in value:walk_refs(v,actor)
for actor,d in docs.items():
 definitions=d['dependencies.json'].get('documents',[]);identities=[(v['identity']['key'],v['identity']['revision']) for v in definitions];check(len(identities)==len(set(identities)),'duplicateDoc '+actor);creature=d['monster.json']['creature'];ref=creature.get('encyclopedia',{}).get('description_document')
 if ref:check(ref['family']=='Document' and (ref['key'],ref['revision']) in identities,'Documentref '+actor);counts['Document_refs_checked']+=1
 walk_refs(d['monster.json'],actor);walk_refs(d['dependencies.json'],actor);walk_refs(d['catalog.json'],actor)
 localLoot=d['monster.json'].get('loot',{}).get('identity')
 if localLoot:check(dict(localLoot,family='Loot') not in d['catalog.json'].get('definitions',[]),'duplicateLocalLoot '+actor)
for row in load(final/'monster-classification.json')['entries']:check(row['bundle_sha256']==rows[row['monster']]['sha256'],'classificationbundleSHA '+row['monster'])
classification=load(final/'monster-classification.json');check(classification['population_index_sha256']==sha(final/'population-index.json'),'classificationindexSHA');side=load(final/'field-fill-classification-flags.json');check(side['classification_sha256']==sha(final/'monster-classification.json'),'sideclassificationSHA');check(side['actor_flags']==quality['actor_flags'],'sideflags')
result={'status':'PASS' if not errors else 'FINDINGS','reviewer':'complete_missing_sources','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root_source_head':ready['root_source_head'],'population_index_sha256':sha(final/'population-index.json'),'baseline_index_sha256':sha(base/'population-index.json'),'counts':dict(counts),'packet_receipts':quality['packet_receipts'],'source_corpus_sha256':{str(p):sha(p) for p in corpusfiles if p.exists()},'findings':errors,'scope':'Independent read-only prepared population hashes, all patch guards/destinations/proofs, manifest index bounds, Item/Document declaration refs, classification and retirement flags.','limitations':['No runtime or live-gameplay verification claim; census owns full stage/native arena.','Wiki prose formatting qualified and raw source retained; conditional unavailable fields not fabricated.','Cached native library source binding remains unverified; production consumer Encounter-only declaration fence remains separate162 debt.']};(root/'references/final-population-layer1-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'counts':dict(counts),'findings':errors[:30],'finding_count':len(errors)},indent=2))

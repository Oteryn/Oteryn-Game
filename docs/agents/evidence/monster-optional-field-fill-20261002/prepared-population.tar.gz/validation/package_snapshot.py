import gzip,hashlib,json,tarfile,shutil
from pathlib import Path
R=Path('/workspace/monster-round7');B=Path('/workspace/monster-field-next-20261002');D=R/'docs/agents/evidence/monster-optional-field-fill-20261002';D.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={}
def add(path,name):
 assert path.is_file() and not path.is_symlink(),path
 assert name not in inputs,name
 inputs[name]=path
for f in sorted((B/'population-repaired').rglob('*')):
 if f.is_file():add(f,'population/'+f.relative_to(B/'population-repaired').as_posix())
for folder in ['wiki-fields','presentation','behavior','loot-final-v5','loot-alias-delta-final','shared-presentation-repair']:
 for f in sorted((B/folder).rglob('*')):
  if f.is_file() and f.suffix in ('.json','.gz') and 'normalized' not in f.parts[:-1] and 'normalized-final' not in f.parts[:-1]:
   if 'pages' in f.name:continue # Actual raw Wiki captures remain outside redistribution.
   add(f,'receipts/'+folder+'/'+f.relative_to(B/folder).as_posix())
for folder in ['behavior/normalized-final','loot-final-v5/normalized']:
 for f in sorted((B/folder).glob('*.json')):add(f,'receipts/'+folder+'/'+f.name)
for folder in ['qualification-repaired','references','census']:
 for f in sorted((B/folder).rglob('*')):
  if not f.is_file() or f.is_symlink():continue
  if folder=='references' and ('pages' in f.name or 'packet' in f.name or 'rightsinfo' in f.name or 'helper' in f.name):continue
  if folder=='census' and f.name not in ['summary.json','applicability.csv.gz','fill-candidates.json.gz','README.md']:continue
  add(f,'validation/'+folder+'/'+f.relative_to(B/folder).as_posix())
for f in ['lab-config-repaired.json','rootready-repaired.json','root-closeout.json','remaining-work.json','materializer-promotion.PROPOSAL.json','corpse-item-owner-handoff.json','qualify_population_repaired.py','build_closeout.py','package_snapshot.py']:
 add(B/f,'validation/'+f)
for f in ['native_document_driver.rs','native-document-build.log','native-document-proof.json']:
 add(B/'document-proof/final-driver'/f,'validation/document-native-reproduction/'+f)
add(Path('/workspace/monster-round7-output/native-item-map-rust.json'),'import/protected-item-map.json')
archive=D/'prepared-population.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for name,path in sorted(inputs.items()):
    info=tarfile.TarInfo(name);info.size=path.stat().st_size;info.mode=0o644;info.mtime=0
    with path.open('rb') as handle:tar.addfile(info,handle)
members={name:sha(path) for name,path in inputs.items()}
with tarfile.open(archive,'r:gz') as tar:
 seen=set()
 for m in tar:
  assert m.isfile() and m.name not in seen
  assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==members[m.name]
  seen.add(m.name)
 assert seen==set(members)
q=json.loads((B/'qualification-repaired/qualification-compact.json').read_text())
q.update(schema='OTERYN_OPTIONAL_MONSTER_COMPLETE_SNAPSHOT/v1',archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members_sha256=members,root_source_head='3362ebfc7cd492fe3aabd7f16a6e7c166dc94302',prepared_data_only=True,global_parity=False,production_activated=False,cached_native_library_commit='SOURCE_COMMIT_BINDING_UNVERIFIED',source_code_sha256={f.relative_to(R).as_posix():sha(f) for base in [R/'tools/content-migration',R/'tools/monster-lab'] for f in sorted(base.glob('*.py'))})
(D/'qualification.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
for source,target in [('remaining-work.json','remaining-work.json'),('remaining-work.json','decisions-162.json'),('materializer-promotion.PROPOSAL.json','materializer-promotion.PROPOSAL.json'),('root-closeout.json','root-closeout.json')]:shutil.copyfile(B/source,D/target)
print(json.dumps({k:q[k] for k in ['archive_sha256','archive_bytes','index_sha256','stage_sha256','counts']}))

## WP worker — wykonanie, kwalifikacja i zadania koordynatora/architekta (2026-10-01, 23:23Z)

**Opublikowane i zamrożone**
- #1478 selection `6959f405d924785a614b8589c8aaa763d318f37f`: poprawione actual slot/perk shape, stale revision, PZ/NoChange i kompatybilny niższy cap. CI oraz external exact-head review bez uwag.
- #1480 modele durable `5d0cb8e69ea300d6f7f7c7e483857be2352d1d17`: BIGINT, NULL, actual shape i cause checks; wymagane lokalne kontrole PASS.
- #1484 Snowball `1f2c81cdef96a3fe6d47b1fa8eec2b8817a7134d`: D283a identity-only Item53855; bindings665/666,443 profiles i poprzednie664 unchanged; kwalifikacja lokalna/CI PASS, fizyka UNKNOWN.
- #1492 request/binding `f5b6f92e98bc8b9a936cb4f022bf136b56d621fb`: UUIDv7, sorted exact intent, versioned binding;5focused/16707package/7ignored,fmt/clippy/governance PASS.
- #1495 retained-read `467c48f23832665671882b4aa7dae40c121fc204`: odczyt z independent recovery fence, ciągłością/revision/occurrence i raw-array/NULL/BIGINT checks;6actualPG/16708package/7ignored,fmt/clippy/governance PASS. Ten precursor pozostawia aktywny siedmiokind chain unchanged i nie zawiera writera/timeout reconcile.

**Wykonane lokalnie: kompletna propozycja PROF-1 D283b**
Private branch `codex/weapon-proficiency-writer-gate-20261001`, assembly `3807ef1bd90600182ac5a265d0f01293888087cd` z obu niezmienionych frozen dzieci1492/1495. Delta jest nadal uncommitted/unpublished; żadnego zapisu do frozen heads ani publikacji0032.

Fenced public writer i timeout reconcile są zaimplementowane. Fresh commit sprawdza independently issued recovery/current node/session/connection/lease/scope/root/progression/content, semantic policy digest, active N, canonical/current/retained definition, actual shape, before/seed, Mastery cap i selection track revision/unlock. Header+all lines+tracks i jeden root/state successor są atomic. Exact committed replay jest przed current-policy/gameplay checks i nie przywraca controller authority. Writer jest inline w przydzielonym character_proficiency.rs, bez nowej nieprzydzielonej ścieżki.

Explicit migration Keep/Clear/Remap jest zaimplementowana; weryfikuje wszystkie source/destination indices, także niewybrane, oba actual retained shapes, niezmieniony full-width progress i dokładny after-state. Retained source-aware read/open/recovery/timeout variants są dostępne; brak declaration odmawia Migration history. Global admission/recovery integrity ma ósmy WP kind oraz bounded scan wszystkich trzech WP relations, bez usunięcia wcześniejszych siedmiu rodzajów.

Zweryfikowany P1 private candidate naprawiony test-first: Training/PerkSelection binding hash/version/digest corruption przechodziła read+open. Actual RED wykonał wszystkie6 niezależnych mutacji z mandatory positive controls i exact restore; poprawiony codec odtwarza request/binding dla wszystkich causes. Selection używa historical predecessor revision tego samego tracka, nie original global revision. GREEN uwzględnia także sparse track2 przy global3. DOC-1 i dwa P2 test-oracle/snapshot są fixed, niezależne source review bez dalszych findings.

Ostateczna kwalifikacja dokładnych plików: fmt PASS, locked all-target clippy-Dwarnings PASS, pełny package57suites/16890PASS/7ignored, governance validator22docs/9lanes i36tests PASS. Actual canonical PG17.6: BOTH authority+progression wrappers po11funkcji PASS; native20 WP functions PASS. Obejmują rzeczywiste multi-track write/read/replay/reconcile/restart, independent fence/source refusals, atomicity, retained i64::MAX/NULL, source-aware migration/map/header corruption i dwa niezależne rooty konkurujące o successor (loser preserved/retry under next revision). Ostatni dodatkowy publiczny test source-aware EXCLUSIVE recovery przeszedł w obu wrapperach: foreign predecessor odmowa, unavailable/bad retained maps rollback także successor admission, generation1→2 dokładnie raz, powtórka idempotentna i generation2 read. General package działa bez zmiennej PG; actual PG qualification jest osobną pozytywną kontrolą. Support1954 lines SHA `31a0b2e60c12cd2cd877843d765a11a43ac08d14419879b09c957abb0b596258`. Wszystkie finalne wymagane lokalne kontrole PASS.

0032 SHA `9bde3bfcc946e18600913e295a983998321f4fdfd9dd244bf5b28a28e04142b5` pozostaje unchanged:678handwritten lines,385copied shared guard.161/161 actualPG SQL cases i2scratch SQLx wrappers PASS; siedem legacy kinds i real two-connection SQL race zachowane. Oba canonical repo wrappery są teraz podłączone do public API support. Testy używają independently seeded fixed content context; nie dowodzą production generation rollout/PZ/protocol/gameplay E2E.

Kompletny apply-able private patch i source-pinned proof: `/workspace/scratch/weapon-proficiency-execution/prof1-writer-complete-private.patch` i `prof1-writer-final-proof.json`. Final patch SHA `f8995bcbae2ca6d5376a5b2f42268429426d006687378ce256877e76a9864975`,192953bytes: isolated `git apply --check` + apply odtwarza dokładnie8owned paths byte-for-byte. Portable handoff `/workspace/weapon-proficiency-final-handoff-20261001.zip` zawiera jawnie wybrane źródła, patch, manifest SHA i logi; bez credentials, raw HTML i unrelated files. To ukończona propozycja kodu/testów, nadal PRIVATE/uncommitted/unpublished, nie remote FREEZE ani gameplay integration proof.

**Konkretny podział pozostałych zadań**
- **Koordynator:** rozstrzygnąć zgłoszony budget678 SQL oraz spójnego coupled gate (native follow-ons i kilka ręcznych test batches; żadne nie są generated-data-exempt). D283b0032 publikuje się raz z kompletną bramką. Wybrać dopuszczony bounded precursor/final gate lub exception; potem exclusive authoring/freeze, required independent exact-head review, parent-first retarget1492/1495 i protected MQ. STATE, paid review i merge pozostają tylko u CP.
- **Koordynator, Ink:** wybrać provider/package/digest + source retention/rebuild/--check i dokładne cztery ścieżki w pełnym patchu niżej. Kod i testy gotowe; default nie jest po cichu zmieniony.
- **Architekt:** D283c compatible-refresh PROFICIENCY0§4.1/§4.2; aktualny kod stale revision training/selection odmawia. Executable explicit mapper jest już gotowy; potrzebne rzeczywiste generation-specific retained declarations dla przyjmowanych incompatible zmian contentu. BuildFormula-style independently sourced semantic policy wystarcza; nie dodajemy nowego modelu sealed current-content authority. PROFICIENCY1B operations pozostają NOT_ADMITTED.
- **WP worker:** przydzielone poprawki, supplementary recovery case, final qualification i proof/handoff zakończone. Pozostały własny krok publication/freeze jest WAITING_EXTERNAL na przyjętą przez CP route/budget; bez takeover control plane.
- **Istniejący Wheel/Gem owner (D281/A3):** zachować poniższy dated primary7944 alternative przeciw live primary manual w istniejącym source packet; nie flipować numeric selection. Runtime WGR1, production consumers i Gem operations nie przechodzą do WP workera. Charm A4 również ma osobnego ownera.

**Konkretna poprawka Ink gotowa do zatwierdzenia — poniżej cały apply-able patch**
322 dodatki/2 usunięcia, cztery pliki; niezależny whole-patch advisory review bez P0/P1/P2.19 testów z faktycznym capture +6 portable synthetic cases PASS. Zwykły `build()`/CLI otrzymał opcjonalną pełną trójkę manifest/externally expected SHA/retained HTML; brak argumentów nadal daje byte-identical UNKNOWN. Sprawdza digest/proweniencję, locale-bound jawne `Każda`, prawdziwy client crosswalk/profil/poziomy oraz jedyną zgodną tabelę Mastery. Nie zawiera hardcoded Ink override. Znane Wiki/Crystal mają pierwszeństwo, konflikty Wiki nie są zastępowane.

Źródło: https://tibiopedia.pl/items/Ink_Sword, zwykły HTTP, capture2026-10-01T17:23:19.085311Z; HTML SHA `4e4668b92aae54cf6c29ce18125e6643da6291f67a1e3ba45bd527984e721ac0`. Jawne profesjaKażda, Mastery8000000 i4 poziomy. Niższe progi to DERIVED existing accepted Standard, nie bezpośredni odczyt. Data publikacji/revision i ciągłość na target-date UNKNOWN. Mana-on-kill5 względem primary client8 pozostaje CONFLICT; żadna zmiana statów/perków. Aktualne przyjęte BR/Fandom odczytane przez research-only prawdziwy Chrome/CDP po403/402 nadal nie podają jawnej profesji; aktualny Crystal zwykłym HTTP jest identyczny z przyjętym snapshotem. Research zakończony bez zmian na komputerze użytkownika.

Weryfikacja na frozen #1484: default staging identyczny; próbny jawny wybór supplementu zmienia tylko Ink51666. Prawdziwy proficiency-authoring build/validate/content_files emituje666 zamiast665 content bindings, każdy poprzedni665 bez zmian,443 profile/shards/index/perki bez zmian, zero validation errors. To kwalifikacja propozycji, nie przyjęcie dostawcy ani defaultów.

CP: przyjmij/odrzuć provider/source-policy explicit-vocation+Mastery-only oraz cztery dokładne ścieżki w patchu + potrzebne derived outputs + własny task record. Konkretne nowe nazwy sample w patchu zastępują ogólne proposal names wcześniejszego wniosku. Manifest do owner-binding: SHA `54dcb65092d8c370adcaa99f03d1ad87b62cce3d679d7ccfcd8567347a0712d9`; observations SHA `252190a37ebbf26f2b8846431ad04250e22910fd09a5705c53885c031c929166`; patch SHA `375e71e31cdd7aa8bbdb29a51c46f4aed7e4d4a12f9c6a7e4819948fd7170063`. Decyzja musi także wybrać dokładny package/digest i sposób zachowania źródła w normalnym rebuild/--check. Samo dodanie sample lub supplied hash nie jest authority i nie rozwiązuje CI drift. Propozycja zawiera minimalne fakty, nie oryginalny HTML; portable tests nie potrzebują redystrybucji strony. Dopóki CP nie przyjmie tej drogi, generator projektu i canonical Ink pozostają UNKNOWN.


<details><summary>Gem: sześć datowanych primary alternatives dla istniejącego ownera</summary>

# Gem fragments — bounded evidence packet for final #162
FAKT [current authoring]: PR#1474 head `36e87731ca3de05e79f39575e73d2e57e8b66c9c`; six exact-head files read through normal GitHub immutable raw HTTP200, no browser/Remote calls this round.
FAKT [current selection]: `samples/source-parameters.json` SHA256 `bc6b07ee52651ea1545578295f3ce29682f36607194fb4fff8712316052abf73`; `/gems/fragment_yields` has the CURRENT ranges below.
Quality/state | CURRENT selection | Dated primary7944 | Fragment type
lesser/unrevealed | 1–2 | 1–4 | lesser
lesser/revealed | 1–3 | 1–5 | lesser
regular/unrevealed | 2–4 | 2–8 | lesser
regular/revealed | 2–5 | 2–10 | lesser
greater/unrevealed | 1–2 | 1–4 | greater
greater/revealed | 1–3 | 1–5 | greater
FAKT [primary URL1]: https://www.tibia.com/news/?subtopic=newsarchive&id=7944 ; article date2024-06-21, “Summer Update Changes during Test Server”.
FAKT [primary7944 exact quote]: “In addition, we have raised the number of fragments you will receive when crushing or dismantling gems:” followed by the larger table above.
FAKT [primary7944 scope quote]: “All announced changes will be implemented with the release of the summer update.” This is announced release applicability, not a retained completed-release/server trace.
FAKT [primary URL2]: https://www.tibia.com/gameguides/?subtopic=manual&section=characters ; live manual captured2026-10-01 gives the smaller CURRENT table; publication/revision date unknown.
FAKT [primary access]: Both primary texts reuse retained `REMOTE_DESKTOP_NATIVE_CHROME_CDP` captures; no new primary access. No observed user verification click. News retained HTTP status=null; manual status200.
FAKT [primary text pins]: news7944 SHA256 `2a30f5d3c6fe9203a9fe5125a98d75c0e4ac2ea3d1481f6acaea0d17b3e3c687`; manual SHA256 `d35257594793cdf2b7c12ff9a4ba27090362e509bc9075c506d516259319e464`.
FAKT [retained qualified packet]: `/workspace/scratch/gem-primary-release-recheck-agent/qualified-observations.json` SHA256 `038a08dfd754d4219baea8b4a2292dc16fb7e10ed0878ef697df3330d6ac0a5a`; all six resolutions=null and runtime admission=false.
FAKT [#1474 wording]: `/gems/yield_evidence` says exactly “CIPSOFT_OFFICIAL: docs/reference/tibia-manual/characters.md; overrides conflicting OTS yields”.
FAKT [#1474 coverage]: reviewed `source-parameters`, `reference-selection`, `verification-evidence`, `live-source-audit`, `browser-source-audit` JSON and README contain neither7944 identifier nor its “raised the number of fragments” quotation. Exact bodies/hashes are retained in this directory.
FAKT [#1474 audit wording]: live-source-audit `/official_manual/confirmed_facts/5` lists the smaller ranges; browser-source-audit `/upstream_static_comparison/interpretation_notes/6` calls yield/price/loot discrepancies bounded official/wiki overrides or labelledOTS hypotheses.
WNIOSEK [bounded omission]: These six reviewed documents omit the dated primary7944 alternative and discuss manual-versus-OTS disagreements. They do NOT explicitly identify7944 itself as OTS; do not claim that they do, or claim absence throughout the whole repository.
FAKT [reference-selection pin]: SHA256 `c29ecf3f5bc948d5431bd3fc262a97293f438aa72fd84d2467050e3bfd073316`; verification-evidence SHA256 `7cf0fe5d5bab981af90ac865db9b176d512bfb2e9cf904f6db599008c6931bc9`.
FAKT [other exact-head pins]: live-source-audit `b912583964a8fb874afd5aab034cbd8845445b5c16f59dca15d5d3257b372e25`; browser-source-audit `3f7ee588767a5b6c09ee4094018497a9201096b5c403c82ef91825964ca14ad4`; README `a3f42cc08dde74218055c45f348bf9c0866fde1539bd88c23bb838a79502d60f`.
WNIOSEK [qualification only]: Manual-versus-OTS priority does not by itself reconcile a second official primary announcement. Neither announcement date nor live retrieval date alone proves the target2026-09-27 production ranges or any RNG distribution.
NEXT [existing Wheel owner]: Preserve primary7944 as a dated primary alternative with all six applicability resolutions=null; record this bounded qualification in one existing owner packet. Do not change selected numeric ranges from this evidence packet.
SCOPE: No repository edits, tests, Cargo, paid API, Remote/browser use or publication in this round; WGR runtime ownership unchanged.

</details>

<details><summary>Pełny czteroplikowy Ink patch do review/admission (scratch candidate, nie commit)</summary>

```diff
diff --git a/tools/content-schema/item-authoring/item_weapon_proficiency.py b/tools/content-schema/item-authoring/item_weapon_proficiency.py
--- a/tools/content-schema/item-authoring/item_weapon_proficiency.py
+++ b/tools/content-schema/item-authoring/item_weapon_proficiency.py
@@ -23,6 +23,9 @@
 `vocation` attribute staged by `--stage-crystal` into
 `imports/crystalserver/facts/items-weapon-vocations.json` (DERIVED hypothesis; a weapon node
 without the attribute is `unrestricted`), else it is UNKNOWN with a reason.
+An optional externally selected, digest-pinned supplement can fill an UNKNOWN only
+with explicit locale-bound vocation and a uniquely corroborating Mastery observation.
+The owning control plane must admit the provider and exact package before integration.
 """
 
 from __future__ import annotations
@@ -34,6 +37,8 @@
 import xml.etree.ElementTree as ET
 from collections import Counter
 from pathlib import Path
+from datetime import datetime
+from urllib.parse import quote, urlsplit
 
 ROOT = Path(__file__).resolve().parents[3]
 STAGING = ROOT / "imports" / "cipsoft-staticdata"
@@ -464,6 +469,79 @@
     return "standard"
 
 
+# Opt-in only: the owning control plane must authorize the exact manifest digest and
+# provider/source policy before integration. CLI possession is not admission authority.
+# These positive literals are locale-bound; missing restriction never supplies one.
+SUPPLEMENT_VOCATIONS = {("pl", "Każda"): "unrestricted"}
+
+
+def threshold_supplement(manifest_path, manifest_sha256, source_html, bindings, profiles):
+    """Validate an explicitly selected package against the actual client crosswalk."""
+    supplied = (manifest_path, manifest_sha256, source_html)
+    if all(value is None for value in supplied):
+        return None
+    if any(value is None for value in supplied):
+        raise SystemExit("supplement requires manifest, external expected SHA and source HTML")
+    manifest = read_pinned_json(manifest_path, manifest_sha256)
+    if (manifest.get("schema") != "OTERYN_WEAPON_THRESHOLD_SUPPLEMENT/v1"
+        or manifest.get("scope") != "explicit_vocation_and_mastery_only"
+        or manifest.get("client_inputs") != {
+            "proficiencies_sha256": PROFICIENCIES_SHA256,
+            "appearances_sha256": APPEARANCES_SHA256}
+        or manifest.get("threshold_source") != THRESHOLD_SOURCE):
+        raise SystemExit("supplement schema, scope or existing source pins differ")
+    entry = manifest["observations"]
+    if Path(entry["path"]).name != entry["path"]:
+        raise SystemExit("supplement observations must be a sibling file")
+    document = read_pinned_json(manifest_path.parent / entry["path"], entry["sha256"])
+    source = manifest["source"]
+    if (document.get("schema") != "OTERYN_WEAPON_THRESHOLD_OBSERVATIONS/v1"
+        or document.get("source") != source
+        or source.get("provider") != "tibiopedia" or source.get("locale") != "pl"
+        or len(source.get("html_sha256", "")) != 64
+        or sha256_bytes(source_html.read_bytes()) != source["html_sha256"]):
+        raise SystemExit("supplement source provenance or HTML digest differs")
+    try:
+        capture = datetime.fromisoformat(source["captured_at"])
+        if capture.utcoffset() is None:
+            raise ValueError("capture needs timezone")
+    except (KeyError, TypeError, ValueError):
+        raise SystemExit("supplement capture timestamp invalid")
+    item = document["item"]
+    item_id = item["client_object_id"]
+    binding = next((b for b in bindings if b["source_id"] == item_id), None)
+    profile = profiles.get(item["proficiency_id"])
+    if (binding is None or profile is None
+        or item["item_key"] != f"oteryn:item.tibia.i{item_id}"
+        or binding["proficiency_id"] != item["proficiency_id"]
+        or binding["name"] != item["client_name"]
+        or profile["name"] != item["profile_name"]):
+        raise SystemExit("supplement item/profile differs from client crosswalk")
+    expected_url = "https://tibiopedia.pl/items/" + quote(
+        item["client_name"].title().replace(" ", "_"))
+    if source["url"] != expected_url or urlsplit(source["url"]).query:
+        raise SystemExit("supplement URL differs from bound item article")
+    observations = document["observations"]
+    vocation = SUPPLEMENT_VOCATIONS.get((source["locale"], observations.get("vocation_literal")))
+    if vocation is None:
+        raise SystemExit("supplement needs explicit positive locale-bound vocation")
+    if observations.get("displayed_levels") != list(range(1, profile["top_level"] + 1)):
+        raise SystemExit("supplement levels differ from client profile")
+    mastery = observations.get("mastery_points")
+    matches = [name for name, table in THRESHOLDS.items()
+               if table[profile["mastery_level"] - 1] == mastery]
+    ordinary_class = threshold_class(profile["name"], vocation=vocation)
+    if type(mastery) is not int or len(matches) != 1 or matches[0] != ordinary_class:
+        raise SystemExit("supplement Mastery ambiguous or conflicts with vocation/table")
+    return {"item_id": item_id, "threshold_class": matches[0], "vocation": {
+        "basis": "PROVEN", "source": "explicit_threshold_supplement", "value": vocation,
+        "vocation_literal": observations["vocation_literal"], "locale": source["locale"],
+        "mastery_points": mastery, "mastery_level": profile["mastery_level"],
+        "level_threshold_basis": "DERIVED_EXISTING_OWNER_SELECTED_TABLE",
+        "manifest_sha256": manifest_sha256, "observations_sha256": entry["sha256"],
+        "source_provenance": source}}
+
+
 def item_keys() -> set[str]:
     keys: set[str] = set()
     for path in sorted(ITEM_DEFINITIONS.glob("items-*.json")):
@@ -518,7 +596,9 @@
     }
 
 
-def build() -> dict:
+def build(supplement_manifest: Path | None = None,
+          supplement_manifest_sha256: str | None = None,
+          supplement_source_html: Path | None = None) -> dict:
     proficiency_manifest, definitions = load_family(
         STAGING / "proficiencies", "Proficiency", EXPECTED_PROFILES
     )
@@ -551,6 +631,8 @@
         profiles.append(profile)
     profiles.sort(key=lambda p: p["proficiency_id"])
 
+    supplement = threshold_supplement(supplement_manifest, supplement_manifest_sha256,
+                                     supplement_source_html, bindings, by_id)
     out_bindings = []
     seen = set()
     for binding in bindings:
@@ -567,6 +649,11 @@
         item_wiki = wiki.get(item_id, {})
         vocation = vocation_evidence(item_wiki, crystal.get(item_id))
         secondarytype = single(item_wiki.get("secondarytype"))
+        if (supplement and supplement["item_id"] == item_id
+            and vocation["basis"] == "UNKNOWN" and not item_wiki.get("vocrequired")
+            and threshold_class(profile["name"], ammotypes.get(item_id),
+                                vocation.get("value"), secondarytype) == "unknown"):
+            vocation = supplement["vocation"]
         evidence = {
             "ammotype": ammotypes.get(item_id),
             "secondarytype": secondarytype,
@@ -675,7 +762,17 @@
         metavar="ITEMS_XML",
         help="stage the weapon vocation facts from the pinned Crystal items.xml",
     )
+    parser.add_argument("--supplement-manifest", type=Path,
+                        help="owner-selected supplement; no default provider admission")
+    parser.add_argument("--supplement-manifest-sha256",
+                        help="expected digest externally bound by the owning control plane")
+    parser.add_argument("--supplement-source-html", type=Path,
+                        help="retained captured source bytes; digest verified, never emitted")
     args = parser.parse_args(argv)
+    supplement_args = (args.supplement_manifest, args.supplement_manifest_sha256,
+                       args.supplement_source_html)
+    if any(value is not None for value in supplement_args) and args.stage_crystal:
+        parser.error("supplement cannot be combined with --stage-crystal")
     if args.stage_crystal:
         _, bindings = load_family(
             STAGING / "weapon-proficiency-bindings",
@@ -689,7 +786,7 @@
         )
         print(f"wrote {CRYSTAL_VOCATIONS}")
         return 0
-    text = render(build())
+    text = render(build(*supplement_args))
     json.loads(text)  # the rendering must stay valid JSON
     if args.check:
         current = (
diff --git a/tools/content-schema/item-authoring/test_item_weapon_proficiency.py b/tools/content-schema/item-authoring/test_item_weapon_proficiency.py
--- a/tools/content-schema/item-authoring/test_item_weapon_proficiency.py
+++ b/tools/content-schema/item-authoring/test_item_weapon_proficiency.py
@@ -1,4 +1,10 @@
 """Tests for item_weapon_proficiency (ITEM-PROF-1, ITEM-PROF-1b). Run with `python test_item_weapon_proficiency.py`."""
+
+import copy
+import os
+import tempfile
+from pathlib import Path
+from unittest.mock import patch
 
 import json
 import unittest
@@ -177,5 +183,157 @@
         self.assertEqual(iwp.DEFAULT_OUTPUT.read_text(encoding="utf-8"), text)
 
 
+class SupplementTests(unittest.TestCase):
+    # Fixture invocation is prospective only; it does not establish owner admission.
+    SAMPLES = Path(__file__).resolve().parent / "samples"
+    MANIFEST = SAMPLES / "weapon-threshold-tibiopedia-ink-manifest.json"
+
+    @classmethod
+    def setUpClass(cls):
+        cls.baseline = iwp.build()
+        cls.manifest = json.loads(cls.MANIFEST.read_text())
+        cls.observations = json.loads((cls.SAMPLES / cls.manifest["observations"]["path"]).read_text())
+        cls.source_directory = tempfile.TemporaryDirectory()
+        cls.source_html = Path(cls.source_directory.name) / "source.html"
+        supplied = os.environ.get("OTERYN_THRESHOLD_SUPPLEMENT_SOURCE_HTML")
+        cls.source_html.write_bytes(Path(supplied).read_bytes() if supplied
+                                    else b"synthetic unit-test source bytes")
+        if not supplied:  # Synthetic pin for portable no-network unit fixtures only.
+            digest = iwp.sha256_bytes(cls.source_html.read_bytes())
+            cls.manifest["source"]["html_sha256"] = digest
+            cls.observations["source"]["html_sha256"] = digest
+
+    @classmethod
+    def tearDownClass(cls):
+        cls.source_directory.cleanup()
+
+    def candidate(self, manifest=None, observations=None, html=None):
+        # Re-pin mutated fixtures to exercise semantic rejection beyond digest checking.
+        with tempfile.TemporaryDirectory() as directory:
+            base = Path(directory)
+            package = copy.deepcopy(self.manifest if manifest is None else manifest)
+            facts = self.observations if observations is None else observations
+            raw = (json.dumps(facts, ensure_ascii=False) + "\n").encode()
+            (base / package["observations"]["path"]).write_bytes(raw)
+            package["observations"]["sha256"] = iwp.sha256_bytes(raw)
+            path = base / "manifest.json"
+            path.write_text(json.dumps(package))
+            return iwp.build(path, iwp.sha256_bytes(path.read_bytes()), html or self.source_html)
+
+    def test_prospective_fixture_changes_only_ink_binding_and_derived_counts(self):
+        actual = self.candidate()
+        self.assertEqual(actual["profiles"], self.baseline["profiles"])  # all 443, raw perks
+        for key in ("perk_mapping", "perk_raw_enums", "thresholds", "threshold_source"):
+            self.assertEqual(actual[key], self.baseline[key])
+        changed = [(a, b) for a, b in zip(actual["bindings"], self.baseline["bindings"]) if a != b]
+        self.assertEqual(len(changed), 1)
+        ink = changed[0][0]
+        self.assertEqual(ink["client_object_id"], 51666)
+        self.assertEqual(ink["threshold_class"], "standard")
+        self.assertEqual(ink["threshold_evidence"]["vocation"]["value"], "unrestricted")
+        self.assertEqual(actual["counts"]["bindings_by_threshold_class"],
+                         {"crossbow": 37, "knight": 158, "standard": 471})
+        profile = next(p for p in actual["profiles"] if p["proficiency_id"] == 371)
+        self.assertTrue(any(perk.get("Type") == 20 and perk.get("Value") == 8
+                            for level in profile["levels"] for perk in level["Perks"]))
+        for key in set(actual) - {"bindings", "counts"}:
+            self.assertEqual(actual[key], self.baseline[key])
+
+    def test_missing_external_pin_and_wrong_bytes_rejected(self):
+        args = (self.MANIFEST, iwp.sha256_bytes(self.MANIFEST.read_bytes()), self.source_html)
+        for index in range(3):
+            bad = list(args)
+            bad[index] = None
+            with self.subTest(index=index), self.assertRaises(SystemExit):
+                iwp.build(*bad)
+        with self.assertRaises(SystemExit):
+            iwp.build(self.MANIFEST, "0" * 64, self.source_html)
+        with tempfile.TemporaryDirectory() as directory:
+            html = Path(directory) / "source.html"
+            html.write_bytes(b"wrong source bytes")
+            with self.assertRaises(SystemExit):
+                self.candidate(html=html)
+            manifest = Path(directory) / "manifest.json"
+            manifest.write_bytes(self.MANIFEST.read_bytes())
+            (Path(directory) / self.manifest["observations"]["path"]).write_bytes(b"{}")
+            with self.assertRaises(SystemExit):
+                iwp.build(manifest, args[1], self.source_html)
+
+    def test_manifest_source_and_identity_mismatches_rejected(self):
+        for key, value in (("schema", "wrong"), ("scope", "perks"),
+                           ("threshold_source", {}), ("client_inputs", {})):
+            manifest = copy.deepcopy(self.manifest)
+            manifest[key] = value
+            with self.subTest(key=key), self.assertRaises(SystemExit):
+                self.candidate(manifest=manifest)
+        for key, value in (("url", "https://tibiopedia.pl/items/Other"),
+                           ("provider", "unadmitted"), ("locale", "en"),
+                           ("captured_at", "2026-10-01"), ("html_sha256", "0" * 64)):
+            manifest, facts = copy.deepcopy(self.manifest), copy.deepcopy(self.observations)
+            manifest["source"][key] = facts["source"][key] = value
+            with self.subTest(source=key), self.assertRaises(SystemExit):
+                self.candidate(manifest, facts)
+        facts = copy.deepcopy(self.observations)
+        facts["source"]["url"] += "?wrong"
+        with self.assertRaises(SystemExit):
+            self.candidate(observations=facts)
+        for key, value in (("client_object_id", 3294), ("item_key", "wrong"),
+                           ("proficiency_id", 238), ("profile_name", "wrong"),
+                           ("client_name", "wrong")):
+            facts = copy.deepcopy(self.observations)
+            facts["item"][key] = value
+            with self.subTest(item=key), self.assertRaises(SystemExit):
+                self.candidate(observations=facts)
+
+    def test_vocation_levels_and_mastery_must_corroborate_table(self):
+        for key, value in (("vocation_literal", None), ("vocation_literal", ""),
+                           ("vocation_literal", "absent restriction"),
+                           ("vocation_literal", "Knight"), ("displayed_levels", [1, 2, 3]),
+                           ("displayed_levels", [1, 2, 4, 3]), ("mastery_points", 6000000),
+                           ("mastery_points", 2500000), ("mastery_points", "8000000")):
+            facts = copy.deepcopy(self.observations)
+            facts["observations"][key] = value
+            with self.subTest(key=key, value=value), self.assertRaises(SystemExit):
+                self.candidate(observations=facts)
+        tables = copy.deepcopy(iwp.THRESHOLDS)
+        tables["knight"][5] = tables["standard"][5]
+        with patch.object(iwp, "THRESHOLDS", tables), self.assertRaises(SystemExit):
+            self.candidate()
+
+    def test_existing_evidence_and_wiki_disagreement_keep_precedence(self):
+        for wiki, crystal in (({"vocrequired": ["Knights"]}, None),
+                              ({"vocrequired": ["Monks"]}, None),
+                              ({}, {"weapon": True, "vocation": []}),
+                              ({}, {"weapon": True, "vocation": ["Knight;true"]}),
+                              ({"vocrequired": ["Knights", "Monks"]}, None)):
+            meta, records = iwp.wiki_stats()
+            records[51666] = wiki
+            crystal_records = iwp.crystal_vocations()
+            crystal_records[51666] = crystal
+            with patch.object(iwp, "wiki_stats", return_value=(meta, records)), \
+                 patch.object(iwp, "crystal_vocations", return_value=crystal_records):
+                candidate = self.candidate()
+            ink = next(b for b in candidate["bindings"] if b["client_object_id"] == 51666)
+            self.assertEqual(ink["threshold_evidence"]["vocation"], iwp.vocation_evidence(wiki, crystal))
+
+    def test_normal_cli_uses_supplement_and_check(self):
+        with tempfile.TemporaryDirectory() as directory:
+            output = Path(directory) / "candidate.json"
+            manifest = Path(directory) / "manifest.json"
+            facts = json.dumps(self.observations, ensure_ascii=False).encode()
+            (Path(directory) / self.manifest["observations"]["path"]).write_bytes(facts)
+            package = copy.deepcopy(self.manifest)
+            package["observations"]["sha256"] = iwp.sha256_bytes(facts)
+            manifest.write_text(json.dumps(package))
+            args = ["--output", str(output), "--supplement-manifest", str(manifest),
+                    "--supplement-manifest-sha256", iwp.sha256_bytes(manifest.read_bytes()),
+                    "--supplement-source-html", str(self.source_html)]
+            self.assertEqual(iwp.main(args), 0)
+            self.assertEqual(iwp.main(args + ["--check"]), 0)
+            ink = next(b for b in json.loads(output.read_text())["bindings"]
+                       if b["client_object_id"] == 51666)
+            self.assertEqual(ink["threshold_class"], "standard")
+
+
 if __name__ == "__main__":
     unittest.main()
diff --git a/tools/content-schema/item-authoring/samples/weapon-threshold-tibiopedia-ink-manifest.json b/tools/content-schema/item-authoring/samples/weapon-threshold-tibiopedia-ink-manifest.json
new file mode 100644
--- /dev/null
+++ b/tools/content-schema/item-authoring/samples/weapon-threshold-tibiopedia-ink-manifest.json
@@ -0,0 +1,27 @@
+{
+  "schema": "OTERYN_WEAPON_THRESHOLD_SUPPLEMENT/v1",
+  "scope": "explicit_vocation_and_mastery_only",
+  "source": {
+    "url": "https://tibiopedia.pl/items/Ink_Sword",
+    "captured_at": "2026-10-01T17:23:19.085311+00:00",
+    "html_sha256": "4e4668b92aae54cf6c29ce18125e6643da6291f67a1e3ba45bd527984e721ac0",
+    "provider": "tibiopedia",
+    "locale": "pl",
+    "revision_id": null,
+    "publication_timestamp": null
+  },
+  "observations": {
+    "path": "weapon-threshold-tibiopedia-ink-observations.json",
+    "sha256": "252190a37ebbf26f2b8846431ad04250e22910fd09a5705c53885c031c929166"
+  },
+  "client_inputs": {
+    "proficiencies_sha256": "7fea90ec1cfd472f4b5978f4456b430d3271598b4e545b7919d692641411e015",
+    "appearances_sha256": "2dfa943b548472a1ddc7bc5afe97945bc75e14f1f41d74f728f8e622f5dae7e2"
+  },
+  "threshold_source": {
+    "url": "https://tibia.fandom.com/wiki/Weapon_Proficiency",
+    "revid": 1192598,
+    "fetched": "2026-09-30",
+    "acceptance": "owner decision #162 5905899852"
+  }
+}
diff --git a/tools/content-schema/item-authoring/samples/weapon-threshold-tibiopedia-ink-observations.json b/tools/content-schema/item-authoring/samples/weapon-threshold-tibiopedia-ink-observations.json
new file mode 100644
--- /dev/null
+++ b/tools/content-schema/item-authoring/samples/weapon-threshold-tibiopedia-ink-observations.json
@@ -0,0 +1,38 @@
+{
+  "schema": "OTERYN_WEAPON_THRESHOLD_OBSERVATIONS/v1",
+  "source": {
+    "url": "https://tibiopedia.pl/items/Ink_Sword",
+    "captured_at": "2026-10-01T17:23:19.085311+00:00",
+    "html_sha256": "4e4668b92aae54cf6c29ce18125e6643da6291f67a1e3ba45bd527984e721ac0",
+    "provider": "tibiopedia",
+    "locale": "pl",
+    "revision_id": null,
+    "publication_timestamp": null
+  },
+  "item": {
+    "client_object_id": 51666,
+    "item_key": "oteryn:item.tibia.i51666",
+    "client_name": "ink sword",
+    "proficiency_id": 371,
+    "profile_name": "Sword 1H Ink Sword"
+  },
+  "observations": {
+    "vocation_literal": "Każda",
+    "displayed_levels": [
+      1,
+      2,
+      3,
+      4
+    ],
+    "mastery_points": 8000000
+  },
+  "limits": [
+    "No source revision/publication timestamp; target-date continuity unproven.",
+    "Thresholds per level are derived from the existing table, not observed here.",
+    "No item stats or perks adopted; community mana-on-kill 5 conflicts with primary client 8."
+  ],
+  "extraction_provenance": {
+    "proposal_sha256": "7c4bf5e24bfc33124ef33a07853fb96ef9e2709633b4caade73edc405dc35bb3",
+    "method": "Minimal factual extraction from digest-bound full public item article"
+  }
+}
```

</details>

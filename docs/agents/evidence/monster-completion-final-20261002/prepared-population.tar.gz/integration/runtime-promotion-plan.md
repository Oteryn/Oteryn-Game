# Promotion scope and native qualification

Baseline packet validates 1697 Creature, 83 Encounter, 23977 records and 22888 profiles. It verifies reference closure against protected Item map plus canonical appearance/binding evidence, all four-file bundle digests, numeric profiles, index SHA, and preserved quality flags. Re-run with the final population configuration after the remaining source/mechanics lanes complete.

Production materializer currently includes `docs/agents/evidence/OTV2-20260927-creature-admission-wave-a-staged.json`, asserts Creature count1503 and Encounter count61, and pins source identities, record/profile counts, bindings, Encounter manifest SHAs and Wiki/Crystal sources. A reviewed promotion must replace this exact packet and reconcile all these fences together; changing two count constants alone cannot promote it. Keep the population index/classification/quality artifacts with the promoted SHA; the materializer does not consume completion flags as runtime policy.

Suggested owner-lane commands (not executed by this packet):
- Run `tools/monster-lab/run.py arena --config FINAL_CONFIG --output-dir NEW_OUT --ticks 30`: full final-population scheduling, deterministic replay and authored-HP owner death fixture.
- Run native `spell::tests::a_cast_becomes_an_ability_plan_that_the_engine_commits`: existing real supported Ability effect commit fixture; this is player spell-core coverage, not proof every monster inline Ability commits.
- Run `ai_think::profile_schedule::tests::prepared_native_summon_population_consumes_explicit_owner_fixture_facts`: explicit fixture scheduling with summon proposal identities/counts; no real summon installation/lifecycle claim.
- Run `combat::loot_plan::tests::` and owner death-reward durability tests selected by their owning lane: deterministic loot planning alone does not establish durable corpse/loot drop commit.
- Run `foundation::runtime_actor_carrier::damage_contributors_tests::accumulation_never_survives_removal_or_respawn`: owner generation/contributor separation; no timed production respawn claim.

Real monster effect-dispatch, player familiar owner lifecycle, durable corpse/loot integration, timed production respawn and client E2E remain owning-runtime work. Existing `spell::tests::monster_inline_operations_do_not_become_executable_ability_effects` explicitly refuses to treat unknown condition/create_item/summon_creature inline operations as executable. Do not substitute an all-green component arena for these missing receipts.

Governance failure job110817746572 on PR1547 is precisely `governance validation only accepts pull requests targeting main`. The stack draft targets PR1546 branch. Preserve prior draft stack; publish/reconcile the final coherent main-targeting candidate, then run required frozen-head CI. No gate weakening or no-op trigger commit.

This lane does not mutate runtime files, start a live server, trigger paid reviews, merge or deploy. Current162 runtime architecture allocations remain authoritative.

## Cached native execution performed

Ran existing executable `oteryn_game_server-ccaf41209ba80183` without rebuilding: Ability commit1, deterministic loot planning28, owner damage/contributor separation12, death reward limits/replay10, profile scheduling/summon preparation11; all62 passed. Exact binary SHA and build timestamp, filters and logs are in `cached-runtime-tests.json`. Build-to-Git-head provenance is unverified; this is cached fixture evidence only, not qualification of the new population or current candidate. No durable lootdrop commit/E2E/production respawn receipt is claimed.

`build_materializer_proposal.py` renders the complete pin/count patch and a proposal receipt outside the repository. Baseline output `materializer-promotion.PROPOSAL.patch` covers1697/83, Crystal90, records23977/profiles22888 and all stage/index/mapper fences. Re-run with final stage before review. It does not copy the snapshot or apply the patch.

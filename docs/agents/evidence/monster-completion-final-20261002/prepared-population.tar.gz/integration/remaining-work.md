# Co pozostaje do domknięcia potworów

Przygotowane dane docelowe: 1763 stworzenia i 95 Encounter. Produkcyjny materializer nadal przypina 1503/61. Gotowość danych i działanie na serwerze są odrębnymi kwalifikacjami.

- Istniejące mechaniki: 14 pominiętych komponentów u 8 stworzeń.
  - QUEST_SHARED_STATE_OWNER: 3; faceless_bane, ferumbras_mortal_shell, parasite.
  - MEGALOMANIA_MAP_PREDICATES: 9; goshnar_s_megalomania_blue, goshnar_s_megalomania_green, goshnar_s_megalomania_purple.
  - SEACREST_DEFENSIVE_MELEE: 1; seacrest_serpent.
  - WALKER_TARGET_ATTRIBUTES: 1; walker.
- Nowe definicje: 66 oznaczonych pominięć mechanik u 47 stworzeń; statystyki i podstawowe dane przygotowano.
- Familiary: 5 definicji, 5 integracji cyklu właściciela do wykonania; Druid/Sorcerer dodatkowo Challenge (2 komponenty).
- SW6: przygotowane uproszczone pojedyncze pool; nie potwierdzono Global stacking ani runtime step-in. Ferumbras/Parasite/Faceless wymagają uzgodnionego stanu domeny questów.
- Primal: 11 rzeczywistych rejestracji pochodnych; fragmenty registered-type wymagają kwalifikacji importera/runtime i uzgodnienia w162.
- Role: 0 unknown; etykiety wywnioskowane ze źródeł nadal mają flagi niepewności.
- Loot: 158 istniejących wpisów o niskiej pewności u 26 stworzeń.
- Runtime: wykonywanie efektów potworów, instalacja/lifecycle summonów, trwały drop, respawn i E2E klienta.
- Promocja: final snapshot + pełne SHA/liczniki/source bindings, wymagane review i CI do main; potem oddzielnie autoryzowane wdrożenie.

Liczby komponentów, stworzeń i flag nakładają się; nie wolno ich sumować jako jednego licznika brakujących potworów. Pełne listy i SHAs źródłowych raportów są w remaining-work.json.

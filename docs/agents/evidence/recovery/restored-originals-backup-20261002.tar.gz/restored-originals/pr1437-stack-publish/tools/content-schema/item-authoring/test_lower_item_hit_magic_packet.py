"""Literal units, zero ML, all-page agreement and normal current-name guards."""

import copy
import unittest

import lower_item_hit_magic_packet as fields


class HitMagic(unittest.TestCase):
    def args(self, value="6", member="hit_chance"):
        raw = (
            "{{Infobox Object|itemid=7|name=Bow|"
            + ("hit_mod=" if member == "hit_chance" else "mlrequired=")
            + value
            + "}}"
        )
        page = {
            "revision_id": 1,
            "revision_timestamp": "2026-09-01T00:00:00Z",
            "content_sha256": "declared article digest",
            "source_part": "part",
            "source_part_sha256": "part sha",
            "source_page_ordinal": 0,
            "own_objects": [{"box_index": 0, "raw_itemid_values": ["7"]}],
        }
        witness = {k: v for k, v in page.items() if k != "own_objects"}
        witness.update(
            page_id=1,
            box_index=0,
            raw_infobox=raw,
            raw_infobox_sha256=fields.base.sha(raw.encode()),
            balanced=True,
            inside_comment=False,
            positive_exact_infobox_object_match=True,
        )
        return [
            {
                "source_item_id": 7,
                "official_name": "bow",
                "sources": [witness],
                "facts": {
                    member: {"numerator": 3, "denominator": 50}
                    if member == "hit_chance"
                    else 0
                },
            },
            {7: {1}},
            {1: page},
            "2026-09-27T23:59:59Z",
        ]

    def test_exact_signed_relative_units_and_explicit_zero(self):
        for raw, n, d in [("6", 3, 50), ("-7", -7, 100), ("0", 0, 1), ("200", 2, 1)]:
            args = self.args(raw)
            args[0]["facts"]["hit_chance"] = {"numerator": n, "denominator": d}
            self.assertEqual(fields.parse_sources(*args), args[0]["facts"])
        args = self.args("0", "required_magic_level")
        self.assertEqual(fields.parse_sources(*args), {"required_magic_level": 0})
        for raw, member in [
            ("", "hit_chance"),
            ("6%", "hit_chance"),
            ("0.06", "hit_chance"),
            ("6|hit_mod=6", "hit_chance"),
            (str(2**70), "hit_chance"),
            ("-1", "required_magic_level"),
            ("65536", "required_magic_level"),
        ]:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                fields.parse_sources(*self.args(raw, member))

    def test_all_present_pages_must_agree(self):
        args = self.args()
        second = copy.deepcopy(args[0]["sources"][0])
        second["page_id"] = 2
        args[0]["sources"].append(second)
        args[1][7].add(2)
        args[2][2] = copy.deepcopy(args[2][1])
        self.assertEqual(fields.parse_sources(*args), args[0]["facts"])
        second["raw_infobox"] = second["raw_infobox"].replace("hit_mod=6", "hit_mod=7")
        second["raw_infobox_sha256"] = fields.base.sha(second["raw_infobox"].encode())
        with self.assertRaisesRegex(ValueError, "disagreement"):
            fields.parse_sources(*args)

    def test_no_name_exception_blocked_hit_and_owned_ml_conflict(self):
        source = self.args()[0]
        source["target"] = {
            "family": "Item",
            "key": "item",
            "revision": "definition-r1",
        }
        facts = source["facts"]
        definition = {"semantics": {}}
        self.assertEqual(
            fields.qualify(source, definition, [], facts)["hit_percentage_points"], 6
        )
        for state in [
            {"state": "CONFLICT"},
            {"state": "NOT_APPLICABLE"},
            {"state": "KNOWN", "value": "weapon of carving"},
        ]:
            definition["semantics"] = {
                "presentation": {"state": "KNOWN", "value": {"name": state}}
            }
            with self.assertRaisesRegex(ValueError, "normal native name"):
                fields.qualify(source, definition, [], facts)
        definition["semantics"] = {"weapon": {"state": "CONFLICT"}}
        with self.assertRaisesRegex(ValueError, "blocked"):
            fields.qualify(source, definition, [], facts)
        definition["semantics"] = {}
        owner = {"item": source["target"], "required_magic_level": 1}
        with self.assertRaisesRegex(ValueError, "magic level"):
            fields.qualify(source, definition, [owner], {"required_magic_level": 0})
        for changed in [
            [owner, owner],
            [{"item": source["target"] | {"revision": "other"}}],
        ]:
            with self.assertRaisesRegex(ValueError, "target/duplicate"):
                fields.qualify(source, definition, changed, facts)


if __name__ == "__main__":
    unittest.main()

import pathlib,json,hashlib,sys,subprocess,re,collections,datetime
from fractions import Fraction
A=pathlib.Path('/workspace/audit-continuation');W=pathlib.Path('/workspace/pr1437-native-publish')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
P=A/'mantra-bond57-complete-source-proof.json';start_sha=sha(P.read_bytes());assert start_sha=='f80dff9bfeb17d6a356d5852bc912501f6a17b86270e3e9bcfa99313688f0c7c';proof=load(P);baseline=proof['native_baseline_head'];assert baseline=='8257ba68d449a4975345897823d8282393e5bae2'
def frozen(p):return subprocess.check_output(['git','show',baseline+':'+p],cwd=W)
indexpath=A/'global-infobox-object-own-itemid-index.json';manifestpath=A/'global-infobox-object-source-manifest.json';index=load(indexpath);manifest=load(manifestpath);assert sha(indexpath.read_bytes())==proof['input_sha256'][str(indexpath)];assert sha(manifestpath.read_bytes())==proof['input_sha256'][str(manifestpath)];assert index['cutoff']==manifest['qualification_cutoff']==proof['cutoff']
prior=load(A/'elemental-magic-level-modifier-49-source-qualification.json');prior26={r['item_id']for r in prior['records']if not r['holds']};assert len(prior26)==26;ids={r['item_id']for r in proof['records']};assert len(ids)==len(proof['records'])==57 and not ids&prior26
D={r['definition']['identity']['key']:r['definition']for s in json.loads(frozen('content/items/index.json'))['shards']for r in json.loads(frozen(s))['records']};B=json.loads(frozen('imports/crystalserver/bindings/items.json'))['bindings'];byid=collections.defaultdict(list);bykey=collections.defaultdict(list)
for b in B:byid[b['external_id']].append(b);bykey[b['target']['key']].append(b)
sys.path.insert(0,str(W/'tools/content-schema/item-authoring'));import engine_items as engine
clientsha='2dfa943b548472a1ddc7bc5afe97945bc75e14f1f41d74f728f8e622f5dae7e2';client=(W/f'content/assets/files/appearances-{clientsha}.dat').read_bytes();assert sha(client)==clientsha;objects=engine.load_appearance_objects(client)
cur=json.loads(frozen(f'imports/official/appearance-membership/appearances-{clientsha}.json'));assert cur['entries']==__import__('appearance_membership').manifest_entries(client);members={r[0]:r for r in cur['entries']};oldmembers={}
for rev,digest in [('ff7ede593c69d4c658b382c97443e8155926924a','6adb790d1064c2d31ffb2e5ce1a7aef376942ba672edea2adb6cafc620dd18f1'),('00ce02a57ca5a12e48f32a3476e37471167e4c3f','17a72b30b5c3c9ca8c1283cfb2febd2a93a145ff8ab66916f7a412d0f1dee5a1')]:oldmembers[rev]={r[0]:r for r in json.loads(frozen(f'imports/official/appearance-membership/appearances-{digest}.json'))['entries']}
world=set()
for prefix in ['content/world/objects','content/world/terrain']:
 for p in subprocess.check_output(['git','ls-tree','-r','--name-only',baseline,prefix],cwd=W,text=True).splitlines():
  if p.endswith('.json'):world.update(r['provenance']['item_pointer']['key']for r in json.loads(frozen(p)).get('records',[])if r.get('provenance',{}).get('item_pointer'))
points={'magic level':'MAGIC_LEVEL_POINTS','axe fighting':'SKILL_AXE','club fighting':'SKILL_CLUB','distance fighting':'SKILL_DISTANCE','fist fighting':'SKILL_FIST','shielding':'SKILL_SHIELD','sword fighting':'SKILL_SWORD','speed':'SPEED'}|prior['new_aliases'];percents={'crithit_ch':'CRITICAL_HIT_CHANCE','critextra_dmg':'CRITICAL_HIT_DAMAGE','hpleech_am':'LIFE_LEECH_AMOUNT','hpleech_ch':'LIFE_LEECH_CHANCE','manaleech_am':'MANA_LEECH_AMOUNT','manaleech_ch':'MANA_LEECH_CHANCE'};modfields=['attrib',*percents,'mantra','elementalbond'];order=['ELEMENTAL_BOND','INVISIBILITY','MANA_SHIELD','MANTRA','CLEAVE_PERCENT','CRITICAL_HIT_CHANCE','CRITICAL_HIT_DAMAGE','DEATH_MAGIC_LEVEL_POINTS','EARTH_MAGIC_LEVEL_POINTS','ENERGY_MAGIC_LEVEL_POINTS','FIRE_MAGIC_LEVEL_POINTS','HEALING_MAGIC_LEVEL_POINTS','HEALTH_GAIN','HEALTH_TICKS','HOLY_MAGIC_LEVEL_POINTS','ICE_MAGIC_LEVEL_POINTS','LIFE_LEECH_AMOUNT','LIFE_LEECH_CHANCE','MAGIC_LEVEL_POINTS','MAGIC_SHIELD_CAPACITY_FLAT','MAGIC_SHIELD_CAPACITY_PERCENT','MANA_GAIN','MANA_LEECH_AMOUNT','MANA_LEECH_CHANCE','MANA_TICKS','PERFECT_SHOT_DAMAGE','PERFECT_SHOT_RANGE','REFLECT_DAMAGE','SKILL_AXE','SKILL_CLUB','SKILL_DISTANCE','SKILL_FIST','SKILL_SHIELD','SKILL_SWORD','SPEED','SUPPRESS_DROWN','SUPPRESS_DRUNK']
def parse(params):
 if any(len(v)!=1 for k,v in params.items()if k in modfields):return None
 fields={k:v[0]for k,v in params.items()};values={}
 if 'attrib'in fields:
  for bit in fields['attrib'].lower().split(','):
   m=re.fullmatch(r'([a-z ]+) ([+-]?[0-9]+)',bit.strip());kind=points.get(m[1])if m else None
   if kind is None or kind in values or not -(2**31)<=int(m[2])<2**31:return None
   values[kind]={'kind':'SIGNED_POINTS','value':int(m[2])}
 for p,k in percents.items():
  if p in fields:
   m=re.fullmatch(r'([+]?[0-9]+(?:\.[0-9]+)?)%',fields[p])
   if not m:return None
   v=Fraction(m[1])
   if not 0<=v<=100 or v.numerator>2**63-1 or v.denominator>2**64-1:return None
   values[k]={'kind':'RATIONAL_PERCENT','value':{'numerator':v.numerator,'denominator':v.denominator}}
 if 'mantra'in fields:
  m=fields['mantra']
  if not re.fullmatch(r'[+-]?[0-9]+',m)or not -(2**15)<=int(m)<2**15:return None
  values['MANTRA']={'kind':'SIGNED_POINTS','value':int(m)}
 if 'elementalbond'in fields:
  b=fields['elementalbond'].lower()
  if b not in ['physical','energy','earth']:return None
  values['ELEMENTAL_BOND']={'kind':'ELEMENT','value':b.upper()}
 return values
parts={};vectors=0;atoms=0;lanes=collections.Counter();laneatoms=collections.Counter();namecounts=collections.Counter();allsourcecount=0;transportlabels=set();rawliteral=collections.Counter()
def rawsources(iid,supplied=None):
 refs=index['by_own_itemid_integer_mention'][str(iid)];result=[];supplied=supplied or []
 for ref in refs:
  p=pathlib.Path(ref['capture_path'])
  if p not in parts:assert sha(p.read_bytes())==ref['capture_sha256'];parts[p]=load(p)
  part=parts[p];assert part['status']==200 and not part['api_error'];page=part['pages'][ref['page_ordinal']];box=page['infobox_objects'][ref['box_index']];assert page['revision_timestamp']<=proof['cutoff'];assert box['balanced']and not box['inside_comment']and box['positive_exact_infobox_object_match'];assert box['itemid_occurrences'][0]['strict_positive_comma_ids']==[iid];assert not box['duplicate_parameter_names'];params=box['parameter_values']
  if not any(k in params for k in modfields):continue
  if supplied:
   matches=[s for s in supplied if s['page_id']==page['page_id']];assert len(matches)==1;s=matches[0];assert s['capture_path']==str(p)and s['capture_sha256']==ref['capture_sha256'];assert s['retained_raw_own_template']==box['raw'];assert sha(box['raw'].encode())==s['raw_own_template_sha256'];assert s['parameters']==params;assert s['fields']=={k:v[0]for k,v in params.items()if len(v)==1};assert s['revision_id']==page['revision_id']and s['revision_timestamp']==page['revision_timestamp']and s['title']==page['title'];assert s['whole_article_sha256_declared']==page['content_sha256'];transportlabels.add(s['source_transport'])
  result.append(params)
 if supplied:assert len(result)==len(supplied)
 return result
for r in proof['records']:
 iid=r['item_id'];key=r['item_key'];d=D[key];assert r['full_target']==d['identity']and r['target_field']=='skill_modifiers.modifiers';assert r['full_target']['family']=='Item'and r['full_target']['revision']=='definition-r1';assert not r['holds'];assert key not in world
 assert len(byid[str(iid)])==len(bykey[key])==1;assert byid[str(iid)]==bykey[key];b=byid[str(iid)][0];assert b['disposition']=='EXACT'and b['target']==r['full_target']and b['identity_namespace']=='ots/item_server_id'and b['source_key']=='oteryn:source.crystalserver'and b['source_revision']in oldmembers;assert oldmembers[b['source_revision']][iid][1]==members[iid][1]
 obj=objects[iid];assert obj['flags'].get('flags.take')is True and not any(obj['flags'].get(k)is True for k in ['flags.bank','flags.clip','flags.liquidpool','flags.corpse','flags.player_corpse','flags.unmove']);semantics=d.get('semantics',{});pres=semantics.get('presentation',{'state':'UNKNOWN'});assert pres['state']in['KNOWN','UNKNOWN'];name=pres.get('value',{}).get('name',{'state':'UNKNOWN'});assert name['state']in['KNOWN','UNKNOWN'];namecounts[name['state']]+=1
 if name['state']=='KNOWN':assert name['value'].strip().casefold()==obj['name'].strip().casefold()
 group=semantics.get('skill_modifiers',{'state':'UNKNOWN'});current=group if group['state']!='KNOWN'else group['value']['modifiers'];assert current==r['existing_value']=={'state':'UNKNOWN'}
 sources=rawsources(iid,r['sources']);assert sources;parsed=[parse(p)for p in sources];assert all(p is not None and p==parsed[0]for p in parsed)
 for p in sources:
  actual=p.get('actualname',p.get('name',['']))[0];assert actual.strip().casefold()==obj['name'].strip().casefold();
  for f in ['mantra','elementalbond']:
   if f in p:rawliteral[(f,p[f][0])]+=1
 incoming=r['incoming_value'];assert {e['kind']:e['parameter']['value']for e in incoming}==parsed[0]and len({e['kind']for e in incoming})==len(incoming);assert [e['kind']for e in incoming]==sorted([e['kind']for e in incoming],key=order.index)
 for e in incoming:assert e['parameter']['state']=='KNOWN'and all(e[k]=={'state':'UNKNOWN'}for k in ['target_domain','evaluation_phase','priority'])
 lane='mantra'if 'MANTRA'in parsed[0]else'bond';lanes[lane]+=1;laneatoms[lane]+=len(incoming);atoms+=len(incoming);vectors+=1;allsourcecount+=len(sources)
assert vectors==57 and atoms==130 and lanes=={'mantra':35,'bond':22}and laneatoms=={'mantra':83,'bond':47}
proposals=load(A/'remaining10-disjoint-positive-batch-proposals.json');heldids={}
for lane,expected in [('mantra',3),('bond',10)]:
 held=proposals['holds'][lane];assert len(held)==expected;heldids[lane]=[]
 for r in held:
  assert r['item_id']not in ids;raw=rawsources(r['item_id']);assert any(parse(p)is None for p in raw);heldids[lane].append(r['item_id'])
assert sha(P.read_bytes())==start_sha
report={'schema':'OTERYN_MANTRA_BOND57_INDEPENDENT_REVIEW/v1','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_VECTOR_FACTS_PASS_PROVENANCE_LABEL_REPAIR_REQUIRED','native_baseline_sha':baseline,'source_proof_sha256':start_sha,'vectors':57,'atoms':130,'lane_items':dict(lanes),'lane_atoms':dict(laneatoms),'source_present_page_witnesses':allsourcecount,'actual_capture_parts':len(parts),'names':dict(namecounts),'held_ids_reconfirmed':heldids,'prior26_disjoint':True,'combined83_vector_atoms':193,'source_transport_proof_labels':sorted(transportlabels),'actual_source_transport':manifest['method'],'source_wholegroup_independent_parser':'All actual raw parameters retained, integer/percent/element units reparsed independently, complete vectors equal facts and strictly native ordered; no dropped empty/conditional modifier field','native_owner_acceptance':['Existing ReferenceSkillModifierKind::Mantra typed SignedPoints parameter; formal mantra integer points range[-32768,32767]; full formal profile damage_types remains unresolved','Existing ReferenceSkillModifierKind::ElementalBond typed Element parameter; exact Physical/Energy/Earth literal routes','All 130 context triples target_domain/evaluation_phase/priority UNKNOWN; no gameplay binding inferred'],'findings':[{'classification':'PROVEN','gate_classification':'EVIDENCE_GAP','location':'build-mantra-bond57-source-proof.py source_transport assignments and all57 proof witnesses','problem':'Proof says retained normal HTTP capture, but bound global manifest records anonymous browser/CDP same-origin capture after ordinary HTTP block','repair':'New external successor proof/builder labels actual retained browser/CDP transport; preserve original SHA and source raw/value coordinates truthfully'}],'minimal_successor_proposal':['Keep prior26 proof/packet immutable and its closed cohort; separate Mantra/Bond source proof/packet and explicit57 selector','Reuse unchanged full raw/own-ID/all-present/portable/native identity predicates from26 compiler once available, with exact literal Mantra/Bond parser/owner routes added only under57 selector','Rust existing skill modifier atomic setter reused; narrowly admit Kind::Mantra with Known(SignedPoints) i16 bounds and Kind::ElementalBond with Known(Element) allowedthree; preserve context UNKNOWN and strict complete-vector order','Check53? No new activation/admission/typedgroup/context contract; add meaningful empty critical/leech, conditional/bounds, wrong element/unit, blocked/known conflict and late-error atomic tests','Current source historical digest corpus retained as proof coordinates; successor guards current relevant identity/name/owner/domain, never require an unrelated native physical/readability whole-file historical hash'],'immutability':['Original26 source qualification 4448a9a... preserved; original17+6 holds unchanged','Current proof f80dff9... retained as source generation; successor provenance repair receives new SHA','No script regeneration/production edits/Cargo/new network during independent review'],'limitations':['Read-only source proof/implementation proposal, not Rust compilation/frozen candidate validation','Full raw articles/API response not retained; fragment SHA recomputed, full article SHA declared capture metadata','No complete formal Mantra damage_types profile or whole-Item readiness claim']}
out=A/'mantra-bond57-independent-source-review.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k in ['status','native_baseline_sha','vectors','atoms','lane_items','lane_atoms','names','held_ids_reconfirmed','source_present_page_witnesses','actual_capture_parts','findings']},indent=2));print('REPORT',out);print('SHA',sha(out.read_bytes()))

"""Explicit pair source/cut and owner guards, independent of native document facts."""

import copy
import json
import unittest

import lower_item_forge3332_packet as forge


class ForgeSources(unittest.TestCase):
    def args(self):
        proof = json.loads((forge.ROOT / forge.PROOF).read_text())
        record = proof["current_native_identity"]["retained_current_record"]
        definition = {"identity": record["identity"], "semantics": record["semantics"]}
        return [
            proof,
            copy.deepcopy(proof["source_pair"]["retained_source_row"]),
            definition,
            {"id": 3332, "name": "hammer of wrath", "flags": {"flags.take": True}},
            [],
            set(),
        ]

    def test_separate_current_cut_and_idempotent_existing_owner(self):
        args = self.args()
        row = forge.qualify(*args)
        self.assertEqual(row["forge"], {"classification": 2, "max_tier": 2})
        args[4] = [row | {"required_magic_level": 7}]
        self.assertEqual(forge.qualify(*args), row)
        args[0]["current_selector"]["qualification_cutoff"] = "2026-07-28T23:59:59Z"
        with self.assertRaisesRegex(ValueError, "cutoff"):
            forge.qualify(*args)

    def test_source_and_current_target_owner_fail_closed(self):
        def source_pair(a):
            a[1]["fields"]["max_tier"] = {"state": "ABSENT"}

        def native_name(a):
            a[2]["semantics"]["presentation"]["value"]["name"] = {"state": "UNKNOWN"}

        def conflict(a):
            a[4] = [
                {"item": a[0]["target"], "forge": {"classification": 2, "max_tier": 3}}
            ]

        for change in [
            source_pair,
            native_name,
            conflict,
            lambda a: a[1].update(revision_id=1),
            lambda a: a[2]["identity"].update(revision="other"),
            lambda a: a[3]["flags"].update({"flags.take": False}),
            lambda a: a[5].add(a[0]["target"]["key"]),
        ]:
            args = self.args()
            change(args)
            before = copy.deepcopy(args)
            with self.assertRaises(ValueError):
                forge.qualify(*args)
            self.assertEqual(args, before)

    def test_proof_and_input_digest_drift(self):
        with self.assertRaisesRegex(ValueError, "source digest drift"):
            forge.checked(forge.ROOT, forge.PROOF, "0" * 64)
        proof = json.loads((forge.ROOT / forge.PROOF).read_text())
        with self.assertRaisesRegex(ValueError, "source digest drift"):
            forge.checked(forge.ROOT, proof["source_pair"]["artifact_path"], "0" * 64)

    def test_forward_reverse_binding_uniqueness(self):
        proof = self.args()[0]
        row = proof["identity_bridge"]["br_to_full_native"]["row"]
        target = proof["target"]
        self.assertEqual(forge.exact_binding([row], row, target), row)
        other = copy.deepcopy(row)
        other["target"]["key"] = "oteryn:item.tibia.i3333"
        for bindings in ([row, other], [row, row], [other]):
            with self.assertRaisesRegex(ValueError, "binding drift"):
                forge.exact_binding(bindings, row, target)
        alias = row | {"disposition": "ACCEPTED_ALIAS"}
        with self.assertRaisesRegex(ValueError, "binding drift"):
            forge.exact_binding([alias], alias, target)


if __name__ == "__main__":
    unittest.main()

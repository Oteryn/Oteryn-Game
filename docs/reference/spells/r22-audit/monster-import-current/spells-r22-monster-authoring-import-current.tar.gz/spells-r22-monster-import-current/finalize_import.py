"""Bind exhaustive registration audit and publish compact source-only import review artifacts."""
import json,hashlib,zipfile
from pathlib import Path
from collections import Counter
R=Path('/workspace/spells-r22-monster-import-current');A=Path('/workspace/spells-r22-source-audit')
def load(p):return json.loads(p.read_text())
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(source,path,name,kind):return source,path,str(name).lower(),str(kind).lower()
d=load(R/'all-registered-spells.json');actual={};capture_inputs=[]
for source in ('canary','crystal'):
 p=A/({'canary':'canary-main-current','crystal':'crystal-summer-current'}[source]+'-registered-spells.json');rows=load(p);capture_inputs.append({'source':source,'path':str(p),'sha256':sha(p),'captured_registrations':len(rows)})
 for row in rows:
  rec=row['record'];actual.setdefault(key(source,rec['file'],rec.get('name'),rec['spell_type']),[]).append(row)
status=Counter();unmatched=[]
for row in d:
 k=key(row['source'],row['provenance']['path'],row['name'],row['kind']);matches=actual.get(k,[])
 if matches:
  assert all(x['sha256']==row['provenance']['sha256'] for x in matches)
  row['registration_capture']={'status':'CAPTURED_SOURCE_REGISTRATION','captures':[{'registration_key':x['registration_key'],'extraction':x['extraction'],'engine_enabled_path':x['engine_enabled_path'],'logical_key':x['logical_key']} for x in matches]}
 else:
  row['registration_capture']={'status':'LEXICAL_DECLARATION_NOT_CAPTURED','qualification':'Explicitly unresolved; no claim that this registration executes or is enabled.'};unmatched.append({'source':row['source'],'name':row['name'],'kind':row['kind'],'provenance':row['provenance']})
 status[row['registration_capture']['status']]+=1
ours={key(x['source'],x['provenance']['path'],x['name'],x['kind']) for x in d};capture_only=[]
for k,rows in actual.items():
 if k not in ours:
  for row in rows:capture_only.append(row)
write(R/'all-registered-spells.json',d)
for source in ('canary','crystal'):write(R/'registered-spells'/f'{source}.json',[x for x in d if x['source']==source])
closure={'source_registration_audit_inputs':capture_inputs,'lexical_declarations':len(d),'declaration_capture_status':dict(status),'lexical_not_captured':unmatched,'captured_not_lexically_indexed':capture_only,'captured_source_records_total':sum(x['captured_registrations'] for x in capture_inputs),'limits':['Counts of lexical declarations and captured source registrations are distinct.','Source-disabled #example registrations are retained as source evidence, never active abilities.','Opaque custom registrations remain explicitly unresolved.']};write(R/'registration-capture-closure.json',closure)
s=load(R/'summary.json');s['registration_inventory_kind']='lexical_named_declarations_not_proof_of_executed_registrations';s['actual_source_registration_capture_counts']={x['source']:x['captured_registrations'] for x in capture_inputs};s['registration_capture_closure']='registration-capture-closure.json';write(R/'summary.json',s)
profiles=load(R/'monster-profiles.json');slots=load(R/'monster-spell-slots.json')
blockers={'runtime_activation':False,'profile_outcomes':dict(Counter(x['conversion_status'] for x in profiles)),'slot_outcomes':dict(Counter(x['conversion_status'] for x in slots)),'unresolved_spell_slots':[{'slot_key':f"{x['source']}/{x['monster_source']['path']}/{x['group']}/{x['source_slot_index']}",'name':x['source_parameters'].get('name'),'source_parameters':x['source_parameters'],'monster_source':x['monster_source'],'registered_source':x['registered_source'],'conversion_status':x['conversion_status'],'manifest_rows':x.get('conversion_manifest_rows',[])} for x in slots if x['conversion_status'] not in ('mapped','approved_omission')],'invalid_profiles':[{'candidate_id':x['candidate_id'],'provenance':x['provenance'],'structure_errors':x.get('structure_errors')} for x in profiles if x['conversion_status']=='STRUCTURE_INVALID'],'partial_extractions':[{'candidate_id':x['candidate_id'],'provenance':x['provenance'],'partial_extraction':x['partial_extraction']} for x in profiles if 'partial_extraction' in x],'limits':['Mapped is real typed authoring conversion and structure validation, not runtime activation or complete external semantic agreement.','Custom encounter callbacks require native owners; no callback fabricated from an ability name.']};write(R/'remaining-blockers.json',blockers)
readme='''# Full pinned monster spell authoring import\n\nAll tracked monster files and script packs from observed current Canary 04b83b51 and Crystal 00ce02a5 are retained as distinct donor populations. Converted bundles are genuine existing authoring-schema Creature/Behavior/Presentation plus Ability/Effect/Formula candidates. Mapped source slots preserve source order, interval and chance through the converter. Source parameter tables and exact Git blob/SHA-256 provenance remain in split per-source slot files.\n\n`mapped` does not mean admitted native Game gameplay. Identities remain source scoped; full monster AI and custom encounter callbacks are not enabled. Historical converter engine rules need current parity qualification. External published attack observations are bound separately by the monster-reference report; absent chance/interval/effect values remain unknown.\n\n`registration-capture-closure.json` distinguishes lexical declarations from actual sandbox-captured registrations, including source-disabled examples and opaque entries. `remaining-blockers.json` lists unresolved individual spells, invalid donor creature fields, and source-faithful partial extraction of tables whose top-level encounter setup cannot run outside the engine. SoulWar interval 7 is read from the exact pinned source library; no Zone positions, Storage ids, world state or gameplay callbacks are fabricated.\n\nSource-input Lua/XML/DAT snapshots are local reference inputs and excluded from the review archive. The split source profile and slot files plus all converted JSON bundles are included. The combined convenience arrays are redundant and excluded.\n''';(R/'README.md').write_text(readme)

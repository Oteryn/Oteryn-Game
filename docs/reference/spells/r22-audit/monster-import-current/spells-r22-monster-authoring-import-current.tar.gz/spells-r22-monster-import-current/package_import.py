import json,hashlib,tarfile,gzip,io
from pathlib import Path
from collections import Counter
R=Path('/workspace/spells-r22-monster-import-current')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
slots=load(R/'monster-spell-slots.json')
with (R/'slot-admission-flags.jsonl').open('w') as f:
 for s in slots:
  row={'slot_key':f"{s['source']}/{s['monster_source']['path']}/{s['group']}/{s['source_slot_index']}",'source_exactly_bound':True,'typed_authoring_conversion':s['conversion_status'],'native_execution_ready':False,'runtime_activation':False,'external_complete_verification':False,'execution_blockers':['wild_monster_runtime_not_composed']+(['custom_native_semantics_unresolved'] if s['conversion_status']=='unresolved_semantics' else [])}
  f.write(json.dumps(row,separators=(',',':'))+'\n')
exclude={'monster-profiles.json','monster-spell-slots.json','SHA256SUMS','publication-manifest.json'}
files=sorted(p for p in R.rglob('*') if p.is_file() and p.relative_to(R).parts[0] not in ('source-inputs','__pycache__') and p.name not in exclude and p.suffix in ('.json','.jsonl','.md','.py'))
checksums={p.relative_to(R).as_posix():sha(p) for p in files};(R/'SHA256SUMS').write_text(''.join(f'{h}  {p}\n' for p,h in checksums.items()))
files.append(R/'SHA256SUMS');files.sort()
target=Path('/workspace/spells-r22-monster-authoring-import-current.tar.gz')
with target.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz:
  with tarfile.open(mode='w',fileobj=gz,format=tarfile.PAX_FORMAT) as tar:
   for p in files:
    data=p.read_bytes();info=tarfile.TarInfo('spells-r22-monster-import-current/'+p.relative_to(R).as_posix());info.size=len(data);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(data))
manifest={'archive':str(target),'archive_sha256':sha(target),'archive_bytes':target.stat().st_size,'included_files':len(files),'per_file_sha256':'SHA256SUMS','scope':'Both observed current pinned source populations, all data packs, typed candidate bundles; no native gameplay activation.','excluded':['Original source Lua/XML/DAT snapshots','Redundant combined profile/slot convenience arrays'],'typed_source_slots':len(slots),'conversion_counts':dict(Counter(s['conversion_status'] for s in slots)),'native_execution_ready_slots':0,'source_input_pins':load(R/'summary.json')['sources'],'verification_proof_sha256':sha(R/'verification-proof.json'),'slot_input_sha256':sha(R/'monster-spell-slots.json'),'profile_input_sha256':sha(R/'monster-profiles.json'),'current_branch_heads':'Observed current-head authoring candidates only; no implicit production pin promotion.'}
(R/'publication-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))

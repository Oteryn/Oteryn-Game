# NPC — druga lokalna partia uzupełniania

2026-10-04. Kwalifikowany import danych do lokalnego WorldProject. Bez zmian zamrożonego repo produktu, PR, pushu, wdrożenia i runtime. Nie jest to deklaracja pełnej wykonywalnej zgodności NPC.

## Zmiany rzeczywiście zaimportowane

- **188 ofert w 13 Service:** usunięto count i wpisano tę samą liczbę jako sub_type. Dla każdej oferty udowodniono dokładne pochodzenie z historycznego importera, który kopiował donorowe count oznaczające itemSubType; 173 oferty mają proof obu donorów, 15 Canary. Zachowano wszystkie ceny i pozostałe pola. Nie stosowano ogólnej reguły przepisywania natywnych ilości lub ładunków. Wsparcie: 361 obserwacji, 25 dokładnie sprawdzonych plików źródłowych.
- **31 dodatkowych powiązań źródłowych dla 5 NPC:** Tereban 14, Alesar 6, Henricus 6, Oldrak 3, Halvar 2. Alesar ma wyłącznie dowód załadowania helpera, bez wywołania jego funkcji; tych sześciu zapisów nie uznajemy za aktywne zachowania questa. Każdy rekord zachowuje native Quest/Progress/Transition null i runtime false. Uzupełnienia wskazują zewnętrzny skompresowany sidecar; nie zastępują starej tabeli.
- Powiązania źródłowe dotyczą teraz 336 unikalnych NPC (poprzednio 335); 5 oznacza liczbę zaktualizowanych rekordów w tej partii. Pozostają 33 wstrzymane powiązania: 32 odrębnego typu Captain Haba (Open Sea) i 1 zmiany epoki storage Summer Shirtalis.

Finalny import: **1282 NPC / 836 dialogów / 380 usług / 2564 profile**, IMPORTED_DATA_ONLY, aktorzy 0, aktywowane usługi 0. SHA projektu: e749728fc12b0b79a8a296fdb8b8c8393b5dd2c8b4e7ef0115c8836084347ebc. Limity niezmienione.

Pełna różnica: 18 istniejących deklaracji, pozostałe 2927 deklaracji i wszystkie profile, przedmioty, stare ceny, źródła, archiwum, świat i assets niezmienione. Dane z poprzedniej partii zachowane. Nowy patch jawnie dodaje source_only=true/runtime_eligible=false także do metadanych migracji; oryginalny patch subagenta pozostaje niezmieniony jako dowód.

## Rozliczone dane bez zbędnego importu

- **36 obserwacji podróży:** wszystkie mają już zgodne parametry natywnych tras. 32 helpery zostały dodatkowo udowodnione statycznie. Pozostałe 4 dotyczą Hawkhurst/Hawkhurst Ingol i własnego tekstu `All Hand Hoy!`; brak pola tekstu wyjazdu w Route DTO jest rzeczywistą luką kontraktu. Nie dodano żadnej trasy ani duplikatu. Szczegóły: travel-wrapper-batch/gap-reclassification.json.
- **3821 zapisów usług specjalnych** — 3696 spell learning, 64 blessing, 12 promotion, 49 kick — ma sprawdzony typowany format. Dodatkowo 597 wywołań parsera/banku/opłat zachowano w 246 rekordach plików; to nie liczba bankierów. Wszystkie 4067 rekordów przeszły Rust roundtrip. Minimalna propozycja kontraktu Spell/Blessing pozostaje nieprzyjęta, bez natywnych tożsamości i wykonawcy. Nie osadzono sidecara w WorldProject ani nie wydano wykonywalnych Service. 8 zapisów dla Isimov, Rahkem, Rock With A Soft Spot i Tyrias ma zachowany konflikt nazwy blessing/numeru. Po sprawdzeniu obu dokładnych łańcuchów Lua→C++ udowodniono brak remapu: 6 wskazuje Embrace, podczas gdy Twist ma 1. Nie nadpisano źródeł ani nie wykonano gry live.
- **314 obserwacji zmienionych definicji Item:** 110 różni się wyłącznie wartościami description, 204 innymi danymi definicji. Zweryfikowano oba końce każdej różnicy. To klasyfikacja, nie dowód równoważności znaczenia tekstu, nowe wiązanie EXACT ani dopuszczenie grafiki klienta.

## Weryfikacja i odtworzenie

Niezależny przegląd: continuation-review/RESULT.md. Migracja 15 fixtures PASS; podróże 8 fixtures PASS; usługi specjalne 6 Rust + 10 Python PASS, rzeczywisty native Service i cały typowany sidecar roundtrip PASS. Quest: 71 kotwic dodatkowych źródeł i zakres 31 referencji PASS. Kontrola pełnej różnicy oraz rzeczywisty npc-import PASS.

Pakiet zależy od wcześniejszego kwalifikowanego backupu i poprawek, patch.json.gz oraz hashowanych sidecarów quest-reuse, service-subtype-migration/ready.json.gz i quest-association-repair/repairs.jsonl.gz. Tabele dowodów są zewnętrzne i muszą być zachowane wraz z poprawką. qualification.json przypina ich hashe, bibliotekę, binarium, helper i weryfikator.

Pełne odtworzenie: python3 /workspace/npc-upstream-first-audit/continuation-batch/restore_and_apply.py --scratch-dir /tmp/nowa-nieistniejaca-kopia

Opcja --base-world pozwala wykorzystać wcześniej odtworzony projekt poprzedniej partii; skrypt najpierw wymaga poprawnego natywnego importu z dokładnym SHA bazowym. Oszczędza ponowne odtwarzanie niezmienionego wcześniejszego łańcucha. Test nowej poprawki na świeżej kopii, z wcześniej odtworzoną bazą dopuszczoną przez npc-import i dokładny bazowy SHA, zakończył się PASS_REPRODUCED_LOCAL_CONTINUATION_DATA_IMPORT. Wynik: reproduction.json. Wcześniejszy niezmieniony łańcuch backupu ma odrębny PASS pełnego odtworzenia w full-plan-integration/reproduction.json.

Istniejąca mapa i luka NPC placement/dispatch z poprzedniego raportu pozostają aktualne. Nie wykonywano pozornego E2E ani aktywacji serwera. remaining-work.json zawiera bieżące rzeczywiste braki i właścicieli; nie liczyć obserwacji jako niekompletnych NPC.

Źródła: istniejący cache Canary/Crystal, historyczny importer i aliasy z repo, wcześniejszy chroniony pakiet questów. Dodatkowo pobrano wyłącznie osiem brakujących plików C++ ze zwykłego publicznego HTTP GitHub, po cztery z tych samych przypiętych rewizji donorów. Pełne URL, SHA i kotwice: special-service-contract/blessing-native-chain-proof.json. Sprawdzono SHA256 i Git blob względem zapisanych drzew tych rewizji; wszystkie pełne pliki zachowano lokalnie w blessing-cpp-reference-cache.tar.gz, poza WorldProject. Nie ponawiano pobrania NPC/Lua, nie używano wiki ani Remote Desktop.

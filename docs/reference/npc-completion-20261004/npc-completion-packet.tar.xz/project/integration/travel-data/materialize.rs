use std::{env,fs,path::Path};
use oteryn_game_server::content::*;
fn main()->Result<(),Box<dyn std::error::Error>> {
 let args:Vec<String>=env::args().collect();
 if args.len()!=4{return Err("usage: INPUT PATCH FRESH_OUTPUT, or --check INPUT SHA".into());}
 if args[1]=="--check" {
  let admitted=load_data_only_npc_catalogue(Path::new(&args[2]),&args[3])?;
  println!("{}",serde_json::json!({"status":"PASS_PROPOSED_SCHEMA_DATA_ONLY_IMPORT","source_tree_sha256":admitted.source_tree_digest(),"npcs":admitted.npc_count(),"dialogues":admitted.dialogue_count(),"services":admitted.service_count(),"profiles":admitted.profile_count(),"routes_updated":2,"spawned_actors":0,"activated_services":0,"limits_changed":false,"requires_product_schema_adoption":true}));
  return Ok(());
 }
 let input=Path::new(&args[1]);let output=Path::new(&args[3]);
 if output.exists(){return Err("fresh output required".into());}
 let limits=npc_catalogue_preproduction_limits();
 let project=capture_world_project(input.parent().ok_or("parent")?,input.file_name().ok_or("basename")?,limits)?;
 let before_cat=NpcDataCatalogue::from_project(project.clone(),limits.project)?;
 let patch:serde_json::Value=serde_json::from_slice(&fs::read(&args[2])?)?;
 if before_cat.source_tree_digest()!=patch["base_tree_sha256"].as_str().ok_or("base SHA")?{return Err("base tree drift".into());}
 let mut draft=project.migrate_to_v2(); let mut seen=std::collections::BTreeSet::new();
 let updates=patch["updates"].as_array().ok_or("updates")?;
 if updates.len()!=2{return Err("exactly two route text updates required".into());}
 for u in updates {
  let key=u["service"].as_str().ok_or("service")?;
  if !["oteryn:service.travel.hawkhurst","oteryn:service.travel.hawkhurst_ingol"].contains(&key) || !seen.insert(key.to_string()){return Err("service scope".into());}
  let before:ProjectV2TravelRoute=serde_json::from_value(u["before"].clone())?;
  let after:ProjectV2TravelRoute=serde_json::from_value(u["after"].clone())?;
  let mut stripped=after.clone();stripped.departure_text=None;
  if before.departure_text.is_some() || stripped!=before || after.departure_text.as_deref()!=Some("All Hand Hoy!"){return Err("route nontext mutation".into());}
  let target=draft.state.declarations.iter_mut().find_map(|d|match d {
   ProjectV2Declaration::Service{identity,routes,..} if identity.key==key && identity.revision=="definition-r1"=>Some(routes),_=>None
  }).ok_or("existing service")?;
  let matching:Vec<_>=target.iter().enumerate().filter(|(_,r)|r.key==before.key).map(|(i,_)|i).collect();
  if matching.len()!=1 || target[matching[0]]!=before{return Err("route precondition".into());}
  target[matching[0]]=after;
 }
 draft.core.project_revision="npc-local-proposed-schema-travel-text-v5".into();
 let docs=CanonicalProjectDocuments::from_v2_draft(draft,limits.project)?;
 let parsed=docs.clone().into_snapshot(limits.project)?.parse(limits.project)?;
 let candidate=NpcDataCatalogue::from_project(parsed,limits.project)?;
 let expected=candidate.source_tree_digest().to_string();
 fs::create_dir_all(output)?;
 for (locator,bytes) in docs.documents(){let dest=output.join(locator);fs::create_dir_all(dest.parent().ok_or("parent")?)?;fs::write(dest,bytes)?;}
 let admitted=load_data_only_npc_catalogue(output,&expected)?;
 println!("{}",serde_json::json!({"status":"PASS_PROPOSED_SCHEMA_DATA_ONLY_IMPORT","source_tree_sha256":admitted.source_tree_digest(),"npcs":admitted.npc_count(),"dialogues":admitted.dialogue_count(),"services":admitted.service_count(),"profiles":admitted.profile_count(),"routes_updated":2,"spawned_actors":0,"activated_services":0,"limits_changed":false,"requires_product_schema_adoption":true}));
 Ok(())
}

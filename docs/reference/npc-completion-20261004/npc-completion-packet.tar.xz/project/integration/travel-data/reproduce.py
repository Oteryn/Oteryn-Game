"""Local proposed-schema import; reuses admitted world and exact cached donor proofs."""
import argparse,gzip,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2]
HERE=pathlib.Path(__file__).resolve().parent
RUSTC='/workspace/npc-r7-work/rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/rustc'
STAGE=pathlib.Path('/tmp/npc-condition-action/full-crate')
BASE=pathlib.Path('/tmp/npc-continuation-batch/output/qualified-world')
BASE_SHA='e749728fc12b0b79a8a296fdb8b8c8393b5dd2c8b4e7ef0115c8836084347ebc'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--scratch',required=True);a.add_argument('--base',default=str(BASE));a.add_argument('--resume-materialized',action='store_true');args=a.parse_args()
 scratch=pathlib.Path(args.scratch).resolve();base=pathlib.Path(args.base).resolve()
 if scratch.exists() and not args.resume_materialized:raise ValueError('fresh scratch required')
 if not str(scratch).startswith('/tmp/npc-project-travel-'):raise ValueError('dedicated temporary output required')
 proof=json.loads(gzip.decompress((ROOT/'commerce/departure-text-data.json.gz').read_bytes()))
 assert len(proof['source_observations'])==4 and len(proof['unique_updates'])==2
 for row in proof['source_observations']:
  source=row['source_identity'];raw=pathlib.Path(source['local_path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==source['source_sha256']
  for name in ['parent_anchor','travel_anchor']:
   anchor=row['proof'][name];part=raw[anchor['start_byte']:anchor['end_byte_exclusive']];assert hashlib.sha256(part).hexdigest()==anchor['sha256']
  assert row['proof']['departure_text']=='All Hand Hoy!'
 patch={'base_tree_sha256':BASE_SHA,'updates':proof['unique_updates']};scratch.mkdir(parents=True,exist_ok=args.resume_materialized)
 patchpath=scratch/'patch.json';patchpath.write_text(json.dumps(patch,sort_keys=True,separators=(',',':'))+'\n')
 deps=STAGE/'target/debug/deps';lib=deps/'liboteryn_game_server-af12168ea1a09a4b.rlib';serde=deps/'libserde_json-5944012a39b14cce.rlib'
 helper=scratch/'materialize'
 subprocess.run([RUSTC,'--edition=2024',str(HERE/'materialize.rs'),'-L','dependency='+str(deps),'--extern','oteryn_game_server='+str(lib),'--extern','serde_json='+str(serde),'-o',str(helper)],check=True)
 receipts=[]
 for suffix in ['first','reproduced']:
  output=scratch/suffix/'qualified-world'
  if args.resume_materialized:
   assert output.exists()
   continue
  output.parent.mkdir()
  receipt=json.loads(subprocess.run([str(helper),str(base),str(patchpath),str(output)],capture_output=True,text=True,check=True).stdout)
  receipts.append(receipt)
 if not args.resume_materialized:assert receipts[0]==receipts[1]
 original=json.loads((base/'definitions/declarations.json').read_text())
 updated=json.loads((scratch/'first/qualified-world/definitions/declarations.json').read_text())
 expected=json.loads(json.dumps(original));changes=0
 for u in patch['updates']:
  targets=[r for r in expected['records'] if r.get('identity',{}).get('key')==u['service']];assert len(targets)==1
  routes=targets[0]['routes'];idx=[i for i,r in enumerate(routes) if r['key']==u['route_key']];assert len(idx)==1 and routes[idx[0]]==u['before'];routes[idx[0]]=u['after'];changes+=1
 assert expected==updated and changes==2
 for rel in ['authoring/profiles.json','references/native.json','definitions/world.json']:
  if (base/rel).exists(): assert (base/rel).read_bytes()==(scratch/'first/qualified-world'/rel).read_bytes()
 changed=[]
 for source in base.rglob('*.json'):
  rel=source.relative_to(base);dest=scratch/'first/qualified-world'/rel
  assert dest.exists()
  if source.read_bytes()!=dest.read_bytes():changed.append(str(rel))
 assert set(changed)=={'definitions/declarations.json','project.json','manifest.json','content.lock.json'}
 if args.resume_materialized:
  def tree_sha(path):
   digest=hashlib.sha256()
   for source in sorted(path.rglob('*.json')):
    loc=str(source.relative_to(path)).encode();raw=source.read_bytes();digest.update(len(loc).to_bytes(8,'big'));digest.update(loc);digest.update(len(raw).to_bytes(8,'big'));digest.update(raw)
   return digest.hexdigest()
  assert tree_sha(base)==BASE_SHA
  output=scratch/'first/qualified-world';copy=scratch/'reproduced/qualified-world'
  for source in output.rglob('*.json'):assert source.read_bytes()==(copy/source.relative_to(output)).read_bytes()
  expected_sha=tree_sha(output)
  actual=json.loads(subprocess.run([str(helper),'--check',str(output),expected_sha],capture_output=True,text=True,check=True).stdout)
  receipts=[actual,actual]
 rejected=[]
 for name,mutate in [
  ('base-tree-drift',lambda q:q.update(base_tree_sha256='0'*64)),
  ('price-mutation',lambda q:q['updates'][0]['after'].update(price=401)),
  ('duplicate-target',lambda q:q['updates'].__setitem__(1,q['updates'][0]))]:
  negative=json.loads(json.dumps(patch));mutate(negative);np=scratch/(name+'.json');np.write_text(json.dumps(negative));out=scratch/(name+'-output')
  r=subprocess.run([str(helper),str(base),str(np),str(out)],text=True,capture_output=True)
  assert r.returncode!=0 and not out.exists();rejected.append({'case':name,'error':r.stderr.strip()})
 receipt={'status':'PASS_LOCAL_PROPOSED_SCHEMA_TRAVEL_IMPORT_AND_REPRODUCTION','base_tree_sha256':BASE_SHA,'qualified_project':str(scratch/'first/qualified-world'),'materialization':receipts[0],'exact_changed_documents':changed,'source_anchors_verified':4,'negative_cases':rejected,'all_unrelated_records_preserved':True,'schema_adopted_in_product':False,'runtime_activated':False,'build_inputs':{'helper_source_sha256':sha(HERE/'materialize.rs'),'reproducer_sha256':sha(HERE/'reproduce.py'),'game_rlib_sha256':sha(lib),'serde_rlib_sha256':sha(serde)},'data_patch_sha256':sha(patchpath)}
 (scratch/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt))
if __name__=='__main__':main()

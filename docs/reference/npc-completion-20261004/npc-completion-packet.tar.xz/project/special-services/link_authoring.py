"""Cache-only linkage candidates, never WorldProject admission or acquisition execution."""
import hashlib,json,lzma,pathlib,collections
ROOT=pathlib.Path('/workspace/Oteryn-Game')
BASE=pathlib.Path('/tmp/npc-special-service/source-sidecar.json')
OUT=pathlib.Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normalize(s):return ' '.join(s.casefold().split())
def load_catalog():
 catalog=collections.defaultdict(list)
 for p in sorted((ROOT/'tools/content-schema/spell-authoring/samples/starter-bundles').glob('*/spell.json')):
  d=json.loads(p.read_text())['spell']; m=p.with_name('manifest.json'); manifest=json.loads(m.read_text())
  if d['carrier']!='instant':continue # rune item consumption is not trainer acquisition
  ident=d['identity']; req=d['requirements']
  assert set(ident)=={'key','revision'} and type(req['learning_required']) is bool
  assert all(isinstance(v,str) for v in req['vocations'])
  catalog[normalize(d['name'])].append({'ref':{'family':'Spell',**ident},'name':d['name'], 'carrier':d['carrier'], 'requirements':req,'payload_path':str(p.relative_to(ROOT)),'payload_sha256':sha(p),'manifest_sha256':sha(m),'donor_revisions':{s['repository']:s['revision'] for s in manifest['sources'] if 'repository' in s}})
 return catalog

def classify(row,catalog):
 op=row['operation']; kind=op['kind']; reasons=[]; candidate=None; disposition='HeldSourceOnly'
 if kind=='SpellLearning':
  assert type(op['price_gold']) is int and op['price_gold']>=0 and type(op['premium']) is bool
  matches=catalog.get(normalize(op['spell_source_name']),[])
  if len(matches)==0: reasons.append('MissingCompleteSpellAuthoringPayload')
  elif len(matches)!=1: reasons.append('AmbiguousSpellAuthoringName')
  else:
   candidate=matches[0]; disposition='ExistingSpellAuthoringCandidate'
   repo={'canary':'opentibiabr/canary','crystal':'zimbadev/crystalserver'}[row['source']['source']]
   if candidate['donor_revisions'].get(repo)!=row['source']['revision']:reasons.append('SourceEpochMismatch')
   reasons+=['NameMatchRequiresOwningSpellBinding','WorldProjectSpellFamilyNotAdopted','SourceGateNotExecutable']
   if candidate['requirements']['learning_required'] is False:
    disposition='ModernAutomaticFreeAuthoringCandidate'
    reasons.append('LegacyTrainerQuoteInformationalOnly')
   else: reasons+=['AtomicAcquisitionConsumerMissing','BankDebitContractNotAdopted']
 elif kind=='BlessingPurchase':
  if op['blessing_source_id']==6 and normalize(row['source_observation'].get('keyword',''))=='twist of fate': reasons.append('ProvenStaticBlessingIdentityConflict_6Embrace_1Twist')
  reasons+=['NativeBlessingPolicyBindingMissing','LevelDependentQuoteUnbound','AtomicBlessingConsumerMissing']
 elif kind=='Promotion': reasons+=['NativeVocationTransitionBindingMissing','AtomicPromotionConsumerMissing']
 elif kind=='Kick':reasons+=['SourceCoordinatesNotNativeDestination','ActorTravelFenceConsumerMissing']
 elif kind=='BankApiSites': reasons+=['CallSitesAreNotProviders','BankConsumerContractNotAdopted']
 else: raise ValueError(kind)
 return {'disposition':disposition,'spell_ref_candidate':candidate['ref'] if candidate else None,'held_reasons':reasons,'runtime_admitted':False,'charge_gold':None,'mutate_learned':False}

def main():
 catalog=load_catalog(); rows=json.loads(BASE.read_text()); result=[]
 for i,r in enumerate(rows):result.append({'source_row_index':i,'source':r['source'],'bundle_pointer':r['bundle_pointer'],'source_quote':r['operation'],**classify(r,catalog)})
 counts=collections.Counter(r['disposition'] for r in result); reasons=collections.Counter(x for r in result for x in r['held_reasons'])
 envelope={'base_sidecar_sha256':sha(BASE),'policy':'Accepted S16 automatic/free; source quotes remain informational','catalog':[c for entries in catalog.values() for c in entries],'rows':result}
 raw=json.dumps(envelope,ensure_ascii=False,separators=(',',':')).encode(); (OUT/'authoring-candidates.json.xz').write_bytes(lzma.compress(raw))
 pathlib.Path('/tmp/npc-special-service/authoring-candidates.json').write_bytes(raw)
 summary={'rows':len(result),'dispositions':dict(counts),'held_reasons':dict(reasons),'catalog_instant_payloads':sum(map(len,catalog.values())),'source_files':len({(r['source']['source'],r['source']['path']) for r in rows}),'native_admitted':0,'fee_or_learned_mutations':0,'expanded_sha256':hashlib.sha256(raw).hexdigest()}
 (OUT/'coverage.json').write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps(summary,indent=2))
if __name__=='__main__':main()

//! Proposed private Spell core bridge; source IDs, spell names and execution Ability are excluded.
use super::{CasterState, SpellDefinition};
use super::acquisition_plan::{AcquisitionFacts, AcquisitionFailure, AcquisitionPlan, prepare};
use crate::domain::currency::CoinStack;

pub(crate) fn prepare_bound_spell<'a>(spell: &'a SpellDefinition, player: &CasterState,
    owned_quote_gold: u64, coins: &[CoinStack], entries: usize)
    -> Result<AcquisitionPlan<'a>, AcquisitionFailure> {
    prepare(&AcquisitionFacts {
        spell_key: &spell.key,
        learning_required: spell.learning_required,
        level_required: spell.level,
        premium_required: spell.premium,
        vocation_allowed: spell.vocations.contains(&player.vocation),
        player_level: player.level,
        player_premium: player.premium,
        already_learned: player.learned.contains(&spell.key),
    }, owned_quote_gold, coins, entries)
}
// Deliberately no commit method: Character state plus inventory must share an owning transaction.
// Future owning request must carry CurrentCharacterGameplayFence and CommandRef, recheck the
// Spell revision/quote/current authority, and mint its own existing durability receipt only after
// atomic coin burn/change + learned-key persistence. FeeBurnCause::CharmUnassign cannot be reused.

//! Proposed preparation seam. Never debits inventory, grants a spell, or admits source aliases.
use crate::domain::currency::{CoinStack, FeePlan, FeePlanError, plan_fee};

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct AcquisitionFacts<'a> {
    pub(crate) spell_key: &'a str,
    pub(crate) learning_required: bool,
    pub(crate) level_required: u32,
    pub(crate) premium_required: bool,
    pub(crate) vocation_allowed: bool,
    pub(crate) player_level: u32,
    pub(crate) player_premium: bool,
    pub(crate) already_learned: bool,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum AcquisitionPlan<'a> {
    /// S16: this is information about automatic unlock, not a grant or fee transaction.
    AutomaticFree { spell_key: &'a str, legacy_quote_gold: u64 },
    /// A prepared request only. The owning consumer must revalidate and commit both changes.
    LearningRequired { spell_key: &'a str, fee: Option<FeePlan> },
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum AcquisitionFailure {
    InvalidSpellKey, Level, Premium, Vocation, AlreadyLearned, Fee(FeePlanError),
}
/// Input facts MUST come from a bound SpellDefinition and current server state, not NPC Lua.
/// `quote_gold` is legacy informational for auto unlock; paid acquisition needs an owned quote.
/// Uses the accepted physical-coin planner. Bank money cannot be supplied as synthetic CoinStack.
pub(crate) fn prepare<'a>(facts: &AcquisitionFacts<'a>, quote_gold: u64,
    stacks: &[CoinStack], entries: usize) -> Result<AcquisitionPlan<'a>, AcquisitionFailure> {
    if facts.spell_key.is_empty() { return Err(AcquisitionFailure::InvalidSpellKey); }
    if facts.player_level < facts.level_required { return Err(AcquisitionFailure::Level); }
    if facts.premium_required && !facts.player_premium { return Err(AcquisitionFailure::Premium); }
    if !facts.vocation_allowed { return Err(AcquisitionFailure::Vocation); }
    if !facts.learning_required {
        return Ok(AcquisitionPlan::AutomaticFree { spell_key: facts.spell_key, legacy_quote_gold: quote_gold });
    }
    if facts.already_learned { return Err(AcquisitionFailure::AlreadyLearned); }
    let fee = if quote_gold == 0 { None }
        else { Some(plan_fee(quote_gold, stacks, entries).map_err(AcquisitionFailure::Fee)?) };
    Ok(AcquisitionPlan::LearningRequired { spell_key: facts.spell_key, fee })
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::domain::currency::Coin;
    fn facts() -> AcquisitionFacts<'static> { AcquisitionFacts { spell_key: "fixture:spell/existing",
        learning_required:false,level_required:8,premium_required:false,vocation_allowed:true,
        player_level:8,player_premium:false,already_learned:false } }
    #[test] fn automatic_never_charges_legacy_quote() {
        assert!(matches!(prepare(&facts(),u64::MAX,&[],0),Ok(AcquisitionPlan::AutomaticFree{..})));
    }
    #[test] fn automatic_never_needs_learned_entry() {
        let mut f=facts(); f.already_learned=true;
        assert!(matches!(prepare(&f,500,&[],0),Ok(AcquisitionPlan::AutomaticFree{..})));
    }
    #[test] fn actual_requirement_refusals() {
        let mut f=facts(); f.player_level=7; assert_eq!(prepare(&f,0,&[],0),Err(AcquisitionFailure::Level));
        f.player_level=8;f.premium_required=true; assert_eq!(prepare(&f,0,&[],0),Err(AcquisitionFailure::Premium));
        f.player_premium=true;f.vocation_allowed=false;assert_eq!(prepare(&f,0,&[],0),Err(AcquisitionFailure::Vocation));
    }
    #[test] fn paid_fixture_uses_actual_currency_planner_and_change() {
        let mut f=facts(); f.learning_required=true;
        let coins=[CoinStack{coin:Coin::Platinum,quantity:1,placement_ordinal:1}];
        let result=prepare(&f,35,&coins,1).unwrap();
        match result { AcquisitionPlan::LearningRequired{fee:Some(p),..}=>{
            assert_eq!(p.lines[0].burned,1);assert_eq!(p.change_gold,65);
        },_=>panic!("paid preparation expected") }
        assert_eq!(coins[0].quantity,1); // pure preparation does not mutate durable inputs
    }
    #[test] fn paid_fixture_insufficient_funds_no_grant() {
        let mut f=facts();f.learning_required=true;
        assert_eq!(prepare(&f,100,&[],0),Err(AcquisitionFailure::Fee(FeePlanError::InsufficientFunds)));
    }
    #[test] fn free_required_fixture_skips_zero_fee_planner() {
        let mut f=facts();f.learning_required=true;
        assert!(matches!(prepare(&f,0,&[],0),Ok(AcquisitionPlan::LearningRequired{fee:None,..})));
    }
    #[test] fn learned_paid_fixture_refuses_before_debit() {
        let mut f=facts();f.learning_required=true;f.already_learned=true;
        assert_eq!(prepare(&f,100,&[],0),Err(AcquisitionFailure::AlreadyLearned));
    }
    #[test] fn malformed_binding_rejected() {
        let mut f=facts();f.spell_key="";assert_eq!(prepare(&f,0,&[],0),Err(AcquisitionFailure::InvalidSpellKey));
    }
}

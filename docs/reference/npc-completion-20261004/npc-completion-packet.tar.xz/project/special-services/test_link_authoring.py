import unittest,json,copy,lzma,pathlib
from link_authoring import load_catalog,classify,BASE,OUT
class Tests(unittest.TestCase):
 def setUp(self):
  self.cat=load_catalog();self.rows=json.loads(BASE.read_text());self.row=next(r for r in self.rows if r['operation']['kind']=='SpellLearning' and r['operation']['spell_source_name'].casefold()=='light healing')
 def test_actual_payload_and_epoch(self):
  r=classify(self.row,self.cat);self.assertEqual(r['disposition'],'ModernAutomaticFreeAuthoringCandidate');self.assertIn('SourceEpochMismatch',r['held_reasons']);self.assertEqual(r['spell_ref_candidate']['family'],'Spell');self.assertIsNone(r['charge_gold']);self.assertFalse(r['mutate_learned'])
 def test_missing_payload_not_identity_synthesis(self):
  r=copy.deepcopy(self.row);r['operation']['spell_source_name']='nonexistent fixture';out=classify(r,self.cat);self.assertIsNone(out['spell_ref_candidate']);self.assertIn('MissingCompleteSpellAuthoringPayload',out['held_reasons'])
 def test_ambiguous_name_held(self):
  self.cat['light healing']*=2;self.assertIn('AmbiguousSpellAuthoringName',classify(self.row,self.cat)['held_reasons'])
 def test_paid_fixture_requires_actual_learning_flag_and_owner(self):
  self.cat['light healing'][0]['requirements']['learning_required']=True
  r=classify(self.row,self.cat);self.assertIn('AtomicAcquisitionConsumerMissing',r['held_reasons']);self.assertFalse(r['runtime_admitted']);self.assertIsNone(r['charge_gold'])
 def test_cpp_proven_conflicts_preserved(self):
  conflicts=[r for r in self.rows if r['operation']['kind']=='BlessingPurchase' and r['operation']['blessing_source_id']==6 and r['source_observation'].get('keyword')=='twist of fate'];self.assertEqual(len(conflicts),8)
  for r in conflicts:self.assertIn('ProvenStaticBlessingIdentityConflict_6Embrace_1Twist',classify(r,self.cat)['held_reasons']);self.assertEqual(r['operation']['blessing_source_id'],6)
 def test_full_batch_roundtrip_provenance_and_no_promotion(self):
  data=json.loads(lzma.open(OUT/'authoring-candidates.json.xz','rt').read());self.assertEqual(len(data['rows']),4067)
  self.assertEqual([r['source_row_index'] for r in data['rows']],list(range(4067)))
  for got,original in zip(data['rows'],self.rows):
   self.assertEqual(got['source'],original['source']);self.assertEqual(got['bundle_pointer'],original['bundle_pointer']);self.assertEqual(got['source_quote'],original['operation']);self.assertFalse(got['runtime_admitted']);self.assertIsNone(got['charge_gold']);self.assertFalse(got['mutate_learned'])
 def test_spell_ref_schema_roundtrip_and_wrong_family_negative(self):
  import jsonschema
  from referencing import Registry,Resource
  schema=json.loads((OUT/'authoring-service-proposed.schema.json').read_text());actual=json.loads(pathlib.Path('/workspace/Oteryn-Game/tools/content-schema/spell-authoring/spell.schema.json').read_text())
  monster=json.loads(pathlib.Path('/workspace/Oteryn-Game/tools/content-schema/monster-authoring/monster.schema.json').read_text())
  registry=Registry().with_resources([(actual['$id'],Resource.from_contents(actual)),(monster['$id'],Resource.from_contents(monster))]);v=jsonschema.Draft202012Validator(schema,registry=registry)
  row={'spell':self.cat['light healing'][0]['ref'],'policy':'ModernAutomaticFree','legacy_quote_gold':150};v.validate(json.loads(json.dumps(row)));row['spell']={**row['spell'],'family':'Ability'}
  self.assertTrue(list(v.iter_errors(row)));row['spell']=self.cat['light healing'][0]['ref'];row['charge_gold']=150;self.assertTrue(list(v.iter_errors(row)))
if __name__=='__main__':unittest.main()

# NPC-04: acquisition seam, local unapplied proposal

The server already owns SpellDefinition and CasterState.learned. The current WorldProject/v2 DefinitionFamily owns Ability but does not own Spell. An Ability execution reference is consequently never used as a Spell identity. The existing authoring SpellRef is reused exactly (family, key, revision); adopting a WorldProject Spell family remains an owning content-contract amendment, outside this patch.

## Policy and proposed data shape

Accepted S10 in docs/architecture/OTERYN_SPELL_AUTHORING_SCHEMA_V1.md assigns learning_required to Spell authoring, trainers/prices to NPC acquisition, and learned state to Character. Accepted S16 in the same decision table states modern automatic/free unlocking since 15.22 (2026-01-27), with learning_required=false. Root selected that policy locally for this batch. The new authoring-service schema therefore permits a SpellRef + ModernAutomaticFree + legacy_quote_gold. It has no debit or grant field. The legacy quote is preserved for provenance, never charged for an automatically unlocked definition.

Linkage candidates are not binding proofs. Seven instant starter payloads exist locally; the two rune-carrier payloads with similar names are intentionally excluded. The seven donor manifests use Canary 99902524… and Crystal ff7ede59…, whereas this NPC capture uses Canary 04b83b51… and Crystal 00ce02a5…. All 342 name matches retain SourceEpochMismatch, NameMatchRequiresOwningSpellBinding, WorldProjectSpellFamilyNotAdopted and SourceGateNotExecutable. Normalizing case/whitespace creates a candidate, not an executable alias. Readiness/census records for other spells are metadata and do not replace missing complete authoring payloads.

## Concrete code seam

native-acquisition-preparation-proposed.patch adds two PRIVATE Spell modules, no public identifiers or protocol change. acquisition_bridge::prepare_bound_spell consumes actual SpellDefinition + CasterState. It projects actual native level, vocation membership, premium, learning_required and learned-key membership into the pure planner. Lua vocation IDs and source min_level are not used as player authority.

The planner enforces current requirements. AutomaticFree returns informational data even when the quote is u64::MAX, there are no coins, or a learned entry already exists; no fee planner is called. LearningRequired only occurs for a definition explicitly carrying learning_required=true. It refuses AlreadyLearned, plans an optional nonzero physical-coin fee with existing domain::currency::plan_fee, and returns a PREPARED request. It mutates nothing and cannot acknowledge success. Paid/free-required test cases are labelled fixtures: all seven actual starter definitions in this batch use automatic/free policy.

## Exact remaining ownership amendment

A runtime acquisition command must consume the verified Spell owner binding (existing authoring SpellRef plus owning revision proof), a current owned price quote and current NPC interaction authority. The existing Character/Inventory consumer must gain one atomic operation: revalidate binding/requirements/learned state, burn physical coins and mint change if needed, persist the learned key, then publish its own durable receipt. A failed or stale operation changes neither resource. CasterState is a cast snapshot, not a durable acquisition store.

The request envelope must carry existing durability::character_progression::CurrentCharacterGameplayFence and foundation::protocol::CommandRef. Their game-session identities must agree. The owning transaction checks character revision, session/connection/lease generations, runtime scope and scope ownership generation against current authoritative state. It also fences the quote and Spell revision, makes CommandRef retry idempotent, and uses the receipt of its own successful atomic commit. This patch does not manufacture a receipt, expose a naked mutable learned set as a consumer, or reuse an unrelated fee cause.

Current durability::item_fee_burn::FeeBurnCause only admits CharmUnassign. Add a closed NPC learning cause only in that owning consumer amendment, with an owned NPC acquisition occurrence; Charm occurrence cannot represent NPC learning. Source StdModule.learnSpell can removeMoneyBank. Existing physical coin plans do not authorize bank fallback or synthetic coin stacks. Paid source semantics require the bank owner amendment or an explicit owned policy difference. A caller must never route a paid prepared plan into the existing charm-only writer.

The minimal owned authoring variant for paid learning, when a real learning_required=true definition and atomic consumer exist, would add OwnedAcquisitionQuote rather than blindly adopt source_price. It is deliberately absent from the modern-only authoring schema. No actual current binding in this batch permits that route.

## Other services and preserved conflicts

All 64 blessing rows retain native policy identity, quote formula and atomic consumer holds. The eight captured twist-of-fate/blessing=6 rows remain unchanged. special-service-contract/blessing-native-chain-proof.json proves both pinned StdModule/Player bindings pass 6 directly, native enum/storage identify 6 as Embrace and 1 as Twist. This is a static identity conflict, not a claimed live bug. No automatic 6→1 repair is made.

The 12 promotion rows require a native vocation transition and atomic consumer; 49 kick rows need native actor/destination bindings and fenced movement. The 246 BankApiSites rows represent 597 call sites across 246 donor files, not 246 bank providers. None is promoted into a native service.

## Validation boundary

All 4,067 rows roundtrip with exact source pin/hash, pointer and unchanged quote. Seven Python tests include missing payload, ambiguous names, epoch mismatch, paid-owner hold, eight preserved conflicts, exact-batch reconciliation and actual SpellRef schema validation with wrong Ability family/extra charge rejected. Eight preparation Rust tests plus eight existing currency tests pass. The exact proposed patch applies cleanly to frozen product source and passed offline full game-server lib typechecking in the previously created /tmp stage at 10:14–10:15 UTC. Root subsequently clarified exclusive ownership of that shared integration stage; all worker stage writes/checks stopped immediately. No complete stage snapshot was captured, so this PASS is not independent or combined root qualification. Root must integrate the frozen patch and qualify it once. No fresh workspace copy was created. Product integration tests/runtime admission/atomic persistence are not established by that check.

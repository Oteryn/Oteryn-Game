//! Proposed content staging seam. Qualification preserves CandidateOnly; it does not issue
//! a native actor definition, executable placement, Content generation or current authority.
use super::{
    NpcDataCatalogue, ProjectError, ProjectV2AuthoringProfile, ProjectV2Declaration,
    ProjectV2DefinitionRef, ProjectV2Disposition, ProjectV2Family, ProjectV2Placement,
};

#[derive(Debug)]
pub(crate) struct NpcContentBinding<'a> {
    pub expected_tree_sha256: &'a str,
    pub expected_project_revision: &'a str,
    pub npc: &'a ProjectV2DefinitionRef,
    pub placement_key: &'a str,
}

/// Private, borrowed, canonical payload. No source classification is upgraded by this type.
#[derive(Debug)]
pub(crate) struct NpcContentCandidate<'a> {
    placement: &'a ProjectV2Placement,
    declaration: &'a ProjectV2Declaration,
    presentation: Option<&'a ProjectV2AuthoringProfile>,
    behavior: Option<&'a ProjectV2AuthoringProfile>,
    services: Vec<&'a ProjectV2Declaration>,
    source_tree_sha256: &'a str,
    project_revision: &'a str,
}

impl NpcDataCatalogue {
    pub(crate) fn qualify_npc_content(
        &self,
        binding: NpcContentBinding<'_>,
    ) -> Result<NpcContentCandidate<'_>, ProjectError> {
        if binding.expected_tree_sha256 != self.source_tree_digest()
            || binding.expected_project_revision != self.project_revision()
        {
            return Err(ProjectError::InvalidProject(
                "NPC content source binding mismatch",
            ));
        }
        if binding.npc.family != ProjectV2Family::Npc {
            return Err(ProjectError::InvalidProject("NPC content family mismatch"));
        }
        let declaration = self
            .declaration(binding.npc)
            .ok_or(ProjectError::InvalidProject(
                "NPC content exact definition missing",
            ))?;
        let ProjectV2Declaration::Npc {
            presentation,
            behavior,
            services,
            ..
        } = declaration
        else {
            return Err(ProjectError::InvalidProject(
                "NPC content declaration mismatch",
            ));
        };
        let placement = self
            .placements()
            .iter()
            .find(|p| p.key == binding.placement_key)
            .ok_or(ProjectError::InvalidProject(
                "NPC content placement missing",
            ))?;
        if &placement.definition != binding.npc {
            return Err(ProjectError::InvalidProject(
                "NPC content placement definition mismatch",
            ));
        }
        // The existing WorldProject parser owns world/frame/floor/bounds and reference validation.
        // Resolving exact borrowed members avoids introducing a second index or dialogue parser.
        let profile = |reference: &Option<ProjectV2DefinitionRef>| {
            reference
                .as_ref()
                .map(|r| {
                    self.profile(r).ok_or(ProjectError::InvalidProject(
                        "NPC content referenced profile missing",
                    ))
                })
                .transpose()
        };
        let services = services
            .iter()
            .map(|r| {
                self.declaration(r)
                    .filter(|d| matches!(d, ProjectV2Declaration::Service { .. }))
                    .ok_or(ProjectError::InvalidProject(
                        "NPC content referenced service missing",
                    ))
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(NpcContentCandidate {
            placement,
            declaration,
            presentation: profile(presentation)?,
            behavior: profile(behavior)?,
            services,
            source_tree_sha256: self.source_tree_digest(),
            project_revision: self.project_revision(),
        })
    }
}

impl<'a> NpcContentCandidate<'a> {
    pub(crate) fn placement(&self) -> &'a ProjectV2Placement {
        self.placement
    }
    pub(crate) fn declaration(&self) -> &'a ProjectV2Declaration {
        self.declaration
    }
    pub(crate) fn profiles(
        &self,
    ) -> (
        Option<&'a ProjectV2AuthoringProfile>,
        Option<&'a ProjectV2AuthoringProfile>,
    ) {
        (self.presentation, self.behavior)
    }
    pub(crate) fn services(&self) -> &[&'a ProjectV2Declaration] {
        &self.services
    }
    pub(crate) fn source_binding(&self) -> (&'a str, &'a str) {
        (self.source_tree_sha256, self.project_revision)
    }
    pub(crate) fn disposition(&self) -> ProjectV2Disposition {
        self.placement.disposition
    }
}

#[cfg(test)]
mod tests {
    #![allow(clippy::expect_used)]
    use super::*;
    use crate::content::*;

    fn fixture(rich: bool) -> (
        NpcDataCatalogue,
        ProjectV2DefinitionRef,
        ProjectEvidenceLimits,
    ) {
        let limits = ProjectEvidenceLimits {
            max_documents: 12,
            max_document_bytes: 65536,
            max_total_bytes: 262144,
            max_json_depth: 24,
            max_decoded_fields: 4096,
            max_string_bytes: 32768,
            max_locator_bytes: 160,
            max_locator_segments: 8,
            max_reference_records: 64,
            max_import_records: 8,
            max_reimport_states: 8,
        };
        let npc = ProjectV2DefinitionRef {
            family: ProjectV2Family::Npc,
            key: "oteryn:npc.courier".into(),
            revision: "definition-r1".into(),
        };
        let mut draft = ProjectV2Draft {
            core: ProjectDraft {
                project_revision: "project-r1".into(),
                package_key: "oteryn:content.world-project".into(),
                semantic_schema_version: "reference-schema-v1".into(),
                licensing_metadata: "license:project-owned-v1".into(),
                world_id: "0123456789ab70cd8ef0123456789abc".into(),
                coordinate_frame: "oteryn:frame.courier".into(),
                records: vec![],
                imports: vec![],
                metadata: vec![],
            },
            state: ProjectV2State {
                declarations: vec![ProjectV2Declaration::Npc {
                    identity: ProjectV2Identity {
                        key: npc.key.clone(),
                        revision: npc.revision.clone(),
                    },
                    presentation: None,
                    behavior: None,
                    dialogue: None,
                    services: vec![],
                    fields: vec![],
                }],
                worlds: vec![ProjectV2World {
                    key: "oteryn:world.courier".into(),
                    world_id: "0123456789ab70cd8ef0123456789abc".into(),
                    coordinate_frame: "oteryn:frame.courier".into(),
                    bounds: ProjectV2Bounds {
                        min_x: 0,
                        min_y: 0,
                        max_x_exclusive: 2,
                        max_y_exclusive: 2,
                    },
                    floors: vec![0],
                }],
                placements: vec![ProjectV2Placement {
                    key: "oteryn:placement.courier".into(),
                    world: "oteryn:world.courier".into(),
                    map_revision: "map-r1".into(),
                    definition: npc.clone(),
                    area: None,
                    document: None,
                    parent_placement: None,
                    coordinate_frame: "oteryn:frame.courier".into(),
                    x: 1,
                    y: 0,
                    floor: 0,
                    presentation_order: ProjectV2PresentationOrder { plane: 1, order: 0 },
                    disposition: ProjectV2Disposition::CandidateOnly,
                }],
                ..ProjectV2State::default()
            },
        };
        if rich {
            let presentation = ProjectV2DefinitionRef { family: ProjectV2Family::Presentation, key: "oteryn:presentation.courier".into(), revision: "definition-r1".into() };
            let behavior = ProjectV2DefinitionRef { family: ProjectV2Family::Behavior, key: "oteryn:behavior.courier".into(), revision: "definition-r1".into() };
            for r in [&presentation, &behavior] {
                draft.core.records.push(ProjectReferenceRecord::Generic { identity: DefinitionIdentityDocument { family: if r.family == ProjectV2Family::Presentation { "Presentation" } else { "Behavior" }.into(), key: r.key.clone(), revision: r.revision.clone() }, client_projection: ProjectionDocument::ServerOnly });
            }
            let profiles: Vec<ProjectV2AuthoringProfile> = serde_json::from_str(r#"[
                {"target":{"family":"Presentation","key":"oteryn:presentation.courier","revision":"definition-r1"},"data":{"kind":"Presentation","profile":{"asset_binding":"canary.appearance:outfit/129","selection":null,"palette_bindings":[],"attachment_bindings":[],"visual_effect_bindings":[],"light_level":0,"light_color_binding":null,"audio_bindings":[],"variant_label":null,"status_marker":null}}},
                {"target":{"family":"Behavior","key":"oteryn:behavior.courier","revision":"definition-r1"},"data":{"kind":"Behavior","profile":{"movement":{"can_walk":true,"pass_through":false,"pushable":false,"push_items":false,"push_creatures":false,"walks_on_energy":false,"walks_on_fire":false,"walks_on_poison":false,"wander":null},"targeting":{"hostile":false,"can_target":false,"sense_invisible":false,"target_distance_tiles":0,"static_attack_chance_ppm":0,"flee_health":0,"change_target":null,"strategy_weights":null},"attacks":[],"defenses":[],"voices":null,"summons":null,"periodic_audio":null,"faction":null,"event_bindings":[]}}}
            ]"#).expect("actual profile DTOs");
            draft.state.authoring_profiles = profiles;
            let service = ProjectV2DefinitionRef { family: ProjectV2Family::Service, key: "oteryn:service.courier".into(), revision: "definition-r1".into() };
            if let ProjectV2Declaration::Npc { presentation: p, behavior: b, services, .. } = &mut draft.state.declarations[0] { *p = Some(presentation); *b = Some(behavior); services.push(service.clone()); }
            draft.state.declarations.push(ProjectV2Declaration::Service { identity: ProjectV2Identity { key: service.key, revision: service.revision }, offers: vec![], recipes: vec![], routes: vec![], fields: vec![] });
            let mut other = draft.state.declarations[0].clone();
            if let ProjectV2Declaration::Npc { identity, .. } = &mut other { identity.key = "oteryn:npc.other".into(); }
            draft.state.declarations.push(other);
            let mut placement = draft.state.placements[0].clone();
            placement.key = "oteryn:placement.other".into(); placement.definition.key = "oteryn:npc.other".into(); placement.x = 0;
            draft.state.placements.push(placement);
        }
        let documents = CanonicalProjectDocuments::from_v2_draft(draft, limits).expect("canonical");
        let project = ProjectSnapshot::new(documents.documents().clone(), limits)
            .expect("snapshot")
            .parse(limits)
            .expect("admit");
        (
            NpcDataCatalogue::from_project(project, limits).expect("catalogue"),
            npc,
            limits,
        )
    }

    #[test]
    fn exact_content_qualification_retains_candidate_and_unfilled_profiles() {
        let (catalogue, npc, _) = fixture(false);
        let binding = NpcContentBinding {
            expected_tree_sha256: catalogue.source_tree_digest(),
            expected_project_revision: catalogue.project_revision(),
            npc: &npc,
            placement_key: "oteryn:placement.courier",
        };
        let qualified = catalogue
            .qualify_npc_content(binding)
            .expect("exact qualification");
        assert_eq!(qualified.disposition(), ProjectV2Disposition::CandidateOnly);
        assert_eq!(qualified.placement().definition, npc);
        assert_eq!(
            qualified.source_binding(),
            (catalogue.source_tree_digest(), "project-r1")
        );
        assert_eq!(qualified.profiles(), (None, None));
        assert!(qualified.services().is_empty());
        assert!(matches!(
            qualified.declaration(),
            ProjectV2Declaration::Npc { .. }
        ));
    }

    #[test]
    fn source_substitution_wrong_revision_and_placement_are_refused() {
        let (catalogue, npc, _) = fixture(false);
        let check = |tree, revision, target, placement| {
            catalogue
                .qualify_npc_content(NpcContentBinding {
                    expected_tree_sha256: tree,
                    expected_project_revision: revision,
                    npc: target,
                    placement_key: placement,
                })
                .is_err()
        };
        let wrong_tree = "0".repeat(64);
        assert!(check(
            &wrong_tree,
            catalogue.project_revision(),
            &npc,
            "oteryn:placement.courier"
        ));
        assert!(check(
            catalogue.source_tree_digest(),
            "project-r2",
            &npc,
            "oteryn:placement.courier"
        ));
        let mut wrong = npc.clone();
        wrong.revision = "definition-r2".into();
        assert!(check(
            catalogue.source_tree_digest(),
            catalogue.project_revision(),
            &wrong,
            "oteryn:placement.courier"
        ));
        assert!(check(
            catalogue.source_tree_digest(),
            catalogue.project_revision(),
            &npc,
            "oteryn:placement.other"
        ));
        let mut wrong_family = npc.clone();
        wrong_family.family = ProjectV2Family::Creature;
        assert!(check(
            catalogue.source_tree_digest(),
            catalogue.project_revision(),
            &wrong_family,
            "oteryn:placement.courier"
        ));
    }

    #[test]
    fn bound_profiles_services_resolve_and_foreign_npc_placement_is_refused() {
        let (catalogue, npc, _) = fixture(true);
        let bind = |placement_key| NpcContentBinding { expected_tree_sha256: catalogue.source_tree_digest(), expected_project_revision: catalogue.project_revision(), npc: &npc, placement_key };
        let candidate = catalogue.qualify_npc_content(bind("oteryn:placement.courier")).expect("bound content");
        let (presentation, behavior) = candidate.profiles();
        assert_eq!(presentation.expect("Presentation").target.key, "oteryn:presentation.courier");
        assert_eq!(behavior.expect("Behavior").target.key, "oteryn:behavior.courier");
        assert_eq!(candidate.services().len(), 1);
        assert!(matches!(candidate.services()[0], ProjectV2Declaration::Service { identity, .. } if identity.key == "oteryn:service.courier"));
        assert!(std::ptr::eq(candidate.declaration(), catalogue.declaration(&npc).expect("same canonical NPC")));
        assert!(catalogue.qualify_npc_content(bind("oteryn:placement.other")).is_err());
    }
}

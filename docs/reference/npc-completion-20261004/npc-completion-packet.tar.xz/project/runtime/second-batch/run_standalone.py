#!/usr/bin/env python3
"""Exact proposed local catalogue/module, linked to the real cached native admission APIs."""
from pathlib import Path
import hashlib, json, subprocess
out = Path(__file__).resolve().parent
stage = Path('/tmp/npc-content-second')
stage.mkdir(exist_ok=True)
product = Path('/workspace/Oteryn-Game')
manifest = json.loads((out/'manifest.json').read_text())
module = (out/'npc_content_candidate.rs').read_bytes()
assert hashlib.sha256(module).hexdigest() == manifest['module_sha256']
(stage/'npc_content_candidate.rs').write_bytes(module)
catalogue = (product/'apps/game-server/src/content/npc_catalogue.rs').read_text()
catalogue = catalogue.replace('    pub fn project_revision(&self) -> &str {',
 '    pub(crate) fn placements(&self) -> &[super::ProjectV2Placement] { self.project.v2().map_or(&[], |state| state.placements.as_slice()) }\n    pub fn project_revision(&self) -> &str {')
(stage/'npc_catalogue.rs').write_text(catalogue)
(stage/'wrapper.rs').write_text('''extern crate oteryn_game_server;
extern crate sha2;
extern crate serde_json;
mod content {
 pub use oteryn_game_server::content::*;
 #[path = "/tmp/npc-content-second/npc_catalogue.rs"] mod local_catalogue;
 pub use local_catalogue::NpcDataCatalogue;
 #[path = "/tmp/npc-content-second/npc_content_candidate.rs"] mod npc_content_candidate;
}
''')
deps = Path('/tmp/npc-condition-action/full-crate/target/debug/deps')
rustc = '/workspace/npc-r7-work/rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/rustc'
command = [rustc, '--edition', '2024', '--test', str(stage/'wrapper.rs'),
 '--extern', f'oteryn_game_server={deps}/liboteryn_game_server-af12168ea1a09a4b.rlib',
 '--extern', f'sha2={sorted(deps.glob("libsha2-*.rlib"))[0]}',
 '--extern', f'serde_json={deps}/libserde_json-5944012a39b14cce.rlib',
 '-L', f'dependency={deps}', '-o', str(stage/'tests')]
try:
 subprocess.run(command, check=True)
 result = subprocess.run([str(stage/'tests'), '--nocapture'], check=True, capture_output=True, text=True)
 (stage/'test-output.txt').write_text(result.stdout + result.stderr)
 print(result.stdout)
finally:
 (stage/'tests').unlink(missing_ok=True)

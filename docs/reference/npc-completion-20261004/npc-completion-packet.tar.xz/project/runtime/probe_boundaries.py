#!/usr/bin/env python3
"""Compile actual cached accepted types, never compile/start the server."""
import json, pathlib, subprocess, tempfile
ROOT=pathlib.Path('/workspace/Oteryn-Game')
RUST='/workspace/npc-r7-work/rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/rustc'
DEPS=ROOT/'target/debug/deps'
CASES={
 'authoring_npc_placement_is_expressible': ('oteryn_game_server', 'liboteryn_game_server-af12168ea1a09a4b.rlib', 'use oteryn_game_server::content::{ProjectV2Placement,ProjectV2Family}; pub fn npc(p: &ProjectV2Placement) -> bool { p.definition.family == ProjectV2Family::Npc }', True),
 'native_definition_npc_not_expressible': ('oteryn_game_server', 'liboteryn_game_server-af12168ea1a09a4b.rlib', 'use oteryn_game_server::content::DefinitionFamily; pub fn npc() -> DefinitionFamily { DefinitionFamily::Npc }', False),
 'wire_entity_npc_not_expressible': ('oteryn_protocol_oteryn', 'liboteryn_protocol_oteryn-f0971db6a807bc00.rlib', 'use oteryn_protocol_oteryn::world_spatial_entities::EntityKind; pub fn npc() -> EntityKind { EntityKind::Npc }', False),
}
def run():
 out={}
 with tempfile.TemporaryDirectory(prefix='npc-runtime-boundary-',dir='/tmp') as d:
  for name,(crate,rlib,source,should_pass) in CASES.items():
   src=pathlib.Path(d)/f'{name}.rs'; src.write_text(source)
   cmd=[RUST,'--edition=2024','--crate-type=lib','--emit=metadata','--out-dir',d,'-L',f'dependency={DEPS}','--extern',f'{crate}={DEPS/rlib}',str(src)]
   p=subprocess.run(cmd,text=True,capture_output=True,timeout=30)
   passed=p.returncode==0
   assert passed==should_pass,(name,p.stderr)
   if not should_pass:
    assert 'no variant or associated item named `Npc`' in p.stderr,(name,p.stderr)
   out[name]={'expected_compile_success':should_pass,'actual_compile_success':passed,'stderr':p.stderr,'command':cmd}
 return {'status':'PASS_ACTUAL_TYPE_BOUNDARY_PROBES','scope':'cached accepted type metadata, not gameplay execution','cases':out}
if __name__=='__main__':
 result=run(); pathlib.Path(__file__).with_name('boundary-probes.json').write_text(json.dumps(result,indent=2)+'\n'); print(result['status'])

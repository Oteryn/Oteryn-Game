# Decyzje architekta — lokalny projekt

Status: decyzje organizujące lokalną pracę i projektowane poprawki; nie zastępują accepted contracts produktu.

1. Istniejący WorldProject jest katalogiem danych. Actor placement, dialogue dispatch i service transaction są odrębnymi wymaganiami ścieżki runtime. Potwierdzenie npc-import nigdy nie oznacza uruchomienia aktorów.
2. Jeden wspólny kontrakt warunku questa i uporządkowanego wyniku rozmowy/usługi, oparty na istniejących prototypach. Źródłowe odwołania i proof zostają w authoringu; wykonawca konsumuje wyłącznie zweryfikowane natywne wiązania.
3. Uczestnicy nie tworzą konkurencyjnych parserów aliasów questa ani nowych publicznych identyfikatorów jako obejścia braków. Rozwiązanie ma korzystać z istniejących systemów postępu, inventory/wallet, Spell acquisition i blessing policy; gdy seam nie istnieje, trzeba wskazać i zaproponować najmniejszy patch.
4. Import danych to jedna kontrolowana operacja root na kopii kwalifikowanego projektu, z preconditions, zachowaniem niezależnych rekordów i limitem bez zmian. Sidecary źródeł pozostają hashowane i jawnie zewnętrzne.
5. Trzy poziomy wyniku: zachowane/dopasowane źródło; zweryfikowane natywne dane; zweryfikowane zachowanie runtime. Statusy nie są zamienne.
6. Docelowa próba obejmuje powitanie/odpowiedź, odmowę warunku, udaną usługę, odmowę bez utraty pieniędzy/przedmiotu, zmianę postępu oraz ponowne odczytanie stanu. Istniejące receipt/session-generation/world-channel fence pozostają obowiązkowe; braków nie zastępujemy fikcyjnym receipt.

Otwarty wybór nie staje się domyślną wartością: wariant Captain Haba Open Sea, źródłowa epoka Shirtalis, konflikty cen, źródłowe blessing 6 vs Twist 1 i brakujące Item IDs mają jawne rozstrzygnięcia, nie domniemania.

## Wybrane rozwiązania i korekty po przeglądzie

- Native Transition oznacza routing świata. Nie wolno użyć go jako tożsamości mutacji questa. Quest source linker i rola QuestEffect wymagają osobnego jawnego kontraktu postępu/efektów, bez dodawania surowych storage do runtime.
- Topic jest Option<u16> w prywatnej rozmowie scope session-generation/NPC: brak pozostaje nil, addInteraction ustawia 0, removeInteraction usuwa stan. Program rozmowy max8: EmitReply dokładnie raz (używa istniejącego reply), SetTopic, RequestOutcome max1 z role-checked Interaction. Brak programu deleguje pełną ścieżkę legacy wraz z flagami; nie wolno pominąć reset/ungreet.
- Accepted S16: spelle automatycznie/darmowo odblokowane nie generują płatnej nauki. Ceny dawnych trainerów zachowujemy jako źródłowe informacje; nie naliczamy fikcyjnej opłaty. Używamy istniejącego SpellRef authoringu, nie Ability; WorldProject Spell-family adoption pozostaje nazwanym owning amendment.
- TravelRoute: proponowane optional departure_text, serde default/omitNone, istniejący SourceText validator. To minimalna luka danych dla dwóch istniejących tras z czterech obserwacji; nie tworzymy nowych route IDs.
- Istniejący ProjectV2Placement potrafi wskazać NPC. Problem runtime leży w native DefinitionFamily/actor-carrier/visibility i CHAT dispatch, nie w authoringowym typie placement. Nie tworzymy nowej mapy, tagów protokołu na wyczucie ani Creature udającego NPC.
- Native projektowe ceny i znane Item values pozostają, gdy donor jest hipotezą lub konfliktem. Bieżąca kwalifikacja source pin, canonical alias, known-field projection i appearance to osobne dowody.
- Rabat postman w source custom_modules używa Storage.Quest.ExampleQuest, nie nazwy zadania Postman. Brak tego w 352 source Quest definitions; auxpack ma tabelę, global loader jest nieudowodniony. Zachowujemy pack-qualified source gate bez domyślnego native binding.

"""Reference quote lowering, NOT a runtime transaction or native quest linker."""
from dataclasses import dataclass
@dataclass(frozen=True)
class LinkedDiscount:
    native_gate_ref: str
    amount_gold: int
    def __post_init__(self):
        if not self.native_gate_ref or type(self.amount_gold) is not int or self.amount_gold < 0:
            raise ValueError('verified shared native gate reference and nonnegative integer amount required')
def source_quote(authored_price, free_travel, discounts, gate_results):
    if type(authored_price) is not int or not 0 <= authored_price <= 2**64-1 or type(free_travel) is not bool:
        raise ValueError('typed authored price/free-travel input required')
    if free_travel or authored_price == 0:return 0
    total=0
    for rule in discounts:
        if rule.native_gate_ref not in gate_results or type(gate_results[rule.native_gate_ref]) is not bool:
            raise ValueError('shared gate was not evaluated; do not default missing storage/track')
        if gate_results[rule.native_gate_ref]:total+=rule.amount_gold
    return max(0,authored_price-total)
SOURCE_EFFECT_ORDER=('interaction','free_override','discount_clamp','premium','minimum_level','pz_lock','bank_debit','exhaustion','remove_interaction','departure_text','destination_resolution','set_exhaustion','teleport','effect','achievement','quest_update','reset_npc')

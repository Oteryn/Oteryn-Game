"""Pinned source conflict reconciliation; never chooses a donor price."""
import collections,gzip,hashlib,json,pathlib,sys
BASE=pathlib.Path('/workspace/npc-upstream-first-audit'); HERE=pathlib.Path(__file__).parent
sys.path.insert(0,str(BASE/'native-service-batch'));import prepare as shared
WORLD=pathlib.Path('/tmp/npc-continuation-batch/output/qualified-world')
INPUT=BASE/'full-plan-integration/service-conflicts.jsonl.gz'
TMP=pathlib.Path('/tmp/npc-commerce-project');TMP.mkdir(exist_ok=True)
canon=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def identity(v):return canon({k:x for k,x in v.items() if k!='unit_price'})
def classify(rows,current):
 values={canon(r['value']) for r in rows}; exact=[r for r in rows if r['value'] in current]
 if len(values)>1:return 'DONOR_CONFLICT_ALREADY_PRESENT_SOME' if exact else 'DONOR_CONFLICT_NO_EXACT_NATIVE'
 if len(exact)==len(rows):return 'ALREADY_IMPORTED_EXACT'
 if any(identity(r['value'])==identity(x) for r in rows for x in current):return 'AUTHORING_PRICE_PRESERVED'
 return 'GENUINELY_MISSING_NO_AUTOMATIC_PRIORITY'
def deduplicate_price_observations(output):
 groups=collections.defaultdict(list)
 for group in output:
  if group['old_reason'] not in {'EXISTING_NATIVE_PRICE_DIFFERENT_PRESERVED','DONOR_PRICE_OR_METADATA_CONFLICT'}:continue
  for row in group['source_rows']:
   groups[(group['service'],canon(row['value']))].append({'source':row['source'],'service_row':row['service_row'],'shop_proof':row['shop_proof'],'old_reason':group['old_reason']})
 return [{'service':service,'candidate_offer':json.loads(value),'source_proofs':proofs,'runtime_eligible':False} for (service,value),proofs in sorted(groups.items())]
def main():
 groups=[json.loads(l) for l in gzip.open(INPUT,'rt')];native=json.loads((WORLD/'definitions/declarations.json').read_text());services={r['identity']['key']:r for r in native['records'] if r['kind']=='Service'}
 source_cache={};output=[];flat=collections.Counter();statuses=collections.Counter();dedup=set()
 for n,g in enumerate(groups):
  current=services.get(g['service'],{}).get('offers',[])
  for row in g['rows']:
   s=row['source'];sid=(s['repository'],s['revision'],s['path'],s['source_sha256'])
   if sid not in source_cache:
    b=pathlib.Path(s['local_path']).read_bytes();assert hashlib.sha256(b).hexdigest()==s['source_sha256'];source_cache[sid]=b.decode()
   p=row['shop_proof'];text=source_cache[sid][p['assignment_start']:p['assignment_end']];rhs=text.split('=',1)[1].strip();parsed=shared.table(shared.lo.Parser(rhs).parse());assert shared.hashj(parsed)==p['literal_shop_sha256']
   flat[g['reason']]+=1;dedup.add((g['service'],canon(row['value']),sid,row['service_row']))
  status=classify(g['rows'],current);statuses[status]+=1
  output.append({'input_group':n,'service':g['service'],'old_reason':g['reason'],'status':status,'current_authoring_offers':[x for x in current if any(x['item']==r['value']['item'] and x['direction']==r['value']['direction'] for r in g['rows'])],'historical_existing':g.get('existing'),'source_rows':g['rows'],'runtime_eligible':False})
 with gzip.open(TMP/'reconciliation.jsonl.gz','wt') as f:
  for row in output:f.write(canon(row)+'\n')
 summary={'status':'PASS_FULL_ROW_RECONCILIATION_NO_PRICE_OVERRIDE','groups':len(groups),'source_observations_by_reason':dict(flat),'group_statuses':dict(statuses),'unique_source_observations':len(dedup),'source_bodies_verified':len(source_cache),'qualified_repair_updates':0,'authoring_price_overrides':0,'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'world_declarations_sha256':hashlib.sha256((WORLD/'definitions/declarations.json').read_bytes()).hexdigest(),'full_rows_path':str(TMP/'reconciliation.jsonl.gz'),'full_rows_sha256':hashlib.sha256((TMP/'reconciliation.jsonl.gz').read_bytes()).hexdigest(),'runtime_executed':False}
 dedup_prices=deduplicate_price_observations(output);path=TMP/'deduplicated-price-observations.json.gz';path.write_bytes(gzip.compress((canon(dedup_prices)+'\n').encode(),mtime=0))
 summary.update(price_donor_input_observations=flat['EXISTING_NATIVE_PRICE_DIFFERENT_PRESERVED']+flat['DONOR_PRICE_OR_METADATA_CONFLICT'],price_donor_unique_semantic_variants=len(dedup_prices),dedup_full_provenance_path=str(path),dedup_full_provenance_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 (HERE/'reconciliation-summary.json').write_text(json.dumps(summary,indent=2)+'\n');(HERE/'repair-patch.json').write_text('{"updates":[]}\n');print(json.dumps(summary))
if __name__=='__main__':main()

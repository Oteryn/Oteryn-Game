// LOCAL PROPOSAL ONLY. Import the single shared gate from quest-linking/dialogue;
// do not copy its definition or infer a native quest from a discount label.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectV2TravelDiscount {
    pub gate: ProjectV2NpcQuestGate,
    pub amount_gold: u64,
}
// Proposed optional existing ProjectV2TravelRoute member:
// #[serde(default, skip_serializing_if = "Vec::is_empty")]
// pub discounts: Vec<ProjectV2TravelDiscount>,
// Authored route.price is preserved. IsTravelFree policy is not defaulted here.
// Source array discount order and duplicate entries must remain in authored order.
// The source performs removeMoneyBank BEFORE its exhaustion predicate. A runtime
// transaction amendment must explicitly resolve refusal-without-loss; this DTO
// proposal must not reorder or execute those operations.

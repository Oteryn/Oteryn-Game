import unittest
import reconcile as r
class Tests(unittest.TestCase):
 def setUp(self):self.offer={'item':{'key':'oteryn:item.tibia.i1'},'direction':'SellToPlayer','unit_price':20}
 def test_dedup_keeps_both_source_proofs(self):
  group={'service':'oteryn:service.trade.sample','old_reason':'EXISTING_NATIVE_PRICE_DIFFERENT_PRESERVED','source_rows':[{'value':self.offer,'source':{'source':name},'service_row':1,'shop_proof':{'literal':'proof'}} for name in ['canary','crystal']]}
  out=r.deduplicate_price_observations([group]);self.assertEqual(len(out),1);self.assertEqual(len(out[0]['source_proofs']),2)
 def test_project_price_preserved(self):self.assertEqual(r.classify([{'value':dict(self.offer,unit_price=40)}],[self.offer]),'AUTHORING_PRICE_PRESERVED')
 def test_already_exact(self):self.assertEqual(r.classify([{'value':self.offer}],[self.offer]),'ALREADY_IMPORTED_EXACT')
 def test_donor_disagreement(self):self.assertEqual(r.classify([{'value':self.offer},{'value':dict(self.offer,unit_price=40)}],[self.offer]),'DONOR_CONFLICT_ALREADY_PRESENT_SOME')
 def test_missing_is_separate(self):self.assertEqual(r.classify([{'value':self.offer}],[]),'GENUINELY_MISSING_NO_AUTOMATIC_PRIORITY')
 def test_subtype_not_price(self):self.assertEqual(r.classify([{'value':dict(self.offer,sub_type=7)}],[self.offer]),'GENUINELY_MISSING_NO_AUTOMATIC_PRIORITY')

from source_pricing import LinkedDiscount,source_quote,SOURCE_EFFECT_ORDER
class PricingTests(unittest.TestCase):
 def test_clamp_and_authored_price_not_overwritten(self):
  self.assertEqual(source_quote(5,False,[LinkedDiscount('verified:test-gate',10)],{'verified:test-gate':True}),0)
 def test_free_override_and_false_gate(self):
  self.assertEqual(source_quote(400,True,[],{}),0)
  self.assertEqual(source_quote(400,False,[LinkedDiscount('verified:gate',10)],{'verified:gate':False}),400)
 def test_no_storage_or_missing_gate_default(self):
  with self.assertRaises(ValueError):source_quote(400,False,[LinkedDiscount('verified:gate',10)],{})
 def test_duplicate_source_array_is_additive(self):
  rule=LinkedDiscount('verified:gate',10)
  self.assertEqual(source_quote(400,False,[rule,rule],{'verified:gate':True}),380)
 def test_money_exhaustion_source_order_preserved(self):
  self.assertLess(SOURCE_EFFECT_ORDER.index('bank_debit'),SOURCE_EFFECT_ORDER.index('exhaustion'))

if __name__=='__main__':unittest.main()

use oteryn_game_server::content::item_identity::{ItemKeyAliasTable,RetiredItemKey,is_canonical_item_key,tibia_item_key};
use serde_json::{Value,json};
use oteryn_game_server::content::{ImportBatch, CandidateValue};
fn main(){
 let args:Vec<String>=std::env::args().collect();let raw=std::fs::read(&args[1]).unwrap();let table=ItemKeyAliasTable::parse(&raw).unwrap();
 let input:Value=serde_json::from_slice(&std::fs::read(&args[2]).unwrap()).unwrap();let mut results=vec![];
 for q in input.as_array().unwrap(){let key=q["retired_key"].as_str().unwrap();let expected=q["canonical"].as_str().unwrap();let id=q["source_item_id"].as_u64().unwrap();
  let target=match table.resolve(key){Some(RetiredItemKey::Alias{target})=>target.clone(),other=>panic!("unexpected alias: {other:?}")};
  assert_eq!(target,expected);assert_eq!(tibia_item_key(id).as_deref(),Some(expected));assert!(is_canonical_item_key(expected));
  results.push(json!({"retired_key":key,"canonical":target,"source_item_id":id,"accepted_canonical_alias":true,"current_donor_pin_binding_admitted":false}));
 }
 let mut drifted=raw.clone();drifted.push(b'\n');assert!(ItemKeyAliasTable::parse(&drifted).is_err());
 assert!(table.resolve("oteryn:item.registry.npc08_nonexistent").is_none());assert!(!is_canonical_item_key("oteryn:item.tibia.i0236"));
 let batch:ImportBatch=serde_json::from_slice(&std::fs::read(&args[3]).unwrap()).unwrap();
 assert_eq!(batch.access_disposition,"PENDING");assert_eq!(batch.candidates.len(),4);
 for c in &batch.candidates{assert_eq!(c.evidence_class,"OTS_HYPOTHESIS_ONLY");let mut found=false;for f in &c.normalized_fields{if let CandidateValue::NativeItemBinding(b)=&f.value{assert_eq!(b.identity.family,"Item");assert!(is_canonical_item_key(&b.identity.key));assert!(results.iter().any(|q|q["canonical"]==b.identity.key));found=true;}}assert!(found);}
 let mut invalid:Value=serde_json::from_slice(&std::fs::read(&args[3]).unwrap()).unwrap();invalid["candidates"][0]["candidate_family"]=json!("FakeItem");assert!(serde_json::from_value::<ImportBatch>(invalid).is_err());
 let mut invalid:Value=serde_json::from_slice(&std::fs::read(&args[3]).unwrap()).unwrap();invalid["candidates"][0]["normalized_fields"][0]["value"]["value"]["disposition"]=json!("Exact");assert!(serde_json::from_value::<ImportBatch>(invalid).is_err());
 println!("{}",json!({"status":"PASS_ACTUAL_RUST_ITEM_IDENTITY_CONTRACT","alias_table_keys":table.len(),"results":results,"negative_fixtures":["exact_bytes_drift_rejected","unknown_retired_key_unresolved","leading_zero_canonical_id_rejected"],"source_epoch_compatibility_admitted":false,"new_native_bindings":0,"actual_local_import_batch_dto_decoded":4,"batch_applied":false,"full_private_import_validation":"PENDING_ROOT_ADMISSION_NOT_ASSERTED","dto_negative_fixtures":["unknown_candidate_family_rejected","Exact_in_local_binding_disposition_rejected"]}));
}

# NPC-08: concrete Item resolution and candidate authoring

The resolution matrix accounts for **356 held source offer observations: 105 Item-ID/pin rows, 102 distinct IDs**. These are the previous 350 epoch holds plus six offers without existing canonical targets; they are not 356 different Items or NPCs.

- 110 observations / four IDs change only description text: **236, 238, 7642, 23374**. All other XML data is unchanged after masking those description values, and every actually known native semantic field matches current source values. Unknown native fields remain unknown.
- 204 observations have other XML changes. The matrix identifies changed attribute keys and compares actual current native known fields individually.
- Nine observations have current XML definitions but no accepted baseline source-ID alias.
- 27 reference IDs absent from current donor XML.
- Six observations / three IDs lack XML definitions, accepted source-ID aliases and canonical targets: **40515, 43861, 43969**. XML absence does not prove absence from the donor's binary ItemType catalogue; that wider engine membership was not evaluated. No target is invented from a name or number.

Current native known-field projection matches 269 observations, differs for 48 and remains unproven for 39. **Projection equality is separate from full semantic equivalence and source identity admission.** Ten Item/pin rows contain known field differences; their explicit values and applicable accepted Wiki promotion packet pointers are retained in the matrix. The existing Item stat source policy ranks tibia.com then TibiaWiki above Canary/Crystal hypotheses, so these differences never overwrite native values automatically.

## Actual accepted identity contracts

A small helper linked against the exact cached server library invokes the real Rust `ItemKeyAliasTable::parse/resolve`, including its pinned-byte gate. **64 historical alias mappings pass**; this validates canonical key ownership without admitting current donor-pin identity bindings. Byte drift, unknown retired keys and leading-zero canonical IDs fail as expected.

The four description-only Items have versioned external authoring candidates with exact pin/XML/node hashes, baseline aliases and source text. Their source text fragments validate against the accepted Item authoring `sourceObservations` schema. No family/taxonomy values are fabricated to manufacture complete Item authoring records.

`native-import-batch-candidate.json` additionally uses the actual accepted `ImportBatch`, `ImportCandidate` and `NativeItemBindingDocument` DTOs: four existing targets, `LocalNonProduction`, `PENDING` access, `OTS_HYPOTHESIS_ONLY`. Strict Rust decoding passes. The batch is **external and unapplied**; private full import validation and root admission are not claimed. It adds no EXACT/ACCEPTED_ALIAS provenance bindings and changes no native Item definitions.

The older source-catalogue candidate resolver is also exercised directly. Its empty admitted binding set returns `UNRESOLVED`; one `CANDIDATE` produces `AMBIGUOUS`, even with one target. Neither description text nor a matching known projection is promoted to `ASSERTED` or EXACT.

All 105 matrix rows lack an attached native Item appearance binding, and all current target Items are nonmaterializable. Appearance/runtime qualification remains a separate dimension from data identity and semantic comparisons.

## Reviewable files and reproduction

- `resolution-matrix.json.gz`: compact deterministic per-ID/pin classification, known field values/differences, source alias presence, appearance state and next action.
- `authoring-candidates.json`: four versioned source-aware candidates covering 110 observations.
- `native-import-batch-candidate.json`: actual typed local-only import batch stage.
- `actual-identity-contract.json`, `reproduction.json`: real Rust contract probes and deterministic reproduction hashes.
- `/tmp/npc08-item-resolution/full-resolution-evidence.json.gz`: full node/source/native comparison evidence, hash recorded in `summary.json`, explicitly external.

Run `python3 reproduce.py`. **12 Python fixtures and five real Rust negative fixtures pass**; regeneration reproduces the matrix and both candidate artifacts exactly. Only a small helper was compiled against existing artifacts; no full build, clone, downloads, Wiki/Remote Desktop research, product edits, promoted bindings, PR or runtime activation occurred.

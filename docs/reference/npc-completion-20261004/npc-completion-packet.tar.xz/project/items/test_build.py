import copy,unittest
import build as b
BASE=['item',[['id','236'],['name','potion']],'',[['attribute',[['key','description'],['value','old']],'',[]],['attribute',[['key','weight'],['value','290']],'',[]]]]
NATIVE={'semantics':{'presentation':{'state':'KNOWN','value':{'name':{'state':'KNOWN','value':'potion'},'description':{'state':'UNKNOWN'}}},'physical':{'state':'KNOWN','value':{'weight':{'state':'KNOWN','value':290},'movable':{'state':'UNKNOWN'}}},'charges':{'state':'UNKNOWN'}}}
class Tests(unittest.TestCase):
 def test_description_mask_only(self):
  x=copy.deepcopy(BASE);x[3][0][1][1][1]='new';self.assertEqual(b.strip_description(BASE),b.strip_description(x))
 def test_name_change_not_masked(self):
  x=copy.deepcopy(BASE);x[1][1][1]='other';self.assertNotEqual(b.strip_description(BASE),b.strip_description(x))
 def test_gameplay_change_not_masked(self):
  x=copy.deepcopy(BASE);x[3][1][1][1][1]='291';self.assertNotEqual(b.strip_description(BASE),b.strip_description(x))
 def test_attribute_multiplicity_preserved(self):
  x=copy.deepcopy(BASE);x[3].append(copy.deepcopy(x[3][1]));self.assertNotEqual(b.strip_description(BASE),b.strip_description(x));self.assertIsNone(b.xml_value(x,'/physical/value/weight'))
 def test_known_match_unknown_preserved(self):
  x=b.compare_native(NATIVE,[{'shape':BASE}]);self.assertTrue(x['complete_known_projection_match']);self.assertFalse(x['full_native_semantics_proven']);self.assertIn('/charges',x['unknown_native_fields'])
 def test_mismatch_explicit(self):
  x=copy.deepcopy(BASE);x[3][1][1][1][1]='291';p=b.compare_native(NATIVE,[{'shape':x}]);self.assertFalse(p['complete_known_projection_match']);self.assertEqual(p['mismatching_known_fields'][0]['native'],290)
 def test_unmapped_known_not_assumed(self):
  n=copy.deepcopy(NATIVE);n['semantics']['trade_restrictions']={'state':'KNOWN','value':{'marketable':{'state':'KNOWN','value':True}}};self.assertFalse(b.compare_native(n,[{'shape':BASE}])['complete_known_projection_match'])
 def test_missing_source_unproven(self):self.assertFalse(b.compare_native(NATIVE,[])['complete_known_projection_match'])
 def test_actual_empty_admission(self):self.assertEqual(b.accepted.resolve_native_mapping(236,[])['disposition'],'UNRESOLVED')
 def test_one_candidate_does_not_admit(self):self.assertEqual(b.accepted.resolve_native_mapping(236,[{'source_item_id':236,'content_key':'oteryn:item.tibia.i236','evidence_ref':'fixture:source','state':'CANDIDATE'}])['disposition'],'AMBIGUOUS')
 def test_missing_evidence_rejected(self):
  with self.assertRaises(b.accepted.CatalogError):b.accepted.resolve_native_mapping(236,[{'source_item_id':236,'content_key':'oteryn:item.tibia.i236','state':'CANDIDATE'}])
 def test_conflicting_assertions(self):
  rows=[{'source_item_id':236,'content_key':k,'evidence_ref':'fixture:source','state':'ASSERTED'} for k in ['oteryn:item.tibia.i236','oteryn:item.tibia.i238']];self.assertEqual(b.accepted.resolve_native_mapping(236,rows)['disposition'],'CONFLICT')
if __name__=='__main__':unittest.main()

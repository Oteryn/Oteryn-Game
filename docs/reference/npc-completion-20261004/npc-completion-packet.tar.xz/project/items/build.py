import collections,copy,gzip,hashlib,importlib.util,json,pathlib,re,sys
OUT=pathlib.Path(__file__).parent;BASE=OUT.parents[1];TMP=pathlib.Path('/tmp/npc08-item-resolution');TMP.mkdir(exist_ok=True);REPO=pathlib.Path('/workspace/Oteryn-Game');WORLD=pathlib.Path('/tmp/npc-full-plan-final-world')
sys.path.insert(0,str(BASE/'item-epoch-reconciliation'));import reconcile as ep
spec=importlib.util.spec_from_file_location('accepted_item_identity_catalog',REPO/'tools/reference-world-corridor-census/item_identity_catalog.py');accepted=importlib.util.module_from_spec(spec);spec.loader.exec_module(accepted)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def known(x,path=''):
 if isinstance(x,dict):
  if x.get('state')=='KNOWN' and not isinstance(x.get('value'),dict):return {path:x['value']}
  z={}
  for k,v in x.items():z.update(known(v,path+'/'+k))
  return z
 return {}
def unknown(x,path=''):
 if isinstance(x,dict):
  if x.get('state')=='UNKNOWN':return [path]
  return sum((unknown(v,path+'/'+k) for k,v in x.items()),[])
 return []
NUMERIC={'/physical/value/weight':'weight','/charges/value/count':'charges','/protection/value/armor':'armor','/weapon/value/attack':'attack','/weapon/value/defense':'defense','/weapon/value/range':'range','/imbuement/value/slot_count':'imbuementslot','/container/value/capacity':'containersize'}
def xml_value(shape,path):
 if path=='/presentation/value/name':return dict(shape[1]).get('name')
 attrs=collections.defaultdict(list)
 for ch in shape[3]:
  if ch[0]=='attribute':a=dict(ch[1]);attrs[a.get('key','').lower()].append(a.get('value'))
 if path=='/weapon/value/weapon_type':
  vals=attrs['weapontype'];return vals[0].upper() if len(vals)==1 and vals[0] in {'ammunition','axe','club','distance','fist','shield','spellbook','sword','wand'} else None
 key=NUMERIC.get(path)
 if key is None:return None
 vals=attrs[key]
 if len(vals)!=1 or not isinstance(vals[0],str) or not re.fullmatch(r'-?\d+',vals[0]):return None
 return int(vals[0])
def compare_native(native,shapes):
 k=known(native.get('semantics',{}));proof=[];unmapped=[];mismatch=[]
 for path,val in k.items():
  source=xml_value(shapes[0]['shape'],path) if len(shapes)==1 else None
  if source is None:unmapped.append(path)
  elif type(source) is not type(val) or source!=val:mismatch.append({'path':path,'native':val,'source':source})
  else:proof.append({'path':path,'value':val})
 return {'matching_known_fields':proof,'mismatching_known_fields':mismatch,'unmapped_known_fields':unmapped,'unknown_native_fields':unknown(native.get('semantics',{})),'complete_known_projection_match':bool(k) and not mismatch and not unmapped,'full_native_semantics_proven':False}
def strip_description(shape):
 out=copy.deepcopy(shape)
 for child in out[3]:
  if child[0]=='attribute' and dict(child[1]).get('key','').lower()=='description':
   child[1]=[[k,'SOURCE_DESCRIPTION_VALUE_NOT_GAMEPLAY'] if k=='value' else [k,v] for k,v in child[1]]
 return out
def source_shape_sha(nodes):return hashlib.sha256(json.dumps(nodes,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def source_bytes(pin,v):
 p=pathlib.Path(v['path'])
 raw=p.read_bytes() if p.is_file() else gzip.decompress((BASE/'item-epoch-reconciliation/baseline-ff7-items.xml.gz').read_bytes()) if pin==ep.FF else None
 if raw is None:raise ValueError('MISSING_CACHED_CURRENT_DONOR_XML')
 assert hashlib.sha256(raw).hexdigest()==v['sha256'];assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==v['git_blob_sha1'];return raw

def main():
 epdata=json.load(open(BASE/'item-epoch-reconciliation/summary.json'));idx={r:ep.index(source_bytes(r,v))[0] for r,v in epdata['inputs'].items()}
 ref=json.load(open(WORLD/'definitions/reference.json'));items={r['identity']['key']:r for r in ref['records'] if r['kind']=='Item'};decl=json.load(open(WORLD/'definitions/declarations.json'));auth={r['item']['key']:r for r in decl['item_authoring']};bindings=json.load(open(WORLD/'presentations/bindings.json'))['bindings']
 latest={}
 for a in json.load(open(REPO/'content/items/aliases.json'))['entries']:
  if a['key'] not in latest or a['version']>latest[a['key']]['version']:latest[a['key']]=a
 byid=collections.defaultdict(list)
 for a in latest.values():
  ev=a.get('evidence',{})
  if a['state']=='ALIAS' and ev.get('source_revision')==ep.FF:byid[ev.get('source_item_id')].append(a)
 classified={int(r['item_source_id']):r for r in json.load(open(BASE/'continuation-batch/item-difference-classification.json'))['records']}
 groups=collections.defaultdict(list)
 for l in gzip.open(BASE/'item-epoch-reconciliation/offer-reconciliation.jsonl.gz','rt'):
  r=json.loads(l)
  if r['old_group'] in ('CROSS_EPOCH_HELD','MISSING_TARGET') and r['status']!='EXACT_DEFINITION_ACCEPTED_ALIAS_CHAIN_CANDIDATE':groups[r['source']['source'],r['source']['revision'],r['source_item_id']].append(r)
 stats_path=REPO/'docs/agents/evidence/OTV2-20260930-item-stats-promotion-v2.json';stats=json.load(open(stats_path));statlookup={}
 for n,v in enumerate(stats['promotions']):statlookup[v['item_key'],v['field_path']]={'packet_pointer':'/promotions/'+str(n),'typed_value':v['typed_value']}
 matrix=[];candidates=[];full=[];category=collections.Counter();projection=collections.Counter();directions=collections.Counter()
 for (source,pin,i),rows in sorted(groups.items()):
  key=rows[0]['canonical_candidate'];native=items.get(key);current=idx[pin].get(i,[]);baseline=idx[ep.FF].get(i,[]);al=[a for a in byid[i] if a['target']==key] if key else []
  if rows[0]['status']=='NO_CANONICAL_TARGET_CANDIDATE':kind='UPSTREAM_ORPHAN_REFERENCE_NO_XML_ALIAS_OR_NATIVE_TARGET'
  elif not current:kind='CURRENT_DONOR_XML_DEFINITION_ABSENT'
  elif not baseline:kind='CURRENT_DEFINITION_ADDED_BASELINE_ALIAS_ABSENT'
  elif ep.compare(idx[pin],idx[ep.FF],i)=='FULL_ITEM_ELEMENT_DIFFERENT':kind=classified[i]['category']
  else:kind='ACCEPTED_SOURCE_ID_ALIAS_ABSENT'
  category[kind]+=len(rows)
  cp=compare_native(native,current) if native else {'matching_known_fields':[],'mismatching_known_fields':[],'unmapped_known_fields':[],'unknown_native_fields':[],'complete_known_projection_match':False,'full_native_semantics_proven':False}
  bp=compare_native(native,baseline) if native else cp
  proj='CURRENT_NATIVE_KNOWN_PROJECTION_MATCH' if cp['complete_known_projection_match'] else 'CURRENT_NATIVE_KNOWN_FIELDS_DIFFER' if cp['mismatching_known_fields'] else 'CURRENT_NATIVE_PROJECTION_NOT_PROVEN'
  projection[proj]+=len(rows)
  desc_unaltered=bool(current and baseline and len(current)==len(baseline)==1 and strip_description(current[0]['shape'])==strip_description(baseline[0]['shape']))
  presentation=auth.get(key,{}).get('presentation');bound=bool(presentation and any(b['presentation']==presentation for b in bindings))
  admitted=accepted.resolve_native_mapping(i,accepted.ADMITTED_NATIVE_BINDINGS)
  assert admitted['disposition']=='UNRESOLVED'
  row={'source':source,'pin':pin,'source_item_id':i,'observations':len(rows),'existing_canonical_candidate':key,'xml_classification':kind,'known_native_projection':proj,'known_matching_field_count':len(cp['matching_known_fields']),'known_mismatch_paths':[x['path'] for x in cp['mismatching_known_fields']],'known_unmapped_paths':cp['unmapped_known_fields'],'unknown_native_field_count':len(cp['unknown_native_fields']),'all_other_source_xml_identical_after_description_text_mask':desc_unaltered,'accepted_baseline_alias_count':len(al),'actual_admitted_identity_result':admitted['disposition'],'native_appearance_bound':bound,'native_materializable':bool(native and native.get('materializable')),'new_exact_binding':False,'runtime_eligible':False}
  row['known_field_differences']=[]
  for diff in cp['mismatching_known_fields']:
   path=diff['path'].strip('/').replace('/value/','.');authority=statlookup.get((key,path));row['known_field_differences'].append({**diff,'accepted_wiki_stat_packet_evidence':authority})
  row['source_changed_attribute_keys']=sorted({d['current_attribute_key'] or 'OUTER_OR_NESTED_STRUCTURE' for d in classified.get(i,{}).get('deltas',[])}) if kind in ('ONLY_DESCRIPTION_TEXT_CHANGED','GAMEPLAY_OR_OTHER_DEFINITION_CHANGE') else []
  row['next_action']='SOURCE_OWNER_ADMIT_CURRENT_PIN_AFTER_REVIEW; APPEARANCE_RUNTIME_SEPARATE' if kind=='ONLY_DESCRIPTION_TEXT_CHANGED' else 'PRESERVE_NATIVE_VALUES; REVIEW_TYPED_CURRENT_SOURCE_DELTAS' if cp['mismatching_known_fields'] else 'SOURCE_ITEM_ID_CROSSWALK_REQUIRED; DO_NOT_GUESS_FROM_NAME_OR_NUMBER' if not al else 'COMPLETE_CHANGED_SOURCE_FAMILY_MAPPING_BEFORE_BINDING_ADMISSION'
  row['xml_absence_scope']='XML/accepted-alias/current-native catalogue only; source binary ItemType membership is not proven absent' if not current else None
  candidate=None
  if kind=='ONLY_DESCRIPTION_TEXT_CHANGED' and desc_unaltered and cp['complete_known_projection_match'] and al:
   candidate={'source_item_id':i,'content_key':key,'state':'CANDIDATE','evidence_ref':'npc08-item-resolution:'+source+':'+pin+':'+str(i)}
   resolver=accepted.resolve_native_mapping(i,[candidate]);assert resolver['disposition']=='AMBIGUOUS'
   current_description=[dict(x[1]).get('value') for x in current[0]['shape'][3] if x[0]=='attribute' and dict(x[1]).get('key','').lower()=='description']
   old_description=[dict(x[1]).get('value') for x in baseline[0]['shape'][3] if x[0]=='attribute' and dict(x[1]).get('key','').lower()=='description']
   candidate_record={'version':'npc08-item-epoch-authoring-candidate-v1','native_item_ref':{'family':'Item',**native['identity']},'candidate_binding':candidate,'actual_candidate_resolver_result':resolver,'source_key':'oteryn:source.'+('canary' if source=='canary' else 'crystalserver'),'source_revision':pin,'identity_namespace':source+'/internal-item-id','source_description_delta':{'current':current_description,'baseline':old_description},'source_observations':{'attributes_text':json.dumps({'pin':pin,'source_item_id':i,'description':current_description,'classification':'SOURCE_ONLY_NON_EXECUTABLE'},separators=(',',':'))},'provenance':{'current_xml_sha256':epdata['inputs'][pin]['sha256'],'baseline_xml_sha256':epdata['inputs'][ep.FF]['sha256'],'current_node_shape_sha256':source_shape_sha(current),'baseline_node_shape_sha256':source_shape_sha(baseline),'accepted_alias_keys':[a['key'] for a in al]},'native_known_projection_proof':cp,'accepted_native_item_binding':False,'full_native_semantics_proven':False,'runtime_eligible':False}
   candidates.append(candidate_record);row['candidate_stage_index']=len(candidates)-1;row['candidate_resolver_result']='AMBIGUOUS';directions['candidate_source_observations']+=len(rows)
  matrix.append(row);full.append({'matrix':row,'current_xml_nodes':current,'baseline_xml_nodes':baseline,'current_native_projection':cp,'baseline_native_projection':bp,'accepted_aliases':al,'source_observations':rows,'native_current_item':native})
 # Validate candidate source text fragments against the real accepted Item authoring definition, without fabricating mandatory family/taxonomy data.
 import jsonschema
 schema=json.load(open(REPO/'tools/content-schema/item-authoring/item.schema.json'))
 for c in candidates:jsonschema.Draft202012Validator(schema['$defs']['sourceObservations']).validate(c['source_observations'])
 assert len(matrix)==105 and sum(r['observations'] for r in matrix)==356 and len(candidates)==4 and directions['candidate_source_observations']==110
 (OUT/'resolution-matrix.json.gz').write_bytes(gzip.compress(json.dumps(matrix,separators=(',',':')).encode(),compresslevel=9,mtime=0))
 (OUT/'authoring-candidates.json').write_text(json.dumps({'schema':'NPC_ITEM_IDENTITY_AUTHORING_CANDIDATE_STAGE/v1','accepted_item_binding_contract':'tools/reference-world-corridor-census/item_identity_catalog.py:resolve_native_mapping','candidates':candidates,'native_source_identity_bindings_added':0,'native_item_definitions_changed':0},ensure_ascii=False,separators=(',',':'))+'\n')
 # Stage the actual accepted local-only ImportBatch DTO externally; do not apply it or create EXACT provenance bindings.
 native_candidates=[]
 for c in candidates:
  target=c['native_item_ref'];iid=c['candidate_binding']['source_item_id']
  native_candidates.append({'source_candidate_id':'canary:item:'+str(iid),'source_label':items[target['key']]['semantics']['presentation']['value']['name']['value'],'source_numeric_id':iid,'candidate_family':'Item','candidate_operation':'BindNativeItem','candidate_target':target['key']+'@'+target['revision'],'candidate_formula':'NOT_APPLICABLE','evidence_class':'OTS_HYPOTHESIS_ONLY','closure_disposition':'LocalNonProduction','disposition_reason':'External authoring stage only: exact canonical alias and unchanged source gameplay XML; source description and unknowns retained; current-pin EXACT/runtime admission absent.','normalized_fields':[{'field_path':'binding.native-item','value':{'type':'NativeItemBinding','value':{'identity':target,'disposition':'LocalNonProduction'}}},{'field_path':'source.current-node-sha256','value':{'type':'Text','value':c['provenance']['current_node_shape_sha256']}},{'field_path':'source.item-id','value':{'type':'SourceId','value':iid}},{'field_path':'source.observations','value':{'type':'Text','value':c['source_observations']['attributes_text']}}]})
 batch={'batch_id':'npc08-item-authoring-current-canary-local-v1','source_repository':'opentibiabr/canary','source_revision':ep.CA,'source_artifact_sha256':epdata['inputs'][ep.CA]['sha256'],'access_disposition':'PENDING','source_generation_profile':'NPC08_ITEM_SOURCE_AUTHORING_LOCAL/v1','importer':'npc08-cache-only-item-epoch-stage','mapper':'npc-completion-project/items/build.py','mapper_revision':'npc08-local-v1','mapper_sha256':sha(pathlib.Path(__file__)),'candidates':sorted(native_candidates,key=lambda c:c['source_candidate_id']),'reimport_states':[]}
 (OUT/'native-import-batch-candidate.json').write_text(json.dumps(batch,separators=(',',':'))+'\n')
 fullp=TMP/'full-resolution-evidence.json.gz';fullp.write_bytes(gzip.compress(json.dumps(full,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=9,mtime=0))
 summary={'status':'NPC08_CONCRETE_PER_ID_PIN_MATRIX_AND_ACTUAL_BINDING_CANDIDATE_STAGE','matrix_rows':len(matrix),'unique_ids':len({r['source_item_id'] for r in matrix}),'source_offer_observations':356,'xml_classification_counts':dict(category),'native_known_projection_counts':dict(projection),'description_only_authoring_candidates':len(candidates),'candidate_source_observations':110,'actual_candidate_resolver_status':'AMBIGUOUS','actual_admitted_identity_status':'UNRESOLVED','full_semantic_equivalence_or_exact_binding_claimed':False,'native_appearance_bindings_missing_rows':sum(not r['native_appearance_bound'] for r in matrix),'native_materializable_rows':sum(r['native_materializable'] for r in matrix),'inputs':{'accepted_identity_mapper':{'path':str(REPO/'tools/reference-world-corridor-census/item_identity_catalog.py'),'sha256':sha(REPO/'tools/reference-world-corridor-census/item_identity_catalog.py')},'aliases_sha256':sha(REPO/'content/items/aliases.json'),'native_item_reference_sha256':sha(WORLD/'definitions/reference.json'),'epoch_summary_sha256':sha(BASE/'item-epoch-reconciliation/summary.json'),'current_native_stats_packet_sha256':sha(stats_path),'current_native_stats_source_policy':'tibia.com then TibiaWiki; Canary/Crystal hypotheses, known Game values preserved'},'large_external_evidence':{'path':str(fullp),'sha256':sha(fullp),'embedded':False},'native_source_identity_bindings_added':0,'native_item_definitions_changed':0,'runtime_eligible':False}
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
if __name__=='__main__':main()

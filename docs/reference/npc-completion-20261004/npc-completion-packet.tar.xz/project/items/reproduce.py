import gzip,hashlib,json,pathlib,subprocess,sys
OUT=pathlib.Path(__file__).parent;BASE=OUT.parents[1];REPO=pathlib.Path('/workspace/Oteryn-Game');TMP=pathlib.Path('/tmp/npc08-item-resolution');TMP.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=['resolution-matrix.json.gz','authoring-candidates.json','native-import-batch-candidate.json'];before={n:sha(OUT/n) for n in tracked};subprocess.run([sys.executable,str(OUT/'test_build.py')],check=True);subprocess.run([sys.executable,str(OUT/'build.py')],check=True,stdout=subprocess.DEVNULL);after={n:sha(OUT/n) for n in tracked};assert before==after
full=json.load(gzip.open(TMP/'full-resolution-evidence.json.gz','rt'));queries={}
for row in full:
 if row['accepted_aliases']:
  m=row['matrix'];queries[m['source_item_id']]={'retired_key':row['accepted_aliases'][0]['key'],'canonical':m['existing_canonical_candidate'],'source_item_id':m['source_item_id']}
query=TMP/'identity-queries.json';query.write_text(json.dumps(list(queries.values()),sort_keys=True));assert len(queries)==64
q=json.load(open(BASE/'full-plan-integration/qualification.json'));game=pathlib.Path(q['build_inputs']['game_rlib']['path']);serde=pathlib.Path(q['build_inputs']['serde_json_rlib']['path']);assert sha(game)==q['build_inputs']['game_rlib']['sha256'];assert sha(serde)==q['build_inputs']['serde_json_rlib']['sha256'];compiler=pathlib.Path('/workspace/npc-r7-work/rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/rustc');helper=TMP/'identity-probe'
subprocess.run([str(compiler),'--edition=2024',str(OUT/'identity_probe.rs'),'-L','dependency='+str(game.parent),'--extern','oteryn_game_server='+str(game),'--extern','serde_json='+str(serde),'-o',str(helper)],check=True)
probe=subprocess.run([str(helper),str(REPO/'content/items/aliases.json'),str(query),str(OUT/'native-import-batch-candidate.json')],check=True,capture_output=True,text=True);actual=json.loads(probe.stdout);assert actual['status']=='PASS_ACTUAL_RUST_ITEM_IDENTITY_CONTRACT' and len(actual['results'])==64 and actual['actual_local_import_batch_dto_decoded']==4 and actual['batch_applied'] is False
(OUT/'actual-identity-contract.json').write_text(probe.stdout)
receipt={'status':'PASS_NPC08_REPRODUCIBLE_MATRIX_AND_ACTUAL_CONTRACT_STAGE','artifact_sha256':after,'python_fixtures':12,'actual_rust_identity_and_dto_negative_fixtures':5,'actual_rust_alias_queries':64,'typed_local_item_import_candidates_decoded':4,'full_private_import_validation':'NOT_ASSERTED_ROOT_ADMISSION_PENDING','actual_identity_contract_sha256':sha(OUT/'actual-identity-contract.json'),'cached_rlib':{'path':str(game),'sha256':sha(game)},'code_sha256':{n:sha(OUT/n) for n in ['build.py','test_build.py','identity_probe.rs']},'native_exact_bindings_added':0,'native_item_definitions_changed':0,'runtime_eligible':False}
(OUT/'reproduction.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

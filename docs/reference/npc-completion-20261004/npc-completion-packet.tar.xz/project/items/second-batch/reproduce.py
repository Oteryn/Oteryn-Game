#!/usr/bin/env python3
"""Cache-only actual admission check; no product writes, network or full build."""
import hashlib,json,pathlib,subprocess
HERE=pathlib.Path(__file__).resolve().parent
receipt=json.loads((HERE/'receipt.json').read_text())
for key in ('candidate_batch','helper_source','game_rlib','serde_rlib'):
 entry=receipt[key]
 assert hashlib.sha256(pathlib.Path(entry['path']).read_bytes()).hexdigest()==entry['sha256'],key
base=pathlib.Path(receipt['baseline']['path'])
files={str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(base.rglob('*')) if p.is_file()}
assert files==receipt['baseline']['documents_sha256'],'baseline changed'
exe='/tmp/npc08-second-validation'
rustc='/workspace/npc-r7-work/rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/rustc'
subprocess.run([rustc,'--edition=2024','-C','strip=symbols',str(HERE/'validate.rs'),'-L','dependency=/workspace/Oteryn-Game/target/debug/deps','--extern','oteryn_game_server='+receipt['game_rlib']['path'],'--extern','serde_json='+receipt['serde_rlib']['path'],'-o',exe],check=True)
result=json.loads(subprocess.check_output([exe,str(base),receipt['candidate_batch']['path']],text=True))
assert result['checks']==receipt['checks'],'actual API results changed'
assert result['max_import_records']==24 and result['import_record_usage_after']==4
assert result['project_limits_debug']==receipt['project_limits_debug'] and result['filesystem_limits_debug']==receipt['filesystem_limits_debug']
positive=result['checks'][0]
assert positive['admitted'] and positive['reparsed'] and positive['new_candidates']==4 and positive['existing_gameplay_and_authoring_unchanged']
assert all(not row['admitted'] for row in result['checks'][1:])
assert result['baseline_licensing']=='PENDING' and result['new_exact_bindings']==0 and not result['runtime_eligible'] and not result['limits_changed']
print(json.dumps({'status':'PASS_REPRODUCED_FULL_ADMISSION','positive_candidates':4,'negative_contracts':5,'source_tree':receipt['baseline']['qualified_tree_sha256'],'product_writes':0,'limits_changed':False}))

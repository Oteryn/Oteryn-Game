use std::{env,fs,path::Path};
use oteryn_game_server::content::{capture_world_project,CanonicalProjectDocuments,ImportBatch,npc_catalogue_preproduction_limits};
fn main()->Result<(),Box<dyn std::error::Error>> {
 let a:Vec<String>=env::args().collect();let p=Path::new(&a[1]);let limits=npc_catalogue_preproduction_limits();
 let project=capture_world_project(p.parent().unwrap(),p.file_name().unwrap(),limits)?;
 let base=project.migrate_to_v2();let candidate:serde_json::Value=serde_json::from_slice(&fs::read(&a[2])?)?;
 let original_imports=base.core.imports.len();let original_candidates:usize=base.core.imports.iter().map(|b|b.candidates.len()).sum();
 let mut checks=Vec::new();
 for case in ["positive","approved-access","missing-target","duplicate-target","wrong-binding-path","formula"] {
  let mut value=candidate.clone();
  match case {
   "approved-access"=>value["access_disposition"]="APPROVED".into(),
   "missing-target"=>{value["candidates"][0]["candidate_target"]="oteryn:item.tibia.i999999@definition-r1".into();value["candidates"][0]["normalized_fields"][0]["value"]["value"]["identity"]["key"]="oteryn:item.tibia.i999999".into();},
   "duplicate-target"=>{let first=value["candidates"][0].clone();value["candidates"][1]["candidate_target"]=first["candidate_target"].clone();value["candidates"][1]["normalized_fields"][0]=first["normalized_fields"][0].clone();},
   "wrong-binding-path"=>value["candidates"][0]["normalized_fields"][0]["field_path"]="binding.fake".into(),
   "formula"=>value["candidates"][0]["candidate_formula"]="10".into(),_=>{}
  }
  let batch:ImportBatch=serde_json::from_value(value)?;let mut draft=base.clone();draft.core.imports.push(batch);
  match CanonicalProjectDocuments::from_v2_draft(draft,limits.project) {
   Err(e)=>checks.push(serde_json::json!({"case":case,"admitted":false,"error":e.to_string(),"debug":format!("{e:?}")})),
   Ok(docs)=>{
    let admitted=docs.into_snapshot(limits.project)?.parse(limits.project)?;
    let current=admitted.migrate_to_v2();
    let intact=current.core.records==base.core.records && current.state==base.state && current.core.metadata==base.core.metadata;
    let new_batch=admitted.imports().iter().find(|b|b.batch_id==candidate["batch_id"].as_str().unwrap()).ok_or("batch dropped")?;
    checks.push(serde_json::json!({"case":case,"admitted":true,"reparsed":true,"new_candidates":new_batch.candidates.len(),"existing_gameplay_and_authoring_unchanged":intact,"imports_before":original_imports,"imports_after":admitted.imports().len(),"candidates_before":original_candidates,"candidates_after":admitted.imports().iter().map(|b|b.candidates.len()).sum::<usize>()}));
   }
  }
 }
 println!("{}",serde_json::json!({"api":"capture_world_project -> CanonicalProjectDocuments::from_v2_draft -> into_snapshot -> ProjectSnapshot::parse","baseline_licensing":base.core.licensing_metadata,"limits_origin":"npc_catalogue_preproduction_limits() unchanged at every API","project_limits_debug":format!("{:?}",limits.project),"filesystem_limits_debug":format!("{:?}",limits),"max_import_records":limits.project.max_import_records,"import_record_usage_after":original_candidates+4,"import_record_metric":"sum(batch.candidates.len()); batches are not counted","limits_changed":false,"private_in_memory":true,"runtime_eligible":false,"new_exact_bindings":0,"asset_promotions":0,"checks":checks}));Ok(())
}

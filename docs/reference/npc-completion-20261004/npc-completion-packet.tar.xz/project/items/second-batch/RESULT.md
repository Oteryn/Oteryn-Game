# NPC-08 — rzeczywista walidacja ImportBatch

**PASS_FULL_NATIVE_IMPORT_CANDIDATE_ADMISSION_LOCAL_ONLY**. Cztery kandydaty Item (23374, 236, 238, 7642) przeszły faktyczny accepted kontrakt projektu, nie tylko dekodowanie DTO.

Helper korzysta z cached game-server rlib: `capture_world_project`, `CanonicalProjectDocuments::from_v2_draft` (pełna walidacja core, imports oraz stanu V2), następnie `into_snapshot` i ponowne `ProjectSnapshot::parse`. Kopia bazowa była byte-identical z qualified world e749728fc12b0b79a8a296fdb8b8c8393b5dd2c8b4e7ef0115c8836084347ebc. Receipt zawiera SHA każdego dokumentu i wejść; reproduction używa istniejącego nested parent, bez ponownego kopiowania projektu.

Rezultat: imports 25 → 26, candidates 0 → 4. Istniejące native records, metadata i cały stan authoringu/gameplay pozostają identyczne. Publiczne Item keys/revisions pozostają istniejące. PENDING oraz LocalNonProduction zachowane. Zero nowych SourceIdentityBinding EXACT, promocji assetów i aktywacji runtime. To przyjęcie lokalnego batcha dowodowego; źródłowe description pozostaje Text w normalized_fields importu, nie zmienia aktualnych statystyk Item ani wyglądu klienta.

Pięć negatywnych prób przechodzi przez ten sam rzeczywisty walidator i kończy się kontraktową odmową: APPROVED access, brak native target, powielony target, nieprawidłowa ścieżka typed binding, niedozwolona formula. Dokładne error/debug zapisano w receipt.json.

Uruchomienie cache-only: `python3 reproduce.py`. Bez buildowania crate, pobierania danych, modyfikacji produktu, podnoszenia limitów albo PR. Root integruje ewentualnie pojedynczy istniejący native-import-batch-candidate.json po zachowaniu preconditions. Cztery kandydaty nie kwalifikują pozostałych 246 obserwacji ani brakujących aliasów/ItemType/appearance.

Limity: wszystkie wywołania używają niezmienionego `npc_catalogue_preproduction_limits()`. `max_import_records=24` mierzy sumę `batch.candidates.len()`, nie liczbę batchów. Po dodaniu batcha użycie wynosi **4/24** przy 26 batchach. Receipt zapisuje faktyczne Debug limitów project/filesystem. Wynik nie oznacza osobnego uruchomienia CLI npc-import; root zachowuje rolę integratora.

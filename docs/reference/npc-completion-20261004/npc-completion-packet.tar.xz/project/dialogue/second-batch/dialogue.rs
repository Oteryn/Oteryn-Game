//! Read-only caller of the native planner at the admitted catalogue boundary.
//! This is not a text matcher, conversation store, authority grant or NPC actor runtime.
use super::*;
use crate::content::{NpcDialogueProgramPlan, prepare_npc_dialogue_program};

#[derive(Debug, Clone, Copy)]
pub(crate) struct NpcDialogueBinding<'a> {
    pub expected_project_revision: &'a str,
    pub expected_tree_sha256: &'a str,
    pub npc: &'a ProjectV2DefinitionRef,
    pub dialogue: &'a ProjectV2DefinitionRef,
}
#[derive(Debug)]
pub(crate) struct ResolvedNpcDialogue<'a> {
    npc: &'a ProjectV2DefinitionRef,
    dialogue: &'a ProjectV2DefinitionRef,
    declaration: &'a ProjectV2Declaration,
}
impl NpcDataCatalogue {
    /// Expectations must come from the caller's selected content binding, not this catalogue.
    /// Matching immutable content says nothing about current session/channel authority.
    pub(crate) fn resolve_dialogue<'a>(
        &'a self,
        binding: NpcDialogueBinding<'a>,
    ) -> Result<ResolvedNpcDialogue<'a>, ProjectError> {
        check_catalogue_binding(self.project_revision(), self.source_tree_digest(), binding)?;
        let npc = self.declaration(binding.npc).ok_or(ProjectError::InvalidProject(
            "NPC dialogue binding references absent NPC revision",
        ))?;
        let dialogue = self.declaration(binding.dialogue).ok_or(ProjectError::InvalidProject(
            "NPC dialogue binding references absent Dialogue revision",
        ))?;
        resolve_owned_dialogue(npc, dialogue, binding.npc, binding.dialogue)
    }
}
fn check_catalogue_binding(
    revision: &str,
    tree: &str,
    binding: NpcDialogueBinding<'_>,
) -> Result<(), ProjectError> {
    if revision != binding.expected_project_revision || tree != binding.expected_tree_sha256 {
        return Err(ProjectError::InvalidProject("NPC dialogue catalogue binding mismatch"));
    }
    if binding.npc.family != ProjectV2Family::Npc
        || binding.dialogue.family != ProjectV2Family::Dialogue
    {
        return Err(ProjectError::InvalidProject("NPC dialogue binding family mismatch"));
    }
    Ok(())
}
fn resolve_owned_dialogue<'a>(
    npc: &'a ProjectV2Declaration,
    dialogue: &'a ProjectV2Declaration,
    npc_ref: &'a ProjectV2DefinitionRef,
    dialogue_ref: &'a ProjectV2DefinitionRef,
) -> Result<ResolvedNpcDialogue<'a>, ProjectError> {
    let ProjectV2Declaration::Npc { identity, dialogue: Some(owned), .. } = npc else {
        return Err(ProjectError::InvalidProject("NPC has no owned Dialogue binding"));
    };
    if npc_ref.family != ProjectV2Family::Npc || identity.key != npc_ref.key
        || identity.revision != npc_ref.revision || owned != dialogue_ref
    {
        return Err(ProjectError::InvalidProject("NPC does not own selected Dialogue revision"));
    }
    let ProjectV2Declaration::Dialogue { identity, .. } = dialogue else {
        return Err(ProjectError::InvalidProject("NPC dialogue reference is not Dialogue"));
    };
    if dialogue_ref.family != ProjectV2Family::Dialogue || identity.key != dialogue_ref.key
        || identity.revision != dialogue_ref.revision
    {
        return Err(ProjectError::InvalidProject("NPC Dialogue identity mismatch"));
    }
    Ok(ResolvedNpcDialogue { npc: npc_ref, dialogue: dialogue_ref, declaration: dialogue })
}
impl<'a> ResolvedNpcDialogue<'a> {
    pub(crate) fn binding(&self) -> (&'a ProjectV2DefinitionRef, &'a ProjectV2DefinitionRef) {
        (self.npc, self.dialogue)
    }
    /// Retains each distinct authored message, without assuming greet/bye state effects.
    pub(crate) fn messages(&self) -> (&'a [String], &'a [String], &'a [String], &'a [String]) {
        match self.declaration {
            ProjectV2Declaration::Dialogue { greet, farewell, walkaway, send_trade, .. } =>
                (greet, farewell, walkaway, send_trade),
            _ => unreachable!("resolved Dialogue invariant"),
        }
    }
    /// The future owning matcher supplies an exact authored key path after source-order
    /// selection. This method neither selects triggers nor invents ancestor callbacks.
    /// Focus/topic are independently obtained read snapshots, never current authority proof.
    /// The plan is read-only; its caller must own any eventual conversation state mutation.
    pub(crate) fn plan_selected_keyword(
        &self,
        path: &[&str],
        focused: bool,
        topic: Option<u16>,
    ) -> Result<NpcDialogueProgramPlan<'a>, ProjectError> {
        if path.is_empty() || path.len() > 8 {
            return Err(ProjectError::InvalidProject("NPC selected keyword path depth is invalid"));
        }
        let ProjectV2Declaration::Dialogue { keywords, .. } = self.declaration else {
            unreachable!("resolved Dialogue invariant");
        };
        let mut siblings = keywords.as_slice();
        for (index, key) in path.iter().enumerate() {
            let node = siblings.iter().find(|node| node.key == *key).ok_or(
                ProjectError::InvalidProject("NPC selected keyword path is absent"),
            )?;
            if index + 1 == path.len() {
                return prepare_npc_dialogue_program(node, focused, topic);
            }
            siblings = &node.children;
        }
        unreachable!("nonempty bounded path");
    }
}

#[cfg(test)]
#[allow(clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;
    use crate::content::{NpcDialoguePlannedStep, ProjectV2NpcDialogueStep};
    fn reference(family: ProjectV2Family, key: &str) -> ProjectV2DefinitionRef {
        ProjectV2DefinitionRef { family, key: key.into(), revision: "r1".into() }
    }
    fn records() -> (ProjectV2Declaration, ProjectV2Declaration, ProjectV2DefinitionRef, ProjectV2DefinitionRef) {
        let nr = reference(ProjectV2Family::Npc, "test:npc");
        let dr = reference(ProjectV2Family::Dialogue, "test:dialogue");
        let npc = serde_json::from_value(serde_json::json!({
            "kind":"NPC", "identity":{"key":nr.key,"revision":nr.revision},
            "presentation":null,"behavior":null,"dialogue":dr,"services":[],"fields":[]
        })).expect("pure declaration fixture; no authority");
        let dialogue = serde_json::from_value(serde_json::json!({
            "kind":"Dialogue", "identity":{"key":dr.key,"revision":dr.revision},
            "greet":["hi"],"farewell":["bye"],"walkaway":["walk"],"send_trade":["trade"],
            "keywords":[{"key":"job","triggers":["job"],"reply":["authored"],"reset":true}],"fields":[]
        })).expect("pure Dialogue fixture");
        (npc, dialogue, nr, dr)
    }
    #[test]
    fn dialogue_catalogue_resolver_consumes_real_admitted_worldproject() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../content/world");
        let catalogue = NpcDataCatalogue::load(root.parent().expect("parent"), OsStr::new("world"), npc_catalogue_preproduction_limits()).expect("admitted WorldProject");
        let (nr, dr) = catalogue.records().find_map(|(reference,declaration)| match declaration {
            ProjectV2Declaration::Npc { dialogue:Some(dialogue), .. } => Some((reference,dialogue)),
            _ => None,
        }).expect("existing NPC Dialogue relation");
        let expected = NpcDialogueBinding {
            expected_project_revision:"g4-npc-provisional-enrichment-r28",
            expected_tree_sha256:"3fcab27b778849cb2453d34161fd16c9cbd58c0bff0d00c54fc12e5583c78148",
            npc:nr,dialogue:dr,
        };
        let resolved = catalogue.resolve_dialogue(expected).expect("independent selected fixture content pin");
        assert_eq!(resolved.binding(), (nr,dr));
        assert!(catalogue.resolve_dialogue(NpcDialogueBinding { expected_project_revision:"stale",..expected }).is_err());
        assert!(catalogue.resolve_dialogue(NpcDialogueBinding { expected_tree_sha256:"foreign",..expected }).is_err());
    }
    #[test]
    fn dialogue_binding_independent_expectations_reject_changed_tree_revision_and_family() {
        let (_, _, nr, dr) = records();
        let binding = NpcDialogueBinding { expected_project_revision:"p1",expected_tree_sha256:"digest1",npc:&nr,dialogue:&dr };
        assert!(check_catalogue_binding("p1", "digest1", binding).is_ok());
        assert!(check_catalogue_binding("p2", "digest1", binding).is_err());
        assert!(check_catalogue_binding("p1", "digest2", binding).is_err());
        let wrong = reference(ProjectV2Family::Service, "test:dialogue");
        assert!(check_catalogue_binding("p1", "digest1", NpcDialogueBinding { dialogue:&wrong,..binding }).is_err());
    }
    #[test]
    fn dialogue_binding_rejects_foreign_membership_and_stale_identity() {
        let (npc, dialogue, nr, dr) = records();
        let foreign = reference(ProjectV2Family::Dialogue, "test:other");
        assert!(resolve_owned_dialogue(&npc, &dialogue, &nr, &foreign).is_err());
        let mut stale = nr.clone(); stale.revision = "r2".into();
        assert!(resolve_owned_dialogue(&npc, &dialogue, &stale, &dr).is_err());
        let mut altered = dialogue.clone();
        if let ProjectV2Declaration::Dialogue { identity, .. } = &mut altered { identity.revision = "r2".into(); }
        assert!(resolve_owned_dialogue(&npc, &altered, &nr, &dr).is_err());
    }
    #[test]
    fn dialogue_resolver_calls_real_planner_and_preserves_messages_and_legacy() {
        let (npc, dialogue, nr, dr) = records();
        let resolved = resolve_owned_dialogue(&npc, &dialogue, &nr, &dr).expect("membership");
        assert_eq!(resolved.binding(), (&nr,&dr));
        let (greet, bye, walk, trade) = resolved.messages();
        assert_eq!((greet[0].as_str(),bye[0].as_str(),walk[0].as_str(),trade[0].as_str()),("hi","bye","walk","trade"));
        assert!(matches!(resolved.plan_selected_keyword(&["job"],true,None).expect("legacy"),NpcDialogueProgramPlan::Legacy(node) if node.reset));
        assert!(resolved.plan_selected_keyword(&[],true,None).is_err());
        assert!(resolved.plan_selected_keyword(&["other"],true,None).is_err());
        assert!(resolved.plan_selected_keyword(&["job","job"],true,None).is_err());
        assert!(resolved.plan_selected_keyword(&["job";9],true,None).is_err());
    }
    #[test]
    fn dialogue_resolver_calls_program_in_source_order_and_retains_nil_topic() {
        let (npc, mut dialogue, nr, dr) = records();
        if let ProjectV2Declaration::Dialogue { keywords, .. } = &mut dialogue {
            keywords[0].reset=false;
            keywords[0].program=Some(vec![ProjectV2NpcDialogueStep::SetTopic{value:1},ProjectV2NpcDialogueStep::EmitReply]);
            keywords[0].topic_equals=Some(0);
            keywords[0].consume_on_topic_mismatch=true;
        }
        let resolved = resolve_owned_dialogue(&npc, &dialogue, &nr, &dr).expect("membership");
        assert!(matches!(resolved.plan_selected_keyword(&["job"],true,None).expect("nil"),NpcDialogueProgramPlan::MatchedNoAction));
        assert!(matches!(resolved.plan_selected_keyword(&["job"],true,Some(0)).expect("program"),NpcDialogueProgramPlan::Ordered(steps) if matches!(steps.as_slice(),[NpcDialoguePlannedStep::SetTopic(1),NpcDialoguePlannedStep::EmitReply(_)])));
    }
    #[test]
    fn dialogue_resolver_cannot_admit_unbound_outcome() {
        let (npc, mut dialogue, nr, dr) = records();
        if let ProjectV2Declaration::Dialogue { keywords, .. } = &mut dialogue {
            keywords[0].reset=false;
            keywords[0].program=Some(vec![ProjectV2NpcDialogueStep::EmitReply,ProjectV2NpcDialogueStep::RequestOutcome{interaction:reference(ProjectV2Family::Interaction,"test:unbound")}]);
        }
        let resolved = resolve_owned_dialogue(&npc, &dialogue, &nr, &dr).expect("membership only");
        assert!(resolved.plan_selected_keyword(&["job"],true,None).is_err());
    }
}

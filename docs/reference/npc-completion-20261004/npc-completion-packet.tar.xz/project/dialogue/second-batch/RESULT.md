Existing owner: `content::NpcDataCatalogue` owns the admitted immutable WorldProject, exact declaration index and canonical tree digest. This patch adds an actual read-only caller of the native dialogue planner at that boundary, without a competing catalogue/index or actor runtime.

Caller supplies expected content project revision/tree digest and exact NPC plus Dialogue references. Resolution checks both immutable pins and actual NPC→Dialogue membership, family/key/revision; arbitrary foreign Dialogue selection is rejected. Selected authored keyword paths are bounded to eight nodes and resolved within this exact declaration. The future owning matcher must preserve source branch selection; this resolver does not guess text matching or ancestor execution.

Greet, farewell, walkaway and trade messages remain separate borrowed data. Legacy plans retain reset/ungreet/move_up. Source topic nil differs from zero; selected branch consume semantics and source step order come from the real existing proposed planner. Request outcomes and native Quest gates remain refused.

No accepted NPC session/actor carrier currently exists, so per-NPC/current-session-generation topic storage and greet/bye mutation remain held for that owning boundary. The independent focused/topic read snapshot supplied here is not session/channel authority evidence. A returned plan grants no mutation authority, receipt or protocol response.

Six Rust tests pass against actual native DTO types, exact planner function body and the production catalogue/resolver modules. One test captures the actual admitted repository WorldProject, consumes independently fixed fixture content pins through the real resolver, and rejects stale revision and foreign tree. Other negatives cover wrong family, foreign NPC membership, stale NPC/Dialogue revision, absent/deep paths, nil topic and unbound outcome. This is content resolution/planning qualification, not live gameplay E2E.

Patch remains unapplied against frozen product source. Parent owns shared-stage integration and final native crate qualification.

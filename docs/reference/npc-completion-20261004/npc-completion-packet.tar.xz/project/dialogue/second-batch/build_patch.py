from pathlib import Path
import difflib,hashlib,json,subprocess
ROOT=Path('/workspace/Oteryn-Game');OWN=Path(__file__).parent
parts=[]
for rel, edit in [('apps/game-server/src/content/npc_catalogue.rs',lambda s:s.replace('use super::{','mod dialogue;\npub(crate) use dialogue::{NpcDialogueBinding, ResolvedNpcDialogue};\n\nuse super::{',1)),('apps/game-server/src/content/mod.rs',lambda s:s.replace('pub use npc_catalogue::{','pub(crate) use npc_catalogue::{NpcDialogueBinding, ResolvedNpcDialogue};\npub(crate) use project::{NpcDialogueProgramPlan, NpcDialoguePlannedStep, prepare_npc_dialogue_program};\npub use npc_catalogue::{',1)),('apps/game-server/src/content/project.rs',lambda s:s.replace('pub use v2::*;','pub use v2::*;\npub(crate) use v2::{NpcDialogueProgramPlan, NpcDialoguePlannedStep, prepare_npc_dialogue_program};',1))]:
    old=(ROOT/rel).read_text();new=edit(old);assert old!=new
    parts.append(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
rel='apps/game-server/src/content/npc_catalogue/dialogue.rs';new=(OWN/'dialogue.rs').read_text()
parts.append(''.join(difflib.unified_diff([],new.splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))
p=OWN/'catalogue-dialogue-resolver.patch';p.write_text(''.join(parts))
r=subprocess.run(['git','apply','--check',str(p)],cwd=ROOT,capture_output=True,text=True);assert r.returncode==0,r.stderr
print(hashlib.sha256(p.read_bytes()).hexdigest(),len(new.splitlines()),'module lines')

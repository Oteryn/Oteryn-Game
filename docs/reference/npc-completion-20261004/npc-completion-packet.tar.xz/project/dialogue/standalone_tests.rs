use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use oteryn_game_server::content::{ProjectV2DefinitionRef, ProjectV2Family, ProjectError};
fn is_v2_lowercase_slug(s: &str) -> bool { !s.is_empty() && s.len()<=64 && s.split('_').all(|x| !x.is_empty() && x.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit())) }
include!("/tmp/npc-dialogue-program/native_keyword.rs");
#[path="/workspace/npc-upstream-first-audit/npc-completion-project/dialogue/npc_dialogue.rs"] mod proposed;
use proposed::*;
#[cfg(test)] mod tests {
    use super::*;
    fn node() -> ProjectV2DialogueKeyword { serde_json::from_str(r#"{"key":"yes","triggers":["yes"],"reply":["Exact."],"only_focus":true}"#).unwrap() }
    #[test] fn legacy_preserves_state_flags() {
        let mut n=node(); n.reset=true;
        assert!(matches!(prepare_npc_dialogue_program(&n,true,Some(0)).unwrap(),NpcDialogueProgramPlan::Legacy(k) if k.reset));
    }
    #[test] fn ordered_topic_before_reply_is_retained() {
        let mut n=node();n.program=Some(vec![ProjectV2NpcDialogueStep::SetTopic{value:1},ProjectV2NpcDialogueStep::EmitReply]);
        assert_eq!(prepare_npc_dialogue_program(&n,true,None).unwrap(),NpcDialogueProgramPlan::Ordered(vec![NpcDialoguePlannedStep::SetTopic(1),NpcDialoguePlannedStep::EmitReply(&n.reply)]));
    }
    #[test] fn nil_is_distinct_from_zero_and_guard_can_consume() {
        let mut n=node();n.program=Some(vec![ProjectV2NpcDialogueStep::EmitReply]);n.topic_equals=Some(0);n.consume_on_topic_mismatch=true;
        assert_eq!(prepare_npc_dialogue_program(&n,true,None).unwrap(),NpcDialogueProgramPlan::MatchedNoAction);
        assert!(matches!(prepare_npc_dialogue_program(&n,true,Some(0)).unwrap(),NpcDialogueProgramPlan::Ordered(_)));
        n.consume_on_topic_mismatch=false;assert_eq!(prepare_npc_dialogue_program(&n,true,None).unwrap(),NpcDialogueProgramPlan::Skip);
    }
    #[test] fn bounds_and_duplicate_reply_refused_before_any_effect() {
        let mut n=node();
        for p in [vec![],vec![ProjectV2NpcDialogueStep::EmitReply;2],vec![ProjectV2NpcDialogueStep::SetTopic{value:1};9]] { n.program=Some(p);assert!(prepare_npc_dialogue_program(&n,true,None).is_err()); }
    }
    #[test] fn outcome_interaction_family_is_not_role_permission() {
        let mut n=node();n.program=Some(vec![ProjectV2NpcDialogueStep::RequestOutcome{interaction:ProjectV2DefinitionRef{family:ProjectV2Family::Interaction,key:"oteryn:source.unbound_role".into(),revision:"source-only".into()}},ProjectV2NpcDialogueStep::EmitReply]);
        assert!(prepare_npc_dialogue_program(&n,true,None).unwrap_err().to_string().contains("ROLE_BINDING_UNAVAILABLE"));
        if let Some(p)=n.program.as_mut() { if let ProjectV2NpcDialogueStep::RequestOutcome{interaction}=&mut p[0] { interaction.family=ProjectV2Family::Transition; } }
        assert!(prepare_npc_dialogue_program(&n,true,None).unwrap_err().to_string().contains("not world Transition"));
    }
    #[test] fn source_quest_track_is_never_admitted_as_native_progress() {
        let mut n=node();n.gate=Some(ProjectV2NpcQuestGate{all:vec![ProjectV2NpcQuestPredicate{track:ProjectV2NpcQuestTrack{quest:ProjectV2DefinitionRef{family:ProjectV2Family::Quest,key:"oteryn:source.unbound_quest".into(),revision:"source-only".into()},track:"source_unbound".into()},comparison:ProjectV2NpcQuestCompare::Equal,value:1}]});
        assert!(prepare_npc_dialogue_program(&n,true,None).unwrap_err().to_string().contains("NATIVE_QUEST_TRACK_BINDING_UNAVAILABLE"));
    }
    #[test] fn implicit_legacy_effects_never_interleave_with_explicit_program() {
        let mut n=node();n.program=Some(vec![ProjectV2NpcDialogueStep::EmitReply]);n.ungreet=true;assert!(prepare_npc_dialogue_program(&n,true,None).is_err());
        n.ungreet=false;n.program=None;n.topic_equals=Some(1);assert!(prepare_npc_dialogue_program(&n,true,None).is_err());
    }
    #[test] fn lua_storage_action_and_out_of_range_topic_fail_closed() {
        assert!(serde_json::from_str::<ProjectV2NpcDialogueStep>(r#"{"kind":"SetStorage","value":1}"#).is_err());
        assert!(serde_json::from_str::<ProjectV2NpcDialogueStep>(r#"{"kind":"SetTopic","value":65536}"#).is_err());
    }
}

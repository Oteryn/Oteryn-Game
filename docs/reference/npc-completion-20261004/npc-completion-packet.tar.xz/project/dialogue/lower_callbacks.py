#!/usr/bin/env python3
"""Bounded complete callback grammar; never lowers a partial branch or Quest storage."""
import collections,gzip,hashlib,importlib.util,json
from pathlib import Path
ROOT=Path('/workspace/npc-upstream-first-audit');OWN=Path(__file__).parent;TMP=Path('/tmp/npc-dialogue-program');TMP.mkdir(exist_ok=True)
sp=importlib.util.spec_from_file_location('base',ROOT/'native-dialogue-lowering/lower.py');base=importlib.util.module_from_spec(sp);sp.loader.exec_module(base)
H=base.Hold
class Grammar:
 def __init__(self,s):self.s=s;self.ts=base.ex.lex(s)[0];self.i=0;self.dp=base.ex.delimiters(self.ts)
 def words(self,*words):
  if [t.text for t in self.ts[self.i:self.i+len(words)]]!=list(words):raise H('CALLBACK_GRAMMAR_UNSUPPORTED')
  self.i+=len(words)
 def peek(self):return self.ts[self.i].text if self.i<len(self.ts) else None
 def call(self,callee):
  self.words(*callee,'(');left=self.i-1;right=self.dp[left];args=[self.s[self.ts[a].start:self.ts[b-1].end] for a,b in base.ex.args(self.ts,left,right)];self.i=right+1;return args
 def prefix(self):
  self.words('local','player','=','Player','(','creature',')','local','playerId','=','player',':','getId','(',')','if','not','npcHandler',':','checkInteraction','(','npc',',','creature',')','then','return','false','end')
 def actions(self):
  steps=[];reply=None
  while self.peek() not in ('elseif','end',None):
   if self.peek()!='npcHandler':raise H('FOREIGN_ACTION_OR_NESTED_BRANCH_UNSUPPORTED')
   method=self.ts[self.i+2].text
   if method=='say':
    args=self.call(['npcHandler',':','say'])
    if len(args)!=3 or args[1].strip()!='npc' or args[2].strip()!='creature' or reply is not None:raise H('SPEECH_ORDER_TEXT_OR_TARGET_UNSUPPORTED')
    reply=base.plain_parts(base.Parser(args[0]).parse());steps.append({'kind':'EmitReply'})
   elif method=='setTopic':
    args=self.call(['npcHandler',':','setTopic'])
    if len(args)!=2 or args[0].strip()!='playerId':raise H('TOPIC_OWNER_SCOPE_UNSUPPORTED')
    value=base.Parser(args[1]).parse()
    if type(value) is not int or not 0<=value<=65535:raise H('TOPIC_NIL_DYNAMIC_OR_OUT_OF_BOUNDS')
    steps.append({'kind':'SetTopic','value':value})
   else:raise H('FOREIGN_ACTION_OR_QUEST_EFFECT_UNBOUND')
  if reply is None or not 1<=len(steps)<=8:raise H('EMPTY_OR_OVERSIZE_NATIVE_PROGRAM')
  return reply,steps
 def parse(self):
  self.prefix();self.words('if');nodes=[]
  while True:
   args=self.call(['MsgContains'])
   if len(args)!=2 or args[0].strip()!='message':raise H('KEYWORD_SOURCE_BINDING_UNSUPPORTED')
   trigger=base.Parser(args[1]).parse()
   validation=base.lower_keyword(['{'+args[1]+'}','StdModule.say','{npcHandler=npcHandler,text="shape"}'])
   self.words('then');topic=None
   if self.peek()=='if':
    self.words('if');args=self.call(['npcHandler',':','getTopic'])
    if args!=['playerId']:raise H('TOPIC_READ_OWNER_SCOPE_UNSUPPORTED')
    self.words('==');token=self.ts[self.i];self.i+=1;topic=base.Parser(token.text).parse()
    if type(topic) is not int or not 0<=topic<=65535:raise H('TOPIC_GUARD_NOT_NATIVE_U16')
    self.words('then');reply,steps=self.actions();self.words('end')
    if self.peek() not in ('elseif','end'):raise H('OUTER_EFFECT_AFTER_GUARD_WOULD_BE_DROPPED')
   else:reply,steps=self.actions()
   node={'key':validation['key'],'triggers':[trigger],'reply':reply,'only_focus':True,'program':steps}
   if topic is not None:node.update(topic_equals=topic,consume_on_topic_mismatch=True)
   nodes.append(node)
   if self.peek()=='elseif':self.words('elseif');continue
   self.words('end');break
  if self.peek()=='return':self.words('return','true')
  if self.peek() is not None:raise H('CALLBACK_TRAILING_CONTROL_FLOW_OR_ACTION')
  return nodes

def binding_guards(s,doc,fn,registration):
 ts=base.ex.lex(s)[0];dp=base.ex.delimiters(ts);tables=[(ts[i].start,ts[j].end) for i,j in dp.items() if ts[i].text=='{'];contexts=base.obs.contexts(s,ts)
 def scoped(a,b):return any(f['body_span']['start_char']<=a and b<=f['body_span']['end_char_exclusive'] for f in doc['functions']) or any(c['region']['start_char']<=a and b<=c['region']['end_char_exclusive'] for c in contexts)
 for name,expected in [('keywordHandler',['local','keywordHandler','=','KeywordHandler',':','new','(',')']),('npcHandler',['local','npcHandler','=','NpcHandler',':','new','(','keywordHandler',')'])]:
  writes=[i for i,t in enumerate(ts[:-1]) if t.text==name and ts[i+1].text=='=' and (i==0 or ts[i-1].text not in ('.',':')) and not any(a<t.start<b for a,b in tables)]
  if len(writes)!=1:raise H('HANDLER_INSTANCE_REBOUND_OR_MISSING')
  i=writes[0];end=i-1+len(expected)
  if i==0 or [t.text for t in ts[i-1:end]]!=expected or scoped(ts[i].start,ts[end-1].end):raise H('HANDLER_EXACT_TOP_LEVEL_CONSTRUCTOR_UNPROVEN')
  if end<len(ts) and (ts[end].text in ('or','and','..','+','-','*','/','(','.',':','[',',') or ('\n' not in s[ts[end-1].end:ts[end].start] and ts[end].text!=';')):raise H('HANDLER_CONSTRUCTOR_RHS_EXTENDED')
  for j,t in enumerate(ts):
   if t.text!=name or any(a<t.start<b for a,b in tables):continue
   k=j+1
   while k+1<len(ts) and ts[k].text==',' and ts[k+1].kind=='word':k+=2
   if k>j+1 and k<len(ts) and ts[k].text=='=':raise H('HANDLER_TUPLE_REASSIGNMENT')
   prev=ts[j-1].text if j else None;nxt=ts[j+1].text if j+1<len(ts) else None
   if prev not in ('.',':') and nxt in ('=',':'):continue
   if name=='keywordHandler' and j>=4 and [z.text for z in ts[j-4:j]]==['NpcHandler',':','new','(']:continue
   if name=='npcHandler' and prev=='=' and j>=2 and ts[j-2].text=='npcHandler':continue
   raise H('HANDLER_ALIAS_ESCAPE_OR_INDEXED_ACCESS')
 for i,t in enumerate(ts):
  if t.kind!='word' or t.text not in ('Player','MsgContains','KeywordHandler','NpcHandler','StdModule','CALLBACK_MESSAGE_DEFAULT'):continue
  j=i+1
  while j+1<len(ts) and ts[j].text in ('.',':') and ts[j+1].kind=='word':j+=2
  if j<len(ts) and ts[j].text=='=' or i>0 and ts[i-1].text=='function':raise H('UPSTREAM_CALLBACK_CLASS_OR_FUNCTION_REBOUND')
  if t.text in ('Player','MsgContains') and (i+1>=len(ts) or ts[i+1].text!='('):raise H('UPSTREAM_CALLBACK_FUNCTION_ESCAPE')
 fi=next(i for i,t in enumerate(ts) if t.start==fn['span']['start_char'])
 if fi==0 or ts[fi-1].text!='local' or scoped(fn['span']['start_char'],fn['span']['end_char_exclusive']):raise H('CALLBACK_LOCAL_UNCONDITIONAL_DEFINITION_UNPROVEN')
 ra,rb=registration['span']['start_char'],registration['span']['end_char_exclusive']
 if scoped(ra,rb) or ra<fn['span']['end_char_exclusive']:raise H('CALLBACK_REGISTRATION_CONTEXT_OR_ORDER_UNPROVEN')
 allowed={ts[fi+1].start}
 for c in doc['calls']:
  if c['callee']=='npcHandler:setCallback':
   args=c['argument_spans']
   if len(args)!=2:raise H('CALLBACK_REGISTRATION_ARGS_UNSUPPORTED')
   if source_expr(s,args[1])=='creatureSayCallback':allowed.add(args[1]['start_char'])
 for t in ts:
  if t.text=='creatureSayCallback' and t.start not in allowed:raise H('CALLBACK_REBOUND_OR_ESCAPED')
def source_expr(s,a):return s[a['start_char']:a['end_char_exclusive']].strip()

def compile_callback(s,doc):
 funcs=[f for f in doc['functions'] if f['name']=='creatureSayCallback']
 if len(funcs)!=1:raise H('ONE_CALLBACK_DEFINITION_UNPROVEN')
 fn=funcs[0]
 if fn['parameters_source'].replace(' ','')!='npc,creature,type,message':raise H('CALLBACK_SIGNATURE_UNSUPPORTED')
 regs=[r for r in doc['callback_registrations'] if r['callback_expression']=='creatureSayCallback']
 if len(regs)!=1 or regs[0]['callback_event_expression']!='CALLBACK_MESSAGE_DEFAULT' or len(doc['callback_registrations'])!=1:raise H('DEFAULT_CALLBACK_REGISTRATION_UNPROVEN')
 binding_guards(s,doc,fn,regs[0])
 body=s[fn['body_span']['start_char']:fn['body_span']['end_char_exclusive']]
 nodes=Grammar(body).parse()
 return nodes,{'callback_anchor':base.anchor(s,fn['span']),'registration_anchor':base.anchor(s,regs[0]['span']),'scope':'Private focused conversation for the same npc/creature; current caller must prove session/generation/NPC fences.','branch_policy':'Preserve source if/elseif trigger order; a matched keyword with failed inner topic guard consumes that callback branch with no reply/topic effect.','quest_outcomes':'No Quest/Progress effect is inferred; any unsupported body rejects the entire callback.'}

def run():
 counts=collections.Counter();held=collections.Counter();candidates=[];index=json.load(open(ROOT/'callback-extraction/summary.json'))['index']
 for row in index:
  doc=json.loads(gzip.decompress((ROOT/'callback-extraction'/row['artifact']).read_bytes()))
  if not any(f['name']=='creatureSayCallback' for f in doc['functions']):continue
  sid=doc['source_identity'];s=Path(sid['local_path']).read_text();assert hashlib.sha256(s.encode()).hexdigest()==sid['source_sha256'];counts['source_callbacks_examined']+=1
  try:
   nodes,proof=compile_callback(s,doc);candidates.append({'source_identity':sid,'nodes':nodes,'proof':proof,'source_only':True,'runtime_eligible':False});counts['qualified_callbacks']+=1;counts['qualified_program_nodes']+=len(nodes);counts['topic_guarded_nodes']+=sum('topic_equals' in n for n in nodes)
  except H as e:held[str(e)]+=1
 result={'schema':'NPC_BOUNDED_CALLBACK_PROGRAM_CANDIDATES/v1','counts':dict(counts),'hold_reasons':dict(held),'candidates':candidates,'runtime_activated':False,'source_downloads':0,'quest_role_bindings_emitted':0};(TMP/'callback-program-candidates.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n');(OWN/'callback-summary.json').write_text(json.dumps({k:v for k,v in result.items() if k!='candidates'},indent=2)+'\n');print(json.dumps(result['counts']));print(json.dumps(result['hold_reasons']))
if __name__=='__main__':run()

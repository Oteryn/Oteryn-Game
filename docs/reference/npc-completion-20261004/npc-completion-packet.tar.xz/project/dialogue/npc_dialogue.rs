//! Bounded declarative dialogue steps; foreign outcomes retain their owning authority.
use super::*;

// Reused prospective Quest read-gate vocabulary. Source Storage/kv are never native tracks.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectV2NpcQuestTrack {
    pub quest: ProjectV2DefinitionRef,
    pub track: String,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum ProjectV2NpcQuestCompare { Equal, GreaterOrEqual }
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectV2NpcQuestPredicate {
    pub track: ProjectV2NpcQuestTrack,
    pub comparison: ProjectV2NpcQuestCompare,
    pub value: i64,
}
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectV2NpcQuestGate { pub all: Vec<ProjectV2NpcQuestPredicate> }

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", deny_unknown_fields)]
pub enum ProjectV2NpcDialogueStep {
    /// Emits this keyword's existing `reply` parts once, at this exact source position.
    EmitReply,
    /// Private conversation state, fenced by the caller; never durable Quest Progress.
    SetTopic { value: u16 },
    /// Interaction family alone is insufficient: a role-bound foreign owner must admit it.
    RequestOutcome { interaction: ProjectV2DefinitionRef },
}

pub(super) fn validate_v2_npc_dialogue_program(
    keyword: &ProjectV2DialogueKeyword,
) -> Result<(), ProjectError> {
    if keyword.consume_on_topic_mismatch && keyword.topic_equals.is_none() {
        return Err(ProjectError::InvalidProject("NPC topic mismatch consume policy needs a topic guard"));
    }
    if let Some(gate) = &keyword.gate {
        if gate.all.is_empty() || gate.all.len() > 4 {
            return Err(ProjectError::InvalidProject("NPC dialogue gate needs 1 to 4 predicates"));
        }
        let mut unique = BTreeSet::new();
        for predicate in &gate.all {
            if predicate.track.quest.family != ProjectV2Family::Quest
                || !is_v2_lowercase_slug(&predicate.track.track)
                || !unique.insert(predicate)
            {
                return Err(ProjectError::InvalidProject("NPC dialogue gate invalid native Quest track"));
            }
        }
        // Current native declarations contain no admitted Quest-track read contract.
        return Err(ProjectError::InvalidProject("NPC_NATIVE_QUEST_TRACK_BINDING_UNAVAILABLE"));
    }
    let Some(program) = &keyword.program else {
        if keyword.topic_equals.is_some() {
            return Err(ProjectError::InvalidProject("NPC topic guard requires explicit program"));
        }
        return Ok(());
    };
    if program.is_empty() || program.len() > 8 {
        return Err(ProjectError::InvalidProject("NPC dialogue program needs 1 to 8 steps"));
    }
    if program.iter().filter(|s| matches!(s, ProjectV2NpcDialogueStep::EmitReply)).count() != 1 {
        return Err(ProjectError::InvalidProject("NPC dialogue program must emit existing reply exactly once"));
    }
    let outcomes: Vec<_> = program.iter().filter_map(|s| match s {
        ProjectV2NpcDialogueStep::RequestOutcome { interaction } => Some(interaction),
        _ => None,
    }).collect();
    if outcomes.len() > 1 {
        return Err(ProjectError::InvalidProject("NPC dialogue program has multiple outcome requests"));
    }
    if outcomes.iter().any(|r| r.family != ProjectV2Family::Interaction) {
        return Err(ProjectError::InvalidProject("NPC dialogue outcome requires Interaction role, not world Transition"));
    }
    if !outcomes.is_empty() {
        // No fake accepted role map. An owning, fenced foreign adapter is still required.
        return Err(ProjectError::InvalidProject("NPC_DIALOGUE_OUTCOME_ROLE_BINDING_UNAVAILABLE"));
    }
    if keyword.reset || keyword.ungreet || keyword.move_up.is_some() {
        return Err(ProjectError::InvalidProject("NPC dialogue program with implicit legacy state effects is unqualified"));
    }
    Ok(())
}

/// A read-only plan for the future owning NPC dispatcher, not a mutation or receipt.
#[derive(Debug, PartialEq, Eq)]
pub(crate) enum NpcDialoguePlannedStep<'a> {
    EmitReply(&'a [String]),
    SetTopic(u16),
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) enum NpcDialogueProgramPlan<'a> {
    Skip,
    MatchedNoAction,
    Ordered(Vec<NpcDialoguePlannedStep<'a>>),
    /// Retains all legacy reset/ungreet/move_up fields for their owning legacy handler (not yet integrated).
    Legacy(&'a ProjectV2DialogueKeyword),
}
pub(crate) fn prepare_npc_dialogue_program(
    keyword: &ProjectV2DialogueKeyword,
    focused: bool,
    topic: Option<u16>,
) -> Result<NpcDialogueProgramPlan<'_>, ProjectError> {
    validate_v2_npc_dialogue_program(keyword)?;
    if (keyword.only_focus && !focused) || (keyword.only_unfocus && focused) {
        return Ok(NpcDialogueProgramPlan::Skip);
    }
    if keyword.topic_equals.is_some_and(|value| topic != Some(value)) {
        return Ok(if keyword.consume_on_topic_mismatch {
            NpcDialogueProgramPlan::MatchedNoAction
        } else { NpcDialogueProgramPlan::Skip });
    }
    let mut result = Vec::new();
    if let Some(program) = &keyword.program {
        for step in program {
            result.push(match step {
                ProjectV2NpcDialogueStep::EmitReply => NpcDialoguePlannedStep::EmitReply(&keyword.reply),
                ProjectV2NpcDialogueStep::SetTopic { value } => NpcDialoguePlannedStep::SetTopic(*value),
                ProjectV2NpcDialogueStep::RequestOutcome { .. } => {
                    return Err(ProjectError::InvalidProject("NPC_DIALOGUE_OUTCOME_ROLE_BINDING_UNAVAILABLE"));
                }
            });
        }
    } else { return Ok(NpcDialogueProgramPlan::Legacy(keyword)); }
    Ok(NpcDialogueProgramPlan::Ordered(result))
}

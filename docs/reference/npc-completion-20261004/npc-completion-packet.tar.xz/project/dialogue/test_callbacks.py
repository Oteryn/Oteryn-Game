import importlib.util,unittest
from pathlib import Path
sp=importlib.util.spec_from_file_location('cb',Path(__file__).with_name('lower_callbacks.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
PRE='local keywordHandler=KeywordHandler:new()\nlocal npcHandler=NpcHandler:new(keywordHandler)\n'
OPEN='local function creatureSayCallback(npc,creature,type,message)\nlocal player=Player(creature)\nlocal playerId=player:getId()\nif not npcHandler:checkInteraction(npc,creature) then return false end\n'
CLOSE='\nend\nnpcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT,creatureSayCallback)\n'
BODY='if MsgContains(message,"job") then npcHandler:setTopic(playerId,1) npcHandler:say("Reply.",npc,creature) end\nreturn true'
def compile(body=BODY,pre=PRE,close=CLOSE):
 s=pre+OPEN+body+close;return m.compile_callback(s,m.base.ex.capture(s))
class Tests(unittest.TestCase):
 def test_exact_before_reply_order(self):
  n,_=compile();self.assertEqual(n[0]['program'],[{'kind':'SetTopic','value':1},{'kind':'EmitReply'}])
 def test_inner_topic_guard_consumes_branch(self):
  n,_=compile('if MsgContains(message,"yes") then if npcHandler:getTopic(playerId)==1 then npcHandler:say("Reply.",npc,creature) npcHandler:setTopic(playerId,0) end end')
  self.assertEqual(n[0]['topic_equals'],1);self.assertTrue(n[0]['consume_on_topic_mismatch'])
 def test_guard_outer_effect_must_not_drop(self):
  with self.assertRaises(m.H):compile('if MsgContains(message,"yes") then if npcHandler:getTopic(playerId)==1 then npcHandler:say("Reply.",npc,creature) end npcHandler:setTopic(playerId,0) end')
 def test_no_declarative_rows_cannot_hide_binding_reassignment(self):
  for x in ['npcHandler=other','keywordHandler=other','local x=npcHandler','Player=other','MsgContains=other','CALLBACK_MESSAGE_DEFAULT=other','npcHandler,keywordHandler=other,other']:
   with self.assertRaises(m.H):compile(pre=PRE+x+'\n')
 def test_registration_context_order_and_callback_escape(self):
  for close in ['\nend\nif q then npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT,creatureSayCallback) end','\nend\ncreatureSayCallback=other\nnpcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT,creatureSayCallback)','\nend\nlocal x=creatureSayCallback\nnpcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT,creatureSayCallback)',CLOSE+'npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT,other)']:
   with self.assertRaises(m.H):compile(close=close)
 def test_storage_multi_speech_nil_and_patterns_held(self):
  for body in [BODY.replace('npcHandler:setTopic(playerId,1)','player:setStorageValue(Storage.Quest,1)'),BODY.replace('end\nreturn true','npcHandler:say("Again.",npc,creature) end\nreturn true'),BODY.replace('playerId,1','playerId,nil'),BODY.replace('"job"','"j.b"')]:
   with self.assertRaises(m.H):compile(body)
if __name__=='__main__':unittest.main()

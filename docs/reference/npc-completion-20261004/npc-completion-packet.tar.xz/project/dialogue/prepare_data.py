import collections,copy,gzip,hashlib,json
from pathlib import Path
ROOT=Path('/workspace/npc-upstream-first-audit');OWN=Path(__file__).parent;TMP=Path('/tmp/npc-dialogue-program');BASE=Path('/tmp/npc-full-plan-final-world/definitions/declarations.json')
result=json.load(open(TMP/'callback-program-candidates.json'));declarations=json.load(open(BASE));records={r['identity']['key']:r for r in declarations['records']};ass={}
for u in json.load(open(ROOT/'native-source-fields/staged.json'))['updates']:
 for a in json.loads(u['field']['value']['value'])['source_only_artifact_references']:ass[a['source'],a['path']]=u['target']['key']
updates={};evidence=collections.defaultdict(list);held=[];counts=collections.Counter();proposals=collections.defaultdict(list)
for row in result['candidates']:
 sid=row['source_identity'];npc=records.get(ass.get((sid['source'],sid['path'])));ref=npc.get('dialogue') if npc else None
 if not ref or ref['key'] not in records:held.append({'source':sid,'reason':'NO_SINGLE_EXISTING_REFERENCED_DIALOGUE'});continue
 key=ref['key'];d=records[key];counts['source_callbacks_with_dialogue']+=1
 # Require the complete callback branch sequence to match native sibling order.
 positions=[]
 for n in row['nodes']:
  matches=[(i,v) for i,v in enumerate(d.get('keywords',[])) if v.get('triggers')==n['triggers']]
  if len(matches)!=1 or matches[0][1]['reply']!=n['reply'] or any(matches[0][1].get(f,False) for f in ('reset','ungreet','only_unfocus','move_up')):
   held.append({'source':sid,'reason':'EXISTING_TEXT_TRIGGER_STATE_OR_MISSING_NODE_CONFLICT','triggers':n['triggers']});positions=[];break
  positions.append(matches[0][0])
 if not positions or positions!=sorted(positions):
  if positions:held.append({'source':sid,'reason':'EXISTING_SIBLING_ORDER_CONFLICT'})
  continue
 for n,i in zip(row['nodes'],positions):proposals[key,i].append({'node':n,'source_identity':sid,'source_proof':row['proof']})
for (key,i),rows in proposals.items():
 shape={json.dumps(r['node'],sort_keys=True) for r in rows}
 if len(shape)!=1:held.append({'dialogue_key':key,'reason':'DONOR_PROGRAM_OR_GUARD_CONFLICT'});continue
 n=rows[0]['node']
 if key not in updates:updates[key]={'before':records[key],'after':copy.deepcopy(records[key])}
 dest=updates[key]['after']['keywords'][i]
 assert 'program' not in dest and 'gate' not in dest and 'topic_equals' not in dest
 dest['program']=n['program'];dest['only_focus']=True
 if 'topic_equals' in n:dest['topic_equals']=n['topic_equals'];dest['consume_on_topic_mismatch']=True
 evidence[key].append({'existing_keyword_key':dest['key'],'sources':rows});counts['program_nodes_proposed']+=1;counts['topic_guarded_nodes_proposed']+='topic_equals' in n
for key,u in updates.items():
 field='oteryn:source.npc.local_callback_program';assert not any(f['field_path']==field for f in u['after']['fields'])
 prov={'schema':'NPC_LOCAL_CALLBACK_PROGRAM_PROPOSAL/v1','source_only':True,'runtime_eligible':False,'association':'HISTORICAL_FILENAME_TARGET_ASSOCIATION_NOT_NEW_EXACT_BINDING','source_proofs':evidence[key],'quest_progress_bindings_emitted':0}
 u['after']['fields'].append({'field_path':field,'value':{'type':'Text','value':json.dumps(prov,sort_keys=True,separators=(',',':'))}});u['after']['fields'].sort(key=lambda f:f['field_path'])
patch={'updates':list(updates.values())};data=(json.dumps(patch,ensure_ascii=False,separators=(',',':'))+'\n').encode();(TMP/'native-data-patch.json').write_bytes(data);counts['dialogues_proposed']=len(updates);counts['held_source_candidates']=len(held)
summary={'status':'PROPOSED_SCHEMA_DEPENDENT_UNAPPLIED_SOURCE_ONLY_DATA','counts':dict(counts),'holds':held,'base_declarations_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(data).hexdigest(),'patch_bytes':len(data),'runtime_activated':False,'schema_patch_required':True,'quest_roles_admitted':False};(TMP/'data-evidence.json').write_text(json.dumps(summary,separators=(',',':'))+'\n');(OWN/'data-summary.json').write_text(json.dumps({k:v for k,v in summary.items() if k!='holds'},indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='holds'},indent=2))

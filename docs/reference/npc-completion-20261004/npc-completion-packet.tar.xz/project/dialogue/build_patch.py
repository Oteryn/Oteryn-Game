from pathlib import Path
import difflib,hashlib,json,subprocess,re
ROOT=Path('/workspace/Oteryn-Game');OWN=Path(__file__).parent;TMP=Path('/tmp/npc-dialogue-program');TMP.mkdir(exist_ok=True)
rel='apps/game-server/src/content/project/v2.rs';before=(ROOT/rel).read_text();after=before.replace('mod creature;','mod npc_dialogue;\nmod creature;',1).replace('pub use creature::*;','pub use npc_dialogue::*;\npub use creature::*;',1)
fields='''    /// Read-only native Quest gate; refuses admission until its track owner is bound.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub gate: Option<ProjectV2NpcQuestGate>,
    /// Missing conversation topic is nil, distinct from zero.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub topic_equals: Option<u16>,
    /// Callback branches may consume a keyword while their inner topic guard fails.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub consume_on_topic_mismatch: bool,
    /// Source-ordered bounded steps; None preserves the existing single reply behavior.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub program: Option<Vec<ProjectV2NpcDialogueStep>>,
'''
after=after.replace('pub struct ProjectV2DialogueKeyword {\n','pub struct ProjectV2DialogueKeyword {\n'+fields,1)
after=after.replace('    for keyword in keywords {\n        *node_count += 1;','    for keyword in keywords {\n        validate_v2_npc_dialogue_program(keyword)?;\n        *node_count += 1;',1)
assert after!=before
patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
newrel='apps/game-server/src/content/project/v2/npc_dialogue.rs';new=(OWN/'npc_dialogue.rs').read_text();patch+=''.join(difflib.unified_diff([],new.splitlines(True),fromfile='/dev/null',tofile='b/'+newrel))
testrel='apps/game-server/tests/content_world_project_v2_npc_admission.rs';old=(ROOT/testrel).read_text();newtest,n=re.subn(r'(?m)^(\s*)ProjectV2DialogueKeyword \{',lambda m:m[0]+'\n'+m[1]+'    gate: None,\n'+m[1]+'    topic_equals: None,\n'+m[1]+'    consume_on_topic_mismatch: false,\n'+m[1]+'    program: None,',old);assert n==4
patch+=''.join(difflib.unified_diff(old.splitlines(True),newtest.splitlines(True),fromfile='a/'+testrel,tofile='b/'+testrel))
(OWN/'native-dialogue-program.patch').write_text(patch);r=subprocess.run(['git','apply','--check',str(OWN/'native-dialogue-program.patch')],cwd=ROOT,capture_output=True,text=True);assert r.returncode==0,r.stderr
(TMP/'v2.rs').write_text(after);(TMP/'npc_dialogue.rs').write_text(new)
(OWN/'patch-verification.json').write_text(json.dumps({'status':'PASS_UNAPPLIED_NATIVE_PATCH_CHECK','base_sha256':hashlib.sha256(before.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'manual_module_lines':len(new.splitlines()),'product_modified':False,'quest_gate_admitted':False,'foreign_outcomes_admitted':False},indent=2)+'\n')
print('patch valid',len(patch.splitlines()),'lines')

#[cfg(test)] mod tests {
    use super::*;
    fn request() -> ProjectV2NpcQuestTrack {
        ProjectV2NpcQuestTrack { quest: ProjectV2DefinitionRef { family: ProjectV2Family::Quest,
            key:"fixture:quest.courier".into(),revision:"r1".into() }, track:"delivery".into() }
    }
    fn owner() -> (Vec<ProjectV2Declaration>,Vec<ProjectV2AuthoringProfile>) {
        let r=request();
        (vec![ProjectV2Declaration::Quest { identity:ProjectV2Identity{key:r.quest.key.clone(),revision:r.quest.revision.clone()},fields:vec![] }],
         vec![ProjectV2AuthoringProfile { target:r.quest,data:ProjectV2AuthoringProfileData::Quest(ProjectV2QuestAuthoring {
             tracks:vec![ProjectV2QuestTrackAuthoring{key:r.track,initial_value:Some(0)}],..Default::default() }) }])
    }
    #[test] fn exact_owner_and_authored_local_track_validate() {
        let (d,p)=owner();let r=request();let m=verify_v2_quest_track_membership(&r,&d,&p).unwrap();
        assert_eq!(m.quest(),&r.quest);assert_eq!(m.track(),"delivery");
    }
    #[test] fn missing_read_does_not_use_authored_initial_zero() {
        let(d,p)=owner();let m=verify_v2_quest_track_membership(&request(),&d,&p).unwrap();
        assert_eq!(compare_v2_quest_track_value(&m,ProjectV2NpcQuestCompare::Equal,0,None),ProjectV2QuestPredicateValue::Unknown);
        assert_eq!(compare_v2_quest_track_value(&m,ProjectV2NpcQuestCompare::Equal,0,Some(0)),ProjectV2QuestPredicateValue::Pass);
        assert_eq!(compare_v2_quest_track_value(&m,ProjectV2NpcQuestCompare::GreaterOrEqual,1,Some(0)),ProjectV2QuestPredicateValue::Deny);
    }
    #[test] fn another_quest_or_revision_cannot_borrow_track() {
        let(d,p)=owner();let mut r=request();r.quest.revision="r2".into();assert!(verify_v2_quest_track_membership(&r,&d,&p).is_err());
        r=request();r.quest.key="fixture:quest.other".into();assert!(verify_v2_quest_track_membership(&r,&d,&p).is_err());
    }
    #[test] fn source_storage_and_world_transition_are_rejected() {
        let(d,p)=owner();let mut r=request();r.track="Storage.Quest.ExampleQuest".into();assert!(verify_v2_quest_track_membership(&r,&d,&p).is_err());
        r=request();r.track="9000".into();assert!(verify_v2_quest_track_membership(&r,&d,&p).is_err());
        r=request();r.quest.family=ProjectV2Family::Transition;assert!(verify_v2_quest_track_membership(&r,&d,&p).is_err());
    }
    #[test] fn missing_profile_or_track_is_not_membership() {
        let(d,p)=owner();assert!(verify_v2_quest_track_membership(&request(),&d,&[]).is_err());
        let mut r=request();r.track="unbound".into();assert!(verify_v2_quest_track_membership(&r,&d,&p).is_err());
    }
    #[test] fn duplicate_owner_or_tracks_fail_closed() {
        let(d,mut p)=owner();p.push(p[0].clone());assert!(verify_v2_quest_track_membership(&request(),&d,&p).is_err());
        let(d,mut p)=owner();if let ProjectV2AuthoringProfileData::Quest(q)=&mut p[0].data { q.tracks.push(q.tracks[0].clone()); }
        assert!(verify_v2_quest_track_membership(&request(),&d,&p).is_err());
    }
    #[test] fn legacy_empty_tracks_roundtrip_without_new_json_field() {
        let q:ProjectV2QuestAuthoring=serde_json::from_str(r#"{"premium":false}"#).unwrap();assert!(q.tracks.is_empty());
        assert_eq!(serde_json::to_string(&q).unwrap(),r#"{"premium":false}"#);
        assert!(serde_json::from_str::<ProjectV2QuestTrackAuthoring>(r#"{"key":"delivery","storage":9000}"#).is_err());
    }
    #[test] fn shared_gate_membership_checks_every_predicate_and_bounds() {
        let(d,p)=owner();let predicate=ProjectV2NpcQuestPredicate{track:request(),comparison:ProjectV2NpcQuestCompare::Equal,value:1};
        assert_eq!(validate_v2_npc_quest_gate_membership(&ProjectV2NpcQuestGate{all:vec![predicate.clone()]},&d,&p).unwrap().len(),1);
        assert!(validate_v2_npc_quest_gate_membership(&ProjectV2NpcQuestGate{all:vec![predicate.clone(),predicate.clone()]},&d,&p).is_err());
        assert!(validate_v2_npc_quest_gate_membership(&ProjectV2NpcQuestGate{all:vec![]},&d,&p).is_err());
        let mut missing=predicate;missing.track.track="unbound".into();assert!(validate_v2_npc_quest_gate_membership(&ProjectV2NpcQuestGate{all:vec![missing]},&d,&p).is_err());
    }
}

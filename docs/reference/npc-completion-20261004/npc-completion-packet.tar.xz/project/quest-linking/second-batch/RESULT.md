# LOCAL PROPOSED named Quest-track amendment

`named-quest-tracks.patch` changes the **existing** `ProjectV2QuestAuthoring` with optional `tracks`, canonical sorting and sorted/unique name validation. It adds `quest_tracks.rs` (106 lines) and updates the one existing struct-literal fixture. No migration, root schema/protocol revision or runtime grant. Product remains untouched.

Membership lookup requires an exact Quest declaration and exact Quest-profile family/key/revision, then explicit authored local-track membership. Missing/duplicate owner, missing track, stale revision, source storage expression, numeric storage ID and World Transition reject. Private proof fields prevent callers constructing membership accidentally. Proof is immutable **authoring membership**, not permission to read/write durable progress.

The shared dialogue gate remains `{all:[{track:{quest,track},comparison,value}]}`. The amendment depends on the earlier dialogue DTO patch, without modifying its `NPC_NATIVE_QUEST_TRACK_BINDING_UNAVAILABLE` refusal. `initial_value: Option<i64>` is metadata for a future owning initializer; a missing state read returns `Unknown`, including when authored initial value is zero. Pure comparisons do not activate any gate or effect.

Checked locally available Quest worker data: protected `bac15d89890dda6c4cb802a15b7192ccbd3e98b0` snapshot and existing sidecars; no newer private strict-schema output or accepted track/persistence contract is available. No competing Quest parser or alias inference was introduced.

Verification: `git apply --check` PASS against frozen product; eight focused **Rust metadata tests PASS**, using the exact amended QuestAuthoring/profile definitions, exact shared gate DTOs and cached native foreign types/serde libraries. Cases include explicit membership, missing/zero distinction, stale owner/revision, unsupported storage/World Transition, missing/duplicate profile/track, legacy JSON omission/unknown fields and all gate predicates/bounds. This is not a full native-crate compilation; root owns integration check.

Stage: `/tmp/npc-quest-track-amendment` 2.8 MB; durable second-batch under 45 KB. Patch SHA and base pin in `patch-check.json`; final test receipt in `verification.json`. Remaining owner seam: accepted fenced Quest-track reader/writer and role-bound QuestEffect transaction. Actor activation remains disabled.

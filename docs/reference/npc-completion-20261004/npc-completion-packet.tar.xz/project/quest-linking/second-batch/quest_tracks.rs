//! LOCAL PROPOSED amendment: authoring membership, never a runtime grant or storage alias.
use super::*;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectV2QuestTrackAuthoring {
    /// Explicit native local name scoped by its owning Quest revision.
    pub key: String,
    /// Only an owning initializer may consume this; a missing read stays unknown.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub initial_value: Option<i64>,
}

pub(super) fn validate_v2_quest_track_authoring(
    tracks: &[ProjectV2QuestTrackAuthoring],
) -> Result<(), ProjectError> {
    if tracks.iter().any(|track| !is_native_track_name(&track.key))
        || tracks.windows(2).any(|pair| pair[0].key >= pair[1].key)
    {
        return Err(ProjectError::InvalidProject("Quest tracks require sorted unique native local names"));
    }
    Ok(())
}

fn is_native_track_name(key: &str) -> bool {
    is_v2_lowercase_slug(key) && key.as_bytes().first().is_some_and(u8::is_ascii_lowercase)
}

/// Proof of immutable DTO membership only. Does not bind a durable reader, writer or receipt.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProjectV2QuestTrackMembership {
    quest: ProjectV2DefinitionRef,
    track: String,
}
impl ProjectV2QuestTrackMembership {
    pub fn quest(&self) -> &ProjectV2DefinitionRef { &self.quest }
    pub fn track(&self) -> &str { &self.track }
}

pub fn verify_v2_quest_track_membership(
    request: &ProjectV2NpcQuestTrack,
    declarations: &[ProjectV2Declaration],
    profiles: &[ProjectV2AuthoringProfile],
) -> Result<ProjectV2QuestTrackMembership, ProjectError> {
    if request.quest.family != ProjectV2Family::Quest || !is_native_track_name(&request.track) {
        return Err(ProjectError::InvalidProject("Quest track requires Quest family and native local name"));
    }
    let matches = declarations.iter().filter(|declaration| matches!(declaration,
        ProjectV2Declaration::Quest { identity, .. }
        if identity.key == request.quest.key && identity.revision == request.quest.revision)).count();
    if matches != 1 {
        return Err(ProjectError::InvalidProject("Quest track owning declaration absent or ambiguous"));
    }
    let mut owners = profiles.iter().filter(|profile| profile.target == request.quest);
    let Some(owner) = owners.next() else {
        return Err(ProjectError::InvalidProject("Quest track owning authoring absent"));
    };
    if owners.next().is_some() {
        return Err(ProjectError::InvalidProject("Quest track owning authoring ambiguous"));
    }
    let ProjectV2AuthoringProfileData::Quest(authoring) = &owner.data else {
        return Err(ProjectError::InvalidProject("Quest track owner profile kind mismatch"));
    };
    validate_v2_quest_track_authoring(&authoring.tracks)?;
    if !authoring.tracks.iter().any(|track| track.key == request.track) {
        return Err(ProjectError::InvalidProject("Quest track not explicitly authored by owning Quest revision"));
    }
    Ok(ProjectV2QuestTrackMembership { quest: request.quest.clone(), track: request.track.clone() })
}

/// Same shared gate fields as dialogue. Validating membership never admits a runtime gate.
pub fn validate_v2_npc_quest_gate_membership(
    gate: &ProjectV2NpcQuestGate,
    declarations: &[ProjectV2Declaration],
    profiles: &[ProjectV2AuthoringProfile],
) -> Result<Vec<ProjectV2QuestTrackMembership>, ProjectError> {
    if gate.all.is_empty() || gate.all.len() > 4 {
        return Err(ProjectError::InvalidProject("NPC Quest gate needs 1 to 4 predicates"));
    }
    let mut unique = BTreeSet::new();
    gate.all.iter().map(|predicate| {
        if !unique.insert(predicate) {
            return Err(ProjectError::InvalidProject("NPC Quest gate has duplicate predicate"));
        }
        verify_v2_quest_track_membership(&predicate.track, declarations, profiles)
    }).collect()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProjectV2QuestPredicateValue { Pass, Deny, Unknown }

/// Pure value comparison after membership validation, not a persistent state consumer.
/// The future fenced reader supplies `observed`; authoring initial_value is never substituted.
pub fn compare_v2_quest_track_value(
    _membership: &ProjectV2QuestTrackMembership,
    comparison: ProjectV2NpcQuestCompare,
    expected: i64,
    observed: Option<i64>,
) -> ProjectV2QuestPredicateValue {
    let Some(observed) = observed else { return ProjectV2QuestPredicateValue::Unknown; };
    let pass = match comparison {
        ProjectV2NpcQuestCompare::Equal => observed == expected,
        ProjectV2NpcQuestCompare::GreaterOrEqual => observed >= expected,
    };
    if pass { ProjectV2QuestPredicateValue::Pass } else { ProjectV2QuestPredicateValue::Deny }
}

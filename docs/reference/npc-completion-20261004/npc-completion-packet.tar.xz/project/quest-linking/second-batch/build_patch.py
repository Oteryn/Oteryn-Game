"""Patch existing QuestAuthoring; shared dialogue gate DTO remains unchanged."""
import difflib,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path('/workspace/Oteryn-Game');OWN=pathlib.Path(__file__).parent;TMP=pathlib.Path('/tmp/npc-quest-track-amendment');TMP.mkdir(exist_ok=True)
rel='apps/game-server/src/content/project/v2.rs';before=(ROOT/rel).read_text();after=before.replace('mod creature;','mod quest_tracks;\nmod creature;',1).replace('pub use creature::*;','pub use quest_tracks::*;\npub use creature::*;',1)
field='''    /// LOCAL PROPOSED: explicitly authored native local tracks, not source storage IDs.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tracks: Vec<ProjectV2QuestTrackAuthoring>,
'''
after=after.replace('pub struct ProjectV2QuestAuthoring {\n','pub struct ProjectV2QuestAuthoring {\n'+field,1)
after=after.replace('            ProjectV2AuthoringProfileData::Quest(profile) => {\n','            ProjectV2AuthoringProfileData::Quest(profile) => {\n                profile.tracks.sort_by(|left, right| left.key.cmp(&right.key));\n',1)
after=after.replace('        ProjectV2AuthoringProfileData::Quest(value) => {\n','        ProjectV2AuthoringProfileData::Quest(value) => {\n            validate_v2_quest_track_authoring(&value.tracks)?;\n',1)
assert after!=before
module=(OWN/'quest_tracks.rs').read_text();patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));newrel='apps/game-server/src/content/project/v2/quest_tracks.rs'
patch+=''.join(difflib.unified_diff([],module.splitlines(True),fromfile='/dev/null',tofile='b/'+newrel))
testrel='apps/game-server/tests/content_world_project_v2.rs';oldtest=(ROOT/testrel).read_text();newtest=oldtest.replace('data: ProjectV2AuthoringProfileData::Quest(ProjectV2QuestAuthoring {\n','data: ProjectV2AuthoringProfileData::Quest(ProjectV2QuestAuthoring {\n                tracks: vec![],\n',1);assert newtest!=oldtest
patch+=''.join(difflib.unified_diff(oldtest.splitlines(True),newtest.splitlines(True),fromfile='a/'+testrel,tofile='b/'+testrel));(OWN/'named-quest-tracks.patch').write_text(patch)
check=subprocess.run(['git','apply','--check',str(OWN/'named-quest-tracks.patch')],cwd=ROOT,capture_output=True,text=True);assert check.returncode==0,check.stderr
# Metadata harness uses amended exact Quest DTO and exact profile enum/wrapper, plus cached foreign DTOs.
def block(name):
 m=re.search(r'(?m)^pub (?:struct|enum) '+name+r'\s*\{',after);start=after.rfind('#[derive',0,m.start());end=after.find('\n}\n',m.end())+3;return after[start:end]
gate=(OWN.parent.parent/'dialogue/npc_dialogue.rs').read_text();gate=gate[gate.index('#[derive'):gate.index('\n#[derive',gate.index('pub struct ProjectV2NpcQuestGate'))]
slug=after[after.index('fn is_v2_lowercase_slug'):after.index('\n/// Dialogue text',after.index('fn is_v2_lowercase_slug'))]
harness='use serde::{Deserialize,Serialize};\nuse std::collections::BTreeSet;\nuse oteryn_game_server::content::*;\n'+slug+'\n'+gate+'\n'+block('ProjectV2QuestAuthoring')+'\n'+block('ProjectV2AuthoringProfileData')+'\n'+block('ProjectV2AuthoringProfile')+'\n#[path="'+str(OWN/'quest_tracks.rs')+'"] mod proposed;\nuse proposed::*;\n'+(OWN/'tests.rs').read_text()
(TMP/'metadata_tests.rs').write_text(harness)
result={'status':'PASS_LOCAL_PROPOSED_PATCH_CHECK','base_v2_sha256':hashlib.sha256(before.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'module_lines':len(module.splitlines()),'runtime_admission_changed':False,'shared_gate_fields_changed':False,'product_modified':False,'private_quest_worker_data_available':False,'cached_protected_revision':'bac15d89890dda6c4cb802a15b7192ccbd3e98b0'}
(OWN/'patch-check.json').write_text(json.dumps(result,separators=(',',':'))+'\n');print(json.dumps(result))

use std::{env,fs};
use oteryn_game_server::content::{ProjectV2Declaration,ProjectV2AuthoringProfile};
fn main()->Result<(),Box<dyn std::error::Error>> {
 let source=fs::read(env::args().nth(1).ok_or("candidate path")?)?;
 let value:serde_json::Value=serde_json::from_slice(&source)?;
 let declarations:Vec<ProjectV2Declaration>=serde_json::from_value(value["declarations"].clone())?;
 let profiles:Vec<ProjectV2AuthoringProfile>=serde_json::from_value(value["authoring_profiles"].clone())?;
 if declarations.len()!=352 || profiles.len()!=352{return Err("count drift".into());}
 for declaration in &declarations {if !matches!(declaration,ProjectV2Declaration::Quest{..}){return Err("only Quest source DTOs".into());}}
 println!("PASS_EXISTING_RUST_QUEST_AND_QUEST_AUTHORING_DTO declarations={} profiles={} runtime_bindings=0",declarations.len(),profiles.len());
 Ok(())
}

import copy,unittest
from linker import BindingError,canonical,sha,validate_binding,normalize_record
class LinkerTests(unittest.TestCase):
 def setUp(self):
  self.quest={'identity':{'key':'oteryn:quest.real_source_fixture','revision':'quest-r1'},'source_data':{'progress':[]}}
  self.keys={(self.quest['identity']['key'],'quest-r1')}
  self.bind={'authoring_quest':self.quest['identity'],'native_quest_binding':None,'native_progress_binding':None,'native_transition_binding':None}
 def test_known_source_identity_kept_runtime_ineligible(self):
  out=validate_binding(self.bind,self.keys,set());self.assertFalse(out['runtime_eligible']);self.assertIsNone(out['native_progress_binding'])
 def test_explicit_existing_native_quest_ref_is_only_authoring_link(self):
  b=copy.deepcopy(self.bind);b['native_quest_binding']={'family':'Quest',**self.quest['identity']}
  out=validate_binding(b,self.keys,{('Quest',self.quest['identity']['key'],'quest-r1')});self.assertEqual(out['status'],'NATIVE_QUEST_AUTHORING_REFERENCE_VALID_ONLY');self.assertFalse(out['runtime_eligible'])
 def test_unresolved_native_quest_and_stale_revision_rejected(self):
  b=copy.deepcopy(self.bind);b['native_quest_binding']={'family':'Quest',**self.quest['identity'],'revision':'stale'}
  with self.assertRaisesRegex(BindingError,'absent or wrong revision'):validate_binding(b,self.keys,{('Quest',self.quest['identity']['key'],'quest-r1')})
 def test_storage_string_never_admitted_as_progress_binding(self):
  b=copy.deepcopy(self.bind);b['native_progress_binding']='Storage.Quest.Example'
  with self.assertRaisesRegex(BindingError,'progress contract unavailable'):validate_binding(b,self.keys,set())
 def test_world_transition_never_quest_transition(self):
  b=copy.deepcopy(self.bind);b['native_transition_binding']={'family':'Transition','key':'oteryn:transition.world_gate','revision':'r1'}
  with self.assertRaisesRegex(BindingError,'World Transition is not it'):validate_binding(b,self.keys,{('Transition','oteryn:transition.world_gate','r1')})
 def test_unknown_fields_fail_closed(self):
  b=copy.deepcopy(self.bind);b['runtime_eligible']=True
  with self.assertRaisesRegex(BindingError,'unknown or missing'):validate_binding(b,self.keys,set())
 def test_no_filename_identity_guess(self):
  b=copy.deepcopy(self.bind);b['authoring_quest']['key']='oteryn:quest.guessed_from_filename'
  with self.assertRaisesRegex(BindingError,'unknown protected'):validate_binding(b,self.keys,set())
 def test_mismatched_source_definition_digest_rejected(self):
  r={'authoring_quest':self.quest['identity'],'authoring_definition_sha256':'0'*64}
  with self.assertRaisesRegex(BindingError,'digest mismatch'):normalize_record(r,{next(iter(self.keys)):self.quest},set(),{})
if __name__=='__main__':unittest.main()

#!/usr/bin/env python3
"""Exact source-context/epoch contract requests from existing held records; no aliases."""
import gzip,json,pathlib
from linker import ROOT,OUT,canonical,sha
def main():
 assessment=json.load(gzip.open(ROOT/'quest-association-repair/assessment.json.gz'));held=[r for r in assessment['records']if r['disposition']=='HELD_SOURCE_CONTEXT_OR_EPOCH']
 groups={};summer=[]
 for row in held:
  if row['path'].endswith('captain_haba_open_sea.lua'):
   p=row['proof'];anchor=p['registered_type_anchor'];source=anchor['source'];assert 'Game.createNpcType("Captain Haba (Open Sea)")' in anchor['line_text']
   key=source['source'],source['path'];context={'repository':source['repository'],'revision':source['revision'],'path':source['path'],'source_sha256':source['source_sha256'],'registered_type':'Captain Haba (Open Sea)'}
   group=groups.setdefault(key,{'source_context':context,'source_context_digest':sha(canonical(context)),
    'registered_type_anchor':anchor,'display_name_anchor':p['display_name_anchor'],'existing_character_candidate':{'family':'NPC',**p['existing_main_target']},
    'native_actor_context_binding':None,'native_quest_binding':None,'runtime_eligible':False,
    'decision':'KEEP_DISTINCT_SOURCE_NPC_CONTEXT_UNDER_EXISTING_CHARACTER_CANDIDATE_REQUIRE_EXPLICIT_ACTOR_CONTEXT_CONSUMER','source_occurrences':[]})
   group['source_occurrences'].append({k:row[k] for k in ('original_row_1based','authoring_quest','source_track','source_transition','line')})
  else:
   p=row['proof'];assert p['kind']=='SOURCE_EPOCH_STORAGE_TARGET_DRIFT'
   summer.append({'authoring_quest':row['authoring_quest'],'protected_original_occurrence':{k:row[k] for k in ('original_row_1based','source_track','source_transition','path','line')},
    'old_target_symbol':p['old_symbol'],'old_source_blob_sha256':p['old_blob_sha256'],'old_storage_identity_equivalence_proven':False,
    'current_target_symbol':p['current_symbol'],'current_occurrence_anchor':p['current_line_anchor'],
    'request':'QUEST_AUTHORING_OWNER_RECONCILE_CURRENT_PIN_SOURCE_OCCURRENCE_AND_NAMED_TRACK_WITHOUT_IMPLICIT_OLD_STORAGE_ALIAS',
    'native_quest_binding':None,'native_progress_binding':None,'native_transition_binding':None,'runtime_eligible':False})
 assert len(groups)==2 and sum(len(g['source_occurrences'])for g in groups.values())==32 and len(summer)==1
 result={'schema':'NPC_QUEST_SOURCE_CONTEXT_CONTRACT_REQUESTS/v1','source_only':True,'variant_contexts':list(groups.values()),'epoch_reconciliation_requests':summer,
  'source_holds_accounted':33,'native_runtime_activated':False,'new_native_identities':0}
 (OUT/'source-context-manifest.json').write_bytes(canonical(result)+b'\n');print(json.dumps({'status':'PASS_EXACT_SOURCE_CONTEXT_MANIFEST','source_holds':33,'variant_contexts':2,'epoch_requests':1,'native_bindings':0}))
if __name__=='__main__':main()

# NPC-01/NPC-07: smallest concrete Quest linking contract

Implemented `linker.py`: SourceOccurrence → exact known protected Quest authoring identity. It overlays the 31 qualified supplements on the immutable 4379-row historical table, checks every Quest definition digest and every existing NPC target/revision, then produces a normalized source association table. There are 352 known Quest identities, 4346 qualified NPC source associations, 33 source-context/epoch holds. **No source occurrence becomes a native Progress/Transition binding.**

Optional explicit binding input must exactly match `NPC_EXPLICIT_QUEST_AUTHORING_BINDINGS/v1`, pinned decoded snapshot digest, and a list of `{authoring_quest, native_quest_binding, native_progress_binding, native_transition_binding}`. Native Quest references must resolve by exact family/key/revision to the actual WorldProject. Unknown fields, guessed identities, stale revisions and unsupported progress/transition bindings reject. A valid native Quest ref establishes an **authoring reference only**, never executable readiness.

Actual current APIs:

- `apps/game-server/src/content/project/v2.rs`: `ProjectV2Declaration::Quest`, `ProjectV2AuthoringProfileData::Quest`, `ProjectV2QuestAuthoring`. Quest authoring has requirements/rewards/encounters/fields, **no named progress track definitions or accepted progress references**.
- `ProjectV2Family` has no Progress. `ProjectV2Declaration::Transition` belongs to world routing; it must never stand in for a Quest transition.
- `CharacterProgressionFact<K,R,V>` is a generic domain value, not an accepted persistent Quest-track contract.
- `durability/character_progression.rs` + migration `0009_character_progression.sql` implement fenced XP/level state. `durability/bestiary_progress.rs` + migration `0019_character_bestiary_progress.sql` implement race kill counts. Neither offers Quest track read/write APIs. Reusing these names or tables for source storage would silently change semantics.

Concrete data DTO candidate: 352 `Quest` declarations and matching `Quest` authoring profiles using **the 352 already present protected authoring keys**, containing only source-only provenance references in existing CandidateField/Text. No source requirements, `completeness`, unresolved conditions, flags or runtime aliases are promoted. `validate_dto.rs` verifies the candidate through the actual existing Rust DTO deserializers. This candidate is prepared, **not applied** and does not create an accepted Quest runtime subsystem.

Smallest remaining product seam for the root-selected shared gate/effect:

1. Extend **existing** `ProjectV2QuestAuthoring` with explicitly authored named tracks scoped by a verified Quest reference, e.g. `tracks: Vec<QuestTrackAuthoring { key, value_kind, initial_value: Option<i64> }>`. Track names come from the owning Quest worker's explicit accepted mapping, never from raw storage numbers, filename guessing or automatic source alias conversion. Missing initial state remains unknown; no implicit zero or -1.
2. Add an owner-approved `QuestTrackRef { quest: ProjectV2DefinitionRef, track: String }` resolver checking the Quest family/revision and authored track membership. `QuestGate` reads only that verified ref and returns unknown/deny when state is missing. NPC topic is separately `Option<u16>`; missing topic is not zero.
3. Add a read-only Quest-track consumer and a **role-bound QuestEffect** to the existing Character semantic transaction path. The effect carries the verified Quest/track, expected state/guard, next typed value and command occurrence. It must use current `CurrentCharacterGameplayFence`, Character revision/recovery/session/lease/scope/node checks, immutable receipt deduplication, and commit alongside the associated inventory/wallet effects. No generic World Transition, raw `setStorageValue` writer or fabricated receipt is allowed.
4. Schema/consumer owner must define the precise track value domain, missing-state policy, receipt kind and loader/track registration evidence before these references are executable. This lane deliberately rejects every non-null progress/Quest-transition binding while that seam is absent.

`source-context-manifest.json` is a concrete request for the 33 holds:

- Captain Haba Open Sea: two exact repository/pin/type contexts, 32 source occurrences. Preserve `Game.createNpcType("Captain Haba (Open Sea)")` as a distinct source context under a candidate existing character reference, with actor-context binding null. The main Haba actor must not consume these branches until an explicit context consumer exists. No new NPC identity is invented.
- Summer Shirtalis: one explicit current-pin occurrence anchor and old unresolved target identity. The owning Quest authoring worker must reconcile the current `DreamScar.Permission` occurrence/track against the old unresolved `DreamScarAccess` reference. Similar name, line, topic or value is not storage identity proof.

Ready inputs: protected snapshot at `bac15d89890dda6c4cb802a15b7192ccbd3e98b0`; original association table; 31-row supplement; current exact source context manifest. Private/new Quest worker edits are unavailable here and are not claimed as integrated. The linker reuses these artifacts and introduces no competing Quest parser or alias resolver.

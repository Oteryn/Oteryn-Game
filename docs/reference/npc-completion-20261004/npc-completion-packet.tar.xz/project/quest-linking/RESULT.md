# NPC-01/NPC-07 local result

Ready implementation: `linker.py` checks/normalizes the 352 protected Quest authoring identities, all 4379 source associations and the 31 supplementary repairs. It outputs 4346 qualified NPC source associations, 33 context/epoch holds, **zero accepted native progress/transition bindings and zero runtime-eligible links**. Inputs and output hashes are in `manifest.json`.

Concrete DTO candidate: `quest-authoring-candidate-patch.json.gz` contains 352 source-only `Quest` declarations and 352 matching `Quest` authoring profiles using existing protected identities. The actual cached game-server Rust DTO deserializers accepted all candidates. **Not applied to WorldProject, not a runtime Quest subsystem, no private Quest-worker updates presumed.**

Eight meaningful linker fixtures passed: known source identity, explicit existing native Quest authoring reference, stale revision rejection, raw storage rejection, World Transition rejection, unknown field rejection, filename guess rejection, source definition digest rejection. Compressed candidate roundtrip/hash qualification passed. Receipts in `verification.json`.

NPC-07 exact requests: `source-context-manifest.json` accounts for all 33 holds: two distinct Captain Haba Open Sea source contexts with 32 occurrences, and one current-epoch Summer Shirtalis storage-target reconciliation. Existing character candidates are separated from actor contexts; no invented NPC identity or storage alias.

Remaining concrete seam: `ProjectV2QuestAuthoring` has no accepted named-track membership; Character durability has XP/level and Bestiary readers/writers, not Quest-track persistence. Root's role-bound QuestEffect requires that owner contract plus fenced receipt/atomic commit integration. `CONTRACT.md` specifies the smallest additions and points to actual types/files. Progress and Quest-transition bindings fail closed until implemented; generic World Transition is never reused.

Commerce dependency: `commerce-gate.json` preserves pack-qualified `Storage.Quest.ExampleQuest` as opaque. Auxiliary declarations are tables; global selected-loader resolution remains unproven. No match among 352 Quest definitions and no native PostmanQuest alias. Absent `new frontier` discount entry yields source amount zero without inventing a Quest gate.

Scope: own lane only, under 100 KB durable; large reproducible source-link table in `/tmp/npc-completion-quest-linking`. No network, product edit, PR, cloned build or runtime activation.

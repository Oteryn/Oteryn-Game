#!/usr/bin/env python3
"""Concrete fail-closed source→known Quest authoring linker, not a Quest storage parser."""
import argparse,collections,gzip,hashlib,json,pathlib,re
ROOT=pathlib.Path('/workspace/npc-upstream-first-audit');OUT=ROOT/'npc-completion-project/quest-linking';TEMP=pathlib.Path('/tmp/npc-completion-quest-linking')
NATIVE_SEAMS={'quest':'ProjectV2Declaration::Quest + ProjectV2AuthoringProfileData::Quest',
 'progress':None,'quest_transition':None,'persistent_quest_track_reader':None,'persistent_quest_track_writer':None}
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
class BindingError(ValueError):pass
def exact_fields(value,fields):
 if not isinstance(value,dict) or set(value)!=set(fields):raise BindingError('unknown or missing binding fields')
def identity(value):
 exact_fields(value,('key','revision'))
 if not all(isinstance(value[k],str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,159}',value[k]) for k in value):raise BindingError('invalid identity')
 return value
def ref(value,family):
 exact_fields(value,('family','key','revision'))
 if value['family']!=family:raise BindingError('wrong semantic family')
 identity({k:value[k] for k in ('key','revision')});return value
def validate_binding(binding,authoring_keys,declarations):
 exact_fields(binding,('authoring_quest','native_quest_binding','native_progress_binding','native_transition_binding'))
 authoring=identity(binding['authoring_quest']);key=(authoring['key'],authoring['revision'])
 if key not in authoring_keys:raise BindingError('unknown protected authoring Quest identity')
 quest=binding['native_quest_binding']
 if quest is not None:
  ref(quest,'Quest')
  if ('Quest',quest['key'],quest['revision']) not in declarations:raise BindingError('native Quest reference absent or wrong revision')
 # ProjectV2Family lacks Progress. Its Transition is World routing; do not reuse it for Quest progress.
 if binding['native_progress_binding'] is not None:raise BindingError('accepted native Quest progress contract unavailable')
 if binding['native_transition_binding'] is not None:raise BindingError('accepted native Quest transition contract unavailable; World Transition is not it')
 return {'authoring_quest':authoring,'native_quest_binding':quest,'native_progress_binding':None,'native_transition_binding':None,
 'status':'NATIVE_QUEST_AUTHORING_REFERENCE_VALID_ONLY' if quest else 'KNOWN_PROTECTED_QUEST_AUTHORING_CANDIDATE','runtime_eligible':False}
def normalize_record(record,quests,decls,bindings):
 quest=record['authoring_quest'];key=quest['key'],quest['revision']
 if key not in quests:raise BindingError('source occurrence references unknown authoring Quest')
 if record['authoring_definition_sha256']!=sha(canonical(quests[key])):raise BindingError('protected Quest definition digest mismatch')
 occurrence=record['source_occurrence'];npc=record['npc_target']
 if npc and ('NPC',npc['key'],npc['revision']) not in decls:raise BindingError('existing NPC target missing or revision drift')
 binding=bindings.get(key,{'authoring_quest':quest,'native_quest_binding':None,'native_progress_binding':None,'native_transition_binding':None})
 accepted=validate_binding(binding,set(quests),decls)
 return {'source_association_sha256':sha(canonical(record)),'authoring_quest':quest,'authoring_definition_sha256':record['authoring_definition_sha256'],
 'source_track':record['source_track'],'source_transition':record['source_transition'],'source_occurrence':occurrence,
 'npc_target':npc,'source_qualification':record['source_qualification'],'source_association_scope':'AUTHORING_CANDIDATE_NOT_ACCEPTED_PROGRESS_OR_TRANSITION',
 **accepted,'source_only':True,'all_source_conditions_validated':False,'source_readiness_promoted':False,
 'native_runtime_status':'NO_ACCEPTED_QUEST_PROGRESS_PERSISTENCE_CONSUMER'}
def build(world,manifest=None):
 snapshot_path=ROOT/'quest-reuse/protected-quest-authoring.json.gz';snapshot=json.load(gzip.open(snapshot_path));quests={(q['identity']['key'],q['identity']['revision']):q for q in snapshot['quest_definitions']};assert len(quests)==352
 state=json.load(open(world/'definitions/declarations.json'));decls={(d['kind'],d['identity']['key'],d['identity']['revision']) for d in state['records']}
 bindings={}
 if manifest is not None:
  exact_fields(manifest,('schema','protected_snapshot_sha256','bindings'))
  if manifest['schema']!='NPC_EXPLICIT_QUEST_AUTHORING_BINDINGS/v1' or manifest['protected_snapshot_sha256']!=sha(canonical(snapshot)):raise BindingError('binding manifest input revision/digest mismatch')
  for row in manifest['bindings']:
   valid=validate_binding(row,set(quests),decls);key=valid['authoring_quest']['key'],valid['authoring_quest']['revision']
   if key in bindings:raise BindingError('duplicate explicit Quest binding')
   bindings[key]=row
 old_path=ROOT/'quest-reuse/associations.jsonl.gz';old=[json.loads(x) for x in gzip.open(old_path,'rb')]
 repairs_path=ROOT/'quest-association-repair/repairs.jsonl.gz';repairs=[json.loads(x) for x in gzip.open(repairs_path,'rb')];replacement={r['original_association_row_1based']:r for r in repairs};assert len(replacement)==31
 records=[]
 for number,old_record in enumerate(old,1):
  record=replacement.get(number,old_record)
  if number in replacement and record['original_association_sha256']!=sha(canonical(old_record)):raise BindingError('supplement does not qualify immutable original source record')
  normalized=normalize_record(record,quests,decls,bindings);normalized['historical_row_1based']=number
  records.append(normalized)
 # Concrete source-only DTO candidates use existing protected identities, never storage-derived IDs.
 candidates=[];profiles=[]
 for key,q in sorted(quests.items()):
  metadata={'schema':'PROTECTED_QUEST_AUTHORING_SOURCE_CANDIDATE/v1','source_only':True,'runtime_eligible':False,'authoring_definition_sha256':sha(canonical(q)),
   'protected_authoring_revision':snapshot['revision'],'protected_snapshot_sha256':sha(canonical(snapshot)),
   'native_progress_binding':None,'native_transition_binding':None,'source_readiness_promoted':False,
   'source_artifact':'quest-reuse/protected-quest-authoring.json.gz','schema_validation_owner':'EXISTING_QUEST_WORKER_NOT_THIS_LINKER'}
  field={'field_path':'oteryn:source.quest.protected_authoring_reference','value':{'type':'Text','value':canonical(metadata).decode()}}
  candidates.append({'kind':'Quest','identity':q['identity'],'fields':[field]})
  profiles.append({'target':{'family':'Quest',**q['identity']},'data':{'kind':'Quest','profile':{'fields':[field]}}})
 TEMP.mkdir(exist_ok=True)
 table=b''.join(canonical(r)+b'\n'for r in records);(TEMP/'source-authoring-links.jsonl.gz').write_bytes(gzip.compress(table,mtime=0))
 patch={'declarations':candidates,'authoring_profiles':profiles,'applied':False,'runtime_eligible':False};(TEMP/'quest-authoring-candidate-patch.json').write_bytes(canonical(patch))
 ready=sum(bool(r['npc_target']) and r['source_qualification'] in ('EXACT_PIN_SOURCE_BYTES','CROSS_PIN_IDENTICAL_SOURCE_BYTES_ONLY') for r in records)
 result={'status':'PASS_KNOWN_QUEST_AUTHORING_SOURCE_LINKER','protected_quests':len(quests),'source_occurrence_links':len(records),'npc_source_associations_ready':ready,'source_context_or_epoch_holds':len(records)-ready,
 'current_world_native_quest_declarations':sum(k[0]=='Quest'for k in decls),'verified_native_progress_bindings':0,'verified_native_transition_bindings':0,'runtime_eligible_links':0,
 'known_identity_quest_declaration_candidates':len(candidates),'matching_quest_authoring_profile_candidates':len(profiles),'candidate_patch_path':str(TEMP/'quest-authoring-candidate-patch.json'),
 'candidate_patch_sha256':sha(canonical(patch)),'source_links_path':str(TEMP/'source-authoring-links.jsonl.gz'),'source_links_decoded_sha256':sha(table),'input_pins':{'protected_snapshot_gzip_sha256':sha(snapshot_path.read_bytes()),'protected_snapshot_decoded_sha256':sha(canonical(snapshot)),'historical_associations_gzip_sha256':sha(old_path.read_bytes()),'repair_associations_gzip_sha256':sha(repairs_path.read_bytes()),'world_declarations_sha256':sha((world/'definitions/declarations.json').read_bytes())},'accepted_seams':NATIVE_SEAMS}
 (OUT/'manifest.json').write_bytes(canonical(result)+b'\n');print(json.dumps(result))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--world',type=pathlib.Path,default=pathlib.Path('/tmp/npc-full-plan-final-world'));p.add_argument('--bindings',type=pathlib.Path);a=p.parse_args();build(a.world,json.load(open(a.bindings))if a.bindings else None)

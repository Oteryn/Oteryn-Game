# Independent architecture and lane review

Review scope: local proposals, concrete source-data outputs and bounded tests. No product writes, full builds or runtime activation by reviewer.

The selected architecture respects real existing boundaries: World routing Transition is not a Quest outcome, source Storage is not native Progress, Spell is not Ability, existing authoring Placement can reference NPC while native actor/wire families still cannot. Automatic/free spell learning remains the accepted S16 policy; legacy trainer prices are informational.

Two material dialogue defects were found and corrected: legacy state effects were omitted by the program planner, and callback-only sources could bypass handler construction/rebinding proof. The planner now retains a distinct Legacy path; direct constructor/registration/alias/rebinding guards reject the independently reproduced bad source. Six Python compiler fixtures and eight compiled Rust planner tests passed. All 36 callback/registration anchors for 18 callbacks and 55 candidate program nodes were independently verified. Current authoring-text/state conflicts hold all 18 callbacks: zero native Dialogue updates are proposed by that data stage.

Quest linking: 352 known protected Quest declaration/profile candidates, 4,346 qualified source associations and 33 source holds. Eight Python tests pass; no native Progress or Quest transition binding is produced. Existing Quest DTO parsing proves typed source retention, not persistent progression.

Commerce: 427 existing conflict groups reconciled without price overrides; eleven fixtures pass. Optional departure_text patch is a concrete unapplied schema proposal. Travel discounts still require owned native gate linkage and a transaction decision for the source's debit-before-exhaustion sequence.

Special services: 342 candidates reference seven existing instant Spell authoring payloads but remain held for owning identity/epoch/family authority. Seven Python tests and sixteen compiled preparation/currency tests pass. Automatic learning does not charge; paid preparation fixtures are pure and do not create an accepted paid-learning transaction. The earlier library check from a reused stage is explicitly not combined root qualification.

Items: four description-only identity candidates remain AMBIGUOUS in the actual candidate resolver and UNRESOLVED for admission. Matching known item fields is not complete semantic equivalence or appearance compatibility.

Runtime: actual type probes establish authoring NPC placement support and missing native/wire NPC variants. The contract delta is concrete and useful, but remains a proposal. No integrated NPC placement, CHAT dispatch, transaction commit, persistent Quest progress or activated existing-map E2E has been qualified. Those tasks are not DONE.

Root must qualify its merged stage and any actual native data import separately. See findings.json for per-lane readiness; proposal readiness is never substituted for task completion.

Read-only merged-stage review: the added real admission/reparse test preserves ordered SetTopic/EmitReply and topic guard/consume metadata. The negative test exercises unowned outcomes and incompatible legacy flags; specific error assertions were recommended to rule out incidental rejection. No new contract defect found. Reviewer did not run Cargo or change the root-owned stage; root test result is separate.

Root strengthened the negative test with the exact role-binding and implicit legacy-state error checks and reports all 10 admission tests passing. The final test source was rechecked read-only; recommendation resolved.
